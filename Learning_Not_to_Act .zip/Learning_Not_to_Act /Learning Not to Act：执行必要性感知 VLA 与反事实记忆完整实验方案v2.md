# Learning Not to Act  
## Execution-Necessity-Aware Vision-Language-Action Learning with Counterfactual Memory

**中文题目：** 学会不行动：基于执行必要性估计与反事实记忆的视觉-语言-动作学习  
**工作简称：** ENA-VLA（Execution-Necessity-Aware VLA）  
**Benchmark：** PAB 2.0 — PAB-S + PAB-H  
**目标投稿：** CoRL / NeurIPS / ICLR  
**计划周期：** 6 个月

---

# 1. 研究核心

现有 Vision-Language-Action 模型通常学习如下映射：

$\pi(a_t\mid o_t,l$),

其中 \(o_t\) 是当前视觉观测，\(l\) 是语言指令，\(a_t\) 是机器人动作。

这种训练方式隐含了一个强假设：

> 只要语言指令被输入，机器人就应该采取动作。

然而真实部署中，语言指令通常描述的是一个**目标状态**，而不是一个无条件的动作触发器。

例如：

> “Put the bowl on the plate.”

至少存在三种情况：

1. bowl 已经在 plate 上；
2. bowl 已经靠近 plate，只需要轻微修正；
3. bowl 仍在远处，需要完整执行操作。

传统 VLA 在训练时主要看到第三类正向 demonstration，而很少看到前两种状态，因此可能学成：

$instruction\rightarrow action$

而不是：

$instruction + state \rightarrow \text{whether action is still necessary}$.

原方案已经意识到“已满足 / 部分满足 / 未满足”三类初始状态的重要性，并以冗余动作率作为核心指标。

本研究将这个问题重新定义为：

$\boxed{\text{Execution Necessity Estimation}}$

即：

> 给定语言目标和当前状态，机器人还需要进行多少干预？

---

# 2. 与 Progress Awareness 的区别

2026 年已经出现多项 progress-aware VLA 工作。PALM 通过预测 subtask progress 减少 long-horizon manipulation 中的 repeated actions、missed steps 和 premature termination；ProgressVLA 也显式估计任务进度并用于动作生成。

因此，本研究不应再声称“VLA 从未考虑任务是否完成”。

我们的研究问题必须进一步收紧。

Progress-aware 方法主要回答：

$\text{How far has the task progressed?}$

而本文回答：

$\boxed{\text{Is further physical intervention still necessary?}}$

两者尤其在以下场景产生区别：

- 任务在策略开始运行之前就已经完成；
- 任务只需要一个很小的 residual correction；
- 当前视觉状态无法判断过去某一步是否已经执行；
- 多步指令中部分步骤已经由其他 agent、人类或机器人提前完成。

因此本文研究的是：

> **execution necessity，而不仅仅是 trajectory progress。**

---

# 3. 研究假设

整个研究围绕四个假设展开。

## H1：Execution Necessity Gap

现有 VLA 在标准任务上成功率很高，但在目标已经满足的状态下仍会输出显著动作。

即：

$P(\|a_t\|>0\mid G(s_t)=1)$

显著高于理想值。

这里：

$G(s_t)=1$

表示当前环境状态已经满足语言目标。

---

## H2：Current-state information 对一部分任务已经足够

对于视觉上明确可观察的目标：

> bowl 是否已经在 plate 上；

单帧图像就可以判断是否应该停止。

因此：

$P(N_t\mid o_t,l)$

应该已经能够解决大量简单任务。

这类任务不应强行引入 memory。

---

## H3：部分 execution necessity 本质上是 history-dependent

对于部分可观测任务：

$P(N_t\mid o_t,l) \neq P(N_t\mid o_{0:t},l)$.

例如：

- 已经把物体放进抽屉，然后抽屉关闭；
- 按钮要求按三次，但当前画面无法判断已经按了几次；
- 多步骤任务当前场景无法区分“步骤 A 做过”与“步骤 A 尚未做”；
- 某个状态改变发生在遮挡区域。

此时 memory 才真正必要。

---

## H4：不是所有历史都同样有价值

对当前决策真正重要的是：

> 删除某条历史记忆后，模型的正确决策能力是否下降。

因此：

$\text{semantic similarity} \neq \text{decision usefulness}$.

MemoryVLA 已证明 temporal memory 对 long-horizon manipulation 有显著作用，而 RoboMME 进一步将机器人记忆划分为 temporal、spatial、object 和 procedural 等类别。

本文不再试图证明“机器人需要 memory”，而是进一步研究：

$\boxed{\text{Which memories are useful for deciding whether to act?}}$

---

# 4. 问题形式化

设机器人轨迹为：

$\tau=(o_0,a_0,o_1,a_1,\ldots,o_t)$.

语言目标为：

$l$.

定义 history：

$H_t=(o_0,a_0,\ldots,o_{t-1},a_{t-1})$.

---

## 4.1 Goal Satisfaction

定义目标满足程度：

$g_t\in[0,1]$.

其中：

$g_t=1$

表示目标完全满足。

但仅仅预测 goal completion 还不足以解决 partial state。

因此进一步定义：

---

# 5. Execution Necessity

定义：

$n_t\in[0,1]$,

表示为了满足目标，还需要多少物理干预。

理想情况下：

$n_t=0$

意味着无需再行动；

$0<n_t<1$

意味着只需要 residual correction；

$n_t\approx1$

意味着需要完整执行操作。

同时定义一个离散执行模式：

$z_t\in \{STOP,\,REPAIR,\,EXECUTE\}.$

对应：

| 状态 | \(z_t\) | \(n_t\) |
|---|---|---:|
| 已满足 | STOP | 0 |
| 部分满足 | REPAIR | 0–1 |
| 未满足 | EXECUTE | 接近 1 |

这样比原方案的：

$act / skip$

二分类更完整。

---

# 6. Benchmark：PAB 2.0

新的 benchmark 分成两个部分：

$\boxed{PAB=PAB\text{-}S+PAB\text{-}H}$

其中：

- PAB-S：State-observable；
- PAB-H：History-dependent。

这个区分是整个论文最重要的实验设计之一。

---

# 7. PAB-S：State-Observable Execution Necessity

PAB-S 中：

$o_t$

已经足够判断目标是否完成。

例如：

> put the bowl on the plate

三个状态：

### Satisfied

bowl 已经稳定位于 plate 上。

正确行为：

$STOP$.

### Partial

bowl 已经接触 plate 边缘，但位置不稳定。

正确行为：

$REPAIR$.

### Unsatisfied

bowl 位于远处。

正确行为：

$EXECUTE$.

---

# 8. PAB-S 任务来源

不再使用原文档中尚未确认是否真实存在的 `"wipe the table"`、`"clean the plate"` 等 conceptual task。

第一版 benchmark 只使用 LIBERO 官方实际存在的任务。

LIBERO 官方任务表中已经包含：

- `open_the_middle_drawer_of_the_cabinet`
- `put_the_bowl_on_the_stove`
- `put_the_wine_bottle_on_top_of_the_cabinet`
- `open_the_top_drawer_and_put_the_bowl_inside`
- `turn_on_the_stove`
- `put_the_bowl_on_the_plate`
- `put_the_wine_bottle_on_the_rack`
- 多种 `pick_up ... and place ...` 任务。
w
PAB-S v1 建议首先选择 8 个 task family。

例如：

| ID | 基础任务 | Satisfied | Partial | Unsatisfied |
|---|---|---|---|---|
| S1 | Bowl → plate | 已在 plate 中央 | plate 边缘 | 桌上 |
| S2 | Bowl → stove | 已在 stove | 靠近 stove | 远处 |
| S3 | Bottle → rack | 已在 rack | rack 边缘 | 桌面 |
| S4 | Object → basket | 已在 basket | basket 边缘 | 桌上 |
| S5 | Open drawer | 完全打开 | 半开 | 关闭 |
| S6 | Turn on stove | 已打开 | 临界位置 | 关闭 |
| S7 | Bowl → cabinet | 已放入 | 柜门口 | 桌上 |
| S8 | Bottle → cabinet top | 已放置 | 偏离目标 | 桌面 |

---

# 9. PAB-S 状态构造

每个 task family 构造三类初始状态。

## 9.1 Satisfied

优先使用：

### 方法 A：成功轨迹终态

从成功 demonstration 的最后稳定状态截取。

### 方法 B：环境 state editing

直接修改：

- object pose；
- drawer joint；
- stove joint；
- receptacle relation。

---

## 9.2 Partial

Partial 不再简单定义为：

> “目标位置偏 5 cm”。

而应该根据 task-specific residual distance 构造多个难度。

例如：

$d=2,5,10\text{ cm}$.

形成：

$n_t$

的连续监督。

---

## 9.3 Unsatisfied

使用：

- 官方 initial state；
- 随机合理扰动；
- OOD spatial positions。

---

# 10. PAB-H：History-Dependent Execution Necessity

PAB-H 是论文真正体现 memory 必要性的部分。

核心原则：

> 尽量构造当前 observation 非常相似，但正确行为不同的状态。

即：

$o_t^A\approx o_t^B$

但：

$z_t^A\neq z_t^B$.

---

# 11. PAB-H 四类任务

## H1：Occluded Completion

例：

> put the bowl into the drawer and close it.

两条历史：

### History A

机器人已经：

$pick\rightarrow place\rightarrow close$.

### History B

机器人只：

$close$.

最终 drawer 都是关闭的。

当前 RGB 中 bowl 不一定可见。

机器人必须根据历史判断：

> bowl 是否已经放进去。

---

## H2：Repetition / Counting

任务：

> press / turn / manipulate object \(N\) times.

当前视觉状态在每次操作后高度相似。

正确行为依赖：

$count(H_t)$.

例如：

$2/3$

次时应该继续，

$3/3$

时应该 STOP。

这一类型与 RoboMME 中强调的 counting/history-dependent memory 问题天然兼容。

---

## H3：Stage-Ambiguous Long-Horizon Tasks

使用 LIBERO-10 中已有 multi-step task，例如：

> turn on the stove and put the moka pot on it.

构造两个当前视觉相似但 history 不同的状态：

$H_A:\text{stove 已操作}$

以及：

$H_B:\text{stove 尚未操作}$.

要求模型判断下一步是否仍需执行第一个 subgoal。

---

## H4：Hidden Object / Object Permanence

物体执行 manipulation 后被：

- drawer；
- microwave；
- container；
- camera occlusion

遮挡。

当前帧无法完整确定 object state。

正确判断依赖过去：

$(o_{t-k},a_{t-k})$.

---

# 12. Benchmark 规模

最终 PAB 2.0：

### PAB-S

8 task families × 3 states。

共：

$24$

种配置。

### PAB-H

8 task families × 3 history/state conditions。

共：

$24$

种配置。

最终：

$48$

个 benchmark configurations。

每个配置：

$20$

个固定随机 seed。

总评估：

$960$

episodes / model。

主实验至少重复：

$3$

个 training seeds。

---

# 13. 模型整体结构

ENA-VLA 由三个部分组成：

$\boxed{VLA Backbone+Execution Necessity Head+Selective Memory}$

Backbone 第一版采用：

**OpenVLA-OFT**。

OpenVLA-OFT 官方已经提供针对：

- LIBERO-Spatial；
- LIBERO-Object；
- LIBERO-Goal；
- LIBERO-10；

以及四 suite 联合训练的 checkpoint，其官方联合模型在原始 LIBERO 四 suite 上报告约 96.8% 平均 success rate，因此非常适合作为能力较强的 backbone，而不是故意选择弱模型制造 failure。

---

# 14. 模块一：Execution Necessity Head

当前 observation 与 instruction 编码为：

$h_t=f_\theta(o_t,l)$.

Execution Necessity Head 输出：

$p(z_t\mid h_t)$

以及：

$\hat n_t$.

即：

### classification output

$STOP / REPAIR / EXECUTE$

### regression output

$\hat n_t\in[0,1]$.

结构建议：

$h_t\rightarrow MLP(1024)\rightarrow MLP(512)$.

然后分两个 head：

$Head_{mode}$

和：

$Head_{necessity}$.

---

# 15. 推理逻辑

如果：

$P(STOP)>\theta_s$,

则返回：

$STOP.$

而不是普通 action vector。

Benchmark 中 STOP 解释为：

- 保持当前位置；
- 不改变 gripper；
- episode 进入 termination check。

如果：

$z_t=REPAIR$

或者：

$EXECUTE$,

则调用原 VLA action expert。

第一版不强行通过：

$a_t\leftarrow n_ta_t$

缩放动作，因为 translation、rotation 与 gripper action 的物理含义不同。

Partial-state behavior 通过 partial demonstration fine-tuning 学习。

---

# 16. Training Labels

## 16.1 Mode label

$y_z\in\{STOP,REPAIR,EXECUTE\}$.

由 simulator state predicate 自动生成。

---

## 16.2 Necessity label

定义 expert residual cost：

$D(s_t,l)$.

并归一化：

$n_t=\frac{D(s_t,l)}{D(s_{init},l)+\epsilon}$.

在不同任务中 \(D\) 可以是：

### placement

object-target distance；

### drawer

joint angle residual；

### switch

joint state residual；

### multi-step

remaining subgoal fraction；

### trajectory

expert remaining horizon。

所以 \(n_t\) 不需要依赖主观 VLM label。

---

# 17. 为什么不再把 VLM 标注作为主要 ground truth

原方案计划混合：

- trajectory truncation；
- VLM labeling；
- self-exploration。

新版中：

### simulator ground truth

作为主标签。

### VLM labeling

只用于：

- 模糊任务；
- real-world annotation；
- semantic generalization。

这样避免把 VLM bias 引入 benchmark ground truth。

---

# 18. 模块二：Selective Counterfactual Memory

Memory 只在 PAB-H 中应当带来明显收益。

设当前 query：

$q_t=(o_t,l)$.

Memory bank：

$M_t=\{m_1,\ldots,m_N\}$.

每个 memory item：

$m_i=(e_i^v,e_i^l,a_i,t_i)$.

其中包括：

- visual embedding；
- language/task embedding；
- action；
- timestamp；
- optional state/event information。

---

# 19. “Causal Memory”的重新定义

原方案定义：

$d(\pi(M),\pi(M\setminus m))$

作为 causal contribution。

但这只能测量：

> memory 是否影响决策。

一个错误 memory 也可能产生很大的 output change。

所以新版定义为：

$\boxed{C(m;q,y)=\mathcal L(\pi(q,M\setminus m),y)-\mathcal L(\pi(q,M),y)}$


其中：

$y$

是真实 Execution Necessity label。

---

# 20. Counterfactual Utility 的解释

如果：

$C(m)>0$,

删除 memory 后性能变差。

因此它是：

$helpful\ memory$.

如果：

$C(m)\approx0$,

则是：

$irrelevant\ memory$.

如果：

$C(m)<0$,

则说明删除 memory 后反而更好。

这是：

$harmful\ memory$.

这个定义比：

$\|\pi(M)-\pi(M\setminus m)\|$

更有意义。

---

# 21. Offline Counterfactual Probing

训练阶段，对 memory candidate 做 leave-one-out：

$M\rightarrow M\setminus m_i$.

分别计算：

$L_{full}$

与：

$L_{-i}$.

标签：

$C_i=L_{-i}-L_{full}$.

不需要遍历所有 memory。

每个 query 采样：

$K_{probe}=8\sim32$

个 candidate。

---

# 22. Query-Conditioned Memory Scorer

非常关键的一点：

不能学习：

$C(m)$.

而必须学习：

$\boxed{C(m;q)}$

因为同一条 memory：

> “drawer 已打开”

对“put bowl in drawer”非常重要，

但对：

> “put wine bottle on rack”

可能完全无关。

因此 scorer 输入：

$[q,m,q\odot m,|q-m|]$.

使用：

- small Transformer；
- cross-attention；
- 或 3-layer MLP。

输出：

$\hat C(m;q)$.

---

# 23. Memory Scorer Loss

同时使用 regression 与 ranking。

$L_{mem}=L_{reg}+\lambda_rL_{rank}$.

Regression：

$L_{reg}=SmoothL1(\hat C,C)$.

Ranking：

若：

$C_i>C_j$,

要求：

$\hat C_i>\hat C_j$.

这样 retrieval 目标直接对应：

> 哪条 memory 对当前 decision 更有帮助。

---

# 24. Candidate Retrieval

新版明确取消：

> CLIP top-100 → causal rerank

作为唯一 candidate 路径。

因为这与：

> “不相似但有决策价值的 memory”

这一研究假设矛盾。

候选集合改成：

$M_c=M_{semantic}\cup M_{recent}\cup M_{event}\cup M_{diverse}$.

其中：

### Semantic

embedding nearest neighbors；

### Recent

最近 \(K_r\) 帧；

### Event

动作边界、subgoal transition、object-state change keyframes；

### Diverse

diversity / reservoir sampling。

最后统一计算：

$\hat C(m;q)$.

取：

$TopK_C$.

---

# 25. Memory Fusion

检索：

$m_1,\ldots,m_K$

后，通过：

$CrossAttention(q,M_K)$

得到：

$h^{mem}_t$.

Execution Necessity Head 输入：

$[h_t,h^{mem}_t]$.

于是：

$p(z_t\mid o_t,l,M_t)$.

这是真正实现：

> history 帮助判断“现在还需不需要行动”。

---

# 26. Memory Forgetting

Forgetting 在首篇论文中作为 secondary contribution，而不是主线。

对 memory 维护：

$S_i=EMA_q[\max(C(m_i;q),0)]$.

同时记录：

$H_i=EMA_q[\max(-C(m_i;q),0)]$.

定义 retention score：

$R_i=S_i-\lambda_hH_i+\lambda_rRecency_i$.

Memory bank 超预算时：

$\arg\min_i R_i$

优先被删除。

这比原来的：

> contribution 越低越删除

多考虑了：

**harmful memory。**

---

# 27. 整体训练 Loss

模型总损失：

$L=L_{action}+\lambda_1L_{mode}+\lambda_2L_{necessity}+\lambda_3L_{memory}$.

---

## Mode Loss

$L_{mode}=CE(\hat z,z)$.

---

## Necessity Loss

$L_{necessity}=Huber(\hat n,n)$.

---

## Action Loss

只在：

$z\neq STOP$

时计算：

$L_{action}$.

这保留原方案“不要让 STOP 样本学习假动作”的优点。

---

# 28. Training Stages

训练采用四阶段。

## Stage A：Backbone sanity check

直接使用官方：

`moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10`

先复现原始 LIBERO。

目标不是达到论文 reported number 的最后 0.1%，而是确认：

$SR_{original}\ge90\%$.

---

## Stage B：State-only ENA

冻结大部分 VLA backbone。

只训练：

- Execution Necessity Head；
- 必要 projection layer。

首先在：

$PAB-S$

验证。

---

## Stage C：Memory Scorer

在：

$PAB-H$

构造 history。

执行 offline counterfactual probing。

得到：

$(q,m,C)$

dataset。

训练：

$\hat C(q,m)$.

---

## Stage D：Unified ENA-VLA

加入：

- memory retrieval；
- cross-attention；
- execution necessity head。

冻结主要 action backbone。

训练：

- memory fusion；
- EN head；
- optional LoRA。

---

# 29. Baselines

主实验至少包括以下 baseline。

## B0：OpenVLA-OFT

无 execution reasoning。

---

## B1：VLM-as-Judge

当前 RGB + instruction 输入 VLM：

> Has the task already been completed?

YES：

$STOP$.

---

## B2：State-only ENA

$(o_t,l)\rightarrow z_t,n_t$.

这是最重要 baseline。

它回答：

> memory 到底有没有必要。

---

## B3：Progress Regression

预测：

$progress\in[0,1]$.

以 normalized remaining trajectory length 训练。

用于与 PALM / ProgressVLA 类思想进行机制对照，而不必完整复现不同 backbone。Progress-aware VLA 已经成为 2026 年明确的研究方向。

---

## B4：Fixed Recent History

直接输入最近：

$N$

帧。

无 retrieval。

---

## B5：Similarity Memory

CLIP/VLA embedding cosine retrieval。

---

## B6：Recency Memory

只取最近 \(K\) 个 event。

---

## B7：Random / Diverse Memory

用于判断 memory gain 是否只是增加 context。

---

## B8：Counterfactual Memory

本文方法。

---

## B9：Oracle Memory

直接用 simulator ground truth 找到真正相关的历史。

这是 memory upper bound。

---

# 30. 不再把 TD-error 作为主要 baseline

原方案使用 prioritized replay / TD-error。

但这里主要是 imitation-learning VLA。

TD-error 并不是最自然的 retrieval baseline。

因此改成更有说服力的：

- similarity；
- recency；
- attention；
- fixed history；
- random；
- oracle。

---

# 31. 主实验 E1：现有 VLA 是否知道“不应该行动”

模型：

OpenVLA-OFT。

数据：

PAB-S。

测量：

$UER$

Unnecessary Execution Rate。

定义：

$UER=P(\text{significant intervention}\mid z=STOP)$.

---

# 32. E1 额外测量

不能只统计 action vector 是否非零。

新增：

### Goal Disturbance Rate

$GDR=P(G(s_{final})<G(s_0)\mid G(s_0)=1)$.

即：

> 本来已经成功，机器人反而把它弄坏了多少次。

这是非常有表现力的指标。

---

# 33. 主实验 E2：Execution Necessity Learning

比较：

- OpenVLA-OFT；
- VLM Judge；
- Progress；
- ENA。

分别测试：

### STOP

### REPAIR

### EXECUTE。

核心结果表：

| Model | STOP Acc | REPAIR Acc | EXECUTE Acc | UER ↓ | FSR ↓ | SR ↑ |
|---|---:|---:|---:|---:|---:|---:|

---

# 34. False Stop Rate

定义：

$FSR=P(STOP\mid z\neq STOP)$.

这是非常重要的安全指标。

不能只追求：

$UER\downarrow$.

因为一个永远不动作的模型：

$UER=0$.

但没有意义。

因此论文的目标是：

$UER\downarrow$

同时：

$FSR\downarrow$.

---

# 35. 主实验 E3：Memory 到底什么时候需要

分别在：

$PAB-S$

和：

$PAB-H$

测试：

### State-only

与：

### State + Memory。

理想结果应该是：

$\Delta_{memory}^{PAB-S}\approx0$

而：

$\Delta_{memory}^{PAB-H}>0$.

这是整篇论文最重要的 mechanism result。

因为它证明：

> 我们不是强行给所有任务塞 memory。

而是：

> memory 在 history-dependent execution necessity 中才真正必要。

---

# 36. 主实验 E4：Counterfactual Memory 是否优于 Similarity

测试：

- Recent；
- Random；
- Similarity；
- Attention；
- Counterfactual；
- Oracle。

主要指标：

### Useful@K

$\frac{\#\{m\in TopK:C(m)>0\}}{K}$

### Harmful@K

$\frac{\#\{m\in TopK:C(m)<0\}}{K}$

### Decision Accuracy

最终：
$STOP/REPAIR/EXECUTE$

准确率。

---

# 37. Similarity Trap

保留原方案这个很好的思想，但重新定义。

构造：

### Similar but useless

画面/任务语义很像，但与当前 completion 无关。

### Dissimilar but useful

画面不同，但包含决定当前任务是否完成的关键事件。

比较：

$Rank_{sim}$

与：

$Rank_{cf}$.

这部分不再试图抽象证明“相似 ≠ 因果”，而是直接证明：

> decision utility ranking 与 semantic similarity ranking 不等价。

---

# 38. Ablation

完整方法：

$ENA+CFMemory$.

消融：

### A1

去掉 Execution Necessity Head。

### A2

只预测 binary STOP/ACT。

证明 REPAIR 类是否必要。

### A3

去掉 scalar \(n_t\)。

### A4

去掉 memory。

### A5

memory 换成 recent frames。

### A6

memory 换成 cosine retrieval。

### A7

scorer 改为：

$C=|\Delta action|$

而不是 utility-aware：

$\Delta loss$.

这一项尤其重要，因为它直接证明新版 causal utility 定义的价值。

### A8

候选只使用 similarity top-K。

证明 candidate union 的必要性。

### A9

去掉 negative/harmful memory。

---

# 39. Generalization Experiments

至少做四种。

## G1：Unseen Objects

训练：

- bowl；
- bottle。

测试：

- mug；
- box。

---

## G2：Language Paraphrase

训练：

> put the bowl on the plate

测试：

> place the bowl onto the plate

或：

> the bowl should already be on the plate.

---

## G3：New Spatial Configuration

改变：

- camera；
- target position；
- distractors；
- object initial position。

---

## G4：Memory Distractors

真实 history：

$H_{useful}$

中人为加入：

$N$

条无关 memory。

测试：

$N=0,8,32,128$.

观察 memory 方法随 noise 增加的 degradation。

这一实验会非常适合展示 counterfactual retrieval 的价值。

---

# 40. 评估指标

最终指标分五组。

## A. Task Performance

$Task\ Success\ Rate$

---

## B. Execution Necessity

### Mode Accuracy

### Macro-F1

### Necessity MAE

$|\hat n-n|$

---

## C. Unnecessary Action

### UER

Unnecessary Execution Rate。

### GDR

Goal Disturbance Rate。

### Post-Completion Action Steps

目标已满足后仍动作的 step 数。

### Cumulative Intervention

$CI=\sum_t\|Wa_t\|$.

其中：

$W$

对 translation / rotation / gripper 分别 normalization。

---

## D. False Refusal

### FSR

False Stop Rate。

### Premature Stop Rate

partial 状态过早 STOP。

---

## E. Memory

### Useful@K

### Harmful@K

### Retrieval Recall

### Memory Gain

$MG=Acc_{memory}-Acc_{state-only}$.

---

# 41. Calibration

STOP 是一个高风险决策，因此加入：

### ECE

Expected Calibration Error。

### Brier Score。

然后画：

$P(STOP)$

与实际 completion probability 的 reliability diagram。

这样阈值：

$\theta_s$

可以从 validation set 确定，而不是拍脑袋。

---

# 42. Statistical Protocol

所有 benchmark model 使用相同 initial states 和 random seeds。

主要结果：

$3$

个 training seeds。

每个 benchmark condition：

$20\sim50$

episodes。

报告：

$mean\pm95\%\ CI$.

Episode-level 指标使用 bootstrap confidence interval。

模型间采用 paired initial-state evaluation。

---

# 43. Real-Robot Experiments

真机不需要复制所有 PAB。

选择 4 个任务。

---

## R1：Visible placement

> Put the cup on the tray.

三状态：

- 已在 tray；
- tray 边缘；
- 桌面。

---

## R2：Drawer

> Open the drawer.

状态：

- open；
- half-open；
- closed。

---

## R3：Occluded completion

> Put the object inside the drawer and close it.

测试：

历史可见，

但当前 drawer 已关闭。

---

## R4：History/count task

例如：

> Press the button three times.

测试是否知道已经：

$0/3,2/3,3/3$.

---

# 44. 真机评估规模

每个任务：

$3$

conditions。

每 condition：

$15\sim20$

trials。

约：

$180\sim240$

episodes。

核心只比较：

- vanilla VLA；
- state-only ENA；
- ENA + CFMemory。

---

# 45. 真机最重要的展示视频

论文视频需要重点展示三组 case。

### Case 1

任务已经完成。

Vanilla：

> 仍然抓取。

ENA：

> STOP。

### Case 2

部分完成。

Vanilla：

> 完整重做。

ENA：

> residual correction。

### Case 3

当前画面相同，但历史不同。

State-only：

> 无法区分。

Memory：

> 根据历史作出不同决策。

第三组 case 会是整个 paper 最有说服力的视频。

---

# 46. M1：第一月执行方案

新版 M1 最大变化是：

> **先验证 phenomenon，再大规模造 benchmark。**

原计划直到完成大量 PAB 工程后才在 W4 做 go/no-go。

新版提前。

---

# 47. M1-W1：Backbone + Mini-PAB

第一周完成：

### Day 1–2

复现 OpenVLA-OFT 官方 evaluation。

官方推荐基于其现有 LIBERO eval scripts 和对应 checkpoint 开始。

### Day 3

选择 4 个官方 task：

- bowl → plate；
- object → basket；
- open drawer；
- bowl → stove。

### Day 4

每个任务构造：

- satisfied；
- unsatisfied。

### Day 5

每 condition：

$20$

episodes。

---

# 48. 第一个 Go / No-Go

计算：

$UER$.

### Case A

$UER>50\%$.

说明 failure 强。

立即继续。

### Case B

$20\%<UER<50\%$.

问题仍然存在。

重点转向：

- partial；
- PAB-H。

### Case C

$UER<20\%$.

不能立即 NO-GO。

继续测试：

- partial state；
- PAB-H。

只有：

$PAB-S$

和：

$PAB-H$

均表现良好时才真正放弃主问题。

---

# 49. M1-W2

扩展到：

$8$

个 PAB-S task families。

完成：

- state constructor；
- predicate；
- label generator；
- evaluator。

---

# 50. M1-W3

构造：

$2\sim4$

个 PAB-H prototype。

重点验证：

$StateOnly$

是否真的失败。

如果：

$Acc_{state-only}\approx Acc_{history}$

说明 history task 设计得不够 ambiguous。

必须重做 benchmark，而不是急着开发 memory model。

---

# 51. M1-W4

冻结：

**PAB 2.0 v0 protocol。**

得到：

- OpenVLA-OFT baseline；
- PAB-S result；
- PAB-H preliminary result；
- failure videos；
- first plot。

M1 成功标准：

$UER_{vanilla}\ge20\%$

或者：

$MemoryGap_{PAB-H}\ge10\%$.

两者至少满足一个。

---

# 52. M2：Execution Necessity

M2 只做：

$State-only\ ENA$.

不要提前开发复杂 memory。

Week 1：

dataset builder。

Week 2：

mode head。

Week 3：

continuous necessity head。

Week 4：

完整 PAB-S evaluation。

目标：

$UER\downarrow$

且：

$FSR\le10\%$.

同时：

$SR_{ENA}\ge0.95SR_{OFT}$.

---

# 53. M3：Counterfactual Memory

Week 1：

完成 PAB-H 8 task families。

Week 2：

实现 memory candidate pool。

Week 3：

offline counterfactual probing。

Week 4：

训练：

$\hat C(q,m)$.

M3 成功标准：

$$
Useful@K_{CF}
>
Useful@K_{Similarity}.
$$

并且：
$$
Acc_{PAB-H}^{CF}
-
Acc_{PAB-H}^{state}
\ge10\%.
$$

---

# 54. M4：Unified Model

整合：

$$
ENA
+
CFMemory.
$$

运行：

- main table；
- ablation；
- similarity trap；
- memory distractor；
- threshold calibration。

M4 末必须已经能够形成论文核心三张图。

---

# 55. M5：Generalization + Real Robot

前两周：

- unseen objects；
- language paraphrase；
- distractor history；
- OOD scenes。

后两周：

real robot。

若真机工程拖慢，不允许影响主论文。

真机属于：

**enhancement**，

不是 paper viability 的唯一条件。

---

# 56. M6：Paper

Week 1：

全部结果 freeze。

Week 2：

paper first draft。

Week 3：

补 reviewer-style ablation。

Week 4：

polish + release。

---

# 57. 算力需求

由于 backbone 大部分时间冻结，本项目没有必要重新训练 7B VLA。

主要成本：

### OpenVLA-OFT evaluation

1×A100/H100。

### EN head

1×A100 足够。

### Counterfactual probing

适合：

$4\sim8$

GPU 并行。

### Unified LoRA

约：

$2\sim4$

张 A100。

因此真正算力瓶颈不是 training，而是：

$counterfactual\ evaluation$.

---

# 58. Engineering Structure

建议目录：

```text
learning_not_to_act/
│
├── configs/
│   ├── pab_s.yaml
│   ├── pab_h.yaml
│   ├── ena.yaml
│   └── memory.yaml
│
├── benchmark/
│   ├── task_registry.py
│   ├── state_builder.py
│   ├── history_builder.py
│   ├── predicates.py
│   └── evaluator.py
│
├── models/
│   ├── execution_head.py
│   ├── necessity_head.py
│   ├── memory_bank.py
│   ├── candidate_retriever.py
│   ├── counterfactual_scorer.py
│   └── ena_vla.py
│
├── counterfactual/
│   ├── probe.py
│   ├── label_builder.py
│   └── train_scorer.py
│
├── eval/
│   ├── eval_pab_s.py
│   ├── eval_pab_h.py
│   ├── eval_memory.py
│   └── metrics.py
│
└── results/
```

---

# 59. 核心风险

## Risk 1：Vanilla VLA 已经会 STOP

解决：

不要只测试简单 satisfied state。

继续测试：

- partial；
- history-dependent；
- distractor；
- long-horizon。

---

## Risk 2：State-only ENA 已经解决所有问题

这不是坏结果。

它说明：

> 当前 observable completion 根本不需要复杂 memory。

论文变成：

> execution necessity benchmark + lightweight ENA。

然后 memory 部分只保留真正 history-dependent task。

---

## Risk 3：Memory 没有提升

首先检查：

$PAB-H$

是否真的满足：
$$
P(z|o_t,H_t)
\neq
P(z|o_t).
$$
如果 state-only classifier 也能预测，说明 benchmark 有 visual shortcut。

---

## Risk 4：Counterfactual scorer 只是另一种 retrieval score

解决方式不是强调“causal”这个词。

而是实验证明：

$$
C(m;q)>0,\;=0,\;<0
$$

分别对应：

- helpful；
- irrelevant；
- harmful memory。

然后展示删除这些 memory 后 decision loss 的真实变化。

---

## Risk 5：两个 story 又重新变成两篇论文

必须始终坚持：

**主问题只有一个：**

$$
\boxed{
When should the robot act?
}
$$

Memory 只是：

> 当 current state 不足以回答这个问题时需要的机制。

---

# 60. 论文最终贡献

最终 paper 不建议写六七条贡献。

只保留三条。

## Contribution 1：Problem + Benchmark

提出：

$$
Execution\ Necessity
$$

作为 VLA 的一个独立能力，并构建：

$$PAB-S/PAB-H.$$

---

## Contribution 2：Execution-Necessity-Aware VLA

提出：

$$
STOP / REPAIR / EXECUTE
$$

以及 continuous residual necessity estimation。

证明能够减少：

- redundant execution；
- goal disturbance；

同时避免：

- false stopping。

---

## Contribution 3：Selective Counterfactual Memory

在 history-dependent tasks 中定义 query-conditioned decision utility：

$$
C(m;q)
$$

并证明：

> 当前状态可观察时 memory 基本无益，而 history-dependent execution necessity 中 selective memory 显著有效。

这是我认为最漂亮的贡献。

---

# 61. 最理想的主结果

如果最终得到如下结果：

| Model | PAB-S | PAB-H |
|---|---:|---:|
| OpenVLA-OFT | 差 | 差 |
| ENA State-only | **很好** | 一般 |
| ENA + Recent History | 很好 | 较好 |
| ENA + Similarity Memory | 很好 | 较好 |
| ENA + CF Memory | 很好 | **最好** |

整个故事就完整了。

它说明：

第一：

> VLA 的问题不是“不会操作”。

第二：

> 它缺乏明确的 execution necessity 判断。

第三：

> 对于 observable task，当前视觉已经足够。

第四：

> 对 history-dependent task，memory 真正必要。

第五：

> memory 的价值不在“记得越多”，而在“记得对当前决定真正有帮助的历史”。

---

# 62. 推荐论文标题

首选：

**Learning Not to Act: Execution-Necessity-Aware Vision-Language-Action Learning with Counterfactual Memory**

更简洁版本：

**Learning Not to Act: When Should Vision-Language-Action Models Stop, Repair, or Execute?**

如果后期 memory 结果非常强：

**Learning Not to Act: Execution Necessity and Selective Memory in Vision-Language-Action Models**

如果最终 memory 并没有成为主要贡献：

**Learning Not to Act: Teaching Vision-Language-Action Models When Action Is Unnecessary**

---

# 63. 最终研究主线

整篇论文从头到尾只回答一个问题：

$$
\boxed{
\textbf{Does the robot still need to act?}
}
$$

第一层：

$$
Current\ State
$$

能不能回答？

第二层：

如果不能：

$$
History
$$

是否能够回答？

第三层：

如果历史很长：

$$
Which\ memories
$$

真正值得用于这个判断？

于是整个逻辑链成为：

$$
\boxed{
Goal\ State
\rightarrow
Execution\ Necessity
\rightarrow
History\ Dependence
\rightarrow
Selective\ Memory
}
$$

而不再是原方案里的：

$$
Precondition\ Head
+
Causal\ Memory.
$$

这应该作为接下来所有 benchmark、模型、实验和论文写作的统一原则。