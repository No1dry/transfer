# Learning Not to Act：下一阶段验证与执行方案
## 从 Terminal Failure 到 Intermediate Execution Necessity

> 项目：Learning Not to Act / ENA-VLA  
> 阶段：Mini-PAB 之后的机制验证与 benchmark 重构  
> 目标：把 execution necessity failure 与 spatial generalization、terminal-state 无监督、系统级 action gating 三类混淆因素彻底分离  
> 推荐后端：OpenVLA-OFT + LIBERO  
> 文档用途：下一阶段实验执行与结果判定

---

# 1. 当前结论

Mini-PAB 已经证明以下现象真实存在：

1. OpenVLA-OFT 在正常 unsatisfied 条件下具有较高任务成功率；
2. 在目标已经满足时，模型仍然会产生大量显著动作；
3. satisfied 条件下的末端运动量与正常执行相近，但对物体几乎没有有效作用；
4. 场景编辑版 satisfied 会放大 failure，因此不能把 UER=100% 直接解释成纯 execution-necessity failure；
5. 自然 terminal-state 下仍观察到明显多余动作，说明现象并非完全由人工场景编辑造成；
6. 物体大幅移位时，模型会受到明显 spatial prior 影响；
7. 但 `put bowl on plate` 的部分现象提示：模型并非简单 replay 固定坐标，它在较小 spatial shift 下很可能仍有视觉 grounding。

因此当前最重要的研究任务不再是：

> “继续证明目标完成后模型还会动。”

而是进一步回答：

> **这些动作到底来自哪里？模型是否看到了目标？是否隐式判断了完成状态？还是 action pipeline / controller 在 success 后改变了行为？**

---

# 2. 当前需要区分的三个假设

## H1：Fixed / Prior-Dominated Motion

模型主要依赖训练期间形成的 spatial/action prior。

表现为：

- 物体移位后仍朝旧位置伸手；
- 抓取动作不能适应较大位置变化；
- satisfied failure 主要是 spatial OOD 的副作用。

形式上：

$$
a_t \approx \pi(l,\text{training prior})
$$

而不是充分依赖：

$$
a_t \approx \pi(o_t,l).
$$

## H2：Visual Grounding Exists, but Execution Necessity Is Missing

模型能够根据图像定位目标物体：

$$
o_t \rightarrow p_{\text{object}},
$$

但并不会显式判断：

$$
G(s_t)=1 \Rightarrow \mathrm{STOP}.
$$

典型表现：

- 机械臂确实朝当前 bowl 位置伸过去；
- 不是朝训练旧坐标；
- 但到达目标附近后出现悬停、游移、不闭合夹爪或其他无效动作。

核心解释：

> 模型知道“东西在哪里”，但不知道“现在还应不应该继续执行”。

## H3：Implicit Completion Awareness without an Explicit STOP Mechanism

模型可能已经隐式感知：

$$
G(s_t)=1,
$$

但连续动作策略本身没有显式：

$$
\mathrm{STOP}
$$

或：

$$
\mathrm{SKIP}
$$

决策接口。

于是出现：

- 机械臂靠近目标；
- 到达抓取阶段却不闭合；
- 或后续动作进入低效游移；
- 整个 episode 又不会自然终止。

如果 H3 成立，论文的核心动机可以升级为：

> **The policy may implicitly perceive goal completion, yet lacks an explicit mechanism to convert that perception into an execution-level STOP decision.**

---

# 3. 为什么不能只依赖 Terminal-State 实验

Terminal-state 实验仍然重要，但它存在天然反驳：

> Behavior cloning 的 demonstration 在任务成功处结束，因此模型从未被监督“任务完成后应该输出什么”。

所以：

$$
\text{terminal failure}
$$

始终可能被解释为：

$$
\text{post-demonstration extrapolation}.
$$

这不是说 terminal experiment 没有意义，而是：

> terminal experiment 只能作为现象验证和 control，不能单独承担 execution necessity 的核心因果证据。

---

# 4. 新的实验层级

后续实验按以下四层推进：

$$
\boxed{
\text{Terminal}
\rightarrow
\text{Intermediate}
\rightarrow
\text{Matched Pair}
\rightarrow
\text{History-dependent}
}
$$

对应：

1. **Terminal Replay**
2. **Intermediate Completed-Subgoal**
3. **Matched Satisfied / Near-Satisfied Pair**
4. **PAB-H**

同时加入两组机制诊断：

5. **Action Causality Trace**
6. **Spatial Displacement Sweep**

---

# 5. Experiment A：Action Causality Trace

## 5.1 目的

首先排除一个非常关键的系统级替代解释：

> “机械臂到 bowl 附近不闭合夹爪，并不是模型不想抓，而是 success 后 runner / controller / environment 阻止了夹爪动作。”

必须区分整个 action pipeline：

$$
\text{Model}
\rightarrow
\text{Postprocess}
\rightarrow
\text{Controller}
\rightarrow
\text{Physics}.
$$

## 5.2 实验对象

优先使用：

```text
put_the_bowl_on_the_plate
```

选择：

```text
5–10 个 satisfied episodes
```

要求这些 episode 满足：

- 机械臂明显朝当前 bowl 位置靠近；
- bowl 已经在 plate 上；
- 最终没有实际抓起 bowl；
- 最好包含“到 bowl 附近但夹爪不闭合”的典型 case。

## 5.3 每步记录

增加 trace：

```text
step
goal_satisfied
eef_position
bowl_position
eef_to_bowl_distance
raw_gripper_action
processed_gripper_action
actuator_control
finger_joint_qpos
env_done
allow_after_done
```

重点分析：

$$
d(\mathrm{eef},\mathrm{bowl}) < 5\text{ cm}
$$

附近的窗口。

## 5.4 四种判定

### Case A：模型本身输出 OPEN

如果：

```text
raw = OPEN
processed = OPEN
controller = OPEN
```

则说明：

> 模型自己没有产生 grasp decision。

这是 policy-side behavior。

### Case B：Raw CLOSE，但 processed 变 OPEN

如果：

```text
raw = CLOSE
processed = OPEN
```

说明问题在：

```text
normalize / binarize / invert
```

等 postprocess。

这是 adapter bug，不可用于论文结论。

### Case C：Processed CLOSE，但 actuator 是 OPEN

如果：

```text
processed = CLOSE
actuator = OPEN
```

才真正支持：

> success / controller 层存在 system-level gating。

### Case D：Actuator CLOSE，但 finger 不动

如果：

```text
processed = CLOSE
actuator = CLOSE
finger_qpos 不变化
```

问题属于：

- controller；
- contact；
- joint limit；
- physics。

---

# 6. Experiment B：Success 后强制闭合测试

## 6.1 目的

进一步直接测试：

> goal satisfied 后，系统是否物理上禁止夹爪闭合。

## 6.2 方法

在：

```text
goal_satisfied == True
```

时绕过 VLA。

人工送入一个明确的 gripper close command。

例如在 postprocess 后的 action convention 下：

```python
action = np.zeros(7)
action[-1] = +1.0
```

前提：再次确认当前环境中：

```text
+1 = CLOSE
-1 = OPEN
```

## 6.3 判定

### 如果夹爪正常闭合

则排除：

> success predicate 自动阻止夹爪闭合。

这意味着 satisfied case 中“不闭夹爪”主要来自 policy。

### 如果夹爪无法闭合

则必须先定位：

```text
runner
controller
environment
robosuite done logic
```

在完全排除 gating 前，不能把“不闭夹爪”解释为 model behavior。

---

# 7. Experiment C：Terminal Replay

## 7.1 定位

Terminal Replay 保留，但其角色重新定义为：

```text
现象验证 + 自然状态 control
```

而不是最核心的 scientific evidence。

## 7.2 方法

从正常 unsatisfied 初态出发：

$$
s_0 \rightarrow \cdots \rightarrow s_T.
$$

要求模型自己完成任务。

在成功后：

1. 继续运行若干步；
2. 等待 release；
3. 等待机械臂进入自然 post-action pose；
4. 保存真实状态；
5. 重置到该状态；
6. 再次输入相同 instruction。

## 7.3 执行规模

至少：

```text
4 tasks × 30 seeds
```

推荐任务包含：

```text
bowl_on_plate
bowl_on_stove
object_in_basket
open_middle_drawer
```

## 7.4 指标

```text
UER
GDR
Post-completion Action Steps
Object Displacement
EEF Displacement
Gripper Close Count
```

额外记录：

```text
raw / processed gripper action
```

## 7.5 解释边界

即使 Terminal Replay 得到：

$$
UER > 50\%,
$$

论文也不能写成：

> “这证明模型不知道任务完成。”

只能写：

> “在自然完成状态下，当前 VLA 缺乏稳定的 post-completion execution policy。”

真正排除 terminal-supervision objection 的关键实验是下一项。

---

# 8. Experiment D：Intermediate Completed-Subgoal

## 8.1 这是下一阶段最关键的实验

相比 Terminal Replay，它最大的优势是：

> 状态发生在 demonstration 中间，整个任务还没有结束。

因此：

> “demo 在终态没有 next-action label”

这个反驳自然失效。

## 8.2 核心思想

选择一个多阶段任务：

$$
g_1 \rightarrow g_2 \rightarrow g_3.
$$

当：

$$
g_1
$$

已经完成，但：

$$
g_2,g_3
$$

尚未完成时，重新给模型一个只描述：

$$
g_1
$$

的 instruction。

正确行为应为：

$$
\mathrm{STOP}
$$

或：

$$
\mathrm{SKIP}.
$$

关键点：

> 当前 state 本身就是训练 demonstration 中真实出现过的中间状态。

---

# 9. Intermediate Task 设计

优先选择 LIBERO 中真实的 multi-stage task。

例如：

```text
open the top drawer and put the bowl inside
```

分解为：

```text
g1: open the top drawer
g2: pick up the bowl
g3: put the bowl inside
```

当 drawer 已经打开、bowl 尚未放进去时：

原始长任务仍未完成。

此时重新给：

```text
open the top drawer
```

正确行为是：

```text
STOP / SKIP
```

而不是再次操作 drawer。

---

# 10. 第二类 Intermediate Task

例如：

```text
turn on the stove and put the moka pot on it
```

分为：

```text
g1: turn on stove
g2: move moka pot
```

在：

```text
stove 已打开
moka pot 尚未放上去
```

时重新询问：

```text
turn on the stove
```

正确行为：

```text
STOP
```

---

# 11. Intermediate Control

每一个 completed-subgoal state 必须配一个 matched unsatisfied control。

例如：

### State A

```text
drawer already open
```

Instruction：

```text
open the drawer
```

Label：

```text
STOP
```

### State B

```text
drawer still closed
```

Instruction：

```text
open the drawer
```

Label：

```text
EXECUTE
```

尽量保证：

```text
camera
robot pose
lighting
scene layout
```

一致。

---

# 12. Intermediate 实验最关键的指标

除了 UER，还应该测：

### Re-execution Rate

$$
RER = P(\text{model re-executes completed subgoal}).
$$

### Completed-Subgoal Disturbance

$$
CSD = P(g_1\text{ 被破坏}\mid g_1\text{ 已完成}).
$$

### Skip Accuracy

$$
SA = P(\mathrm{STOP}\mid g_1=1).
$$

---

# 13. Intermediate 实验成功标准

如果：

```text
正常未完成 subgoal：模型成功率高
```

同时：

```text
已完成 subgoal：模型仍高频 re-execute
```

那么就得到比 terminal experiment 更强的结论：

> failure 不能再被“terminal 没有动作监督”解释。

---

# 14. Experiment E：Matched Satisfied / Near-Satisfied Pair

## 14.1 目的

区分：

```text
H2: visual grounding exists but no execution-necessity reasoning
```

和：

```text
H3: implicit completion awareness
```

## 14.2 核心设计

构造两个 observation 尽可能接近的状态。

### Pair A：Satisfied

```text
bowl 已经在 plate 上
```

所以：

$$
G(s_A)=1.
$$

### Pair B：Near-Satisfied

```text
bowl 在 plate 边缘 / 离 plate 很近
但还没有满足 success predicate
```

所以：

$$
G(s_B)=0.
$$

## 14.3 关键控制

尽量保证：

```text
bowl 位置非常接近
robot initial pose 一致
camera 一致
plate 一致
background 一致
```

目标是：

$$
\|o_A-o_B\|
$$

尽量小，但：

$$
G(s_A)\neq G(s_B).
$$

---

# 15. Matched Pair 的行为预测

## 如果 H1 为主

模型主要受 prior 影响。

那么 A 和 B 的行为差异很小。

## 如果 H2 为主

模型都能找到 bowl，但不知道 completion。

A 和 B 都可能尝试抓。

## 如果 H3 为主

应该看到：

### Near-satisfied

```text
approach
close gripper
repair / move bowl
```

### Satisfied

```text
approach
但明显减少 close
或者进入 non-grasp / hesitation
```

这将直接说明：

> 模型行为对 goal satisfaction state 有反应，但缺乏明确 STOP mechanism。

---

# 16. Matched Pair 的关键指标

### Grasp Decision Rate

$$
GDR_{\text{grasp}}
=
P(
\mathrm{CLOSE\ command}
\mid
 d(\mathrm{eef},\mathrm{object})<\delta
).
$$

建议：

$$
\delta=5\text{ cm}.
$$

比较：

$$
GDR_{\text{grasp}}^{sat}
$$

和：

$$
GDR_{\text{grasp}}^{near}.
$$

同时比较：

```text
approach time
minimum object distance
close command frequency
object displacement
post-approach motion
```

---

# 17. Experiment F：Spatial Displacement Sweep

## 17.1 目的

解释：

> 为什么 `bowl_on_plate` 看起来会跟随当前 bowl，而大幅 relocation 时却回到 prior position。

假设：

> 模型具有视觉 grounding，但只在训练分布附近有效；随着 displacement 增加，spatial prior 逐渐占主导。

## 17.2 位移设置

对同一任务，使用：

$$
\Delta d
=
0,
2,
5,
10,
15,
20,
25\text{ cm}.
$$

## 17.3 每个位移

建议：

```text
10–20 seeds
```

## 17.4 指标

在 grasp 前窗口中测：

### Actual-target distance

$$
d_{\text{actual}}
$$

### Prior-target distance

$$
d_{\text{prior}}
$$

定义：

$$
R_{\text{visual}}
=
d_{\text{prior}}
-
d_{\text{actual}}.
$$

如果：

$$
R_{\text{visual}}>0,
$$

说明更接近当前实际 object。

如果：

$$
R_{\text{visual}}<0,
$$

说明更靠近训练 prior。

## 17.5 预期结果

理想可能出现：

```text
0–5 cm: visual grounding dominates
10–15 cm: mixed regime
20–25 cm: training prior dominates
```

这能统一此前两个看似冲突的观察：

1. `bowl_on_plate`：会跟随当前 bowl；
2. 大幅 relocation：会朝 prior position。

---

# 18. Experiment G：Compositional Goal Relabeling

该实验保留，但放到 generalization，而不是主实验。

## 18.1 设计

对同一个 observation：

```text
bowl 已经在 plate 上
```

给不同 instruction：

```text
put the bowl on the plate
put the bowl on the stove
put the bowl in the basket
```

于是同一视觉输入分别对应：

```text
STOP
EXECUTE
EXECUTE
```

## 18.2 用途

它主要测：

$$
\text{goal-conditioned execution generalization}
$$

因此放到：

```text
Generalization / Ablation
```

部分更合理。

---

# 19. Experiment H：PAB-H Prototype

PAB-H 暂时不取代 PAB-S。

它作为下一层问题：

> 当当前状态本身不足以判断 execution necessity 时，history 是否必要？

## 19.1 第一类：Occluded Completion

例如：

```text
put bowl into drawer and close drawer
```

构造：

### History A

```text
pick bowl
place in drawer
close drawer
```

### History B

```text
close drawer
```

最终 observation 尽可能相同：

```text
drawer closed
bowl invisible
robot pose similar
```

但：

```text
A -> STOP
B -> EXECUTE
```

## 19.2 第二类：Stage Ambiguity

例如：

```text
turn on stove and put moka pot on it
```

构造视觉上相似状态，但历史上：

```text
A: stove 已经执行过
B: stove 尚未执行
```

## 19.3 第一阶段只做 Oracle History

不要立即训练 memory retrieval。

首先只比较：

```text
State-only
State + Oracle History
```

如果：

$$
Acc_{\mathrm{history}}-Acc_{\mathrm{state}}<10\%,
$$

说明 task 没有真正形成 history dependence，需要重做 benchmark。

只有 gap 明显后才进入 Counterfactual Memory。

---

# 20. 下一阶段执行顺序

严格建议按以下顺序：

```text
Step 1  Action Causality Trace
Step 2  Success 后人工 Force-Close
Step 3  扩 Terminal Replay 到更多 seeds / tasks
Step 4  Intermediate Completed-Subgoal Prototype
Step 5  Matched Satisfied / Near-Satisfied Pair
Step 6  Spatial Displacement Sweep
Step 7  PAB-H Prototype
Step 8  Compositional Goal Relabeling
```

---

# 21. 优先级

## P0：必须马上做

```text
A. Action Causality Trace
B. Force-Close
D. Intermediate Completed-Subgoal
```

这三项决定如何解释当前现象。

## P1：很重要

```text
E. Matched Pair
F. Displacement Sweep
```

它们决定：

> visual grounding、spatial prior 与 execution necessity 之间是什么关系。

## P2：后续

```text
G. Goal Relabeling
H. PAB-H
```

---

# 22. 推荐脚本结构

新增：

```text
scripts/
├── trace_action_pipeline.py
├── test_force_close_after_success.py
├── build_terminal_replay.py
├── eval_terminal_replay.py
├── build_intermediate_subgoal_states.py
├── eval_intermediate_subgoal.py
├── build_matched_pairs.py
├── eval_matched_pairs.py
├── run_spatial_sweep.py
└── eval_pab_h_prototype.py
```

---

# 23. Action Trace 输出格式

建议每个 episode 输出一个 CSV：

```text
step,
goal_satisfied,
eef_x,
eef_y,
eef_z,
obj_x,
obj_y,
obj_z,
eef_obj_dist,
raw_gripper,
processed_gripper,
actuator_gripper,
finger_qpos_left,
finger_qpos_right,
env_done
```

---

# 24. 每个实验统一保存

```text
results/mechanism/
├── action_trace/
├── force_close/
├── terminal_replay/
├── intermediate/
├── matched_pair/
├── spatial_sweep/
└── pab_h/
```

每个目录至少保存：

```text
config.yaml
episode_records.json
summary.csv
videos/
report.md
```

---

# 25. 每个实验必须回答的问题

| 实验 | 必须回答的问题 |
|---|---|
| Action Trace | 不闭夹爪到底发生在哪一层？ |
| Force-Close | success 后系统是否仍允许真实执行 close command？ |
| Terminal Replay | 自然完成状态下，post-completion action failure 是否稳定存在？ |
| Intermediate | 在非 terminal、训练真实出现的状态里，模型是否会重新执行已完成 subgoal？ |
| Matched Pair | 当视觉几乎相同、仅 goal satisfaction 不同时，模型行为是否显著不同？ |
| Spatial Sweep | visual grounding 与 spatial prior 的有效边界在哪里？ |
| PAB-H | current observation 不足时，history 是否真正提供不可替代的信息？ |

---

# 26. 结果解释决策树

## 情况 1

如果：

```text
force-close 正常
raw / processed gripper 都 OPEN
```

则：

> “不闭夹爪”属于 policy-side behavior。

继续比较 satisfied vs near-satisfied。

## 情况 2

如果：

```text
raw CLOSE
processed OPEN
```

则：

> 修 adapter；当前行为结论作废。

## 情况 3

如果：

```text
processed CLOSE
controller / actuator OPEN
```

则：

> 排查 system-level gating；当前 satisfied 实验不能解释模型意图。

## 情况 4

如果 Intermediate 仍有明显 re-execution：

> failure 不能归咎于 terminal supervision 缺失。

这是最重要的结果之一。

## 情况 5

如果 Matched Pair 中：

```text
near-satisfied: close
satisfied: open / hesitate
```

则支持：

> implicit completion awareness exists, but no explicit STOP interface.

## 情况 6

如果两者都抓：

> 更支持 visual grounding exists, but execution necessity reasoning is absent.

## 情况 7

如果两者都朝 prior position：

> spatial prior 仍是主导混淆，需要更强视觉模型或更小 spatial intervention。

---

# 27. 论文主线的更新版本

当前更稳妥的主线应该是：

> Standard VLAs are optimized primarily for action generation. We study a complementary capability: deciding whether further physical intervention is still necessary.

然后从四个层级建立证据：

### Level 1：Natural terminal states

```text
post-completion behavior is unstable
```

### Level 2：Intermediate completed subgoals

```text
failure persists away from terminal states
```

### Level 3：Matched pairs

```text
behavior changes as a function of goal satisfaction
```

### Level 4：History-dependent states

```text
when the current observation is insufficient, selective memory becomes necessary
```

---

# 28. 当前最重要的研究判断

现阶段不要再把问题简单描述为：

> “VLA 看不见当前物体位置。”

也不要简单描述为：

> “VLA 任务完成后一定会重复整条轨迹。”

目前数据更支持一个更细粒度的可能性：

$$
\boxed{
\text{Visual Grounding}
\neq
\text{Execution Necessity}
\neq
\text{Explicit STOP Control}
}
$$

也就是说：

1. 模型可能知道目标物在哪里；
2. 甚至可能对 goal completion 有一定隐式感知；
3. 但这些信息并没有稳定地被转换成：
   - STOP；
   - SKIP；
   - REPAIR；
   - EXECUTE；

这样的执行级决策。

这正是下一阶段实验需要验证的核心。

---

# 29. 最小下一步

如果只允许先做三个实验，顺序应为：

## ① Force-Close

确认 success 后系统是否仍允许夹爪动作。

## ② Action Causality Trace

确定“不闭夹爪”到底来自：

```text
model
postprocess
controller
physics
```

哪一层。

## ③ Intermediate Completed-Subgoal

用非 terminal 中间状态直接攻击：

> “BC 只是没教 terminal 后该怎么办”

这个最强替代解释。

如果这三个实验结果都支持原 hypothesis，再进入：

```text
Matched Pair
Spatial Sweep
PAB-H
ENA Head
```

会比现在直接扩 benchmark 更稳。
