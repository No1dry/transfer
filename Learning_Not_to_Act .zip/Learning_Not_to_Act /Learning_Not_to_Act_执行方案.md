# Learning Not to Act：执行方案
## Execution-Necessity-Aware VLA with Counterfactual Memory

> **周期**：6 个月  
> **主线**：Execution Necessity → PAB-S / PAB-H → State-only ENA → Counterfactual Memory → Unified ENA-VLA  
> **推荐后端**：OpenVLA-OFT + LIBERO  
> **目标**：形成一套可复现的 benchmark、模型、消融、泛化和真机实验，并产出完整论文结果。

---

# 0. 项目原则

整个项目只围绕一个问题推进：

$$
\text{Does the robot still need to act?}
$$

研究路线分三层：

1. **当前状态是否已经足够判断是否需要行动？**
2. **如果当前状态不足，历史信息是否必要？**
3. **如果历史很长，哪些记忆真正对当前执行必要性判断有帮助？**

因此整个工程顺序必须保持：

$$
\text{Phenomenon}
\rightarrow
\text{PAB-S}
\rightarrow
\text{State-only ENA}
\rightarrow
\text{PAB-H}
\rightarrow
\text{Selective Memory}
\rightarrow
\text{Unified Model}
$$

**禁止一开始就直接开发复杂 memory 模块。**

原因很简单：如果 state-only 已经能解决大多数任务，就没有必要把 memory 强行塞进模型。

---

# 1. 核心变量与任务定义

## 1.1 Goal Satisfaction

定义目标满足程度：

$$
g_t \in [0,1]
$$

其中：

$$
g_t = 1
$$

表示目标已经完全满足。

## 1.2 Execution Necessity

定义执行必要性：

$$
n_t \in [0,1]
$$

其中：

- $n_t = 0$：无需动作；
- $0 < n_t < 1$：只需要 residual correction；
- $n_t \approx 1$：需要完整执行。

## 1.3 离散执行模式

定义：

$$
z_t \in
\{
\mathrm{STOP},
\mathrm{REPAIR},
\mathrm{EXECUTE}
\}
$$

对应关系：

| 状态 | Mode | Execution Necessity |
|---|---|---|
| 已满足 | STOP | $n_t \approx 0$ |
| 部分满足 | REPAIR | $0<n_t<1$ |
| 未满足 | EXECUTE | $n_t \approx 1$ |

---

# 2. Benchmark 结构

整个 benchmark 统一称为：

**PAB 2.0**

分为两部分：

- **PAB-S**：State-observable execution necessity
- **PAB-H**：History-dependent execution necessity

---

# 3. 项目目录

建议项目根目录：

```text
/home/z/learning_not_to_act/
```

推荐结构：

```text
learning_not_to_act/
│
├── configs/
│   ├── backbone/
│   │   └── openvla_oft.yaml
│   ├── pab_s.yaml
│   ├── pab_h.yaml
│   ├── ena.yaml
│   └── memory.yaml
│
├── benchmark/
│   ├── task_registry.py
│   ├── state_builder.py
│   ├── history_builder.py
│   ├── predicates.py
│   ├── label_generator.py
│   └── evaluator.py
│
├── models/
│   ├── execution_head.py
│   ├── necessity_head.py
│   ├── memory_bank.py
│   ├── candidate_retriever.py
│   ├── counterfactual_scorer.py
│   ├── memory_fusion.py
│   └── ena_vla.py
│
├── counterfactual/
│   ├── probe.py
│   ├── build_labels.py
│   └── train_scorer.py
│
├── training/
│   ├── train_ena.py
│   ├── train_memory.py
│   └── train_unified.py
│
├── eval/
│   ├── eval_original_libero.py
│   ├── eval_pab_s.py
│   ├── eval_pab_h.py
│   ├── eval_memory.py
│   ├── eval_generalization.py
│   └── metrics.py
│
├── scripts/
│   ├── inspect_task.py
│   ├── inspect_demo.py
│   ├── build_pab_s.py
│   ├── build_pab_h.py
│   ├── visualize_state.py
│   └── export_results.py
│
├── data/
│   ├── pab_s/
│   ├── pab_h/
│   ├── memory_bank/
│   └── counterfactual_labels/
│
├── results/
│   ├── m1/
│   ├── m2/
│   ├── m3/
│   ├── m4/
│   └── final/
│
└── reports/
    ├── m1_report.md
    ├── m2_report.md
    └── experiment_log.md
```

---

# 4. 六个月总计划

| 月份 | 核心任务 | 最重要产出 |
|---|---|---|
| M1 | 现象验证 + Mini-PAB + PAB-S/PAB-H v0 | 确认问题是否真实存在 |
| M2 | State-only Execution Necessity | ENA 在 PAB-S 上有效 |
| M3 | PAB-H + Counterfactual Memory | 证明 history-dependent gap |
| M4 | Unified ENA-VLA + 完整消融 | 主实验结果完成 |
| M5 | 泛化 + 真机 | 泛化表 + 真机视频 |
| M6 | 补实验 + 写论文 | 投稿版 |

---

# 5. M1：现象验证与 Benchmark 构建

M1 的核心目标不是“把 benchmark 做完”。

而是尽快回答：

$$
\text{Does the failure actually exist?}
$$

---

# 6. M1-W1：OpenVLA-OFT + Mini-PAB

## 6.1 W1 目标

第一周只做：

- OpenVLA-OFT baseline 跑通；
- 4 个真实 LIBERO task；
- satisfied / unsatisfied 两种状态；
- 现象 sanity check。

不要一开始就构建完整 48-task benchmark。

## 6.2 Day 1：锁定环境与 checkpoint

创建环境信息文件：

```text
configs/environment.md
```

至少记录：

```markdown
# Environment

- Python:
- PyTorch:
- CUDA:
- transformers:
- libero:
- robosuite:
- mujoco:
- openvla-oft commit:
- checkpoint:
- GPU:
```

建议把当前 checkpoint 固定下来，例如：

```text
moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10
```

不要在实验中途换 checkpoint。

## 6.3 Day 1-2：复现原始 LIBERO

实现：

```text
eval/eval_original_libero.py
```

至少从以下 suite 各测试若干任务：

```text
libero_spatial
libero_object
libero_goal
libero_10
```

第一版不追求完整 official benchmark。

目标是确认：

```text
模型加载正常
action normalization 正常
LIBERO env 正常
episode loop 正常
success predicate 正常
```

建议：

```text
每 suite：2 个任务
每任务：5 trials
```

最低要求：

$$
SR_{\mathrm{original}} \ge 80\%
$$

如果明显低于官方能力，先排查工程问题，不能直接进入 PAB。

---

# 7. Mini-PAB 任务选择

第一批只选 4 个任务。

推荐优先选：

1. bowl → plate
2. object → basket
3. open drawer
4. bowl → stove

要求：

- LIBERO 中真实存在；
- success predicate 可以明确读取；
- satisfied state 可以程序化构造；
- 当前 RGB 基本可以判断是否完成。

---

# 8. Mini-PAB 状态

每个任务先只构造：

```text
satisfied
unsatisfied
```

暂时不做 partial。

每种状态：

```text
20 seeds
```

因此：

$$
4 \times 2 \times 20 = 160
$$

个 episode。

---

# 9. State Builder

实现：

```text
benchmark/state_builder.py
```

统一接口：

```python
def build_state(task_id, condition, seed):
    # condition: satisfied / partial / unsatisfied
    ...
```

---

# 10. Success Predicate

实现：

```text
benchmark/predicates.py
```

统一接口：

```python
def check_goal_satisfied(env, task_id):
    return bool_value
```

要求：

- benchmark ground truth 优先来自 simulator state；
- 不使用 VLM 作为主要 ground truth；
- 每个 predicate 必须有单元测试。

例如：

```python
assert check_goal_satisfied(env_satisfied) is True
assert check_goal_satisfied(env_unsatisfied) is False
```

---

# 11. W1 核心评估指标

## 11.1 Unnecessary Execution Rate

定义：

$$
UER =
P(
\text{significant intervention}
\mid
z=\mathrm{STOP}
)
$$

第一版 significant intervention 可以简单定义成：

```text
end-effector displacement
gripper state change
object displacement
```

不要只使用 action vector norm。

## 11.2 Goal Disturbance Rate

定义：

$$
GDR =
P(
G(s_{\mathrm{final}})<G(s_0)
\mid
G(s_0)=1
)
$$

直观意义：

> 本来已经完成，机器人却把任务状态破坏掉。

## 11.3 Post-Completion Action Steps

记录：

```text
目标已经满足以后，模型仍继续执行了多少 step
```

---

# 12. M1-W1 Go / No-Go

### GO-A：问题很强

如果：

$$
UER > 50\%
$$

说明 Learning Not to Act failure 很明显。

继续按原计划推进。

### GO-B：问题中等

如果：

$$
20\% < UER \le 50\%
$$

仍然继续。

重点增加：

- partial state；
- PAB-H；
- long-horizon。

### Conditional GO

如果：

$$
UER \le 20\%
$$

不要立即放弃。

继续测试：

- partial state；
- history-dependent task。

只有 PAB-S 和 PAB-H 都没有明显问题，才真正考虑换题。

---

# 13. W1 交付物

必须生成：

```text
results/m1/mini_pab_raw.json
results/m1/mini_pab_summary.csv
reports/m1_w1_sanity.md
```

至少包含：

| Task | Condition | Success | UER | GDR | Action Steps |
|---|---:|---:|---:|---:|---:|

同时保存：

```text
success video
redundant-action video
goal-disturbance video
```

至少各 3 个。

---

# 14. M1-W2：PAB-S v0

## 14.1 扩展任务

从 4 个 task 扩到：

```text
8 task families
```

每个任务：

```text
satisfied
partial
unsatisfied
```

共：

$$
8\times3=24
$$

种状态配置。

---

# 15. Partial State 构造

Partial 不再简单写成“偏移 5 cm”。

每个 task 必须定义一个 residual function：

$$
D(s,l)
$$

例如：

### Placement

$$
D(s,l)=
\|p_{\mathrm{object}}-p_{\mathrm{target}}\|
$$

### Drawer

$$
D(s,l)=
|q_{\mathrm{drawer}}-q^*|
$$

### Switch

$$
D(s,l)=
|q_{\mathrm{switch}}-q^*|
$$

---

# 16. Necessity Label

定义：

$$
n_t =
\mathrm{clip}
\left(
\frac{D(s_t,l)}
{D(s_{\mathrm{reference}},l)+\epsilon},
0,
1
\right)
$$

第一版可以把状态分为：

```text
STOP:
n <= 0.05

REPAIR:
0.05 < n < 0.6

EXECUTE:
n >= 0.6
```

具体阈值只用于初始化，最终应该通过 validation 调整。

---

# 17. PAB-S 配置文件

创建：

```text
configs/pab_s.yaml
```

示例：

```yaml
tasks:
  - id: bowl_on_plate
    source_suite: libero_goal
    condition:
      satisfied:
        mode: STOP
      partial:
        mode: REPAIR
      unsatisfied:
        mode: EXECUTE
```

---

# 18. M1-W2 检查标准

每个配置都必须满足：

1. state 可以稳定 reset；
2. predicate 正确；
3. RGB 图像合理；
4. 没有明显 simulator artifact；
5. satisfied / partial / unsatisfied 不是通过无关视觉 shortcut 区分。

---

# 19. M1-W3：PAB-H Prototype

PAB-H 的目标是制造：

$$
o_t^A \approx o_t^B
$$

但是：

$$
z_t^A \neq z_t^B
$$

即：

> 当前画面非常接近，但正确行为依赖历史。

---

# 20. PAB-H 第一批 Prototype

建议只做 2-4 类。

## H1：Occluded Completion

任务：

```text
put object into drawer and close drawer
```

History A：

```text
pick
place object
close drawer
```

History B：

```text
close drawer
```

最终：

```text
drawer 都是 closed
```

但正确判断不同。

## H2：Counting

构造：

```text
press / turn / manipulate N times
```

History：

```text
0/N
1/N
...
N/N
```

当前视觉尽量一致。

## H3：Stage Ambiguity

例如：

```text
turn on stove and put moka pot on stove
```

构造：

```text
history A:
stove 已打开

history B:
stove 未打开
```

当前状态尽可能控制为相似。

## H4：Hidden Object

物体进入：

```text
drawer
container
microwave
```

后被遮挡。

当前 RGB 无法直接判断内部 object state。

---

# 21. PAB-H 第一项关键实验

在任何 memory 模型之前，先训练或测试：

```text
State-only classifier
```

和：

```text
Oracle-history classifier
```

如果：

$$
Acc_{\mathrm{history}}
-
Acc_{\mathrm{state}}
< 10\%
$$

说明 PAB-H 构造失败。

不要继续做 memory，重新设计任务。

---

# 22. M1-W4：冻结 Benchmark v0

M1 末输出：

```text
PAB-S v0
PAB-H prototype
OpenVLA-OFT baseline
State-only gap
```

---

# 23. M1 最终 Go / No-Go

项目继续的充分条件：满足下面至少一个。

### 条件 A

$$
UER_{\mathrm{OpenVLA-OFT}}
\ge 20\%
$$

### 条件 B

$$
Acc_{\mathrm{history}}
-
Acc_{\mathrm{state}}
\ge 10\%
$$

如果两个都不满足：

```text
暂停复杂方法开发
重新评估选题
```

---

# 24. M1 交付物

```text
data/pab_s/v0/
data/pab_h/v0/

results/m1/openvla_oft_baseline.json
results/m1/pab_s_baseline.csv
results/m1/pab_h_state_history_gap.csv

reports/m1_report.md
```

---

# 25. M2：State-only Execution Necessity

M2 的目标：

> 不使用 memory，只解决 observable execution necessity。

---

# 26. M2-W1：数据构造

训练数据包含：

```text
STOP
REPAIR
EXECUTE
```

三类，尽量类别平衡。

建议：

```text
每 task family
每 mode
100-500 samples
```

优先从：

- success trajectory；
- perturbed state；
- simulator state；

自动生成。

---

# 27. M2-W2：Execution Necessity Head

模型输入：

```text
visual feature
language feature
```

输出两个 head：

```text
mode logits
necessity scalar
```

形式：

$$
p(z_t\mid o_t,l)
$$

以及：

$$
\hat n_t.
$$

---

# 28. Loss

Mode loss：

$$
L_{\mathrm{mode}}
=
CE(\hat z,z)
$$

Necessity loss：

$$
L_{\mathrm{necessity}}
=
\mathrm{Huber}(\hat n,n)
$$

Action loss 只在：

$$
z\neq\mathrm{STOP}
$$

时计算。

总损失：

$$
L=
L_{\mathrm{action}}
+
\lambda_1 L_{\mathrm{mode}}
+
\lambda_2 L_{\mathrm{necessity}}.
$$

---

# 29. M2-W3：STOP / REPAIR / EXECUTE Evaluation

核心比较：

```text
OpenVLA-OFT
VLM-as-Judge
Binary STOP/ACT
ENA STOP/REPAIR/EXECUTE
```

---

# 30. M2 指标

至少输出：

```text
Mode Accuracy
Macro F1
STOP Recall
False Stop Rate
UER
GDR
Necessity MAE
Task Success Rate
```

---

# 31. False Stop Rate

定义：

$$
FSR=
P(
\mathrm{STOP}
\mid
z\neq\mathrm{STOP}
)
$$

这一指标必须与 UER 同时报告。

因为：

```text
永远 STOP
```

会得到极低的 UER，却是失败模型。

---

# 32. M2-W4：阈值 Calibration

对：

$$
P(\mathrm{STOP})
$$

做 calibration。

记录：

```text
ECE
Brier Score
Reliability Diagram
```

STOP threshold：

$$
\theta_s
$$

只能在 validation set 上确定，不能根据 test set 调。

---

# 33. M2 成功标准

最低要求：

$$
UER_{\mathrm{ENA}}
<
0.5
\times
UER_{\mathrm{OFT}}
$$

同时：

$$
FSR \le 10\%
$$

且：

$$
SR_{\mathrm{ENA}}
\ge
0.95
SR_{\mathrm{OFT}}.
$$

---

# 34. M2 输出

```text
checkpoints/ena_state_only/
results/m2/main_pab_s.csv
results/m2/calibration.csv
results/m2/error_cases/
reports/m2_report.md
```

---

# 35. M3：Counterfactual Memory

M3 只解决 PAB-H。

---

# 36. M3-W1：扩展 PAB-H

将 prototype 扩展到：

```text
8 task families
```

最终目标：

```text
24 history configurations
```

---

# 37. Memory Item

每条 memory：

```python
{
    "visual_embedding": ...,
    "language_embedding": ...,
    "action": ...,
    "timestamp": ...,
    "event_type": ...,
    "task_id": ...
}
```

---

# 38. Candidate Pool

禁止只使用：

```text
similarity top-K
```

候选集合采用：

$$
M_c =
M_{\mathrm{semantic}}
\cup
M_{\mathrm{recent}}
\cup
M_{\mathrm{event}}
\cup
M_{\mathrm{diverse}}.
$$

---

# 39. Candidate 来源

### Semantic

VLA/CLIP embedding 相似度。

### Recent

最近的若干 event。

### Event

保存：

```text
grasp
release
drawer-open
drawer-close
switch-change
subgoal transition
```

附近关键帧。

### Diverse

随机 / reservoir / clustering 保留不同历史。

---

# 40. M3-W2：Offline Counterfactual Probing

对 query：

$$
q=(o_t,l)
$$

和候选 memory：

$$
m_i
$$

分别计算：

$$
L_{\mathrm{full}}
=
\mathcal{L}(
\pi(q,M),
y
)
$$

以及：

$$
L_{-i}
=
\mathcal{L}(
\pi(q,M\setminus\{m_i\}),
y
).
$$

定义：

$$
C(m_i;q,y)
=
L_{-i}
-
L_{\mathrm{full}}.
$$

---

# 41. Counterfactual Utility 含义

如果：

$$
C>0
$$

表示：

```text
helpful memory
```

如果：

$$
C\approx0
$$

表示：

```text
irrelevant memory
```

如果：

$$
C<0
$$

表示：

```text
harmful memory
```

---

# 42. Probe 规模控制

不做完整：

$$
O(|M|)
$$

leave-one-out。

每个 query 只 probe：

```text
8-32 candidates
```

第一版推荐：

```text
16
```

---

# 43. Probe 数据格式

保存：

```text
data/counterfactual_labels/
```

每条样本：

```json
{
  "query_id": "...",
  "memory_id": "...",
  "task_id": "...",
  "loss_full": 0.21,
  "loss_removed": 0.38,
  "causal_utility": 0.17
}
```

---

# 44. M3-W3：Query-Conditioned Scorer

Scorer 学习：

$$
\hat C(m;q)
$$

而不是：

$$
\hat C(m).
$$

输入建议：

$$
[q,m,q\odot m,|q-m|].
$$

模型第一版直接使用：

```text
3-layer MLP
```

不要一开始使用复杂 Transformer。

---

# 45. Memory Loss

Regression：

$$
L_{\mathrm{reg}}
=
SmoothL1(\hat C,C)
$$

Ranking：

如果：

$$
C_i>C_j
$$

要求：

$$
\hat C_i>\hat C_j.
$$

总损失：

$$
L_{\mathrm{mem}}
=
L_{\mathrm{reg}}
+
\lambda_rL_{\mathrm{rank}}.
$$

---

# 46. M3-W4：Memory Baseline

比较：

```text
Recent
Random
Similarity
Attention score
Counterfactual
Oracle
```

---

# 47. Memory 指标

### Useful@K

$$
Useful@K
=
\frac{
|\{m\in TopK:C(m)>0\}|
}{K}
$$

### Harmful@K

$$
Harmful@K
=
\frac{
|\{m\in TopK:C(m)<0\}|
}{K}
$$

### Memory Gain

$$
MG=
Acc_{\mathrm{memory}}
-
Acc_{\mathrm{state-only}}.
$$

---

# 48. M3 成功标准

至少满足：

$$
Useful@K_{\mathrm{CF}}
>
Useful@K_{\mathrm{Similarity}}
$$

以及：

$$
MG_{\mathrm{CF}}
\ge10\%
$$

在 PAB-H 上成立。

---

# 49. M4：Unified ENA-VLA

M4 才开始整合。

---

# 50. Unified Input

当前状态：

$$
h_t=f(o_t,l)
$$

记忆：

$$
h_t^{mem}
=
CrossAttention(h_t,M_K)
$$

执行判断：

$$
p(z_t\mid h_t,h_t^{mem})
$$

以及：

$$
\hat n_t.
$$

---

# 51. Unified 推理

```python
state_feat = encode(image, instruction)

memory_candidates = retrieve_candidates(...)
memories = counterfactual_rank(
    query=state_feat,
    candidates=memory_candidates
)

memory_feat = memory_fusion(
    query=state_feat,
    memories=memories
)

mode, necessity = execution_head(
    state_feat,
    memory_feat
)

if mode == STOP:
    return STOP_ACTION
else:
    return action_policy(...)
```

---

# 52. M4 主实验

必须形成四张核心表/图。

## Figure 1：Failure Phenomenon

展示：

```text
OpenVLA-OFT
satisfied / partial / unsatisfied
```

## Figure 2：PAB-S

比较：

```text
Vanilla
VLM Judge
Binary
ENA
```

## Figure 3：PAB-H

比较：

```text
State-only
Recent
Similarity
Counterfactual
Oracle
```

## Figure 4：When Memory Helps

画：

```text
PAB-S Memory Gain
PAB-H Memory Gain
```

目标结果：

$$
MG_{\mathrm{PAB-S}}
\approx0
$$

而：

$$
MG_{\mathrm{PAB-H}}>0.
$$

---

# 53. M4 消融

完整消融：

```text
A1 no execution head
A2 binary STOP/ACT
A3 no necessity regression
A4 no memory
A5 recent-only memory
A6 similarity retrieval
A7 |Δaction| counterfactual score
A8 similarity-only candidate pool
A9 no harmful-memory modeling
```

---

# 54. M4 Similarity Trap

构造两种历史：

### Similar but useless

视觉非常相似，但与当前 decision 无关。

### Dissimilar but useful

视觉不相似，但包含决定 completion 的关键 event。

比较：

```text
Similarity rank
Counterfactual rank
```

---

# 55. Memory Distractor Test

向真实 history 中加入：

```text
0
8
32
128
```

条 distractor memory。

画：

$$
Accuracy
\text{ vs. }
Memory\ Noise
$$

比较：

```text
Recent
Similarity
Counterfactual
```

---

# 56. M5：泛化实验

至少做四类。

## G1：Unseen Object

训练和测试 object 不同。

## G2：Language Paraphrase

测试：

```text
put the bowl on the plate
place the bowl onto the plate
make sure the bowl is on the plate
```

## G3：Spatial OOD

改变：

```text
camera
object position
target position
distractors
```

## G4：History Noise

改变历史长度和 distractor 比例。

---

# 57. 真机实验

推荐 4 类。

### R1：Visible Placement

```text
cup → tray
```

### R2：Drawer

```text
open drawer
```

### R3：Occluded Completion

```text
put object in drawer and close drawer
```

### R4：History / Counting

```text
press button N times
```

---

# 58. 真机规模

每任务：

```text
3 conditions
```

每 condition：

```text
15-20 trials
```

模型只比较：

```text
OpenVLA / base VLA
ENA state-only
ENA + Counterfactual Memory
```

---

# 59. M5 真机视频要求

必须保留三类 demo。

### Case 1：Already Done

Vanilla：

```text
继续操作
```

ENA：

```text
STOP
```

### Case 2：Partial

Vanilla：

```text
完整重做
```

ENA：

```text
只做 residual correction
```

### Case 3：Same-looking State, Different History

State-only：

```text
判断错误
```

Memory：

```text
根据 history 得到不同 decision
```

---

# 60. M6：论文与最终补实验

M6 不开发新模型。

只允许：

```text
补 baseline
补 ablation
补 failure analysis
补 figure
补 real-robot trial
```

禁止：

```text
重新设计整个方法
```

---

# 61. 结果汇总表

最终主表建议：

| Model | PAB-S Mode Acc | PAB-S UER ↓ | PAB-H Mode Acc | FSR ↓ | Success ↑ |
|---|---:|---:|---:|---:|---:|
| OpenVLA-OFT | | | | | |
| VLM Judge | | | | | |
| ENA | | | | | |
| ENA + Recent | | | | | |
| ENA + Similarity | | | | | |
| ENA + CF Memory | | | | | |
| Oracle | | | | | |

---

# 62. 每次实验统一保存内容

每次训练必须保存：

```text
config.yaml
git_commit.txt
train.log
metrics.json
checkpoint/
```

每次 evaluation 保存：

```text
episode-level json
summary csv
failure cases
videos
```

---

# 63. Experiment ID 规则

统一：

```text
{date}_{model}_{benchmark}_{seed}
```

例如：

```text
20260930_ena_pab_s_seed0
```

禁止覆盖旧结果。

---

# 64. 实验日志

建立：

```text
reports/experiment_log.md
```

每个实验记录：

```markdown
## EXP-001

### Hypothesis
...

### Change
...

### Config
...

### Result
...

### Interpretation
...

### Next Step
...
```

这样写论文时不用重新回忆实验过程。

---

# 65. 必须优先避免的工程错误

## 65.1 Benchmark Leakage

不要让：

```text
background
camera
lighting
object count
```

直接泄露 STOP / REPAIR / EXECUTE 标签。

## 65.2 Reset Artifact

不同 condition 必须尽可能共享：

```text
camera
robot initial pose
lighting
scene layout
```

只改变任务相关状态。

## 65.3 Success Predicate 与 Observation 不一致

Simulator 可以知道 hidden state，但模型不一定可以。

这正是 PAB-H 的目标。

因此必须明确区分：

```text
ground-truth state
model observation
```

## 65.4 Test Contamination

PAB test seed 与 training augmentation 必须分开。

## 65.5 Threshold Tuning

所有：

```text
STOP threshold
REPAIR threshold
memory K
candidate size
```

只能在 validation set 调。

---

# 66. 统计协议

最终主结果：

```text
3 training seeds
```

每 condition：

```text
至少 20 evaluation episodes
```

报告：

$$
\text{mean} \pm 95\%\ \mathrm{CI}
$$

优先使用：

```text
bootstrap confidence interval
```

因为很多指标是 episode-level binary metric。

---

# 67. 最关键的三个决策点

## Decision 1：M1-W1

问题是否真实存在？

看：

$$
UER
$$

## Decision 2：M1-W3

History 是否真的必要？

看：

$$
Acc_{\mathrm{history}}
-
Acc_{\mathrm{state}}
$$

## Decision 3：M3-W4

Counterfactual Memory 是否真的比 similarity 强？

看：

$$
Useful@K
$$

和：

$$
Memory\ Gain.
$$

如果这三个问题没有被数据支持，不要靠继续加模块来“救论文”。

---

# 68. 最终成功条件

整个项目的理想结果不是：

> 所有任务 memory 都最好。

而是得到更有解释力的结果。

### PAB-S

$$
\text{ENA} \gg \text{Vanilla VLA}
$$

且：

$$
\text{ENA + Memory}
\approx
\text{ENA}.
$$

### PAB-H

$$
\text{ENA + CF Memory}
>
\text{ENA}.
$$

并且：

$$
\text{CF Memory}
>
\text{Similarity Memory}.
$$

这将支持整个研究的核心结论：

> VLA 不仅需要学习如何行动，还需要学习什么时候行动仍然必要；当当前状态不足以支持这一判断时，历史才真正变得重要，而有效的历史选择应基于对当前决策的实际效用，而不是单纯的语义相似度。

---

# 69. 推荐实际启动顺序

如果现在立即开始，建议严格按照以下顺序执行：

```text
1. 跑通 OpenVLA-OFT 原始 LIBERO
2. 找 4 个真实 LIBERO task
3. 构造 satisfied state
4. 跑 160 个 Mini-PAB episode
5. 计算 UER / GDR
6. 确认现象
7. 再扩 PAB-S
8. 构造 2 个 PAB-H prototype
9. 验证 state-only vs history gap
10. 然后才开发 ENA head
11. 最后开发 counterfactual memory
```

这套顺序的核心思想是：

> **每增加一个模块之前，先用实验确认这个模块对应的问题真的存在。**

---

# 70. 第一周完成后的最低成果

第一周结束时，无论最终结果如何，都必须能够回答下面四个问题：

1. OpenVLA-OFT 在正常 LIBERO 上是否工作正常？
2. 当任务一开始就已经完成时，它是否仍然会显著行动？
3. 这种动作是否只是轻微抖动，还是会真正改变环境？
4. 这个现象是否在多个 task family 中稳定出现？

如果这四个问题还不能回答，就不应该进入后续方法开发。
