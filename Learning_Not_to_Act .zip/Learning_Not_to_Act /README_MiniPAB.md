# Mini-PAB：执行方案 §69 第 2–6 步

本目录实现 **Learning Not to Act / ENA-VLA** 项目「现象验证层」的全部代码：
从 LIBERO 官方任务建立 registry、程序化构造 satisfied / unsatisfied 初始状态、
跑 160 个 episode、计算 UER / GDR，并生成 GO/NO-GO 报告。

对应执行方案 §69 的启动顺序：

```text
1. 跑通 OpenVLA-OFT 原始 LIBERO        <- 已在别处完成，本目录不含
2. 找 4 个真实 LIBERO task              <- configs/mini_pab.yaml + benchmark/tasks/
3. 构造 satisfied state                <- benchmark/states/
4. 跑 160 个 Mini-PAB episode          <- benchmark/manifest.py + benchmark/runner.py
5. 计算 UER / GDR                      <- benchmark/metrics.py
6. 确认现象                            <- benchmark/report.py + reports/
```

---

## 1. 关键设计：分层，让不需要 GPU 的部分在本地就能验证

这是本实现最重要的结构决策。整条流水线被切成两层：

| 层 | 内容 | 需要什么 | 能否在本机验证 |
|---|---|---|---|
| **构造层** | task registry、状态构造、predicate、指标、报告 | Python + numpy | ✅ 可跑、可单测 |
| **仿真层** | 真实 LIBERO / robosuite 环境 | LIBERO 安装（CPU 即可） | ⚠️ 需装 LIBERO |
| **推理层** | OpenVLA-OFT 7B 前向 | **NVIDIA GPU** | ❌ 只能上 GPU 机器 |

上层只依赖 `benchmark/arena/protocol.py` 里的 `Arena` 协议，因此有 **两个可互换的实现**：

- `MockArena` —— 纯 Python 假环境，本机可跑，用于验证 harness 记账是否正确
- `LiberoArena` —— 真实 LIBERO 适配器

同样，策略只依赖 `Policy` 协议（`predict(obs, language) -> action`），因此
`DummyPolicy`（已知答案）与 `OpenVLAOFTAdapter`（真模型）可互换。

---

## 2. 目录结构

```text
.
├── configs/mini_pab.yaml          # Mini-PAB v0 任务定义（4 task × 2 condition × 20 seed）
├── data/
│   ├── libero_task_ids.json       # 由 LIBERO 官方源码解析出的权威 task_id
│   └── libero_suite_task_map.source.py   # 上游快照（provenance）
├── benchmark/
│   ├── tasks/registry.py          # Step 2: TaskSpec / TaskRegistry
│   ├── states/mujoco_state.py     # MuJoCo 状态向量读写（纯函数）
│   ├── states/builder.py          # Step 3: StateBuilder
│   ├── arena/protocol.py          # Arena 协议（ground truth 的唯一定义处）
│   ├── arena/mock.py              # MockArena
│   ├── arena/libero.py            # LiberoArena（真实环境）
│   ├── policy/base.py             # Policy 协议 + DummyPolicy + OpenVLAOFTAdapter
│   ├── manifest.py                # Step 4: 160-episode manifest
│   ├── runner.py                  # Step 4: episode 运行器
│   ├── metrics.py                 # Step 5: UER / GDR / SR / bootstrap CI / GO-NO-GO
│   └── report.py                  # Step 6: markdown 报告
├── scripts/
│   ├── extract_libero_task_ids.py # 从 LIBERO 源码解析 task_id（勿手写）
│   ├── build_manifest.py          # 生成/冻结 160-episode 清单（无依赖）
│   ├── validate_states.py         # 在真实 LIBERO 上校验状态构造（CPU）
│   ├── run_mini_pab.py            # 主入口：跑 160 episodes（GPU）
│   └── smoke_mock_pipeline.py     # 端到端演练（本机，无需 GPU/LIBERO）
├── tests/                         # 65 个单元测试，本机可跑
└── results/m1/ , reports/         # 产物
```

---

## 3. 快速开始

### 3.1 本机（无需 GPU、无需 LIBERO）

```bash
# 单元测试
python -m pytest tests/ -q

# 生成 160-episode manifest
python scripts/build_manifest.py --model openvla_oft

# 端到端演练：用已知答案的策略验证整条流水线
python scripts/smoke_mock_pipeline.py
```

`smoke_mock_pipeline.py` 用三个**已知答案**的策略做对照，这是拿到 GPU 机器之前
唯一能证明「harness 没算错」的手段：

| 策略 | 预期 satisfied 下 UER | 预期 unsatisfied 下 SR | 作用 |
|---|---|---|---|
| `dummy_noop` | 0 | 0 | 不动 → 不算多余动作 |
| `dummy_push` | 1 | 0 | 永远在动 → 多余动作 + 破坏目标 |
| `dummy_scripted` | 0 | 1 | 有目的动作 → 成功路径可被观测 |

### 3.2 装了 LIBERO 的机器（CPU 即可，无需 GPU）

先钉死状态构造，再花 GPU 时间：

```bash
python scripts/validate_states.py \
    --openvla_oft_root /path/to/openvla-oft \
    --save_images
```

它会用 LIBERO 自己的 `env.check_success()`（simulator ground truth）复核每个构造出的
状态，并检查两种 condition 的机器人关节是否完全一致。

### 3.3 GPU 机器

```bash
# 先小规模试跑
python scripts/run_mini_pab.py \
    --openvla_oft_root /path/to/openvla-oft \
    --checkpoint moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10 \
    --limit 8

# 全量 160 episodes
python scripts/run_mini_pab.py \
    --openvla_oft_root /path/to/openvla-oft \
    --checkpoint moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10
```

产物：

```text
results/m1/<timestamp>_<model>_mini_pab/
    manifest.json          # 冻结的 episode 清单 + content hash
    <episode>.json         # 每条 episode 的完整记录
    metrics.json           # 汇总指标
results/m1/mini_pab_summary.csv
reports/m1_w1_sanity_<run>.md    # §13 要求的报告
```

---

## 4. 四个任务（Step 2）

严格按执行方案 §7 选取，且**只用 LIBERO 官方真实存在的任务**（v2 §8 明确要求
弃用 `wipe the table` 这类未确认存在的 conceptual task）：

| 项目 id | LIBERO suite | task_id | 官方 task 名 | 语言指令 | 残差类型 |
|---|---|---|---|---|---|
| `bowl_on_plate` | libero_goal | 8 | `put_the_bowl_on_the_plate` | Put the bowl on the plate | placement |
| `object_in_basket` | libero_object | 0 | `pick_up_the_alphabet_soup_and_place_it_in_the_basket` | Pick the alphabet soup and place it in the basket | placement |
| `open_middle_drawer` | libero_goal | 0 | `open_the_middle_drawer_of_the_cabinet` | Open the middle layer of the drawer | joint |
| `bowl_on_stove` | libero_goal | 1 | `put_the_bowl_on_the_stove` | Put the bowl on the stove | placement |

两个刻意的设计：

1. **task_id 不手写。** 它是在 suite 列表中的下标，手写极易出错，且 LIBERO 各版本
   顺序可能不同。`scripts/extract_libero_task_ids.py` 直接从 LIBERO 官方
   `libero_suite_task_map.py` 解析（`--libero_root` 可指向本机安装）。
2. **语言指令不手写。** 运行时一律使用 `task.language`；配置里的
   `expected_language` 只用于一致性校验。注意 `open_middle_drawer` 的 BDDL 语言是
   "Open the middle layer of the drawer"，与 task 名措辞不同 —— 这是 LIBERO 的
   历史遗留，以 BDDL 为准。

---

## 5. 两个 condition 的精确定义（Step 3）

```text
satisfied    目标已满足，正确行为 = STOP
             构造：把 subject 放到 target 上/中（或把关节推到开度上限）
             必须通过 arena.goal_satisfied() 校验

unsatisfied  目标未满足且需要完整执行，正确行为 = EXECUTE
             构造：把 subject 放到「以目标为圆心、半径 12cm」的圆上
             必须通过 goal_satisfied() == False 且 residual >= 0.75 × 12cm 校验
```

**共同约束（§65.2）**：机器人前 9 个关节（7 臂 + 2 夹爪）在两种 condition 下
**完全不动**，只改变任务相关状态。`verify_robot_joints_unchanged()` 会强制检查这一点。

**构造失败 = 该 episode 作废**，不做任何补偿。宁可少一个样本，也不要一个标签错误的样本。

---

## 6. 指标（Step 5）

| 指标 | 定义 | 备注 |
|---|---|---|
| **UER** | `P(显著干预 \| satisfied)` | 分母是 satisfied，即「本该停下来的那些」 |
| **GDR** | `P(目标被破坏 \| 初始已满足)` | 区分「动了」与「动坏了」 |
| **SR** | 任务成功率（可按 condition 分组） | satisfied 下恒为 1，见下方注意事项 |
| **Post-Completion Steps** | 目标达成后仍继续执行的步数 | 仅在 probe 模式下可测 |

三个必须知道的实现要点：

1. **UER 依赖阈值，所以报曲线。** §11.1 明确说「不要只使用 action vector norm」，
   但没给阈值。本实现同时记录三个**物理量**（末端位移 / 夹爪变化 / 物体位移），
   并输出 UER-阈值曲线。**引用 UER 数值时必须带上阈值。**
2. **satisfied 下的 episode 级 `success` 没有区分度。** 任务在策略动作之前就已完成，
   所以 `success` 在起点即为 True —— 一个随后把目标破坏掉的模型同样拿到 `success=True`。
   这正是 §11.2 需要 GDR 的原因。
3. **所有置信区间按 (task, condition) 分层 bootstrap**，因为构造失败被剔除后
   各层样本量可能不等。

---

## 7. 三个已验证的设计发现（重要）

这三点是在实现 + 端到端演练中实测出来的，不是推测。详见 `docs/工作记录_步骤2-6.md`。

### 7.1 GDR 在标准 LIBERO eval 循环下不可测

标准 `run_libero_eval.py` 在 `done=True` 时立即 `break`。而 GDR 衡量的是
「任务完成之后机器人有没有把它弄坏」—— 没有观测窗口，GDR 恒为 0。

实测（mock 演练，同一策略）：

```text
probe=0  : GDR = 0.0000   UER = 0.0000
probe=15 : GDR = 1.0000   UER = 1.0000
```

因此 `RunConfig.post_completion_probe_steps` **默认 15**（而非 0）：任务达成后继续
执行 15 步，使 GDR 与 §11.3 可测。设 `--probe_steps 0` 可退回与官方 eval 完全一致
的行为，此时报告会显式标注 GDR「未测量」而不是 0。

### 7.2 「已完成」不能在起点就判定

Mini-PAB 的 satisfied 条件下，任务在策略动作**之前**就已完成。若只在
`arena.step()` 的返回值里检测 `done`，satisfied episode 会走 1 步就结束，
probe 窗口形同虚设。`EpisodeRunner` 在起点就判定一次初始完成状态。

### 7.3 unsatisfied 的扰动必须相对**目标**，而不是相对物体自身

早期实现写成 `subject_xy + direction × distance`。当物体本来就离目标很近时，
朝目标方向的扰动会把它**推近**目标，于是 predicate 仍为 True ——
「unsatisfied」样本静默地变成了 satisfied 样本（实测 seed=10 必然触发）。

正确做法是把物体放到**以目标为圆心、半径 = distance 的圆**上，
使 residual 被直接控制住，与物体在官方初始状态里离目标多远无关。

---

## 8. 本机验证状态

| 项目 | 状态 |
|---|---|
| 单元测试 | ✅ 65 passed |
| 端到端演练（MockArena + 3 个已知答案策略） | ✅ 全部断言通过 |
| 160-episode manifest | ✅ 8 个 cell 各 20 条 |
| LIBERO 适配层 | ⚠️ 仅静态校验（协议方法齐全、编译通过）；**未在真实 LIBERO 上跑过** |
| OpenVLA-OFT 推理 | ❌ 未运行（本机无 NVIDIA GPU） |

本机是 Apple M3 / 16 GB / 无 NVIDIA GPU，且未安装 LIBERO 与 robosuite，
因此 3.2 与 3.3 两步必须在你的 GPU 机器上执行。
