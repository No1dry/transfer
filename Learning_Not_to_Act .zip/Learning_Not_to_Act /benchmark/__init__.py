"""Mini-PAB: 执行方案 §69 第 2-6 步的现象验证层。

模块划分
--------
先讲清楚哪些东西在本机（CPU/Mac）能跑，哪些必须在 GPU 机器上跑 ——
这决定了每个模块被设计成什么样子。

构造层（本机可跑、可单测）:
    tasks.registry      读 configs/mini_pab.yaml -> TaskSpec
    states.mujoco_state MuJoCo free joint 状态读写（纯函数，可单测）
    states.builder      构造 satisfied / unsatisfied 初始状态
    arena.protocol      环境抽象接口 + MockArena（可单测）
    arena.libero        LIBERO 真实环境适配（仅仿真，CPU 即可）
    metrics             UER / GDR / Post-Completion Steps（纯函数，可单测）

推理层（需要 GPU 机器）:
    arena.protocol 中 policy 只需实现 Policy.predict()，本层不依赖任何
    具体 VLA。policy/ 下给出 OpenVLA-OFT 适配器与 dummy 参考实现。
"""

from __future__ import annotations

__version__ = "0.1.0"
