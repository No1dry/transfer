"""环境抽象层。

为什么需要这一层
----------------
执行方案的硬约束是：**benchmark ground truth 必须来自 simulator state，不能用 VLM**
（§10）。但仿真环境（LIBERO + robosuite + MuJoCo）在开发机上往往装不了。
所以这里定义最小接口 ``Arena``，让上层（状态构造、episode 运行、指标计算）
只依赖接口，从而：

  * ``MockArena``  —— 纯 Python，本机可跑，用于单测与端到端演练
  * ``LiberoArena``—— 真实 LIBERO 适配，在装了 LIBERO 的机器上跑

两者的行为契约必须一致。凡是上层用到的能力，都必须出现在 ``Arena`` 协议里。
"""

from benchmark.arena.protocol import Arena, Observation, StepResult
from benchmark.arena.mock import MockArena

__all__ = ["Arena", "Observation", "StepResult", "MockArena"]


def __getattr__(name: str):
    """``LiberoArena`` 延迟导入：没有 LIBERO 的环境下不应因为 import 失败。"""
    if name == "LiberoArena":
        from benchmark.arena.libero import LiberoArena

        return LiberoArena
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
