"""``LiberoArena``：真实 LIBERO + robosuite 环境的适配器。

运行前提（GPU 机器）
--------------------
    pip install -e LIBERO
    pip install -r openvla-oft/experiments/robot/libero/libero_requirements.txt

本模块**不导入 torch** —— 它只驱动仿真，因此可以在任何装了 LIBERO 的
CPU 机器上单独跑（用于构造状态、验证 predicate、检查初始画面）。

关键设计
--------
1. ``goal_satisfied()`` 直接调用 robosuite 的 ``env.check_success()``。
   这是 LIBERO 自己的 success predicate，也就是 **simulator ground truth**，
   满足 §10 "不使用 VLM 作为主要 ground truth" 的要求。
   我们没有重写 predicate —— 重写会引入与官方不一致的风险。
2. ``reset(official_init_index=i)`` 使用 LIBERO 官方的
   ``task_suite.get_task_init_states(task_id)[i]``，与官方 eval 的
   ``initial_states[episode_idx]`` 语义一致，保证可复现。
3. 机器人关节在构造状态时不被改动；本类额外记录初始 eef / gripper 位置，
   以便 UER 判定使用**物理位移**而不是 action norm。
"""

from __future__ import annotations

import os
import sys
from typing import Any, Sequence

import numpy as np

from benchmark.arena.protocol import Observation, StepResult
from benchmark.states import mujoco_state as ms
from benchmark.states.mujoco_state import task_joint_range_span


class LiberoArena:
    """把 LIBERO 的 ``OffScreenRenderEnv`` 适配成 ``Arena``。

    参数
    ----
    task_suite_name:
        例如 ``libero_goal``。
    task_id:
        ``task_suite.get_task(task_id)`` 的下标。
    openvla_oft_root:
        openvla-oft 仓库根目录。用于复用其 ``libero_utils``（图像预处理、
        dummy action）。这一步很重要：**图像预处理必须与训练一致**，
        否则策略看到的输入分布和它训练时不同，baseline 会被人为削弱。
    env_img_res:
        渲染分辨率，官方 eval 用 256。
    num_steps_wait:
        让物体稳定的空转步数，官方 eval 用 10。
    """

    def __init__(
        self,
        task_suite_name: str,
        task_id: int,
        *,
        openvla_oft_root: str | None = None,
        env_img_res: int = 256,
        num_steps_wait: int = 10,
        seed: int = 0,
        subject: str | None = None,
        target: str | None = None,
        joint_name: str | None = None,
        residual_kind: str = "placement",
        model_family: str = "openvla",
    ):
        self._task_suite_name = task_suite_name
        self._task_id = int(task_id)
        self._env_img_res = int(env_img_res)
        self._num_steps_wait = int(num_steps_wait)
        self._subject = subject
        self._target = target
        self._joint_name = joint_name
        self._residual_kind = residual_kind
        self._model_family = model_family

        self._setup_imports(openvla_oft_root, seed)

        # task 与 suite
        from libero.libero import benchmark  # type: ignore

        benchmark_dict = benchmark.get_benchmark_dict()
        if task_suite_name not in benchmark_dict:
            raise KeyError(f"未知 LIBERO suite {task_suite_name!r}；可用 {sorted(benchmark_dict)}")
        self._task_suite = benchmark_dict[task_suite_name]()
        self._task = self._task_suite.get_task(self._task_id)

        self.task_id = f"{task_suite_name}#{self._task_id}"
        self.task_language = self._task.language

        # 环境
        bddl_file = os.path.join(
            self._get_libero_path("bddl_files"), self._task.problem_folder, self._task.bddl_file
        )
        env_args = {
            "bddl_file_name": bddl_file,
            "camera_heights": self._env_img_res,
            "camera_widths": self._env_img_res,
        }
        from libero.libero.envs import OffScreenRenderEnv  # type: ignore

        self._env = OffScreenRenderEnv(**env_args)
        # 官方 eval 的做法：seed 会影响物体位置，即使使用固定 initial state
        self._env.seed(seed)

        # 缓存官方初始状态（每 task 50 个）
        self._init_states = np.asarray(self._task_suite.get_task_init_states(self._task_id))

        # 取原始 mujoco model/data。
        #
        # robosuite 的 ``sim.model`` 是 ``MjModel`` 包装器，不同版本暴露的属性和
        # 数组布局不一致；而 ``benchmark.states.mujoco_state`` 是按原生
        # mujoco>=3.0 的接口写的（``jnt_qposadr`` / ``geom_rbound`` …）。
        # 所以优先取原生对象，取不到再退回包装器。
        self.model = self._raw_model()
        self._data = self._raw_data()
        if not hasattr(self.model, "jnt_qposadr"):
            raise RuntimeError(
                "拿到的 model 不是原生 mujoco.MjModel（缺少 jnt_qposadr）。"
                "状态编辑依赖原生接口；请检查 robosuite / mujoco 版本，"
                "或在 LiberoArena._raw_model 中补充适配。"
            )

        self._episode_start: dict[str, Any] = {}
        self._max_disp = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        # v2 累计量：路径长度需要"上一步的信号"，逐 step 累加
        self._path = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._prev_signal: dict[str, Any] | None = None
        self._cumulative_measured = False
        # 关节通道：max / path / normalized 三件套（§3.2、§3.5）
        self._joint = {"max": 0.0, "path": 0.0, "normalized_max": 0.0,
                       "range_span": float("nan"), "prev": None}
        # contact 通道（§4.4 / mentor_review_2 §4）：subject / target 分开记，
        # 每组各自 measured / ever / first_step / n_steps。measured 与 ever 必须分开。
        self._contact: dict[str, Any] = self._new_contact_state()
        self._task_geom_cache: set[int] | None = None
        self._robot_geom_cache: set[int] | None = None
        self._last_obs_raw: dict[str, Any] = {}
        self._last_obs_source: str = ""
        self._satisfied_cache: bool | None = None
        self._official_robot_qpos: np.ndarray | None = None
        # reset 结果缓存：LIBERO 的 env.reset() 要重建整个场景，
        # 实测首次 ~29s、后续 ~8s，是整条流水线里最贵的单步操作。
        # Mini-PAB 里同一个 (task, seed) 会被 satisfied 与 unsatisfied
        # 各 reset 一次，缓存后第二次直接写回状态，省掉一半时间。
        self._reset_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
        # 是否允许在 episode 已终止后继续 step。
        #
        # robosuite 在成功那一刻会设 env.done=True，之后任何 env.step() 都会抛
        # "executing action in terminated episode"。而 Mini-PAB 恰恰需要在
        # **任务达成之后**继续观察机器人会不会去抓 —— 这正是 §11.3 与 GDR 的
        # 观测窗口。所以探针期间要把 done 清掉，让仿真继续跑。
        self._allow_after_done = False
        # 目标状态推断的缓存（见 _infer_joint_goal / _infer_placement_goal）
        self._joint_goal_value: float | None = None
        self._goal_anchor: np.ndarray | None = None

    # ------------------------------------------------------------------
    # 初始化辅助
    # ------------------------------------------------------------------

    @staticmethod
    def _setup_imports(openvla_oft_root: str | None, seed: int) -> None:
        if openvla_oft_root:
            root = os.path.abspath(openvla_oft_root)
            if root not in sys.path:
                sys.path.insert(0, root)

    @staticmethod
    def _get_libero_path(key: str) -> str:
        from libero.libero import get_libero_path  # type: ignore

        return get_libero_path(key)

    def _raw_model(self):
        """取原生 ``mujoco.MjModel``。"""
        sim = self._env.sim
        for attr in ("_model", "model"):
            obj = getattr(sim, attr, None)
            if obj is None:
                continue
            if hasattr(obj, "jnt_qposadr"):  # 已经是原生对象
                return obj
            inner = getattr(obj, "_model", None)
            if inner is not None and hasattr(inner, "jnt_qposadr"):
                return inner
        raise RuntimeError("无法从 robosuite sim 中取到原生 mujoco.MjModel")

    def _raw_data(self):
        """取原生 ``mujoco.MjData``。"""
        sim = self._env.sim
        for attr in ("_data", "data"):
            obj = getattr(sim, attr, None)
            if obj is None:
                continue
            if hasattr(obj, "geom_xpos"):  # 已经是原生对象
                return obj
            inner = getattr(obj, "_data", None)
            if inner is not None and hasattr(inner, "geom_xpos"):
                return inner
        raise RuntimeError("无法从 robosuite sim 中取到原生 mujoco.MjData")

    def _libero_utils(self):
        """复用 openvla-oft 的 libero_utils（保证图像预处理与训练一致）。"""
        try:
            from experiments.robot.libero.libero_utils import (  # type: ignore
                get_libero_dummy_action,
                get_libero_image,
                get_libero_wrist_image,
                quat2axisangle,
            )
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "无法导入 openvla-oft 的 experiments.robot.libero.libero_utils。"
                "请通过 openvla_oft_root 参数指定 openvla-oft 仓库根目录，"
                "并确认其依赖已安装。这也保证了图像预处理与训练一致。"
            ) from exc
        return get_libero_dummy_action, get_libero_image, get_libero_wrist_image, quat2axisangle

    # ------------------------------------------------------------------
    # 观测 / 状态
    # ------------------------------------------------------------------

    def _ensure_obs(self) -> dict[str, Any]:
        """保证 ``_last_obs_raw`` 有值，并返回它。

        注意：robosuite 的 ``OffScreenRenderEnv`` **没有** ``get_observation()``
        方法（早期实现误以为有）。取观测只有两条路：
          * ``env.step(action)`` 的返回值
          * ``env.reset()`` 的返回值
        这里用 reset 作为兜底，并用 no-op 动作触发一次渲染，代价可接受
        （只在没有缓存观测时发生一次）。
        """
        if self._last_obs_raw:
            return self._last_obs_raw

        get_libero_dummy_action, _, _, _ = self._libero_utils()
        self._env.reset()
        obs, _, _, _ = self._env.step(get_libero_dummy_action(self._model_family))
        self._last_obs_raw = obs
        return obs

    def get_observation(self) -> Observation:
        _, get_libero_image, get_libero_wrist_image, quat2axisangle = self._libero_utils()
        obs = self._ensure_obs()

        full = get_libero_image(obs)
        wrist = get_libero_wrist_image(obs)
        state = np.concatenate(
            (
                obs["robot0_eef_pos"],
                quat2axisangle(obs["robot0_eef_quat"]),
                obs["robot0_gripper_qpos"],
            )
        )
        return Observation(full_image=full, wrist_image=wrist, state=state, raw=obs)

    def get_state(self) -> np.ndarray:
        return np.asarray(self._env.sim.get_state().flatten(), dtype=np.float64).copy()

    def _reset_solver_warmstart(self) -> None:
        """复位 MuJoCo 约束求解器的 warm-start 缓存（``qacc_warmstart``）。

        为什么必须做：``set_state_from_flattened`` 只恢复 qpos/qvel 等积分状态，
        **不会**清 ``qacc_warmstart``——它是求解器上一次的加速度解，会作为下一次
        求解的初值。于是"同一 seed、同一动作"会因**前面跑过什么**而给出不同轨迹。

        实测：unsatisfied seed 0 在两种运行顺序下 ``raw想合`` 分别是 93 和 75，
        而状态构造本身是确定的（``scripts/check_state_determinism.py`` 显示
        两次构造的碗位差 < 1e-9）。所以差异来自求解器残留，不是状态构造。

        这属于可复现性问题：不修的话"seed"不能唯一确定实验条件。
        """
        try:
            self._env.sim.data.qacc_warmstart[:] = 0.0
        except Exception:  # noqa: BLE001
            pass

    def _reset_controller_goals(self) -> list[str]:
        """把机器人控制器的内部目标复位到**当前**位姿。

        为什么要做：Mini-PAB 是"瞬移"机器人（``set_state_from_flattened``），
        但 robosuite 的 OSC 控制器保留着上一次的目标位姿和内部状态。
        不复位的话，瞬移之后控制器会继续朝**旧目标**施力，
        于是"前面跑过什么 episode"就会影响后面的轨迹 —— 即使初始状态完全相同。

        返回被复位的控制器类名，便于日志/断言。
        """
        done: list[str] = []
        for holder in (self._env, getattr(self._env, "env", None)):
            robots = getattr(holder, "robots", None) if holder is not None else None
            if not robots:
                continue
            for rb in robots:
                ctrl = getattr(rb, "controller", None)
                if ctrl is not None and hasattr(ctrl, "reset_goal"):
                    try:
                        ctrl.reset_goal()
                        done.append(type(ctrl).__name__)
                    except Exception:  # noqa: BLE001
                        pass
            if done:
                break
        return done

    def _refresh_robot_controller_state(self) -> None:
        """让 controller 的内部运动学缓存与当前 sim state 对齐（不推进物理）。

        `controller.update(force=True)` 只重算正运动学与力矩，不 step 仿真；
        `physics_not_advanced` 断言会守住这一点。
        """
        for holder in (self._env, getattr(self._env, "env", None)):
            robots = getattr(holder, "robots", None) if holder is not None else None
            if not robots:
                continue
            for rb in robots:
                ctrl = getattr(rb, "controller", None)
                if ctrl is None:
                    continue
                for kwargs in ({"force": True}, {}):
                    try:
                        ctrl.update(**kwargs)
                        break
                    except TypeError:
                        continue
                    except Exception:  # noqa: BLE001
                        break
            return

    def _refresh_observation_from_current_state(self) -> dict[str, Any]:
        """把 ``_last_obs_raw`` 刷新成与**当前 sim state** 一致的 observation。

        为什么必须做（mentor_review_3 §2.1）：
        ``set_state(..., settle_steps=0)`` 时循环体一次都不执行，
        ``obs`` 保持 ``None``，于是 ``_last_obs_raw`` **完全不更新**；
        而 ``get_observation()`` 又会优先复用旧缓存。结果是一个"混合状态"：
        物体/关节来自新 sim state，**EEF / 夹爪 / 相机图像 / 策略首帧输入
        却来自上一段旧轨迹**。

        实测后果（smoke-v2，16 条 trace）：
          - policy step0 的 EEF 在 6/8 条上逐位相同 = 环境 home 位姿，不是终态；
          - step0→step1 出现 0.27–0.33 m 的伪跳变，而真实单步位移
            median 0.0019 / max 0.0124 m —— 大了 25–170 倍；
          - no-op step0 与前一条 policy 末帧 **8/8 逐位相同**（差 0.00000000）。
        更严重的是策略**首个 action chunk 用的是旧图像**，
        所以整条闭环轨迹都不是对 terminal state 的响应。

        实现要求（§4.1 / §4.2）：
          - 沿 ``.env`` 链找**支持 ``force_update=True``** 的内层 robosuite env；
            LIBERO 的 wrapper 自己的 ``_get_observations()`` 不接受该参数；
          - 调用后**不推进物理**（调用方负责断言 state 未变，见 set_state）；
          - 找不到就**抛可读错误**，绝不静默复用旧缓存 —— 静默复用正是本 bug 的成因。
        """
        # robosuite 的 `_get_observations` 里 `robot0_eef_pos` 取自
        # **controller 的缓存**（controller.update() 时才算），不是直接读 site_xpos。
        # 瞬移机器人后如果不同步刷新 controller，观测里的 EEF 会残留旧值
        # （实测残差 ~0.6 mm —— 远小于 stale 现象的 0.28 m，但仍是系统性偏差）。
        self._refresh_robot_controller_state()

        obj = self._env
        depth = 0
        tried: list[str] = []
        while obj is not None and depth < 5:
            fn = getattr(obj, "_get_observations", None)
            if fn is not None:
                tried.append(type(obj).__name__)
                try:
                    obs = fn(force_update=True)
                except TypeError:
                    # 该层不支持 force_update（例如 LIBERO wrapper）—— 继续往内找。
                    obs = None
                if obs:
                    # 内层 obs 可能缺少 wrapper 额外加的键：合并而不是替换
                    merged = dict(self._last_obs_raw or {})
                    merged.update(dict(obs))
                    self._last_obs_source = type(obj).__name__
                    return merged
            obj = getattr(obj, "env", None)
            depth += 1
        raise RuntimeError(
            "无法在不推进物理的前提下刷新 observation："
            f"在 .env 链上试过 {tried}，没有任何一层支持 _get_observations(force_update=True)。"
            "拒绝静默复用旧缓存（那会导致 policy 首帧输入与 sim state 不一致）。"
        )

    def set_state(self, state: Sequence[float], *, settle_steps: int = 0) -> Observation:
        state = ms.as_state_array(state)
        self._env.sim.set_state_from_flattened(state)
        # 必须按顺序：先清 warm-start，再 forward，最后复位控制器目标
        self._reset_solver_warmstart()
        self._env.sim.forward()
        self._reset_controller_goals()
        get_libero_dummy_action, _, _, _ = self._libero_utils()
        # ★ mentor_review_3 §4.1：无论 settle_steps 是否为 0，都必须让
        #   `_last_obs_raw` 与当前 sim state 一致，否则策略首帧输入是旧观测。
        self._last_obs_raw = self._refresh_observation_from_current_state()
        obs = None
        for _ in range(settle_steps):
            obs, _, _, _ = self._env.step(get_libero_dummy_action(self._model_family))
        if obs is not None:
            self._last_obs_raw = obs
        self._satisfied_cache = None
        return self.get_observation()

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def mark_episode_start(self) -> None:
        """建立 UER/GDR 位移基线（见 ``Arena.mark_episode_start`` 的契约说明）。

        必须读取**当前** obs，而不是假定机器人处于官方 reset 位姿 ——
        因为 Mini-PAB 的初始状态是构造出来的。
        """
        obs = self._ensure_obs()
        self._last_obs_raw = obs
        self._max_disp = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._path = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._cumulative_measured = False
        # 关节通道：最大偏离与累计路径是**两个不同的量**，
        # 只记 "末端 - 起点" 会漏掉"先推开再拉回"这种重执行行为。
        self._joint = {"max": 0.0, "path": 0.0, "normalized_max": 0.0,
                       "range_span": float("nan"), "prev": None}
        # contact：subject / target 分开记，每组各自 measured / ever / first_step / n_steps。
        # measured 与 ever 必须分开（未测量 ≠ 没接触）。
        self._contact = self._new_contact_state()
        start_subject = self._subject_position()
        start_grip = np.array(obs["robot0_gripper_qpos"], dtype=np.float64).copy()
        start_eef = np.array(obs["robot0_eef_pos"], dtype=np.float64).copy()
        start_joint = None
        if self._joint_name:
            try:
                start_joint = float(
                    ms.get_joint_pos(self.get_state(), self.model, self._joint_name)
                )
            except Exception:  # noqa: BLE001
                start_joint = None
        self._joint["prev"] = start_joint
        self._joint["range_span"] = self._task_joint_range_span()
        self._episode_start = {
            "eef": start_eef,
            "gripper": start_grip,
            "subject": start_subject,
            "satisfied": self.goal_satisfied(),
            "task_joint": start_joint,
            "step": 0,
            "gripper_open_ref": self._gripper_open_reference(),
        }
        # §3.1 修复：把 `_prev_signal` 初始化为**起点本身**，而不是 None。
        # 原来设 None 会让第一次 step() 只建立参考点、不累计
        # "起点 → 第一步"的那段路径，于是路径长度系统性地少一段。
        self._prev_signal = {
            "eef": start_eef.copy(),
            "gripper": start_grip.copy(),
            "subject": None if start_subject is None else np.array(start_subject, dtype=np.float64).copy(),
        }

    def reset(self, official_init_index: int = 0) -> Observation:
        get_libero_dummy_action, _, _, _ = self._libero_utils()

        idx = int(official_init_index) % len(self._init_states)

        # 命中缓存：直接写回当时的状态，跳过昂贵的场景重建
        if idx in self._reset_cache:
            state, robot_qpos = self._reset_cache[idx]
            self._env.sim.set_state_from_flattened(state)
            self._reset_solver_warmstart()
            self._env.sim.forward()
            # robosuite 没有"只取观测"的接口，必须走一次 step 才会渲染出图像。
            # 用 no-op 动作，对状态的影响可忽略（与官方 eval 收尾的 dummy step 同性质）。
            obs, _, _, _ = self._env.step(get_libero_dummy_action(self._model_family))
            self._last_obs_raw = obs
            self._satisfied_cache = None
            self._official_robot_qpos = robot_qpos
            self._initial_init_index = idx
            self.mark_episode_start()
            return self.get_observation()

        self._env.reset()
        init_state = self._init_states[idx]
        obs = self._env.set_init_state(init_state)

        # 官方 eval：先空转若干步让物体稳定
        for _ in range(self._num_steps_wait):
            obs, _, _, _ = self._env.step(get_libero_dummy_action(self._model_family))

        self._last_obs_raw = obs
        self._satisfied_cache = None
        self._initial_init_index = idx
        self.mark_episode_start()
        self._capture_official_robot_qpos()

        # 存缓存（只留最近若干个，避免无限增长）
        assert self._official_robot_qpos is not None
        if len(self._reset_cache) >= 64:
            self._reset_cache.pop(next(iter(self._reset_cache)))
        self._reset_cache[idx] = (
            self.get_state(),
            self._official_robot_qpos.copy(),
        )
        return self.get_observation()

    def set_allow_after_done(self, allow: bool) -> None:
        """允许/禁止在 episode 已终止后继续 step（见 _allow_after_done 说明）。"""
        self._allow_after_done = bool(allow)

    def _clear_done_flags(self) -> list[str]:
        """把 done 标志清掉，让仿真能在 episode 终止后继续。

        为什么不能只清 ``self._env.done``：``self._env`` 是 LIBERO 的
        **wrapper**（``libero/envs/env_wrapper.py``），它自己往往没有 ``done``
        属性；真正被 robosuite 检查的是**内层** env（``self._env.env``）。
        只清 wrapper 等于空操作 —— 这就是"探针模式看起来生效、却仍然炸
        ``executing action in terminated episode``"的原因。

        所以这里顺着 ``.env`` 链逐层清，返回实际被清掉的类名，便于断言/日志。
        """
        cleared: list[str] = []
        obj = self._env
        for _ in range(4):  # wrapper -> bddl -> robosuite base，留够层数即可
            if obj is None:
                break
            if getattr(obj, "done", None):
                try:
                    obj.done = False
                    cleared.append(type(obj).__name__)
                except Exception:  # noqa: BLE001
                    pass
            obj = getattr(obj, "env", None)
        return cleared

    def step(self, action: Sequence[float]) -> StepResult:
        action = np.asarray(action, dtype=np.float64).reshape(-1)
        assert action.shape[0] == 7, f"LIBERO 动作应为 7 维，实际 {action.shape}"

        # 探针模式：把上一步设下的 done 清掉，否则 robosuite 会拒绝继续仿真
        if self._allow_after_done:
            self._clear_done_flags()

        obs, reward, done, info = self._env.step(action.tolist())
        self._last_obs_raw = obs
        self._satisfied_cache = None
        # 步计数器：contact 的 first_step 需要它（§4.4）
        if self._episode_start:
            self._episode_start["step"] = int(self._episode_start.get("step", 0)) + 1
        self._update_displacement(obs)
        return StepResult(obs=self.get_observation(), reward=float(reward), done=bool(done), info=info or {})

    def no_op_action(self) -> list[float]:
        get_libero_dummy_action, _, _, _ = self._libero_utils()
        return list(get_libero_dummy_action(self._model_family))

    def render_frame(self):
        """返回当前第三人称画面。

        直接复用最近一次 step 已渲染的 obs，**不额外渲染** ——
        EGL 渲染约 350ms/帧，为了录像再渲染一次会让整轮实验慢一倍。
        """
        if not self._last_obs_raw:
            return None
        _, get_libero_image, _, _ = self._libero_utils()
        return get_libero_image(self._last_obs_raw)

    # ------------------------------------------------------------------
    # Ground truth
    # ------------------------------------------------------------------

    def goal_satisfied(self) -> bool:
        """LIBERO / robosuite 自己的 success predicate。"""
        if self._satisfied_cache is None:
            self._satisfied_cache = bool(self._env.check_success())
        return self._satisfied_cache

    # ------------------------------------------------------------------
    # 目标状态推断
    # ------------------------------------------------------------------

    def set_joint_goal_value(self, joint_key: str, value: float) -> None:
        """由 StateBuilder 在构造 satisfied 状态时告知"哪一端才是目标"。

        为什么需要这个：``residual()`` 要度量"离目标还有多远"，
        但 LIBERO 只暴露二值 success predicate，不告诉我们目标位置。
        而且关节的"打开"方向是场景相关的 —— 实测抽屉 range 是 [-0.16, 0.01]，
        打开对应 **负端**。所以方向必须由构造时的 predicate 探测结果决定，
        不能写死。
        """
        self._joint_goal_value = float(value)

    def _infer_joint_goal(self, joint_key: str) -> float | None:
        """关节任务：用 predicate 探测 range 两端，判断哪一端是目标。

        只在首次需要时做一次，结果缓存。
        """
        if self._joint_goal_value is not None:
            return self._joint_goal_value

        model = self.model
        try:
            lo, hi = ms.get_joint_range(model, joint_key)
        except (KeyError, ValueError, TypeError):
            return None

        saved = self.get_state()
        probe_value = None
        for value in (hi, lo):
            state = ms.set_joint_pos(saved, model, joint_key, value)
            state = ms.clear_all_velocities(state, ms.StateLayout.from_model(model))
            self.set_state(state, settle_steps=0)
            if bool(self.goal_satisfied()):
                probe_value = float(value)
                break

        # 恢复现场 —— 推断过程绝不能改变调用方的状态
        self.set_state(saved, settle_steps=0)
        self._joint_goal_value = probe_value
        return probe_value

    def _infer_placement_goal(self) -> None:
        """placement 任务：把 subject 放到 target 水平的正上方，以此作为目标锚点。

        目标锚点只需要 xy（residual 用 3D 距离，z 由 settle 决定），
        所以直接取 target 的当前 xy 即可。
        """
        if self._goal_anchor is not None or not (self._subject and self._target):
            return
        try:
            self._goal_anchor = self._entity_pos(self._target)
        except (KeyError, TypeError):
            self._goal_anchor = None

    def _entity_pos(self, name_or_prefix: str) -> np.ndarray:
        """取物体（自由关节）或 fixture（body）的世界坐标。"""
        state = self.get_state()
        try:
            return ms.get_object_pos(state, self.model, name_or_prefix)
        except KeyError:
            return self._body_pos(name_or_prefix)

    def residual(self) -> float:
        """到目标的残差 D(s,l)。

        与 ``goal_satisfied`` 不同，这里需要自己算 —— 因为 LIBERO 只暴露二值
        success predicate，不暴露连续残差。M2 的连续标签 n_t 依赖这个量。

        目标的定义是**推断**出来的（见 _infer_joint_goal / _infer_placement_goal），
        而不是写死的参考值，这样在不同场景/不同关节方向下都成立。
        """
        model = self.model

        if self._residual_kind == "joint":
            if not self._joint_name:
                raise ValueError("residual_kind='joint' 需要 joint_name")
            joint_key = self._joint_name
            try:
                joint_key = ms.resolve_single_dof_joint(model, self._joint_name).name
            except KeyError:
                pass

            q = ms.get_joint_pos(self.get_state(), model, joint_key)
            goal = self._infer_joint_goal(joint_key)
            if goal is None:
                # 推断不出来时退化为"到 range 两端的最大距离"，只作为兜底
                lo, hi = ms.get_joint_range(model, joint_key)
                return float(max(abs(hi - q), abs(q - lo)))
            return float(abs(goal - q))

        if not (self._subject and self._target):
            raise ValueError("residual_kind='placement' 需要 subject 与 target")

        self._infer_placement_goal()
        p_sub = self._entity_pos(self._subject)
        if self._goal_anchor is None:
            return float("nan")
        return float(np.linalg.norm(p_sub - self._goal_anchor))

    # ------------------------------------------------------------------
    # UER 信号
    # ------------------------------------------------------------------

    def entity_pos(self, name_or_prefix: str) -> np.ndarray:
        """取实体世界坐标：自由物体读 qpos，fixture 读 body 世界位姿。"""
        try:
            return ms.get_object_pos(self.get_state(), self.model, name_or_prefix)
        except KeyError:
            return self._body_pos(name_or_prefix)

    def _body_pos(self, name_or_prefix: str) -> np.ndarray:
        """取 body 的**世界坐标**。

        这里踩过一个很隐蔽的坑，值得写清楚：

        robosuite 的 ``binding_utils`` 暴露的 ``data.xpos`` 是 **body 局部坐标**
        （相对父 body），**不是世界坐标**。实测：

            body                     sim.data.get_body_xpos (世界)     data.xpos (局部)
            flat_stove_1_main        [-0.404, 0.202, 0.905]            [0, 0, 0]
            plate_1_main             [ 0.049,-0.027, 0.903]            [0, 0, 0]
            table                    [ 0.000, 0.000, 0.875]            [0, 0, 0.875]

        危害：对 **fixture**（stove、cabinet 等没有自由关节的物体）取位置时，
        ``data.xpos`` 返回 [0,0,0]，于是"把碗放到炉子上"实际把碗放到了桌子原点 ——
        satisfied 构造 20 个 seed 里 19 个失败，而表面看只是"构造不出来"。
        自由物体（plate、bowl）走 ``get_object_pos`` 读 qpos，所以没暴露这个问题。

        正确读法是 ``sim.data.get_body_xpos(name)``（robosuite 会做世界坐标换算）。
        """
        body_id = ms.find_body_id(self.model, name_or_prefix)
        name = ms.body_name(self.model, body_id)
        try:
            return np.asarray(self._env.sim.data.get_body_xpos(name), dtype=np.float64)
        except Exception:  # noqa: BLE001 - 退回到原始 data，但明确标注不可靠
            return np.array(self._data.xpos[body_id], dtype=np.float64)

    def _subject_position(self) -> np.ndarray | None:
        if self._residual_kind == "joint":
            if not self._joint_name:
                return None
            return np.array([ms.get_joint_pos(self.get_state(), self.model, self._joint_name)])
        if not self._subject:
            return None
        try:
            return ms.get_object_pos(self.get_state(), self.model, self._subject)
        except KeyError:
            return self._body_pos(self._subject)

    def _task_joint_range_span(self) -> float:
        """任务关节的物理行程 (q_max - q_min)。

        §3.5：不同任务的关节单位不同（抽屉滑轨 = 米，炉钮铰链 = 弧度），
        统一用绝对阈值 `0.01` 没有跨任务物理意义。
        用行程把它归一化成"占全行程的百分比"才可比。
        """
        if not self._joint_name:
            return float("nan")
        return task_joint_range_span(self.model, self._joint_name)

    @staticmethod
    def _new_contact_state() -> dict[str, Any]:
        """contact 累加器的**唯一定义**（subject / target / any 各一组）。

        踩过的坑：这个结构在 `__init__` 与 `mark_episode_start` 里各写了一份，
        改了一处漏了另一处，结果 `_update_displacement` 里
        `self._contact["subject"]` 直接 KeyError，整轮 smoke 全废。
        所以改成单一定义 + 两处调用（见 `tests/test_arena_v2_signals.py` 的守卫测试）。
        """
        return {
            k: {"measured": False, "ever": False, "first_step": None, "n_steps": 0}
            for k in ("subject", "target", "any")
        }

    def _geom_ids_for(self, prefix: str | None) -> set[int]:
        """body 名以 ``prefix`` 开头的所有 geom id。"""
        if not prefix:
            return set()
        ids: set[int] = set()
        try:
            model = self.model
            for gid in range(int(model.ngeom)):
                try:
                    bid = int(model.geom_bodyid[gid])
                    body = model.body_id2name(bid)
                except Exception:  # noqa: BLE001
                    continue
                if body and body.startswith(prefix):
                    ids.add(gid)
        except Exception:  # noqa: BLE001
            pass
        return ids

    def _subject_geom_ids(self) -> set[int]:
        """任务**主体**（被操作对象）的 geom id。"""
        if getattr(self, "_subject_geom_cache", None) is None:
            self._subject_geom_cache = self._geom_ids_for(self._subject)
        return self._subject_geom_cache

    def _target_geom_ids(self) -> set[int]:
        """任务**目标**（容器/灶台/盘子）的 geom id。"""
        if getattr(self, "_target_geom_cache", None) is None:
            self._target_geom_cache = self._geom_ids_for(self._target)
        return self._target_geom_cache

    def _task_object_geom_ids(self) -> set[int]:
        """任务相关 geom 集合 = subject ∪ target（**仅用于兼容汇总**）。

        mentor_review_2 §4：subject 与 target 的接触含义不同 ——
        对 bowl placement 来说，"碰到盘子/灶台" 与 "碰到碗" 是两回事，
        判断"是否重新抓取"时 subject contact 才是关键信号。
        新代码请用 ``_subject_geom_ids`` / ``_target_geom_ids`` 分开看。
        """
        ids = self._subject_geom_ids() | self._target_geom_ids()
        self._task_geom_cache = ids
        return ids

    def _robot_geom_ids(self) -> set[int]:
        """机器人侧 geom id 集合（robot0_* 与 gripper0_*）。"""
        if getattr(self, "_robot_geom_cache", None) is not None:
            return self._robot_geom_cache
        ids: set[int] = set()
        try:
            model = self.model
            for gid in range(int(model.ngeom)):
                try:
                    bid = int(model.geom_bodyid[gid])
                    body = model.body_id2name(bid)
                except Exception:  # noqa: BLE001
                    continue
                if body and (body.startswith("robot0") or body.startswith("gripper0")):
                    ids.add(gid)
        except Exception:  # noqa: BLE001
            pass
        self._robot_geom_cache = ids
        return ids

    def _contact_flags(self) -> dict[str, bool | None]:
        """当前时刻的接触情况，subject / target / any **分开**。

        mentor_review_2 §4：subject 与 target 的接触含义不同。
        对 bowl placement，"碰到盘子/灶台"和"碰到碗"是两件事；
        判断"是否重新抓取"时 subject contact 才是关键。

        返回 ``{"subject": bool|None, "target": bool|None, "any": bool|None}``。
        ``None`` = 读不到 contact 或 geom 映射不出来（**未测量**，不是"没接触"）。
        """
        try:
            contacts = self._env.sim.data.contact
        except Exception:  # noqa: BLE001
            return {"subject": None, "target": None, "any": None}
        if contacts is None:
            return {"subject": None, "target": None, "any": None}
        robot_ids = self._robot_geom_ids()
        if not robot_ids:
            return {"subject": None, "target": None, "any": None}
        sub_ids = self._subject_geom_ids()
        tgt_ids = self._target_geom_ids()
        try:
            n = int(self._env.sim.data.ncon)
        except Exception:  # noqa: BLE001
            n = len(contacts)

        hit_sub = hit_tgt = False
        saw_any_pair = False
        for i in range(n):
            try:
                c = contacts[i]
                g1, g2 = int(c.geom1), int(c.geom2)
            except Exception:  # noqa: BLE001
                continue
            if (g1 in robot_ids and g2 in sub_ids) or (g2 in robot_ids and g1 in sub_ids):
                saw_any_pair = True
                hit_sub = True
            if (g1 in robot_ids and g2 in tgt_ids) or (g2 in robot_ids and g1 in tgt_ids):
                saw_any_pair = True
                hit_tgt = True
        # 映射不出来（既没有 subject 也没有 target geom）时只能说"未测量"
        if not sub_ids and not tgt_ids:
            return {"subject": None, "target": None, "any": None}
        _ = saw_any_pair
        return {
            "subject": hit_sub,
            "target": hit_tgt,
            "any": hit_sub or hit_tgt,
        }

    def _has_task_contact(self) -> bool | None:
        """当前时刻机器人是否与任务实体（subject ∪ target）接触。

        None = 读不到 contact 数据或映射不出来。新代码请优先用
        ``_contact_flags()`` 以区分 subject / target。
        """
        return self._contact_flags()["any"]

    def _gripper_open_reference(self) -> float:
        """夹爪从全开到全闭的 L2 行程（**物理上界**）。

        §3.3：历史阈值 `gripper_change = 0.2` 被注释成"归一化单位"，
        但 `gripper_change` 实际来自真实 finger qpos，其物理行程只有
        **0.0566**（`gripper0_finger_joint{1,2}` 各 0.04，L2 合成）。
        也就是说 0.2 比物理上界还大 3.5 倍 —— 这个通道**永远不可能触发**，
        实测 160 条记录里 0 次命中（连真正成功抓取的 unsatisfied 也是 0）。

        所以必须把物理量归一化到这个行程上，阈值才有意义。
        这里直接从 model 的 joint range 读，不硬编码。
        """
        try:
            model = self.model
            total = 0.0
            for i in range(int(model.njnt)):
                nm = model.joint_id2name(i)
                if nm and "finger" in nm:
                    lo = float(model.jnt_range[i][0])
                    hi = float(model.jnt_range[i][1])
                    total += (hi - lo) ** 2
            return float(np.sqrt(total)) if total > 0 else float("nan")
        except Exception:  # noqa: BLE001
            return float("nan")

    def gripper_current_open_frac(self) -> float:
        """**当前**夹爪开度占全开行程的比例（0=全闭，1=全开）。

        ⚠️ 不要用 ``debug_signals()["gripper_change_norm"]`` 判断"是否已释放"：
        那个量是**整个过程的最大变化**（running max），抓过一次之后就永远 ~1.0，
        再也不可能判定为"已释放"。Stage 2 的稳定窗口正是踩了这个坑 ——
        predicate 在第 78 步就 True，但 stabilize 窗口到 400 步都不满足。

        这里读的是**此刻**的 finger qpos 相对 open reference 的比例。
        """
        open_ref = self._gripper_open_reference()
        if not open_ref or open_ref <= 0 or np.isnan(open_ref):
            return float("nan")
        try:
            q = np.asarray(self._last_obs_raw["robot0_gripper_qpos"], dtype=np.float64)
            return float(np.linalg.norm(q) / open_ref)
        except Exception:  # noqa: BLE001
            return float("nan")

    def _update_displacement(self, obs: dict[str, Any]) -> None:
        if not self._episode_start:
            return
        eef = np.array(obs["robot0_eef_pos"], dtype=np.float64)
        grip = np.array(obs["robot0_gripper_qpos"], dtype=np.float64)

        self._max_disp["eef"] = max(
            self._max_disp["eef"], float(np.linalg.norm(eef - self._episode_start["eef"]))
        )
        self._max_disp["gripper"] = max(
            self._max_disp["gripper"], float(np.linalg.norm(grip - self._episode_start["gripper"]))
        )

        start_sub = self._episode_start.get("subject")
        cur_sub = self._subject_position()
        if start_sub is not None and cur_sub is not None:
            self._max_disp["object"] = max(
                self._max_disp["object"], float(np.linalg.norm(cur_sub - start_sub))
            )

        # ---- v2 累计量（plan1 §7.2 D）----
        # 位移（max_disp）只说明"离开起点多远"；路径长度说明"来回跑了多少"。
        prev = self._prev_signal
        if prev is not None:
            self._path["eef"] += float(np.linalg.norm(eef - prev["eef"]))
            self._path["gripper"] += float(np.linalg.norm(grip - prev["gripper"]))
            if prev.get("subject") is not None and cur_sub is not None:
                self._path["object"] += float(np.linalg.norm(cur_sub - prev["subject"]))
        self._prev_signal = {
            "eef": eef.copy(),
            "gripper": grip.copy(),
            "subject": None if cur_sub is None else np.array(cur_sub, dtype=np.float64).copy(),
        }

        # ---- 关节通道：最大偏离 + 累计路径（§3.2）----
        if self._joint_name:
            try:
                q = float(ms.get_joint_pos(self.get_state(), self.model, self._joint_name))
            except Exception:  # noqa: BLE001
                q = None
            if q is not None:
                q0 = self._episode_start.get("task_joint")
                if q0 is not None:
                    self._joint["max"] = max(self._joint["max"], abs(q - q0))
                    span = self._joint.get("range_span")
                    if span and span > 0 and not np.isnan(span):
                        self._joint["normalized_max"] = max(
                            self._joint["normalized_max"], abs(q - q0) / span
                        )
                pq = self._joint.get("prev")
                if pq is not None:
                    self._joint["path"] += abs(q - pq)
                self._joint["prev"] = q

        # ---- contact（§4.4）----
        flags = self._contact_flags()
        step_now = int(self._episode_start.get("step", 0)) + 1
        for kind in ("subject", "target", "any"):
            v = flags.get(kind)
            if v is None:
                continue
            slot = self._contact[kind]
            slot["measured"] = True
            if v:
                slot["n_steps"] += 1
                if not slot["ever"]:
                    slot["ever"] = True
                    slot["first_step"] = step_now

        self._cumulative_measured = True

    def task_joint_change(self) -> float:
        """**保留旧语义**：相对起点的绝对变化（= max displacement）。

        为了让旧调用方不静默改变含义，这里仍返回 max displacement；
        新代码请显式使用 ``task_joint_max_displacement()`` /
        ``task_joint_path_length()`` / ``task_joint_normalized_max()``。
        """
        return float(self._joint.get("max", 0.0))

    def task_joint_max_displacement(self) -> float:
        """任务关节相对起点的最大绝对偏离（漏不掉"推过去"）。"""
        return float(self._joint.get("max", 0.0))

    def task_joint_path_length(self) -> float:
        """任务关节的累计绝对变化（能抓到"推过去又拉回来"）。"""
        return float(self._joint.get("path", 0.0))

    def task_joint_normalized_max(self) -> float:
        """最大偏离 / 关节行程 —— 跨任务可比的归一化量（§3.5）。"""
        return float(self._joint.get("normalized_max", 0.0))

    def task_joint_range_span(self) -> float:
        return float(self._joint.get("range_span", float("nan")))

    def task_contact(self) -> dict[str, Any]:
        """接触统计，**subject / target 分开**（mentor_review_2 §4）。

        返回结构::

            {
              "subject": {"measured":…, "ever":…, "first_step":…, "n_steps":…},
              "target":  {...},
              "any":     {...},
              # 兼容汇总（= subject ∪ target），旧调用方仍可用
              "measured":…, "ever":…, "first_step":…, "n_steps":…
            }

        ``measured=False`` 表示读不到 contact（**未测量**，不是"没接触"）。
        """

        def pack(kind: str) -> dict[str, Any]:
            slot = self._contact.get(kind, {})
            m = bool(slot.get("measured", False))
            return {
                "measured": m,
                "ever": bool(slot.get("ever", False)) if m else None,
                "first_step": slot.get("first_step") if m else None,
                "n_steps": int(slot.get("n_steps", 0)) if m else None,
            }

        out = {k: pack(k) for k in ("subject", "target", "any")}
        # 兼容旧字段（谁先发生用谁的 first_step）
        anyp = out["any"]
        out.update(anyp)
        return out

    def debug_signals(self) -> dict[str, float]:
        open_ref = (
            self._episode_start.get("gripper_open_ref")
            if self._episode_start
            else None
        )
        if open_ref is None:
            open_ref = self._gripper_open_reference()
        gc = self._max_disp["gripper"]
        sig = {
            "eef_max_displacement": self._max_disp["eef"],
            "gripper_change": gc,
            "gripper_open_reference": open_ref,
            # 归一化物理夹爪变化：0 = 没动，1 = 走完全行程（§3.3）
            "gripper_change_norm": (
                float(gc / open_ref) if open_ref and open_ref > 0 else float("nan")
            ),
            "object_max_displacement": self._max_disp["object"],
            "eef_path_length": self._path["eef"],
            "object_path_length": self._path["object"],
            "gripper_path_length": self._path["gripper"],
            "task_joint_max_displacement": self.task_joint_max_displacement(),
            "task_joint_path_length": self.task_joint_path_length(),
            "task_joint_normalized_max": self.task_joint_normalized_max(),
            "task_joint_range_span": self.task_joint_range_span(),
        }
        return sig

    def cumulative_measured(self) -> bool:
        """v2 累计量是否真的被测量过（用于区分"没测"与"测出来是 0"）。"""
        return bool(self._cumulative_measured)

    # ------------------------------------------------------------------

    @property
    def unnorm_key(self) -> str:
        """动作反归一化 key —— 就是 LIBERO suite 名。

        供 runner 在每条 episode 前告知策略（不同 suite 的 action 统计量不同，
        见 OpenVLAOFTAdapter.set_unnorm_key 的说明）。
        """
        return self._task_suite_name

    def max_steps(self) -> int:
        """官方 eval 对该 suite 的 max steps。"""
        try:
            from experiments.robot.libero.run_libero_eval import TASK_MAX_STEPS  # type: ignore
        except ImportError:
            return 300
        for k, v in TASK_MAX_STEPS.items():
            if getattr(k, "value", k) == self._task_suite_name:
                return int(v)
        return 300

    def _capture_official_robot_qpos(self) -> None:
        """记录官方初始状态下的机器人关节位置（前 9 维）。"""
        layout = ms.StateLayout.from_model(self.model)
        self._official_robot_qpos = ms.get_robot_qpos(self.get_state(), layout)

    def official_robot_qpos(self) -> np.ndarray:
        """官方初始状态下的机器人关节位置。

        ``reset()`` 之后才可用；未 reset 过时现场读取当前值作为兜底。
        """
        if self._official_robot_qpos is None:
            self._capture_official_robot_qpos()
        assert self._official_robot_qpos is not None
        return self._official_robot_qpos.copy()

    def close(self) -> None:
        try:
            self._env.close()
        except Exception:  # pragma: no cover
            pass
