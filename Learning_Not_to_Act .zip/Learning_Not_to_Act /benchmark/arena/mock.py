"""``MockArena``：纯 Python 的假环境，用于在无 LIBERO 的机器上验证整条流水线。

它不是玩具摆设 —— 它的行为契约与 ``LiberoArena`` 完全一致，因此可以：
  * 单测状态构造逻辑（satisfied 是否真的被 predicate 判为 satisfied）
  * 单测 episode 运行器与指标计算（含 UER=0 与 UER=1 两个极端）
  * 在本机端到端演练 160-episode 的完整流程

物理模型（刻意极简，但**可判定、可复现**）:
  * 只有一个自由物体 ``subject``（碗/汤罐）和一个目标 ``target``（盘子）
  * 动作前两维被当作对 subject 的 xy 推移，幅度为 ``action_gain`` 米/单位
  * ``goal_satisfied`` = subject 与 target 的水平距离 < ``success_radius``
  * 关节类任务：subject 变成一个 hinge 关节，``goal_satisfied`` = 关节开度达标
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from benchmark.arena.protocol import Observation, StepResult
from benchmark.states import mujoco_state as ms
from benchmark.states.mujoco_state import task_joint_range_span

# 假模型里几何体类型常量（与 mujoco 对齐）
_MJGEOM_SPHERE = 2


@dataclass
class MockArenaConfig:
    task_id: str = "mock_bowl_on_plate"
    task_language: str = "Put the bowl on the plate"
    subject: str = "akita_black_bowl_1"
    target: str = "plate_1"
    subject_half_height: float = 0.025
    target_half_height: float = 0.010
    success_radius: float = 0.05
    action_gain: float = 0.02
    n_robot_joints: int = 7
    n_gripper_joints: int = 2
    articulated: bool = False
    """True 时 task 是关节类（如开抽屉），subject 变成单自由度关节。"""
    joint_name: str = ""
    """articulated=True 时，被操作关节的名字。留空则用 <subject>_main_joint。"""
    joint_open_target: float = 0.21
    joint_success_tol: float = 0.02
    image_size: int = 256
    seed: int = 0

    # 用于计算 eef / gripper 的 debug signal
    eef_start: tuple[float, float, float] = (0.0, 0.0, 0.5)


class MockArena:
    """实现 ``benchmark.arena.protocol.Arena`` 的假环境。"""

    def __init__(self, cfg: MockArenaConfig | None = None):
        self.cfg = cfg or MockArenaConfig()
        self.task_id = self.cfg.task_id
        self.task_language = self.cfg.task_language

        self._episode_index = -1

        # 注意顺序：_initial_flat_state() 依赖 _goal_target_xy / _eef 等，
        # 所以这些必须在构造初始状态**之前**初始化。
        self._goal_target_xy = np.array([0.04, -0.02], dtype=np.float64)
        self._eef = np.array(self.cfg.eef_start, dtype=np.float64)
        self._gripper = 0.0
        self._max_displacement = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._path = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._prev_signal: dict[str, Any] | None = None
        self._cumulative_measured = False
        self._joint = {"max": 0.0, "path": 0.0, "normalized_max": 0.0,
                       "range_span": float("nan"), "prev": None}
        self._contact = self._new_contact_state()
        self._episode_start: dict[str, Any] = {}
        self._official_robot_qpos: np.ndarray | None = None

        self.model, self._data = self._build_model()
        self._state = self._initial_flat_state()

    # ------------------------------------------------------------------
    # 假 MuJoCo model/data
    # ------------------------------------------------------------------

    def _build_model(self) -> tuple[Any, Any]:
        cfg = self.cfg
        joint_names: list[str] = []
        jnt_type: list[int] = []
        jnt_qposadr: list[int] = []
        jnt_dofadr: list[int] = []
        jnt_range: list[tuple[float, float]] = []

        qpos_adr = dof_adr = 0
        for i in range(cfg.n_robot_joints):
            joint_names.append(f"robot0_joint{i + 1}")
            jnt_type.append(3)
            jnt_qposadr.append(qpos_adr)
            jnt_dofadr.append(dof_adr)
            jnt_range.append((-3.0, 3.0))
            qpos_adr += 1
            dof_adr += 1
        for i in range(cfg.n_gripper_joints):
            # 与真实 LIBERO 一致：夹爪前缀 gripper0_，两指 range 方向相反
            joint_names.append(f"gripper0_finger_joint{i + 1}")
            jnt_type.append(2)  # mjJNT_SLIDE
            jnt_qposadr.append(qpos_adr)
            jnt_dofadr.append(dof_adr)
            jnt_range.append((0.0, 0.04) if i == 0 else (-0.04, 0.0))
            qpos_adr += 1
            dof_adr += 1

        body_names = ["world", "robot0_base"]

        if cfg.articulated:
            # 与真实 LIBERO 的命名风格保持一致：<fixture>_<region>_joint
            self._subject_joint = cfg.joint_name or "wooden_cabinet_1_middle_level"
            joint_names.append(self._subject_joint)
            jnt_type.append(2)  # mjJNT_SLIDE（真实抽屉是 slide joint）
            jnt_qposadr.append(qpos_adr)
            jnt_dofadr.append(dof_adr)
            jnt_range.append((-cfg.joint_open_target, 0.01))
            self._subject_qpos_adr = qpos_adr
            qpos_adr += 1
            dof_adr += 1
            self._subject_joint_type = 3
        else:
            self._subject_joint = f"{cfg.subject}_joint_0"
            joint_names.append(self._subject_joint)
            jnt_type.append(0)
            jnt_qposadr.append(qpos_adr)
            jnt_dofadr.append(dof_adr)
            jnt_range.append((0.0, 0.0))
            self._subject_qpos_adr = qpos_adr
            qpos_adr += 7
            dof_adr += 6
            self._subject_joint_type = 0

        self._target_joint = f"{cfg.target}_joint_0"
        joint_names.append(self._target_joint)
        jnt_type.append(0)
        jnt_qposadr.append(qpos_adr)
        jnt_dofadr.append(dof_adr)
        jnt_range.append((0.0, 0.0))
        self._target_qpos_adr = qpos_adr
        qpos_adr += 7
        dof_adr += 6

        nq, nv, njnt = qpos_adr, dof_adr, len(joint_names)

        # 几何
        body_names += [f"{cfg.subject}_main", f"{cfg.target}_main"]
        self._subject_body = len(body_names) - 2
        self._target_body = len(body_names) - 1
        geom_bodyid = [self._subject_body, self._target_body]
        geom_rbound = [cfg.subject_half_height, cfg.target_half_height]

        model = _MockModel(
            nq=nq,
            nv=nv,
            njnt=njnt,
            na=0,
            ngeom=2,
            nbody=len(body_names),
            joint_names=joint_names,
            jnt_type=np.array(jnt_type, dtype=np.int32),
            jnt_qposadr=np.array(jnt_qposadr, dtype=np.int32),
            jnt_dofadr=np.array(jnt_dofadr, dtype=np.int32),
            jnt_range=np.array(jnt_range, dtype=np.float64),
            body_names=body_names,
            geom_bodyid=np.array(geom_bodyid, dtype=np.int32),
            geom_type=np.array([_MJGEOM_SPHERE, _MJGEOM_SPHERE], dtype=np.int32),
            geom_rbound=np.array(geom_rbound, dtype=np.float64),
        )
        data = _MockData(model)
        return model, data

    # ------------------------------------------------------------------
    # 状态
    # ------------------------------------------------------------------

    def _initial_flat_state(self) -> np.ndarray:
        cfg = self.cfg
        qpos = np.zeros(self.model.nq, dtype=np.float64)
        for j in ms.iter_joints(self.model):
            if j.is_free:
                qpos[j.qpos_adr + 3] = 1.0  # identity 四元数

        table_z = 0.40
        if cfg.articulated:
            qpos[self._subject_qpos_adr] = 0.0  # 抽屉关闭
        else:
            # subject 放在远离 target 的官方初始位置
            qpos[self._subject_qpos_adr : self._subject_qpos_adr + 3] = [
                self._goal_target_xy[0] - 0.13,
                self._goal_target_xy[1],
                table_z + cfg.subject_half_height,
            ]
            # target 固定
            qpos[self._target_qpos_adr : self._target_qpos_adr + 3] = [
                self._goal_target_xy[0],
                self._goal_target_xy[1],
                table_z + cfg.target_half_height,
            ]
        qvel = np.zeros(self.model.nv, dtype=np.float64)
        return np.concatenate([[0.0], qpos, qvel])

    def _sync_data(self) -> None:
        """把扁平状态同步进 data（等价于 mj_forward 之后可读的派生量）。"""
        layout = ms.StateLayout.from_model(self.model)
        qpos = self._state[layout.qpos_slice]
        self._data.qpos = qpos.copy()
        self._data.qvel = self._state[layout.qvel_slice].copy()

        if not self.cfg.articulated:
            self._data.xpos[self._subject_body] = qpos[
                self._subject_qpos_adr : self._subject_qpos_adr + 3
            ]
        self._data.xpos[self._target_body] = qpos[
            self._target_qpos_adr : self._target_qpos_adr + 3
        ]
        self._data.geom_xpos[0] = self._data.xpos[self._subject_body]
        self._data.geom_xpos[1] = self._data.xpos[self._target_body]

    def get_state(self) -> np.ndarray:
        return self._state.copy()

    def set_state(self, state: Sequence[float], *, settle_steps: int = 0) -> Observation:
        state = ms.as_state_array(state)
        if len(state) != len(self._state):
            raise ValueError(f"状态长度不匹配: {len(state)} vs {len(self._state)}")
        self._state = state.copy()
        self._sync_data()
        for _ in range(settle_steps):
            self.step(self.no_op_action())
        return self.get_observation()

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def mark_episode_start(self) -> None:
        """建立 UER/GDR 位移基线（见 Arena.mark_episode_start 的契约说明）。"""
        self._eef = np.array(self.cfg.eef_start, dtype=np.float64)
        self._gripper = 0.0
        self._max_displacement = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        # v2 累计量（与 LiberoArena 保持同一语义，保证两套 arena 指标口径一致）
        self._path = {"eef": 0.0, "object": 0.0, "gripper": 0.0}
        self._cumulative_measured = False
        self._joint = {"max": 0.0, "path": 0.0, "normalized_max": 0.0,
                       "range_span": float("nan"), "prev": None}
        # MockArena 没有真实 contact 数据：measured 恒为 False，
        # 这样指标层就会把它标成"未测量"而不是"没接触"（§4.4）。
        self._contact = self._new_contact_state()
        start_subject = self._subject_position()
        start_eef = np.array(self._eef, dtype=np.float64).copy()
        start_joint = None
        if self.cfg.joint_name:
            try:
                start_joint = float(
                    ms.get_joint_pos(self._state, self.model, self.cfg.joint_name)
                )
            except Exception:  # noqa: BLE001
                start_joint = None
        self._joint["prev"] = start_joint
        self._joint["range_span"] = self._task_joint_range_span()
        self._episode_start = {
            "subject": start_subject,
            "eef": start_eef,
            "gripper": self._gripper,
            "satisfied": self.goal_satisfied(),
            "task_joint": start_joint,
            "step": 0,
            "gripper_open_ref": self._gripper_open_reference(),
        }
        # §3.1：起点就作为路径的第一个参考点，避免漏掉"起点→第一步"
        self._prev_signal = {
            "eef": start_eef.copy(),
            "subject": None if start_subject is None
            else np.array(start_subject, dtype=np.float64).copy(),
            "gripper": float(self._gripper),
        }

    @staticmethod
    def _new_contact_state() -> dict[str, Any]:
        """contact 累加器的唯一定义（与 LiberoArena 同结构）。"""
        return {
            k: {"measured": False, "ever": False, "first_step": None, "n_steps": 0}
            for k in ("subject", "target", "any")
        }

    def _gripper_open_reference(self) -> float:
        """MockArena 的 ``_gripper`` 标量**本身就是归一化开度**（0=开，1=全闭），

        所以它的"全行程"就是 1.0，不需要再按 joint range 归一化。
        这与 LiberoArena 要用真实 finger qpos 行程（0.0566）归一化是不同的来源，
        但归一化之后两者语义一致：0 = 没动夹爪，1 = 走完全行程。
        """
        return 1.0

    def _task_joint_range_span(self) -> float:
        """任务关节行程（与 LiberoArena 同语义）。"""
        if not getattr(self.cfg, "joint_name", None):
            return float("nan")
        return task_joint_range_span(self.model, self.cfg.joint_name)

    def reset(self, official_init_index: int = 0) -> Observation:
        """重置到官方初始状态。

        ``official_init_index`` 对应 LIBERO 的 ``initial_states[episode_idx]``：
        官方每个 task 提供 50 个固定初始状态，用下标选取（**不是**用随机种子）。
        本 mock 用 ``official_init_index`` 派生一个局部 RNG 来模拟这种"固定但多样"
        的初始状态，保证同一 index 永远得到同一状态（可复现），
        不同 index 得到不同状态（有覆盖度）。
        """
        self._episode_index += 1
        state = self._initial_flat_state()

        if not self.cfg.articulated:
            # 局部 RNG：只由 official_init_index 决定，不受调用次数影响
            local_rng = np.random.default_rng(1000 + int(official_init_index))
            pos = ms.get_object_pos(state, self.model, self.cfg.subject)
            pos[:2] += local_rng.uniform(-0.01, 0.01, size=2)
            state = ms.set_object_pos(state, self.model, self.cfg.subject, pos)
        self._state = state
        self._sync_data()

        self.mark_episode_start()
        self._capture_official_robot_qpos()
        return self.get_observation()

    def get_observation(self) -> Observation:
        img = np.zeros((self.cfg.image_size, self.cfg.image_size, 3), dtype=np.uint8)
        img[..., 0] = 128  # 占位图像；MockArena 不做视觉
        proprio = np.concatenate([self._eef, np.zeros(3), [self._gripper, -self._gripper]])

        # 暴露任务实体的位置。
        #
        # 这是有意为之的"作弊通道"：MockArena 不是用来评估视觉泛化的，
        # 而是用来验证 harness 的记账是否正确。给参考策略提供真值位置，
        # 才能构造出"已知答案"的对照（scripted 应当成功、noop 应当失败）。
        # LiberoArena 不提供这个字段，因此真实评估不受影响。
        entities = {
            "subject_pos": self._subject_position().tolist(),
            "target_xy": self._goal_target_xy.tolist(),
        }

        return Observation(
            full_image=img,
            wrist_image=img.copy(),
            state=proprio.astype(np.float64),
            raw={"mock": True, "satisfied": self.goal_satisfied(), "task_entities": entities},
        )

    def step(self, action: Sequence[float]) -> StepResult:
        action = np.asarray(action, dtype=np.float64).reshape(-1)
        assert len(action) == 7, f"动作应为 7 维，实际 {len(action)}"

        # 机器人末端按前两维平移
        self._eef[:2] += action[:2] * self.cfg.action_gain
        self._gripper = float(np.clip(self._gripper + action[6], -1.0, 1.0))

        # 本体直接带动任务实体 —— 刻意选的简化模型。
        #
        # 这里**不**模拟接触/抓取物理，原因值得记录：本 mock 的用途是验证
        # harness 的记账（UER / GDR / SR / 位移信号 / probe 窗口），
        # 而不是评估操作技能。曾经实现过"接触才推动"，结果任何朝物体走的
        # 控制器都会形成推进-远离的寄生回路（末端被卡在接触半径上与物体
        # 一起漂移），使成功路径根本无法被观测到 —— 测试环境本身成了
        # 被测对象，这是错的。简化成"本体带动实体"后，动作与结果的关系
        # 变成确定且可预期的，这正是"已知答案的砝码"所需要的东西。
        if not self.cfg.articulated:
            pos = ms.get_object_pos(self._state, self.model, self.cfg.subject)
            pos[:2] += action[:2] * self.cfg.action_gain
            self._state = ms.set_object_pos(self._state, self.model, self.cfg.subject, pos)
        else:
            cur = ms.get_joint_pos(self._state, self.model, self._subject_joint)
            new = float(
                np.clip(cur + action[0] * self.cfg.action_gain, -self.cfg.joint_open_target, 0.01)
            )
            self._state = ms.set_joint_pos(self._state, self.model, self._subject_joint, new)

        self._sync_data()
        self._update_displacement()
        done = self.goal_satisfied()
        return StepResult(
            obs=self.get_observation(),
            reward=1.0 if done else 0.0,
            done=done,
            info={},
        )

    # ------------------------------------------------------------------
    # Ground truth
    # ------------------------------------------------------------------

    def _subject_position(self) -> np.ndarray:
        if self.cfg.articulated:
            return np.array([ms.get_joint_pos(self._state, self.model, self._subject_joint)])
        return ms.get_object_pos(self._state, self.model, self.cfg.subject)

    def goal_satisfied(self) -> bool:
        if self.cfg.articulated:
            q = ms.get_joint_pos(self._state, self.model, self._subject_joint)
            # 打开对应**负端**（与真实 LIBERO 抽屉一致）
            return abs(q - (-self.cfg.joint_open_target)) <= self.cfg.joint_success_tol
        pos = ms.get_object_pos(self._state, self.model, self.cfg.subject)
        return float(np.linalg.norm(pos[:2] - self._goal_target_xy)) < self.cfg.success_radius

    def residual(self) -> float:
        if self.cfg.articulated:
            q = ms.get_joint_pos(self._state, self.model, self._subject_joint)
            return abs((-self.cfg.joint_open_target) - q)
        pos = ms.get_object_pos(self._state, self.model, self.cfg.subject)
        return float(np.linalg.norm(pos[:2] - self._goal_target_xy))

    # ------------------------------------------------------------------
    # UER 判定所需信号
    # ------------------------------------------------------------------

    # ---- UER 判定所需信号 --------------------------------------------------
    #
    # 用"物理轨迹"而不是 action vector norm 来判断"是否发生了显著干预"：
    # action 噪声可能让 ||a|| 一直非零，但那不等于机器人真的动了东西。
    # 末端位移 / 夹爪变化 / 物体位移三者任一显著，才算 intervention。
    # 阈值扫描见 benchmark/metrics.py。

    def _update_displacement(self) -> None:
        if not self._episode_start:
            return
        eef_d = float(np.linalg.norm(self._eef - self._episode_start["eef"]))
        obj_d = float(np.linalg.norm(self._subject_position() - self._episode_start["subject"]))
        grip_d = abs(self._gripper - self._episode_start["gripper"])
        self._max_displacement["eef"] = max(self._max_displacement["eef"], eef_d)
        self._max_displacement["object"] = max(self._max_displacement["object"], obj_d)
        self._max_displacement["gripper"] = max(self._max_displacement["gripper"], grip_d)

        # v2 路径长度：逐 step 累加，语义与 LiberoArena 一致
        prev = getattr(self, "_prev_signal", None)
        cur_sub = self._subject_position()
        if prev is not None:
            self._path["eef"] += float(np.linalg.norm(self._eef - prev["eef"]))
            self._path["object"] += float(np.linalg.norm(cur_sub - prev["subject"]))
            self._path["gripper"] += abs(self._gripper - prev["gripper"])
        self._prev_signal = {
            "eef": np.array(self._eef, dtype=np.float64).copy(),
            "subject": np.array(cur_sub, dtype=np.float64).copy(),
            "gripper": float(self._gripper),
        }
        self._cumulative_measured = True

        # 关节通道：最大偏离 + 累计路径 + 归一化（§3.2、§3.5）
        if getattr(self.cfg, "joint_name", None):
            try:
                q = float(ms.get_joint_pos(self._state, self.model, self.cfg.joint_name))
            except Exception:  # noqa: BLE001
                q = None
            if q is not None:
                q0 = self._episode_start.get("task_joint")
                if q0 is not None:
                    self._joint["max"] = max(self._joint["max"], abs(q - q0))
                    span = self._joint.get("range_span")
                    if span and span > 0 and not np.isnan(span):
                        self._joint["normalized_max"] = max(
                            self._joint["normalized_max"], abs(q - q0) / span
                        )
                pq = self._joint.get("prev")
                if pq is not None:
                    self._joint["path"] += abs(q - pq)
                self._joint["prev"] = q

    def task_joint_change(self) -> float:
        """旧语义 = 最大偏离（与 LiberoArena 保持一致，避免静默变义）。"""
        return float(self._joint.get("max", 0.0))

    def task_joint_max_displacement(self) -> float:
        return float(self._joint.get("max", 0.0))

    def task_joint_path_length(self) -> float:
        return float(self._joint.get("path", 0.0))

    def task_joint_normalized_max(self) -> float:
        return float(self._joint.get("normalized_max", 0.0))

    def task_joint_range_span(self) -> float:
        return float(self._joint.get("range_span", float("nan")))

    def task_contact(self) -> dict[str, Any]:
        """MockArena 不模拟接触：三组都显式 measured=False（不是"没接触"）。"""
        empty = {"measured": False, "ever": None, "first_step": None, "n_steps": None}
        out = {k: dict(empty) for k in ("subject", "target", "any")}
        out.update(empty)
        return out

    def cumulative_measured(self) -> bool:
        return bool(getattr(self, "_cumulative_measured", False))

    def debug_signals(self) -> dict[str, float]:
        open_ref = self._gripper_open_reference()
        gc = self._max_displacement["gripper"]
        return {
            "eef_max_displacement": self._max_displacement["eef"],
            "gripper_change": gc,
            "gripper_open_reference": open_ref,
            "gripper_change_norm": float(gc / open_ref) if open_ref else float("nan"),
            "object_max_displacement": self._max_displacement["object"],
            "eef_path_length": self._path["eef"],
            "object_path_length": self._path["object"],
            "gripper_path_length": self._path["gripper"],
            "task_joint_max_displacement": self.task_joint_max_displacement(),
            "task_joint_path_length": self.task_joint_path_length(),
            "task_joint_normalized_max": self.task_joint_normalized_max(),
            "task_joint_range_span": self.task_joint_range_span(),
        }

    def entity_pos(self, name_or_prefix: str) -> np.ndarray:
        """取实体位置（MockArena 里都是自由物体或 body xpos）。"""
        try:
            return ms.get_object_pos(self._state, self.model, name_or_prefix)
        except KeyError:
            bid = ms.find_body_id(self.model, name_or_prefix)
            return np.asarray(self._data.xpos[bid], dtype=np.float64)

    def set_allow_after_done(self, allow: bool) -> None:
        """MockArena 没有 terminated-episode 限制，无需处理。"""
        return None

    @property
    def unnorm_key(self) -> str:
        """MockArena 不做动作归一化，返回占位值。"""
        return "mock"

    def no_op_action(self) -> list[float]:
        return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0]

    def render_frame(self):
        """MockArena 不录像（没有真实渲染）。"""
        return None

    def _capture_official_robot_qpos(self) -> None:
        """记录官方初始状态下的机器人关节位置（前 9 维）。"""
        layout = ms.StateLayout.from_model(self.model)
        self._official_robot_qpos = ms.get_robot_qpos(self.get_state(), layout)

    def official_robot_qpos(self) -> np.ndarray:
        """官方初始状态下的机器人关节位置。

        ``reset()`` 之后才可用；未 reset 过时现场读取当前值作为兜底。
        """
        if self._official_robot_qpos is None:
            self._capture_official_robot_qpos()
        assert self._official_robot_qpos is not None
        return self._official_robot_qpos.copy()

    def close(self) -> None:
        return None


# ---------------------------------------------------------------------------
# 极简 model/data 容器（形状与 mujoco>=3.0 对齐）
# ---------------------------------------------------------------------------


@dataclass
class _MockModel:
    nq: int
    nv: int
    njnt: int
    na: int
    ngeom: int
    nbody: int
    joint_names: list[str]
    jnt_type: np.ndarray
    jnt_qposadr: np.ndarray
    jnt_dofadr: np.ndarray
    jnt_range: np.ndarray
    body_names: list[str]
    geom_bodyid: np.ndarray
    geom_type: np.ndarray
    geom_rbound: np.ndarray


@dataclass
class _MockData:
    model: _MockModel

    def __post_init__(self) -> None:
        self.qpos = np.zeros(self.model.nq, dtype=np.float64)
        self.qvel = np.zeros(self.model.nv, dtype=np.float64)
        self.xpos = np.zeros((len(self.model.body_names), 3), dtype=np.float64)
        self.geom_xpos = np.zeros((self.model.ngeom, 3), dtype=np.float64)
