"""``Arena`` 协议：Mini-PAB 对仿真环境的最小需求。

上层代码（状态构造 / episode 运行 / 指标）只允许通过本协议访问环境。
这样 ``MockArena`` 与 ``LiberoArena`` 可以互换，且 ground truth 的定义
被固定在 ``goal_satisfied()`` / ``residual()`` 两个方法上。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, Sequence, runtime_checkable

import numpy as np


@dataclass
class Observation:
    """喂给策略的观测。字段与 OpenVLA-OFT 的 LIBERO eval 保持一致。"""

    full_image: np.ndarray
    """第三人称图像，已按训练预处理旋转 180°。"""

    wrist_image: np.ndarray
    """腕部相机图像，已按训练预处理旋转 180°。"""

    state: np.ndarray
    """本体感受向量: [eef_pos(3), eef_axisangle(3), gripper_qpos(2)] = 8 维。"""

    raw: dict[str, Any] = field(default_factory=dict)
    """原始 obs dict，调试用（不参与策略输入）。"""


@dataclass
class StepResult:
    obs: Observation
    reward: float
    done: bool
    info: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class Arena(Protocol):
    """Mini-PAB 需要仿真环境提供的能力。

    实现注意：``goal_satisfied()`` 必须是 **simulator ground truth**，
    即直接读取仿真状态判定，不得依赖任何学习模型或视觉判断。
    """

    # ---- 基本属性 -------------------------------------------------------

    task_id: str
    """本项目内部的 task id（见 configs/mini_pab.yaml）。"""

    task_language: str
    """LIBERO 的 ``task.language``，作为策略指令。"""

    model: Any
    """MuJoCo model（或等价物），供 benchmark.states.mujoco_state 解析关节/几何。"""

    # ---- 生命周期 -------------------------------------------------------

    def reset(self) -> Observation:
        """重置到官方初始状态。"""

    def get_observation(self) -> Observation:
        """读取当前观测，不推进仿真。"""

    def get_state(self) -> np.ndarray:
        """导出扁平状态数组 [time | qpos | qvel]。"""

    def set_state(self, state: Sequence[float], *, settle_steps: int = 0) -> Observation:
        """把仿真置于给定状态。``settle_steps`` 用于让物理收敛。"""

    def mark_episode_start(self) -> None:
        """把**当前**状态标记为 episode 起点，重置 UER/GDR 的位移基线。

        为什么需要这个显式调用
        ----------------------
        Mini-PAB 的初始状态是**构造出来的**（不是 ``reset()`` 出来的），
        所以不能依赖 reset 来建立位移基线。早期版本就踩过这个坑：
        satisfied 条件下 builder 从未调用 reset，导致 ``debug_signals()``
        恒为 0，UER 永远是 0 —— 一个"看起来很干净但完全错误"的结果。

        契约：``set_state()`` 负责把环境摆到指定状态，
        ``mark_episode_start()`` 负责建立基线。**构造状态之后必须调用它。**
        """

    # ---- 步进 -----------------------------------------------------------

    def step(self, action: Sequence[float]) -> StepResult:
        """执行一个动作（7 维: 6 维位姿增量 + 1 维夹爪）。"""

    def render_frame(self) -> np.ndarray | None:
        """返回当前第三人称画面（uint8 HxWx3），用于录制任务视频。

        这是**可选**能力：返回 ``None`` 表示该实现不支持录制
        （例如 MockArena），调用方必须容忍。
        真实 LIBERO 实现应复用已经渲染好的观测，不要为了录像额外多渲染一次。
        """

    def no_op_action(self) -> list[float]:
        """环境的"什么都不做"动作（保持位置、不改变夹爪）。"""

    # ---- Ground truth ---------------------------------------------------

    def set_allow_after_done(self, allow: bool) -> None:
        """允许/禁止在 episode 已终止后继续 step（可选能力）。

        robosuite 在任务成功瞬间把 ``env.done`` 置 True，之后 ``step()`` 会抛
        "executing action in terminated episode"。而本实验需要在**任务达成后**
        继续观察机器人是否会去动作（GDR 与 §11.3 的观测窗口），
        因此探针期间需要清掉该标志。

        实现可以不支持（MockArena 即无此限制），调用方需容忍。
        """

    def entity_pos(self, name_or_prefix: str) -> np.ndarray:
        """取任务实体（自由物体或 fixture）的**世界坐标** xyz。

        必须由实现方保证是**世界坐标**。这一点踩过坑：robosuite 的
        ``binding_utils`` 暴露的 ``data.xpos`` 是 body **局部**坐标，
        对 fixture 返回 [0,0,0]；把 [0,0,0] 当成目标位置会把物体放到桌子原点。
        正确读法是 ``sim.data.get_body_xpos(name)``。
        """

    def unnorm_key(self) -> str:
        """动作反归一化 key（LIBERO 里即 suite 名）。

        不同 suite 的动作统计量不同，策略必须按 task 切换，否则动作幅度会被
        错误缩放（不报错，只是变差）。MockArena 可返回一个占位值。
        """

    def official_robot_qpos(self) -> np.ndarray:
        """官方初始状态下的机器人关节位置（前 9 维）。

        供 StateBuilder 在构造完状态后**显式写回**，保证两种 condition
        的机器人位姿逐位相同（§65.2）。见 mujoco_state.set_robot_qpos 的说明。
        """

    def goal_satisfied(self) -> bool:
        """目标是否已满足。**必须**来自仿真状态。"""

    def residual(self) -> float:
        """到目标的残差 D(s,l) >= 0，用于 M2 的连续标签 n_t。"""

    def debug_signals(self) -> dict[str, float]:
        """UER 判定所需的物理量：
        - ``eef_max_displacement``: 相对本 episode 起点，末端执行器最大位移 (m)
        - ``gripper_change``:       夹爪开口相对起点的最大变化
        - ``object_max_displacement``: 任务相关物体的最大位移 (m)
        """

    def close(self) -> None:
        """释放资源（MuJoCo 环境必须显式关闭，否则会泄漏）。"""
