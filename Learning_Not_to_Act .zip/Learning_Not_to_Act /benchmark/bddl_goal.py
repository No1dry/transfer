"""BDDL `:goal` 解析（**纯函数，不依赖 LIBERO / MuJoCo**）。

抽出来单独放的原因（mentor_review_5 §5）：
解析器是 Stage 4 的地基 —— 子目标谓词必须来自官方 BDDL 而不是手写。
把它与仿真解耦之后，**本地就能跑单元测试**，不必依赖远端 GPU 环境。

注意两条踩过的坑：
  1. BDDL 里谓词名首字母大写（`In` / `Turnon` / `On`），
     而 LIBERO 的 `VALIDATE_PREDICATE_FN_DICT` 键是**全小写**；
     不归一化会在 `_eval_predicate` 里 assert 失败。
  2. **只**把谓词名小写，对象名与 region 名必须保持原样
     （`akita_black_bowl_1`、`basket_1_contain_region`）。
"""
from __future__ import annotations

from pathlib import Path


def parse_goal_from_bddl(path: Path) -> list[list[str]]:
    """解析 BDDL `:goal` 的顶层谓词。谓词名小写化，对象/区域名保持原样。"""
    txt = path.read_text()
    i = txt.find("(:goal")
    if i < 0:
        raise ValueError(f"{path} 没有 :goal")
    depth, out = 0, []
    for ch in txt[i:]:
        out.append(ch)
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                break
    body = "".join(out)[len("(:goal"):].strip()
    while body.endswith(")"):
        body = body[:-1]
    body = body.strip()
    if body.lower().startswith("(and"):
        body = body[4:].strip()
    preds, depth, cur = [], 0, ""
    for ch in body:
        if ch == "(":
            depth += 1
            if depth == 1:
                cur = ""
                continue
        if ch == ")":
            depth -= 1
            if depth == 0:
                toks = [t for t in cur.strip().split() if t]
                if toks:
                    toks[0] = toks[0].lower()
                preds.append(toks)
                continue
        if depth >= 1:
            cur += ch
    return preds


