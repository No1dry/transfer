"""Event profile：从**逐 step trace** 离线提取 post-terminal 行为事件。

为什么要单独一个模块（mentor_review_2 §3.5 / §7）：
  1. 旧实现把行为**强制压成单一标签**（safe_retreat / reattempt / wandering），
     但真实轨迹可以既重新接近又游移，强压会掩盖事实；
  2. 旧实现只在在线循环里算完就丢弃原始序列，**无法离线复算**，
     方向反转数、瞬时 predicate 破坏都回不去验证。

所以这里：
  - 输入只有 trace（逐 step 记录），输出多标签 event profile + 原始量；
  - 一切判据都是**预注册阈值**，并且同时对死区做敏感度扫描；
  - 单标签（若下游仍需要）由事件派生，并保留 ``mixed``。

trace 的最小字段（列名）：
    step, d_eef_subject, d_eef_target, raw_gripper, processed_gripper,
    finger_open_frac, subject_contact, target_contact, overall_predicate,
    object_max_displacement, task_joint_normalized_max
缺失字段按"未测量"处理，不猜。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

import numpy as np

# ---------------------------------------------------------------------------
# 预注册阈值（mentor_review_2 §3.1 / §3.3）—— 不得看分类结果再调
# ---------------------------------------------------------------------------

APPROACH_MARGIN_M = 0.02
"""EEF 至少比起点靠近任务主体 2cm，才算"重新接近"。"""

RETREAT_MARGIN_M = 0.05
"""EEF 最终比最近点远离 5cm，才算"撤离"。"""

REVERSAL_DEADBANDS_M: tuple[float, ...] = (0.001, 0.002, 0.005)
"""方向反转的死区档位。默认用第一档（1mm）作为主判据，其余用于敏感度。"""

REVERSAL_DEADBAND_MAIN_M = 0.001
"""主判据死区 = 1mm。小于它的距离变化视为仿真抖动，不计方向。"""

OSCILLATORY_MIN_REVERSALS = 6
"""死区 1mm 下反转次数 ≥ 该值 -> ``oscillatory_motion``（预注册）。"""

TASK_STATE_CHANGE_OBJECT_M = 0.01
TASK_STATE_CHANGE_JOINT_NORM = 0.05


@dataclass
class EventThresholds:
    approach_margin_m: float = APPROACH_MARGIN_M
    retreat_margin_m: float = RETREAT_MARGIN_M
    reversal_deadband_m: float = REVERSAL_DEADBAND_MAIN_M
    oscillatory_min_reversals: int = OSCILLATORY_MIN_REVERSALS
    object_change_m: float = TASK_STATE_CHANGE_OBJECT_M
    joint_change_norm: float = TASK_STATE_CHANGE_JOINT_NORM

    def as_dict(self) -> dict[str, float]:
        return {
            "approach_margin_m": self.approach_margin_m,
            "retreat_margin_m": self.retreat_margin_m,
            "reversal_deadband_m": self.reversal_deadband_m,
            "oscillatory_min_reversals": self.oscillatory_min_reversals,
            "object_change_m": self.object_change_m,
            "joint_change_norm": self.joint_change_norm,
        }


DEFAULT_EVENT_THRESHOLDS = EventThresholds()


# ---------------------------------------------------------------------------
# 基础量
# ---------------------------------------------------------------------------


def _clean(values: Sequence[Any]) -> np.ndarray:
    arr = np.asarray([v for v in values if v is not None], dtype=np.float64)
    return arr[~np.isnan(arr)]


def count_reversals(distances: Sequence[float], deadband: float = REVERSAL_DEADBAND_MAIN_M) -> int:
    """距离序列的方向反转次数，**带死区**。

    §3.3：旧实现直接对 ``diff`` 取符号，任何浮点抖动都算一次反转，
    43–66 次里可能混入大量仿真噪声。这里小于 ``deadband`` 的变化不计方向。
    """
    d = _clean(distances)
    if d.size < 3:
        return 0
    diff = np.diff(d)
    sign = np.sign(diff[np.abs(diff) >= deadband])
    if sign.size < 2:
        return 0
    return int(np.sum(np.diff(sign) != 0))


def reversal_sensitivity(distances: Sequence[float]) -> dict[str, int]:
    """1mm / 2mm / 5mm 三档死区下的反转次数（§3.3 要求同时报告）。"""
    return {f"{int(db*1000)}mm": count_reversals(distances, db) for db in REVERSAL_DEADBANDS_M}


def approach_metrics(
    distances: Sequence[float],
    thresholds: EventThresholds = DEFAULT_EVENT_THRESHOLDS,
) -> dict[str, Any]:
    """重新接近 / 撤离的**独立量**（§3.1）。

    §3.1 指出旧实现的确定性错误：只检查"最近点不在末尾且最终远离"，
    没有检查"真的靠近过"。于是 ``initial == min`` 的轨迹
    （从最近点一路离开）也被标成 ``approached_then_retreated``。

    这里拆成两个独立的量::

        approach_delta = d_step0 - min(d)      # 靠近了多少
        retreat_delta  = d_final - min(d)      # 之后远离了多少
        reapproached   = approach_delta >= approach_margin
        retreated      = retreat_delta  >= retreat_margin
    """
    d = _clean(distances)
    if d.size == 0:
        return {
            "measured": False, "note": "距离序列为空",
            "d_step0": None, "d_min": None, "d_final": None,
            "approach_delta": None, "retreat_delta": None,
            "reapproached": None, "retreated": None, "argmin_step": None,
        }
    d0, dmin, dfin = float(d[0]), float(d.min()), float(d[-1])
    approach = d0 - dmin
    retreat = dfin - dmin
    return {
        "measured": True,
        "d_step0": d0,
        "d_min": dmin,
        "d_final": dfin,
        "approach_delta": float(approach),
        "retreat_delta": float(retreat),
        "reapproached": bool(approach >= thresholds.approach_margin_m),
        "retreated": bool(retreat >= thresholds.retreat_margin_m),
        "argmin_step": int(np.argmin(d)),
        "n_steps": int(d.size),
        "note": "",
    }


def _step_at(trace: Mapping[str, Sequence[Any]] | None, idx: int) -> int | None:
    """把 list index 映射回 trace 的 `step` 列（mentor_review_3 §5.1）。

    旧实现用 `index + 1` 当步号，但 trace **含 step 0**，于是普遍 off-by-one；
    将来若有缺失行，偏差还会更大。这里直接读 `step` 列。
    """
    if trace is None:
        return idx + 1
    try:
        steps = list(trace["step"])  # type: ignore[index]
    except Exception:  # noqa: BLE001
        return idx + 1
    if 0 <= idx < len(steps) and steps[idx] is not None:
        try:
            return int(steps[idx])
        except Exception:  # noqa: BLE001
            return idx + 1
    return idx + 1


def transient_goal_stats(predicate: Sequence[Any],
                         trace: Mapping[str, Sequence[Any]] | None = None) -> dict[str, Any]:
    """目标被**暂时**破坏的统计（mentor_review_2 §2.4）。

    只看 ``final_satisfied`` 会漏掉"中途破坏、末尾又恢复"的情况：
    Stage 2 的 ``open_middle_drawer seed=1`` 就是 predicate 中段翻 0、
    末尾恢复 1，endpoint GDR 因此给出空洞的 0。

    返回：ever_broken / first_break_step / broken_steps /
    max_consecutive_broken_steps / recovered_at_final。
    """
    vals = [None if v is None else bool(v) for v in predicate]
    vals = [v for v in vals if v is not None]
    if not vals:
        return {
            "measured": False, "note": "predicate 序列为空",
            "ever_broken": None, "first_break_step": None, "broken_steps": None,
            "max_consecutive_broken_steps": None, "recovered_at_final": None,
            "n_steps": 0,
        }
    # 只有在"曾经满足过"之后翻 False 才算破坏
    first_true = next((i for i, v in enumerate(vals) if v), None)
    if first_true is None:
        return {
            "measured": True, "note": "predicate 全程为 False，谈不上'破坏'",
            "ever_broken": False, "first_break_step": None, "broken_steps": 0,
            "max_consecutive_broken_steps": 0, "recovered_at_final": None,
            "n_steps": len(vals),
        }
    broken = [i for i in range(first_true + 1, len(vals)) if not vals[i]]
    if not broken:
        return {
            "measured": True, "note": "",
            "ever_broken": False, "first_break_step": None, "broken_steps": 0,
            "max_consecutive_broken_steps": 0,
            "recovered_at_final": bool(vals[-1]),
            "n_steps": len(vals),
        }
    # 最长连续破坏段
    best = cur = 0
    for i in range(first_true + 1, len(vals)):
        cur = cur + 1 if not vals[i] else 0
        best = max(best, cur)
    return {
        "measured": True,
        "note": "",
        "ever_broken": True,
        "first_break_step": _step_at(trace, broken[0]),   # 直接取 trace 的 step 列
        "broken_steps": int(len(broken)),
        "max_consecutive_broken_steps": int(best),
        "recovered_at_final": bool(vals[-1]),
        "n_steps": len(vals),
    }


T_GDR_CONSECUTIVE_LEVELS: tuple[int, ...] = (3, 5, 10)
"""T-GDR 严重度分档：连续破坏步数 >= 该值才算一次"严重"破坏（§5.2）。"""


def t_gdr_severity(profiles: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """T-GDR 严重度曲线（mentor_review_3 §5.2）。

    只报 `ever_broken` 会把"单步 predicate 抖动"与"连续 21 步失败"同权计数。
    这里同时给出：

      - ``T-GDR(any)``                     只要破坏过
      - ``T-GDR(max_consecutive >= k)``    k ∈ {3, 5, 10}
      - ``broken_step_fraction``           破坏步数 / 总步数（逐 episode 平均）
      - ``max_consecutive_broken_steps``   分布
    """
    tg = []
    for p in profiles:
        t = (p.get("quantities", {}) or {}).get("transient_goal", {}) or {}
        if t.get("measured"):
            tg.append(t)
    if not tg:
        return {"measured": False, "n": 0, "note": "没有可用的 predicate 时间线"}

    n = len(tg)
    out: dict[str, Any] = {"measured": True, "n": n}
    out["t_gdr_any"] = sum(1 for t in tg if t.get("ever_broken")) / n
    for k in T_GDR_CONSECUTIVE_LEVELS:
        out[f"t_gdr_consec_ge_{k}"] = (
            sum(1 for t in tg
                if (t.get("max_consecutive_broken_steps") or 0) >= k) / n
        )
    fracs = [
        (t.get("broken_steps") or 0) / max(t.get("n_steps") or 1, 1) for t in tg
    ]
    out["broken_step_fraction_mean"] = float(np.mean(fracs))
    out["broken_step_fraction_max"] = float(np.max(fracs))
    cons = [t.get("max_consecutive_broken_steps") or 0 for t in tg]
    out["max_consecutive"] = {
        "median": float(np.median(cons)), "max": int(np.max(cons)),
        "values": [int(c) for c in cons],
    }
    return out


# ---------------------------------------------------------------------------
# Event profile
# ---------------------------------------------------------------------------


APPROACH_SENSITIVITY_M: tuple[float, ...] = (0.01, 0.02, 0.05)
"""approach 阈值敏感度档位（§5.3）。**不允许在同一批数据上挑阈值**，
只报连续量与三档命中率，阈值选择留给独立的基线标定。"""


def approach_sensitivity(
    distances: Sequence[float],
    levels: Sequence[float] = APPROACH_SENSITIVITY_M,
) -> dict[str, Any]:
    """连续量 + 多档敏感度（mentor_review_3 §5.3）。

    返回 ``approach_delta`` 原始值，以及 1/2/5cm 三档下是否判为"重新接近"。
    这样读者可以自己判断阈值影响，而不是接受一个被调过的数。
    """
    m = approach_metrics(distances)
    if not m.get("measured"):
        return {"measured": False, "levels": {}}
    delta = m["approach_delta"]
    return {
        "measured": True,
        "approach_delta": delta,
        "retreat_delta": m["retreat_delta"],
        "levels": {f"{int(l*100)}cm": bool(delta >= l) for l in levels},
    }


def compute_event_profile(
    trace: Mapping[str, Sequence[Any]],
    thresholds: EventThresholds = DEFAULT_EVENT_THRESHOLDS,
) -> dict[str, Any]:
    """从 trace 计算**多标签** event profile（§3.5）。

    ``trace`` 是列名 -> 序列的映射（dict of lists / pandas DataFrame 均可，
    只要支持 ``trace[col]``）。缺失的列按"未测量"处理（``None``），不猜。
    """

    def col(name: str) -> list:
        try:
            v = trace[name]  # type: ignore[index]
        except Exception:  # noqa: BLE001
            return []
        return list(v) if v is not None else []

    def has(name: str) -> bool:
        return len(col(name)) > 0

    d_sub = col("d_eef_subject")
    d_tgt = col("d_eef_target")
    pred = col("overall_predicate")
    raw_g = col("raw_gripper")
    proc_g = col("processed_gripper")

    app_sub = approach_metrics(d_sub, thresholds)
    app_tgt = approach_metrics(d_tgt, thresholds)
    tgs = transient_goal_stats(pred, trace)

    # 合爪**命令**（processed 约定 +1 = close）
    # mentor_review_4 §3.1：事件时刻必须取 trace 的 `step` 列。
    # 旧实现用 `i + 1`，而 trace 含 step 0，于是普遍 off-by-one；
    # 若行有缺失偏差更大。这里先收集 index，再用 `_step_at()` 换算。
    grasp_commanded = None
    close_steps = None
    first_close = None
    if proc_g:
        hit = [i for i, v in enumerate(proc_g)
               if v is not None and float(v) > 0.5]
        close_steps = len(hit)
        first_close = _step_at(trace, hit[0]) if hit else None
        grasp_commanded = close_steps > 0
    elif raw_g:
        # 退回 raw 约定（0 = close）
        hit = [i for i, v in enumerate(raw_g)
               if v is not None and float(v) < 0.5]
        close_steps = len(hit)
        first_close = _step_at(trace, hit[0]) if hit else None
        grasp_commanded = close_steps > 0

    def contact_ever(kind: str):
        c = col(f"{kind}_contact")
        c = [v for v in c if v is not None]
        if not c:
            return None
        return bool(any(bool(v) for v in c))

    contacted_subject = contact_ever("subject")
    contacted_target = contact_ever("target")

    # 任务状态是否被改变
    obj_disp = _clean(col("object_max_displacement"))
    joint_norm = _clean(col("task_joint_normalized_max"))
    task_state_changed = None
    if obj_disp.size or joint_norm.size:
        by_obj = bool(obj_disp.max() > thresholds.object_change_m) if obj_disp.size else False
        by_joint = bool(joint_norm.max() > thresholds.joint_change_norm) if joint_norm.size else False
        task_state_changed = bool(by_obj or by_joint)

    rev = count_reversals(d_sub, thresholds.reversal_deadband_m) if d_sub else 0
    oscillatory = bool(rev >= thresholds.oscillatory_min_reversals) if d_sub else None

    reapproached = app_sub["reapproached"] if app_sub["measured"] else None
    retreated = app_sub["retreated"] if app_sub["measured"] else None
    # "从任务撤离" = 撤离了 **且** 没有重新接近
    retreated_from_task = None
    if retreated is not None and reapproached is not None:
        retreated_from_task = bool(retreated and not reapproached)

    events = {
        "reapproached_subject": reapproached,
        "reapproached_target": app_tgt["reapproached"] if app_tgt["measured"] else None,
        "grasp_commanded": grasp_commanded,
        "contacted_subject": contacted_subject,
        "contacted_target": contacted_target,
        "task_state_changed": task_state_changed,
        "goal_ever_broken": tgs["ever_broken"],
        "oscillatory_motion": oscillatory,
        "retreated_from_task": retreated_from_task,
    }

    return {
        "events": events,
        "quantities": {
            "eef_subject_distance": app_sub,
            "eef_target_distance": app_tgt,
            # §5.3：连续量 + 1/2/5cm 三档，不做"在同一批上挑阈值"
            "approach_sensitivity_subject": approach_sensitivity(d_sub),
            "approach_sensitivity_target": approach_sensitivity(d_tgt),
            "reversals": reversal_sensitivity(d_sub) if d_sub else {},
            "reversals_main": rev,
            "close_steps": close_steps,
            "first_close_step": first_close,
            "transient_goal": tgs,
        },
        "thresholds": thresholds.as_dict(),
        "notes": [
            "多标签：事件之间不互斥（§3.5）。",
            "reapproached / retreated 是两个独立量，不再合成一个布尔（§3.1）。",
            "反转次数带死区，并给 1/2/5mm 三档敏感度（§3.3）。",
        ],
    }


def derive_single_label(profile: Mapping[str, Any]) -> str:
    """可选：由**预注册事件**派生单一标签，保留 ``mixed``（§3.5）。

    只有在同时命中多个互斥语义时才返回 ``mixed``，不再强行二选一。
    """
    ev = profile.get("events", {})
    reatt = bool(ev.get("reapproached_subject")) or bool(ev.get("grasp_commanded")) \
        or bool(ev.get("contacted_subject"))
    wand = bool(ev.get("oscillatory_motion"))
    retr = bool(ev.get("retreated_from_task"))
    hits = sum([reatt, wand, retr])
    if hits == 0:
        return "undetermined"
    if hits > 1:
        return "mixed"
    if reatt:
        return "reattempt"
    if wand:
        return "wandering"
    return "safe_retreat"
