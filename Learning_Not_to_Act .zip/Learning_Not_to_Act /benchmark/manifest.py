"""Step 4: 160-episode 评估清单（manifest）。

执行方案 §8 规定 Mini-PAB 的规模是：

    4 个 task × 2 个 condition × 20 seeds = 160 episodes

manifest 的意义在于**先把要跑的东西全部枚举并落盘**，然后再跑。好处：
  * 结果文件与 manifest 一一对应，缺了哪条一目了然（避免"跑了一半以为跑完了"）
  * manifest 带哈希，可用于校验两次实验确实跑的是同一套初始状态
  * §65.4 要求 test seed 与训练增强分离 —— 冻结的 manifest 就是这个承诺的载体
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from benchmark.tasks.registry import TaskRegistry, TaskSpec


@dataclass(frozen=True)
class EpisodeSpec:
    """一个待跑 episode 的完整身份。"""

    episode_id: str
    task_id: str
    suite: str
    libero_task_id: int
    task_name: str
    condition: str
    seed: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "episode_id": self.episode_id,
            "task_id": self.task_id,
            "suite": self.suite,
            "libero_task_id": self.libero_task_id,
            "task_name": self.task_name,
            "condition": self.condition,
            "seed": self.seed,
        }


@dataclass
class Manifest:
    benchmark_version: str
    created_at_utc: str
    model_name: str
    conditions: list[str]
    seeds: list[int]
    episodes: list[EpisodeSpec] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.episodes)

    def __iter__(self) -> Iterator[EpisodeSpec]:
        return iter(self.episodes)

    @property
    def content_hash(self) -> str:
        """对"跑什么"取哈希（不含时间戳与模型名），用于跨模型对齐校验。"""
        payload = json.dumps(
            [e.as_dict() for e in self.episodes], sort_keys=True, ensure_ascii=False
        ).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for e in self.episodes:
            key = f"{e.task_id}/{e.condition}"
            out[key] = out.get(key, 0) + 1
        return out

    def as_dict(self) -> dict[str, Any]:
        return {
            "benchmark_version": self.benchmark_version,
            "created_at_utc": self.created_at_utc,
            "model_name": self.model_name,
            "conditions": self.conditions,
            "seeds": self.seeds,
            "n_episodes": len(self.episodes),
            "content_hash": self.content_hash,
            "counts": self.counts(),
            "meta": self.meta,
            "episodes": [e.as_dict() for e in self.episodes],
        }

    def write(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.as_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        return path

    @classmethod
    def read(cls, path: Path) -> "Manifest":
        d = json.loads(path.read_text(encoding="utf-8"))
        return cls(
            benchmark_version=d["benchmark_version"],
            created_at_utc=d["created_at_utc"],
            model_name=d["model_name"],
            conditions=d["conditions"],
            seeds=d["seeds"],
            episodes=[EpisodeSpec(**e) for e in d["episodes"]],
            meta=d.get("meta", {}),
        )


def build_manifest(
    registry: TaskRegistry,
    *,
    model_name: str,
    seeds: list[int] | None = None,
    conditions: list[str] | None = None,
) -> Manifest:
    """枚举出全部 episode。

    顺序固定为 task -> condition -> seed，保证两次生成的 manifest 完全一致。
    """
    conditions = conditions or list(registry.meta["conditions"])
    n_seeds = int(registry.meta["episodes_per_condition"])
    seeds = seeds if seeds is not None else list(range(n_seeds))

    episodes: list[EpisodeSpec] = []
    for spec in registry:  # 按 config 中的顺序，稳定
        for cond in conditions:
            for seed in seeds:
                episodes.append(
                    EpisodeSpec(
                        episode_id=f"{spec.id}__{cond}__s{seed:03d}",
                        task_id=spec.id,
                        suite=spec.suite,
                        libero_task_id=spec.task_id,
                        task_name=spec.task_name,
                        condition=cond,
                        seed=seed,
                    )
                )

    return Manifest(
        benchmark_version=registry.meta["benchmark_version"],
        created_at_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        model_name=model_name,
        conditions=list(conditions),
        seeds=list(seeds),
        episodes=episodes,
        meta={
            "config_path": registry.meta["config_path"],
            "n_tasks": len(registry),
            "episodes_per_condition": n_seeds,
        },
    )


def result_file_name(model_name: str, task_id: str, condition: str, seed: int) -> str:
    """单 episode 结果文件名。

    §63 要求实验 ID 形如 ``{date}_{model}_{benchmark}_{seed}`` 且不得覆盖旧结果。
    这里把 date 交给 run 级目录，episode 级用 ``model__task__condition__seed``。
    """
    safe_model = model_name.replace("/", "_").replace("::", "--").replace(" ", "_")
    return f"{safe_model}__{task_id}__{condition}__s{seed:03d}.json"
