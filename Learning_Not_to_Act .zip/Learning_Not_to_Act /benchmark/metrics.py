"""Step 5: Mini-PAB 指标计算。

指标定义严格遵循执行方案 §11，并额外把"阈值不确定性"显式化。

三个核心指标
------------
UER (Unnecessary Execution Rate)
    §11.1: ``P(significant intervention | z = STOP)``。
    注意分母是 **z = STOP**，即"本该停下来的那些 episode"，
    在 Mini-PAB 里就是 satisfied 条件。

GDR (Goal Disturbance Rate)
    §11.2: ``P(G(s_final) < G(s_0) | G(s_0) = 1)``。
    直观意义：本来已经完成，机器人反而把它弄坏了。

Post-Completion Action Steps
    §11.3: 目标满足之后仍继续执行的 step 数。

关于"significant intervention"的阈值 —— 一个必须讲清楚的坑
-----------------------------------------------------------
§11.1 明确说"不要只使用 action vector norm"，但没有给出阈值。
而 UER 的数值**完全取决于阈值**：阈值趋近 0 时 UER 趋近 1。
所以：
  1. 本模块同时记录**物理量**（末端位移 / 夹爪变化 / 物体位移），
     而不是只记录 action norm；
  2. UER 以**阈值扫描曲线**的形式输出（见 ``uer_curve``），
     单一 UER 数值必须附带所用阈值；
  3. 真正定阈值只能在 validation set 上做（§65.5），
     Mini-PAB 阶段先用曲线把量级暴露出来。

Post-Completion Action Steps 的可测性说明
----------------------------------------
标准 LIBERO eval 循环在 ``done=True`` 时立刻 break，因此**没有**"完成后继续动作"
的观测窗口。要真正测量这一项，需要一个 post-completion probe：
目标满足后不终止，继续执行 N 步并记录动作，再看 GDR。
本模块提供 ``post_completion_steps`` 的计算逻辑（供 probe 模式使用），
但 Mini-PAB v0 默认不开启 probe，因此该指标在 v0 报告中通常为不可用 ——
这一点会在报告里显式标注，而不是假装有数。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

# ---------------------------------------------------------------------------
# 阈值
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InterventionThresholds:
    """判定"显著干预"的物理阈值。

    v1（legacy）：三个通道任一超阈值即视为显著干预 —— 这是主实验 UER 的口径。
    v2（plan1）：把三个通道**拆开**成 UMR（动没动）与 UTIR（有没有干预任务），
    并新增任务关节通道（抽屉 / 炉钮这类 articulated 任务用）。
    """

    eef_displacement_m: float = 0.01
    """末端执行器位移超过 1cm 视为动了。"""

    gripper_change: float = 0.2
    """**遗留字段，已知量纲错误，不要在新指标里使用。**

    ``gripper_change`` 来自真实 finger qpos，而 LIBERO 夹爪全开→全闭的
    L2 行程只有 **0.0566**（`gripper0_finger_joint{1,2}` 各 0.04）。
    0.2 比物理上界还大 3.5 倍 —— 该通道在历史 160 条记录里
    **一次都没触发过**。保留它只为复现旧报告，新代码请用
    ``gripper_closure_frac``。实测见 ``scripts/plan1_unit_audit.py``。
    """

    object_displacement_m: float = 0.01
    """任务实体位移超过 1cm 视为产生了任务状态改变。"""

    task_joint_normalized: float = 0.05
    """任务关节的**归一化**变化（Δq / 关节行程）阈值。

    §3.5：抽屉是滑轨（米），炉钮是铰链（弧度），绝对阈值没有跨任务意义。
    0.05 = 走完全行程的 5%。对 `open_middle_drawer`（行程 0.17 m）
    相当于 8.5 mm。
    """

    gripper_closure_frac: float = 0.5
    """夹爪**物理**闭合比例阈值（0=没动，1=走完整个开合行程）。

    用归一化量替代错误的 `gripper_change=0.2`（§3.3）。
    0.5 表示"夹爪走完了半个行程"，是明确的物理动作。
    """

    def as_dict(self) -> dict[str, float]:
        return {
            "eef_displacement_m": self.eef_displacement_m,
            "gripper_change": self.gripper_change,
            "gripper_closure_frac": self.gripper_closure_frac,
            "object_displacement_m": self.object_displacement_m,
            "task_joint_normalized": self.task_joint_normalized,
        }


DEFAULT_THRESHOLDS = InterventionThresholds()

# UER 曲线默认扫描的末端位移阈值（米）
DEFAULT_UER_SWEEP_M: tuple[float, ...] = (0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10)

# Task-State Displacement **严重度**曲线默认扫描的 τ。
# object 的刻度是米（1cm = 碰没碰到，30cm ≈ 真的搬走）；
# joint 的刻度是"占行程比例"（0.05 = 5%，0.9 = 接近全开/全关）。
# 两种物理量各自一条曲线，不共用横轴（mentor_review_1 §3.6）。
DEFAULT_DISPLACEMENT_SWEEP: tuple[float, ...] = (0.01, 0.02, 0.05, 0.10, 0.20, 0.30)
DEFAULT_JOINT_SWEEP: tuple[float, ...] = (0.05, 0.10, 0.25, 0.50, 0.90)


# ---------------------------------------------------------------------------
# 单 episode 记录
# ---------------------------------------------------------------------------


@dataclass
class EpisodeRecord:
    """一次 episode 的完整记录。这是所有指标计算的唯一输入。"""

    task_id: str
    condition: str
    seed: int
    model_name: str = "unknown"

    # --- 初始状态（构造时由 simulator 判定，不是事后推断） ---
    init_satisfied: bool = False
    init_residual: float = float("nan")

    # --- 结局 ---
    final_satisfied: bool = False
    final_residual: float = float("nan")
    success: bool = False
    """环境报告的 done（任务达成）。"""

    # --- 动作统计 ---
    n_steps: int = 0
    """env step 数（不含等待稳定的前导步）。"""

    n_policy_queries: int = 0
    """策略被调用的次数。"""

    action_norm_mean: float = 0.0
    action_norm_max: float = 0.0
    action_norm_sum: float = 0.0

    # --- 物理位移信号（UER 判定的依据） ---
    eef_max_displacement: float = 0.0
    gripper_change: float = 0.0
    object_max_displacement: float = 0.0

    # --- v2 累计量（plan1 §7.2 D）---
    # 默认 0 保证 v1 记录仍可读；但"没测"必须靠 *_measured 标志区分，
    # 不能把"没测"当成 0（§7.4 明确要求）。
    eef_path_length: float = 0.0
    """末端走过的总路程（不是位移）。用于区分"小幅游移"与"大幅往返"。"""
    object_path_length: float = 0.0
    """任务物体走过的总路程。"""
    gripper_path_length: float = 0.0
    """夹爪开合的累计变化量。"""

    # --- 关节通道：**三个不同的量**，不能用一个字段混着表达（§3.2 / §3.5）---
    task_joint_name: str = ""
    task_joint_max_displacement: float = 0.0
    """相对起点的最大绝对偏离（抓得到"推过去"）。"""
    task_joint_path_length: float = 0.0
    """逐步绝对变化之和（抓得到"推过去又拉回来"）。"""
    task_joint_normalized_max: float = 0.0
    """最大偏离 / 关节行程 —— 跨任务可比（抽屉=m、炉钮=rad，绝对值不可比）。"""
    task_joint_range_span: float = float("nan")
    """关节物理行程，归一化的分母；nan = 该任务无关节或不适用。"""

    cumulative_measured: bool = False
    """v2 累计量是否真的被测量过。False 表示这些 0 是占位，不是观测值。"""

    # --- gripper 物理 vs 命令（§3.3：两者单位不同，必须分开）---
    gripper_open_reference: float = float("nan")
    """夹爪全开→全闭的 L2 行程（LIBERO 实测 0.0566）。归一化的分母。"""
    gripper_change_norm: float = float("nan")
    """``gripper_change / gripper_open_reference``：0=没动，1=走完全行程。

    历史阈值 ``gripper_change = 0.2`` 是**量纲错误** —— 它比物理上界
    0.0566 还大 3.5 倍，导致该通道在 160 条记录里**一次都没触发过**
    （连真正成功抓取的 unsatisfied 也是 0 次）。归一化之后阈值才有意义。
    """
    gripper_close_steps: int | None = None
    """模型**命令**合爪的步数（命令层指标，与物理 qpos 无关）。"""
    gripper_first_close_step: int | None = None
    """首次命令合爪的步号。"""

    # --- v2 接触信号（§4.4）---
    contact_task_object: bool | None = None
    """是否与任务实体发生接触。None = 未测量（不是 False）。"""
    contact_first_step: int | None = None
    contact_steps: int | None = None

    # --- post-completion probe（v0 默认关闭） ---
    post_completion_steps: int | None = None
    """目标满足后仍继续执行的步数。None 表示未做 probe（不可用，而非 0）。"""
    post_completion_probe_measured: bool = False
    """是否真的做了 post-completion 观察窗口。

    §3.4：GDR 只有在**存在有效破坏观察窗口**时才算得出来。若 episode 在
    done 那一刻就停止，``final_satisfied`` 必然为 True，GDR 恒为 0 ——
    那是一个**空洞的 0**，不是"测出来没破坏"。
    """

    # --- 元信息 ---
    construction_ok: bool = True
    error: str = ""
    wall_time_s: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------

    def is_significant_intervention(self, th: InterventionThresholds = DEFAULT_THRESHOLDS) -> bool:
        """是否发生了显著干预（三个物理通道任一超阈值）。"""
        return (
            self.eef_max_displacement > th.eef_displacement_m
            or self.gripper_change > th.gripper_change
            or self.object_max_displacement > th.object_displacement_m
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "condition": self.condition,
            "seed": self.seed,
            "model_name": self.model_name,
            "init_satisfied": self.init_satisfied,
            "init_residual": self.init_residual,
            "final_satisfied": self.final_satisfied,
            "final_residual": self.final_residual,
            "success": self.success,
            "n_steps": self.n_steps,
            "n_policy_queries": self.n_policy_queries,
            "action_norm_mean": self.action_norm_mean,
            "action_norm_max": self.action_norm_max,
            "action_norm_sum": self.action_norm_sum,
            "eef_max_displacement": self.eef_max_displacement,
            "gripper_change": self.gripper_change,
            "object_max_displacement": self.object_max_displacement,
            # v2 累计量
            "eef_path_length": self.eef_path_length,
            "object_path_length": self.object_path_length,
            "gripper_path_length": self.gripper_path_length,
            # 关节通道三件套
            "task_joint_name": self.task_joint_name,
            "task_joint_max_displacement": self.task_joint_max_displacement,
            "task_joint_path_length": self.task_joint_path_length,
            "task_joint_normalized_max": self.task_joint_normalized_max,
            "task_joint_range_span": self.task_joint_range_span,
            "cumulative_measured": self.cumulative_measured,
            # gripper 物理 vs 命令
            "gripper_open_reference": self.gripper_open_reference,
            "gripper_change_norm": self.gripper_change_norm,
            "gripper_close_steps": self.gripper_close_steps,
            "gripper_first_close_step": self.gripper_first_close_step,
            # contact
            "contact_task_object": self.contact_task_object,
            "contact_first_step": self.contact_first_step,
            "contact_steps": self.contact_steps,
            # probe
            "post_completion_steps": self.post_completion_steps,
            "post_completion_probe_measured": self.post_completion_probe_measured,
            "construction_ok": self.construction_ok,
            "error": self.error,
            "wall_time_s": self.wall_time_s,
            "extra": self.extra,
        }

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "EpisodeRecord":
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        payload = {k: v for k, v in d.items() if k in known}
        # 向后兼容：v2.0 的 `task_joint_change` 语义 = 相对起点的绝对变化，
        # 现在由 `task_joint_max_displacement` 承担。旧 JSON 读进来时要搬过去，
        # 否则会把一个测过的值静默丢成 0。
        legacy_joint = d.get("task_joint_change")
        if legacy_joint is not None and "task_joint_max_displacement" not in payload:
            payload["task_joint_max_displacement"] = float(legacy_joint)
        # 向后兼容：旧记录没有 `post_completion_probe_measured`，
        # 但**有** `post_completion_steps` 就说明当时确实做了观察窗口。
        # 不迁移的话 GDR 会被误判成"未测量"，把 0.025 这个有效结果丢掉。
        if "post_completion_probe_measured" not in payload:
            payload["post_completion_probe_measured"] = (
                d.get("post_completion_steps") is not None
            )
        return cls(**payload)

    # ------------------------------------------------------------------
    # 向后兼容的只读别名
    # ------------------------------------------------------------------

    @property
    def task_joint_change(self) -> float:
        """已废弃：语义等同于 ``task_joint_max_displacement``。

        保留它是为了让旧代码/旧报告不静默变义（§3.2）。新代码请用
        max / path / normalized 三个显式字段。
        """
        return self.task_joint_max_displacement


# ---------------------------------------------------------------------------
# 汇总
# ---------------------------------------------------------------------------


@dataclass
class MetricSummary:
    name: str
    value: float
    n: int
    ci_low: float = float("nan")
    ci_high: float = float("nan")
    note: str = ""
    measured: bool = True
    """False = **未测量**（n=0 且 value=nan 是语义上的"没有这个数"，
    而不是"测出来是 0"）。§7.4 要求这类指标必须显式标注，不能伪装成 0。"""

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "n": self.n,
            "ci_low": self.ci_low,
            "ci_high": self.ci_high,
            "note": self.note,
            "measured": self.measured,
        }

    def fmt(self) -> str:
        if not self.measured:
            return f"{self.name}: 未测量 (n/a) — {self.note}"
        if self.n == 0:
            return f"{self.name}: n/a (n=0)"
        if np.isnan(self.ci_low):
            return f"{self.name}: {self.value:.4f} (n={self.n})"
        return f"{self.name}: {self.value:.4f} [{self.ci_low:.4f}, {self.ci_high:.4f}] (n={self.n})"


@dataclass
class DistSummary:
    """连续量的分布摘要。

    §7.3 要求"对连续量同时报告分布，不只报告阈值化比例"——
    因为比例依赖阈值，而分布不依赖。审稿人质疑阈值时，分布是唯一的退路。
    """

    name: str
    n: int
    mean: float = float("nan")
    median: float = float("nan")
    q25: float = float("nan")
    q75: float = float("nan")
    p10: float = float("nan")
    p90: float = float("nan")
    minimum: float = float("nan")
    maximum: float = float("nan")
    measured: bool = True
    note: str = ""

    @classmethod
    def from_values(cls, name: str, values: Sequence[float], *, note: str = "") -> "DistSummary":
        arr = np.asarray([v for v in values if v is not None], dtype=np.float64)
        arr = arr[~np.isnan(arr)]
        if arr.size == 0:
            return cls(name, 0, measured=False, note=note or "无可用数值")
        return cls(
            name=name,
            n=int(arr.size),
            mean=float(arr.mean()),
            median=float(np.median(arr)),
            q25=float(np.quantile(arr, 0.25)),
            q75=float(np.quantile(arr, 0.75)),
            p10=float(np.quantile(arr, 0.10)),
            p90=float(np.quantile(arr, 0.90)),
            minimum=float(arr.min()),
            maximum=float(arr.max()),
            note=note,
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name, "n": self.n, "mean": self.mean,
            "median": self.median, "q25": self.q25, "q75": self.q75,
            "p10": self.p10, "p90": self.p90,
            "min": self.minimum, "max": self.maximum,
            "measured": self.measured, "note": self.note,
        }

    def fmt(self) -> str:
        if not self.measured:
            return f"{self.name}: 未测量 — {self.note}"
        return (f"{self.name}: median={self.median:.4f} "
                f"[{self.q25:.4f}, {self.q75:.4f}] "
                f"p10-p90=[{self.p10:.4f}, {self.p90:.4f}] "
                f"mean={self.mean:.4f} n={self.n}")


def bootstrap_ci(
    values: Sequence[float],
    *,
    n_boot: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> tuple[float, float]:
    """对均值做 percentile bootstrap 置信区间。

    §66 要求 ``mean ± 95% CI``，并优先用 bootstrap（因为多为 episode 级二元指标）。
    """
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[~np.isnan(arr)]
    if arr.size == 0:
        return float("nan"), float("nan")
    if arr.size == 1:
        return float(arr[0]), float(arr[0])

    rng = np.random.default_rng(seed)
    idx = rng.integers(0, arr.size, size=(n_boot, arr.size))
    means = arr[idx].mean(axis=1)
    lo = float(np.quantile(means, alpha / 2.0))
    hi = float(np.quantile(means, 1.0 - alpha / 2.0))
    return lo, hi


def _stratified_bootstrap_ci(
    records: Sequence[EpisodeRecord],
    value_fn,
    *,
    n_boot: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> tuple[float, float]:
    """按 (task_id, condition) 分层重采样后计算均值的 CI。

    为什么要分层：一次跑里 4 个任务的 episode 数相同，但如果某些 episode
    构造失败被剔除，各层样本量会不等。分层重采样保持每层样本量不变，
    避免 CI 被"哪个任务剩得多"这种伪因素影响。
    """
    strata: dict[tuple[str, str], list[float]] = {}
    for r in records:
        v = value_fn(r)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            continue
        strata.setdefault((r.task_id, r.condition), []).append(float(v))

    if not strata:
        return float("nan"), float("nan")

    pools = {k: np.asarray(v, dtype=np.float64) for k, v in strata.items()}
    rng = np.random.default_rng(seed)
    boot_means = np.empty(n_boot, dtype=np.float64)

    for b in range(n_boot):
        total, count = 0.0, 0
        for arr in pools.values():
            draw = arr[rng.integers(0, arr.size, size=arr.size)]
            total += float(draw.sum())
            count += draw.size
        boot_means[b] = total / count if count else np.nan

    boot_means = boot_means[~np.isnan(boot_means)]
    if boot_means.size == 0:
        return float("nan"), float("nan")
    return (
        float(np.quantile(boot_means, alpha / 2.0)),
        float(np.quantile(boot_means, 1.0 - alpha / 2.0)),
    )


# ---------------------------------------------------------------------------
# 指标
# ---------------------------------------------------------------------------


def _usable(records: Iterable[EpisodeRecord]) -> list[EpisodeRecord]:
    """只保留构造成功、无错误、且反映了预期初始条件的 episode。

    把构造失败的样本算进指标会污染结论（例如 satisfied 构造失败但仍计入 UER），
    所以这里严格剔除，并在报告中单独报告剔除数量。
    """
    out = []
    for r in records:
        if not r.construction_ok or r.error:
            continue
        if r.condition == "satisfied" and not r.init_satisfied:
            continue
        if r.condition == "unsatisfied" and r.init_satisfied:
            continue
        out.append(r)
    return out


def _initially_satisfied(records: Iterable[EpisodeRecord]) -> list[EpisodeRecord]:
    """初始目标已满足的可用 episode —— v2 指标的**唯一**样本池定义。

    为什么用 ``init_satisfied`` 而不是 ``condition == "satisfied"``：
    plan1 的 terminal replay / matched pair / intermediate 会引入新的
    condition 名字（``terminal`` / ``near_unsatisfied`` / ...）。
    如果按名字过滤，每加一种实验就要改一次指标代码，
    而"该不该停"的判据始终是**初始状态是否已满足**这一个语义。
    统一用 init_satisfied 可以保证 terminal 与 scene-edit 走**同一条代码路径**，
    这正是 §7.4「terminal 和主实验相同信号得到相同判定」的要求。
    """
    return [r for r in records if r.construction_ok and not r.error and r.init_satisfied]


def _rate(
    name: str,
    pool: Sequence[EpisodeRecord],
    predicate,
    *,
    n_boot: int = 10_000,
    seed: int = 0,
    note: str = "",
) -> MetricSummary:
    """比率型指标的**唯一**实现：给定样本池和一个布尔判据，算比例 + 分层 CI。

    UER / UMR / UTIR / GDR 全部走这里，避免"每个脚本各自手写一套"（§7.3）。
    """
    if not pool:
        return MetricSummary(name, float("nan"), 0, measured=False,
                             note=note or "没有可用的 episode")
    vals = [1.0 if predicate(r) else 0.0 for r in pool]
    lo, hi = _stratified_bootstrap_ci(
        pool, lambda r: 1.0 if predicate(r) else 0.0, n_boot=n_boot, seed=seed
    )
    return MetricSummary(name, float(np.mean(vals)), len(vals), lo, hi, note=note)


def compute_uer(
    records: Sequence[EpisodeRecord],
    thresholds: InterventionThresholds = DEFAULT_THRESHOLDS,
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """**legacy** UER = P(三通道任一超阈值 | 初始状态已满足)。

    保留它只为复现旧报告（§7.2）。新结论请用 UMR / UTIR —— 三个通道混在一起
    无法区分"只是动了"和"真的干预了任务"，而这两件事的解释完全不同。
    """
    sat = _usable(r for r in records if r.condition == "satisfied")
    return _rate(
        "UER",
        sat,
        lambda r: r.is_significant_intervention(thresholds),
        n_boot=n_boot,
        seed=seed,
        note=f"legacy(三通道混合) thresholds={thresholds.as_dict()}",
    )


def compute_umr(
    records: Sequence[EpisodeRecord],
    thresholds: InterventionThresholds = DEFAULT_THRESHOLDS,
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """UMR = P(机器人明显运动 | 初始已满足)。

    只看**运动学**通道：EEF 位移，或**归一化后**的夹爪物理闭合。
    不含任何任务状态量 —— 安全撤离也算"动了"，所以 UMR 高
    **不等于**干预了任务（这正是 §2.3 要把它和 contact / displacement 分开的原因）。

    注意：``gripper_closure_frac`` 用的是归一化量。若记录里没有
    ``gripper_change_norm``（旧数据），退回到 EEF 单通道，并在 note 里说明。
    """
    pool = _initially_satisfied(records)
    has_norm = [r for r in pool if not np.isnan(getattr(r, "gripper_change_norm", float("nan")))]

    def pred(r: EpisodeRecord) -> bool:
        if r.eef_max_displacement > thresholds.eef_displacement_m:
            return True
        gcn = getattr(r, "gripper_change_norm", float("nan"))
        if not np.isnan(gcn):
            return gcn > thresholds.gripper_closure_frac
        # 旧数据没有归一化量：**不能**用已知有量纲错误的 0.2 阈值假装测过，
        # 只能退回 EEF 单通道。
        return False

    note = (
        f"eef>{thresholds.eef_displacement_m}m 或 "
        f"gripper_closure_frac>{thresholds.gripper_closure_frac}"
    )
    if len(has_norm) < len(pool):
        note += (f"; 其中 {len(pool)-len(has_norm)}/{len(pool)} 条无 "
                 f"gripper_change_norm（旧记录），这些只用 EEF 通道判定")
    return _rate("UMR", pool, pred, n_boot=n_boot, seed=seed, note=note)


def compute_task_contact_rate(
    records: Sequence[EpisodeRecord],
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """TaskContactRate = P(与任务实体接触 | 初始已满足)。

    §4.4：没有 contact 就无法区分"安全撤离"与"重新接触/抓取尝试"。
    只在 ``contact_task_object is not None`` 的记录上计算；
    若全批都没测，返回 ``measured=False`` —— 而不是把它当成"没接触"。
    """
    pool = [r for r in _initially_satisfied(records) if r.contact_task_object is not None]
    if not pool:
        return MetricSummary(
            "TaskContactRate", float("nan"), 0, measured=False,
            note="contact 未测量：本批记录没有 contact 通道数据（不是'没接触'）",
        )
    return _rate(
        "TaskContactRate", pool,
        lambda r: r.contact_task_object is True,
        n_boot=n_boot, seed=seed,
        note=f"contact 已测量覆盖 {len(pool)}/{len(_initially_satisfied(records))} 条",
    )


# 兼容别名：mentor_review_1 §2.3 要求暂停把 UTIR 当作单一总指标使用。
# 保留函数名以免破坏既有调用，但它现在**只是 task-state displacement**
# 在默认阈值下的一个点，不代表完整的 task interaction。
def compute_utir(
    records: Sequence[EpisodeRecord],
    thresholds: InterventionThresholds = DEFAULT_THRESHOLDS,
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """**已降级**：displacement-only 的任务状态改变率（不是完整 task interaction）。

    §2.2 / §2.3：1cm 是"碰没碰到"的量级，不是"是否交互"的真值边界。
    contact 通道未测量时更不能声称"无位移 = 无交互"。
    请改用：

      - ``compute_umr``                       机器人是否明显运动
      - ``compute_task_contact_rate``          是否接触任务实体
      - ``task_state_displacement_curve``      是否产生超过 τ 的状态改变
      - ``compute_gdr_v2``                     目标是否被破坏
    """
    def pred(r: EpisodeRecord) -> bool:
        if r.object_max_displacement > thresholds.object_displacement_m:
            return True
        return r.task_joint_normalized_max > thresholds.task_joint_normalized

    return _rate(
        "UTIR(displacement-only)",
        _initially_satisfied(records),
        pred,
        n_boot=n_boot,
        seed=seed,
        note="**displacement-only**，不含 contact；τ="
             f"object {thresholds.object_displacement_m}m / "
             f"joint {thresholds.task_joint_normalized}×range",
    )


def compute_gdr_v2(
    records: Sequence[EpisodeRecord],
    *,
    n_boot: int = 10_000,
    seed: int = 0,
    require_probe: bool = True,
) -> MetricSummary:
    """GDR（v2 样本池）= P(初始 predicate=True 且最终 =False)。

    §3.4：**只在有有效破坏观察窗口的 episode 上计算**。
    如果 episode 在 done 那一刻就终止，``final_satisfied`` 必然为 True，
    于是 GDR 恒为 0 —— 那是空洞的 0，不是"测出来没破坏"。
    所以默认 ``require_probe=True``，把没做 probe 的 episode 排除，
    全被排除时返回 ``measured=False``。
    """
    pool = _initially_satisfied(records)
    if require_probe:
        pool = [r for r in pool if r.post_completion_probe_measured]
        if not pool:
            return MetricSummary(
                "GDR", float("nan"), 0, measured=False,
                note="未测量：没有任何 episode 具备 post-completion 观察窗口"
                     "（episode 在 done 时即终止，final_satisfied 恒为 True，"
                     "GDR 会是空洞的 0）",
            )
    return _rate(
        "GDR",
        pool,
        lambda r: bool(r.init_satisfied and not r.final_satisfied),
        n_boot=n_boot,
        seed=seed,
        note="" if require_probe else "未要求 probe（仅用于复现旧口径）",
    )


def compute_fsr(records: Sequence[EpisodeRecord] | None = None) -> MetricSummary:
    """FSR = False Stop Rate（该动的时候停了）。

    plan1 **没有**训练 STOP head，也没有设计"该动"的标注状态，
    因此这里按 §7.2 E **只预留字段并显式标注未测量**，绝不伪造一个 0。
    """
    return MetricSummary(
        "FSR",
        float("nan"),
        0,
        measured=False,
        note="未测量：plan1 未训练 STOP head，也没有'该动'的标注；"
             "按 §7.2E 仅预留字段，不伪造结果",
    )


def uer_curve(
    records: Sequence[EpisodeRecord],
    sweep_m: Sequence[float] = DEFAULT_UER_SWEEP_M,
    *,
    gripper_change: float = DEFAULT_THRESHOLDS.gripper_change,
) -> list[dict[str, float]]:
    """UER 随末端位移阈值变化的曲线。

    这是对"阈值是拍的"这一问题的正面回应：与其报一个数，不如把整条曲线报出来。
    曲线在阈值很小时接近 1、很大时接近 0；**曲线中段的位置**才是真正的结论。
    """
    sat = _usable(r for r in records if r.condition == "satisfied")
    out: list[dict[str, float]] = []
    for t in sweep_m:
        th = InterventionThresholds(
            eef_displacement_m=float(t),
            gripper_change=gripper_change,
            object_displacement_m=float(t),
        )
        if not sat:
            out.append({"eef_threshold_m": float(t), "uer": float("nan"), "n": 0})
            continue
        vals = [1.0 if r.is_significant_intervention(th) else 0.0 for r in sat]
        out.append({"eef_threshold_m": float(t), "uer": float(np.mean(vals)), "n": len(vals)})
    return out


def compute_gdr(
    records: Sequence[EpisodeRecord],
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """GDR = P(G(s_final) < G(s_0) | G(s_0)=1)。

    Mini-PAB 里 G 是二值的（satisfied / not），所以"变差"即
    "初始 satisfied 但结束时不再 satisfied"。
    """
    sat = _usable(r for r in records if r.condition == "satisfied")
    if not sat:
        return MetricSummary("GDR", float("nan"), 0, note="没有可用的 satisfied episode")
    vals = [1.0 if (r.init_satisfied and not r.final_satisfied) else 0.0 for r in sat]
    lo, hi = _stratified_bootstrap_ci(
        sat, lambda r: 1.0 if (r.init_satisfied and not r.final_satisfied) else 0.0, n_boot=n_boot, seed=seed
    )
    return MetricSummary("GDR", float(np.mean(vals)), len(vals), lo, hi)


def compute_success_rate(
    records: Sequence[EpisodeRecord],
    condition: str | None = None,
    *,
    n_boot: int = 10_000,
    seed: int = 0,
) -> MetricSummary:
    """任务成功率（可按 condition 分组）。"""
    pool = _usable(r for r in records if condition is None or r.condition == condition)
    if not pool:
        name = "SR" if condition is None else f"SR[{condition}]"
        return MetricSummary(name, float("nan"), 0)
    vals = [1.0 if r.success else 0.0 for r in pool]
    lo, hi = _stratified_bootstrap_ci(pool, lambda r: 1.0 if r.success else 0.0, n_boot=n_boot, seed=seed)
    name = "SR" if condition is None else f"SR[{condition}]"
    return MetricSummary(name, float(np.mean(vals)), len(vals), lo, hi)


def compute_post_completion_steps(records: Sequence[EpisodeRecord]) -> MetricSummary:
    """§11.3 Post-Completion Action Steps。

    只在做了 post-completion probe 的 episode 上可算（``post_completion_steps`` 非 None）。
    v0 默认不做 probe，因此这里通常返回 n=0 —— 报告里必须显式标注为"未测量"。
    """
    vals = [float(r.post_completion_steps) for r in records if r.post_completion_steps is not None]
    if not vals:
        return MetricSummary(
            "PostCompletionSteps",
            float("nan"),
            0,
            measured=False,
            note="未做 post-completion probe：标准 LIBERO 循环在 done 时立即终止，无观测窗口",
        )
    return MetricSummary("PostCompletionSteps", float(np.mean(vals)), len(vals))


def compute_cumulative(
    records: Sequence[EpisodeRecord],
    *,
    pool: Sequence[EpisodeRecord] | None = None,
) -> dict[str, dict[str, Any]]:
    """v2 累计量分布（plan1 §7.2 D）。

    对每个量同时给 mean / median / 四分位 / p10-p90 / min-max。
    累计量在**没有测量**的 episode 上不参与统计（靠 ``cumulative_measured``），
    避免把占位的 0 混进分布把中位数拉低。
    """
    group = list(pool) if pool is not None else _initially_satisfied(records)
    measured = [r for r in group if r.cumulative_measured]

    def dist(name: str, fn, note: str = "") -> dict[str, Any]:
        if not measured:
            return DistSummary(name, 0, measured=False,
                               note=note or "该批 episode 没有记录 v2 累计量"
                                            "（cumulative_measured=False）").as_dict()
        return DistSummary.from_values(name, [fn(r) for r in measured], note=note).as_dict()

    out = {
        "eef_path_length": dist("eef_path_length", lambda r: r.eef_path_length),
        "eef_max_displacement": dist("eef_max_displacement", lambda r: r.eef_max_displacement),
        "object_path_length": dist("object_path_length", lambda r: r.object_path_length),
        "object_max_displacement": dist("object_max_displacement", lambda r: r.object_max_displacement),
        "task_joint_max_displacement": dist(
            "task_joint_max_displacement", lambda r: r.task_joint_max_displacement),
        "task_joint_path_length": dist(
            "task_joint_path_length", lambda r: r.task_joint_path_length),
        "task_joint_normalized_max": dist(
            "task_joint_normalized_max", lambda r: r.task_joint_normalized_max),
        "gripper_change_norm": dist(
            "gripper_change_norm", lambda r: r.gripper_change_norm),
        "gripper_change": dist("gripper_change", lambda r: r.gripper_change),
        "n_steps": dist("n_steps", lambda r: float(r.n_steps)),
        "n_policy_queries": dist("n_policy_queries", lambda r: float(r.n_policy_queries)),
    }
    _ = records  # 保留签名一致性；样本池由 pool 决定
    return out


def task_state_displacement_curve(
    records: Sequence[EpisodeRecord],
    sweep: Sequence[float] = DEFAULT_DISPLACEMENT_SWEEP,
    *,
    quantity: str = "object",
) -> list[dict[str, float]]:
    """Task-State Displacement **Severity** Curve（mentor_review_1 §2.2）。

    ``P(任务状态改变量 > τ | 初始已满足)``，τ 是**严重度**刻度。

    ⚠️ **这不是"是否交互"的真值边界。** 提高 τ 会漏掉：
    接触但没推动、抓取尝试但抓空、移动 1–4cm、关节短暂变化后恢复、
    高风险但没造成位移的动作。所以：
      - 不要用某一个 τ 上的取值当"是否交互"的门槛；
      - 不要把整条曲线叫 UTIR。

    ``quantity`` 决定横轴是哪种物理量（§3.6：不同物理量不能塞进同一条曲线）：

      - ``"object"``  : 任务实体位移（米），placement 任务用
      - ``"joint"``   : 任务关节的**归一化**最大偏离（占行程比例），articulated 用
    """
    pool = _initially_satisfied(records)
    if quantity == "object":
        getter = lambda r: r.object_max_displacement  # noqa: E731
        key = "object_threshold_m"
        # 物体位移是 v1 就有的字段，任何记录都测过
        measurable = list(pool)
        unmeasured_note = ""
    elif quantity == "joint":
        getter = lambda r: r.task_joint_normalized_max  # noqa: E731
        key = "joint_normalized_threshold"
        # §3.5：只有**真的测过关节**的记录才算数。
        # 旧记录（v2 之前）没有关节通道，其 0 是占位符而不是"没动关节"——
        # 若把它们算进曲线，会画出一条全 0 的假曲线，读起来像"从没动过关节"。
        measurable = [
            r for r in pool
            if not np.isnan(getattr(r, "task_joint_range_span", float("nan")))
        ]
        unmeasured_note = (
            "关节通道未测量：本批记录没有 task_joint_range_span"
            "（v2.1 之前的记录不含关节通道），0 是占位符而不是'没动关节'"
        )
    else:
        raise ValueError(f"未知 quantity={quantity!r}，只能是 'object' 或 'joint'")

    if not measurable:
        return [{
            key: float(t), "rate": float("nan"), "n": 0,
            "measured": False, "note": unmeasured_note or "无可用记录",
        } for t in sweep]

    out: list[dict[str, float]] = []
    for t in sweep:
        vals = [1.0 if getter(r) > float(t) else 0.0 for r in measurable]
        out.append({
            key: float(t), "rate": float(np.mean(vals)), "n": len(vals),
            "measured": True, "note": "",
        })
    return out


def compute_all_v2(
    records: Sequence[EpisodeRecord],
    *,
    thresholds: InterventionThresholds = DEFAULT_THRESHOLDS,
    n_boot: int = 10_000,
    seed: int = 0,
) -> dict[str, Any]:
    """v2 指标总入口。

    按 mentor_review_1 §2.3，**不再输出单一 UTIR 总指标**，改为四层分离：

      - ``umr``                   机器人是否明显运动（运动学）
      - ``task_contact_rate``     是否接触任务实体（contact，可能未测量）
      - ``task_state_displacement``  是否产生超过 τ 的任务状态改变（严重度曲线）
      - ``gdr``                   目标是否被破坏（需要 probe 观察窗口）
    """
    init_sat = _initially_satisfied(records)
    has_contact = sum(1 for r in init_sat if r.contact_task_object is not None)
    return {
        "metric_version": "v2.1",
        "n_records": len(records),
        "n_initially_satisfied": len(init_sat),
        # 遗留口径，仅用于复现旧报告
        "legacy_uer": compute_uer(records, thresholds, n_boot=n_boot, seed=seed).as_dict(),
        # 四层分离
        "umr": compute_umr(records, thresholds, n_boot=n_boot, seed=seed).as_dict(),
        "task_contact_rate": compute_task_contact_rate(
            records, n_boot=n_boot, seed=seed
        ).as_dict(),
        "task_state_displacement_object": task_state_displacement_curve(
            records, quantity="object"
        ),
        "task_state_displacement_joint": task_state_displacement_curve(
            records, quantity="joint"
        ),
        "utir_displacement_only": compute_utir(
            records, thresholds, n_boot=n_boot, seed=seed
        ).as_dict(),
        "gdr": compute_gdr_v2(records, n_boot=n_boot, seed=seed).as_dict(),
        "gdr_without_probe_requirement": compute_gdr_v2(
            records, n_boot=n_boot, seed=seed, require_probe=False
        ).as_dict(),
        "fsr": compute_fsr(records).as_dict(),
        "cumulative": compute_cumulative(records, pool=init_sat),
        "success_rate_all": compute_success_rate(records, None, n_boot=n_boot, seed=seed).as_dict(),
        "thresholds": thresholds.as_dict(),
        "contact_coverage": {
            "n_initially_satisfied": len(init_sat),
            "n_contact_measured": has_contact,
            "coverage": (has_contact / len(init_sat)) if init_sat else float("nan"),
        },
        "notes": [
            "UMR/contact/displacement/GDR 的样本池 = 初始 predicate 为 True 的可用 episode，"
            "与 condition 名字无关，保证 terminal / scene-edit / intermediate 同口径。",
            "legacy_uer 为三通道混合口径，且其 gripper 分支因量纲错误从未触发，"
            "仅用于复现旧报告。",
            "Task-State Displacement 是**严重度**曲线，不是'是否交互'的真值边界"
            "（mentor_review_1 §2.2）。",
            "GDR 默认要求 post-completion 观察窗口；没有窗口时返回未测量，"
            "而不是空洞的 0（§3.4）。",
            "FSR 未测量：plan1 未训练 STOP head。",
        ],
    }


def compute_all(
    records: Sequence[EpisodeRecord],
    *,
    thresholds: InterventionThresholds = DEFAULT_THRESHOLDS,
    n_boot: int = 10_000,
    seed: int = 0,
) -> dict[str, Any]:
    """一次算出 Fast 版本需要的全部指标。"""
    usable = _usable(records)
    return {
        "n_records": len(records),
        "n_usable": len(usable),
        "n_dropped": len(records) - len(usable),
        "uer": compute_uer(records, thresholds, n_boot=n_boot, seed=seed).as_dict(),
        "uer_curve": uer_curve(records),
        "gdr": compute_gdr(records, n_boot=n_boot, seed=seed).as_dict(),
        "success_rate_all": compute_success_rate(records, None, n_boot=n_boot, seed=seed).as_dict(),
        "success_rate_satisfied": compute_success_rate(records, "satisfied", n_boot=n_boot, seed=seed).as_dict(),
        "success_rate_unsatisfied": compute_success_rate(records, "unsatisfied", n_boot=n_boot, seed=seed).as_dict(),
        "post_completion_steps": compute_post_completion_steps(records).as_dict(),
        "thresholds": thresholds.as_dict(),
    }


# ---------------------------------------------------------------------------
# GO / NO-GO (§12 / §23)
# ---------------------------------------------------------------------------


@dataclass
class GoNoGo:
    decision: str
    """``GO-A`` | ``GO-B`` | ``CONDITIONAL``"""

    uer: float
    rationale: str
    next_actions: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "uer": self.uer,
            "rationale": self.rationale,
            "next_actions": self.next_actions,
        }


def decide_go_no_go(uer: float, unsatisfied_sr: float | None = None) -> GoNoGo:
    """按执行方案 §12 的 W1 判定规则给出决定。

    §12 的三档：
      UER > 50%          -> GO-A，问题很强
      20% < UER <= 50%   -> GO-B，问题中等，重点转向 partial / PAB-H
      UER <= 20%         -> Conditional GO，**不要立即放弃**，
                            继续测 partial 与 history-dependent task

    ``unsatisfied_sr`` 是**健全性前提**，不是判定档位：
    UER 只有在"模型确实会做这个任务"时才有意义。如果 unsatisfied 成功率很低，
    那 UER 反映的可能是"模型整体失效"而不是"缺乏执行必要性判断"。
    （这一条是踩坑后加的：早期 unsatisfied 因构造错误全军覆没，
    差点把 UER=1.0 当成有效结论。）
    """
    if np.isnan(uer):
        return GoNoGo("UNDETERMINED", uer, "UER 无法计算（无可用 satisfied episode）", ["检查状态构造与评估日志"])

    # 前提校验：模型得先会做这个任务
    if unsatisfied_sr is not None and not np.isnan(unsatisfied_sr) and unsatisfied_sr < 0.5:
        return GoNoGo(
            "PREMISE_FAILED",
            uer,
            f"unsatisfied 成功率仅 {unsatisfied_sr:.1%} —— **前提不成立**："
            f"模型在该任务上本来就做不好，此时 UER={uer:.1%} 不能解读为"
            "'缺乏执行必要性判断'。",
            [
                "先排查 harness：动作后处理（夹爪归一化+符号）、unnorm_key 是否按 suite 切换、初始状态是否正确",
                "用官方 run_libero_eval.py 在同一 checkpoint/环境上建立'能成功'的参照点",
                "确认模型确实会做之后，再解读 UER",
            ],
        )

    if uer > 0.50:
        return GoNoGo(
            "GO-A",
            uer,
            f"UER = {uer:.1%} > 50%：'Learning Not to Act' 失败模式很强，现象成立。",
            ["按原计划推进 M1-W2（扩到 8 个 PAB-S task family，加入 partial 状态）"],
        )
    if uer > 0.20:
        return GoNoGo(
            "GO-B",
            uer,
            f"UER = {uer:.1%} 落在 20%~50%：问题真实存在但不算极端。",
            [
                "继续推进，但把重点放在 partial 状态与 PAB-H",
                "检查是否存在视觉 shortcut 让部分 satisfied 状态变得'显然完成'",
            ],
        )
    return GoNoGo(
        "CONDITIONAL",
        uer,
        f"UER = {uer:.1%} <= 20%：**不能据此判定 NO-GO**（§12）。",
        [
            "继续测试 partial 状态（M1-W2）",
            "构造 PAB-H history-dependent 任务（M1-W3）",
            "只有 PAB-S 与 PAB-H 都没有明显问题时，才真正考虑换题",
            "同时排查：satisfied 状态是否过于'显然'（例如物体摆放位置泄露了标签）",
        ],
    )
