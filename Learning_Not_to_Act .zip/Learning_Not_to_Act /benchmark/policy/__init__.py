"""策略层：被评估模型的统一接口。

本层是**唯一**需要 GPU 的地方。其余各层（benchmark / eval / metrics）
都不依赖 torch 或 7B 权重。
"""

from benchmark.policy.base import DummyPolicy, Policy

__all__ = ["Policy", "DummyPolicy"]


def __getattr__(name: str):
    """``OpenVLAOFTAdapter`` 延迟导入（避免在无 torch 环境 import 失败）。"""
    if name == "OpenVLAOFTAdapter":
        from benchmark.policy.base import OpenVLAOFTAdapter

        return OpenVLAOFTAdapter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
