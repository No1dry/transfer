"""策略接口与参考实现。

为什么要定义 ``Policy`` 协议
---------------------------
执行方案 §69 第 4-5 步（跑 160 episode、算 UER/GDR）要求 harness 能对接**任意**
被评估模型（OpenVLA-OFT、VLM-as-Judge、后续的 ENA），而 harness 本身不应该
依赖 torch / transformers / 7B 权重。所以：

    上层只认 ``Policy.predict(obs, task_language) -> np.ndarray[7]``

这样 harness 在 CPU 机器上也能跑通（配 ``DummyPolicy`` 或 ``MockArena``），
真正需要 GPU 的只有 ``OpenVLAOFTAdapter`` 这一个薄封装。
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np

from benchmark.arena.protocol import Observation


@runtime_checkable
class Policy(Protocol):
    """被评估策略。"""

    name: str
    """用于结果文件命名与报告。"""

    def reset(self) -> None:
        """每个 episode 开始时调用（清空动作队列 / 内部状态）。"""

    def predict(self, obs: Observation, task_language: str) -> np.ndarray:
        """返回一个动作 chunk 或多个动作。

        返回形状可以是 ``(7,)`` 或 ``(T, 7)``。harness 会按顺序执行。
        动作语义与 LIBERO 一致：``[dx, dy, dz, droll, dpitch, dyaw, gripper]``。
        """


class DummyPolicy:
    """参考策略：不做任何模型推理。

    用途：
      * ``noop``   —— 恒等零动作。用于验证 harness 正确性：
                      在 satisfied 状态下它应当得到 UER = 0，
                      在 unsatisfied 状态下应当得到 SR = 0。
      * ``push``   —— 恒定小幅推移。用于制造"永远在动"的极端，
                      应当得到 UER = 1。它同时也是 GDR 的阳性对照。
      * ``scripted``—— 朝目标推进的简单控制器，用于端到端演练 SR > 0 的路径。

    ``noop`` 与 ``push`` 是两个**已知答案**的极端，因此它们能当作
    harness 的"标准砝码"：如果 harness 在这两个策略上给不出预期数值，
    说明指标计算或信号采集有 bug，而不是模型有问题。
    """

    def __init__(
        self,
        mode: str = "noop",
        *,
        magnitude: float = 1.0,
        seed: int = 0,
        target_xy: tuple[float, float] | None = None,
    ):
        if mode not in ("noop", "push", "scripted"):
            raise ValueError(f"未知 DummyPolicy mode: {mode!r}")
        self.mode = mode
        self.name = f"dummy_{mode}"
        self.magnitude = float(magnitude)
        self.seed = int(seed)
        self.target_xy = target_xy
        self._rng = np.random.default_rng(seed)

    def reset(self) -> None:
        self._query = 0

    def predict(self, obs: Observation, task_language: str) -> np.ndarray:
        if self.mode == "noop":
            return np.zeros(7, dtype=np.float64)

        if self.mode == "push":
            # 模拟"永远在动的 VLA"：不考虑当前状态，直接全速冲向目标位置 + 闭合夹爪。
            #
            # 这正是 H1（Execution Necessity Gap）描述的失败模式：
            # 指令是 "put the bowl on the plate"，策略就一味朝 plate 推进，
            # 完全不检查"碗是不是已经在盘子上了"。
            # 任务已完成时，它会撞上碗并把它推离盘子 —— UER 与 GDR 双高。
            #
            # 两个设计细节都是必要的：
            #   * 朝**目标**全速推进（而不是朝物体）：让 eef 与物体发生接触，
            #     才能真的扰动已完成的目标；
            #   * 不按距离减速：减速会让它在目标附近停住，破坏不了目标。
            action = np.zeros(7, dtype=np.float64)
            d, _ = self._direction_and_distance_to_target(obs)
            action[0], action[1] = d[0], d[1]
            action[6] = 1.0  # 闭合夹爪
            return action * self.magnitude

        # scripted: 把任务实体朝目标推进。
        #
        # 这不是为了"做出一个强 baseline"，而是为 harness 提供一个
        # **已知应当成功**的对照：如果连它都拿不到 SR > 0，
        # 说明成功路径的记账（done / final_satisfied / n_steps）有问题。
        #
        # 用比例控制（按剩余距离缩放步长）而不是恒速，否则会一直冲过目标
        # 来回震荡，永远不满足 success 半径。
        action = np.zeros(7, dtype=np.float64)
        ent = (obs.raw or {}).get("task_entities")
        target = np.asarray(
            ent["target_xy"] if ent else (self.target_xy or (0.0, 0.0)), dtype=np.float64
        )
        origin = np.asarray(ent["subject_pos"], dtype=np.float64)[:2] if ent else np.asarray(obs.state[:2])
        delta = target - origin
        n = float(np.linalg.norm(delta))
        if n < 1e-9:
            return action
        action[0], action[1] = (delta / n) * min(1.0, max(n - 0.005, 0.0) / 0.05)
        return action

    # ------------------------------------------------------------------

    def _direction_and_distance_to_target(self, obs: Observation) -> tuple[tuple[float, float], float]:
        """由本体感受推算"朝目标"的 xy 方向与剩余距离。

        MockArena 里 eef 与物体联动，所以朝目标走就会推动物体；
        真实 LIBERO 里这个方向只是启发式（仅供 harness 的已知答案测试使用，
        不作为正式 baseline）。
        """
        if self.target_xy is None:
            return (1.0, 0.0), float("inf")
        eef = np.asarray(obs.state[:2], dtype=np.float64)
        delta = np.asarray(self.target_xy, dtype=np.float64) - eef
        n = float(np.linalg.norm(delta))
        if n < 1e-6:
            return (1.0, 0.0), 0.0
        return (float(delta[0] / n), float(delta[1] / n)), n

    def _direction_to_target(self, obs: Observation) -> tuple[float, float]:
        d, _ = self._direction_and_distance_to_target(obs)
        return d


class OpenVLAOFTAdapter:
    """OpenVLA-OFT 适配器（需要 GPU 机器）。

    **延迟导入**：本模块在 import 时不加载 torch / openvla-oft，
    这样在没装这些依赖的机器上，其余代码仍然可以导入与单测。

    参数
    ----
    openvla_oft_root:
        openvla-oft 仓库根目录（例如 /path/to/openvla-oft）。
        该仓库的 ``experiments/robot`` 会被加入 sys.path。
    checkpoint:
        例如 ``moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10``。
    unnorm_key:
        动作反归一化 key，通常等于 task suite 名（例如 ``libero_goal``）。
    """

    def __init__(
        self,
        openvla_oft_root: str,
        checkpoint: str,
        *,
        unnorm_key: str = "libero_goal",
        num_images_in_input: int = 2,
        use_proprio: bool = True,
        use_l1_regression: bool = True,
        num_open_loop_steps: int = 8,
        center_crop: bool = True,
        lora_rank: int = 32,
        device: str = "cuda:0",
        name: str | None = None,
    ):
        self.name = name or f"openvla_oft::{checkpoint.split('/')[-1]}"
        # 字段必须覆盖 openvla-oft 的 get_vla / get_action 会读到的全部属性，
        # 否则会在运行时报 AttributeError。这里刻意把 load_in_8bit / load_in_4bit
        # 也显式置 False —— 4090 有 24GB，7B 模型用 bf16 正常加载即可，
        # 不需要量化（量化反而会改变与原论文的可比性）。
        self._cfg_kwargs = dict(
            model_family="openvla",
            pretrained_checkpoint=checkpoint,
            unnorm_key=unnorm_key,
            num_images_in_input=num_images_in_input,
            use_proprio=use_proprio,
            use_l1_regression=use_l1_regression,
            use_diffusion=False,
            use_film=False,
            num_open_loop_steps=num_open_loop_steps,
            center_crop=center_crop,
            lora_rank=lora_rank,
            load_in_8bit=False,
            load_in_4bit=False,
            num_diffusion_steps_train=50,
            num_diffusion_steps_inference=50,
        )
        self._openvla_oft_root = openvla_oft_root
        self._device = device
        self._loaded = False
        self._current_unnorm_key: str | None = None
        # 最近一次前向的原始动作 / 处理后动作（供 trace 使用）
        self.last_raw_actions: np.ndarray | None = None
        self.last_processed_actions: np.ndarray | None = None

    # ------------------------------------------------------------------

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return

        import sys
        from dataclasses import dataclass
        from pathlib import Path

        root = str(Path(self._openvla_oft_root).resolve())
        if root not in sys.path:
            sys.path.insert(0, root)

        # 延迟到真正加载时才 import
        from experiments.robot.openvla_utils import (  # type: ignore
            get_action_head,
            get_noisy_action_projector,
            get_processor,
            get_proprio_projector,
        )
        from experiments.robot.robot_utils import get_model  # type: ignore
        from prismatic.vla.constants import NUM_ACTIONS_CHUNK  # type: ignore

        # 复刻 run_libero_eval.py 的 GenerateConfig 字段（用 dataclass 动态构造，
        # 避免把 openvla-oft 的 draccus config 依赖带进本项目）
        @dataclass
        class _Cfg:
            pass

        cfg = _Cfg()
        for k, v in self._cfg_kwargs.items():
            setattr(cfg, k, v)

        self._NUM_ACTIONS_CHUNK = NUM_ACTIONS_CHUNK
        self._model = get_model(cfg)
        self._processor = get_processor(cfg)
        self._action_head = (
            get_action_head(cfg, self._model.llm_dim)
            if (cfg.use_l1_regression or cfg.use_diffusion)
            else None
        )
        self._noisy_action_projector = get_noisy_action_projector(cfg, self._model.llm_dim) if cfg.use_diffusion else None
        self._proprio_projector = (
            get_proprio_projector(cfg, self._model.llm_dim, proprio_dim=8) if cfg.use_proprio else None
        )
        # 动作反归一化 key 校正。
        #
        # openvla-oft 的这个逻辑写在 run_libero_eval.py 的 check_unnorm_key 里，
        # 不在 openvla_utils 里 —— 直接复用官方推理函数时很容易漏掉，
        # 漏掉的症状是 predict_action 抛 KeyError: 'libero_goal'。
        # 本 checkpoint 的 dataset_statistics.json 里 key 带 _no_noops 后缀，
        # 因此必须做这个回退。
        self._cfg = cfg
        self._resolve_unnorm_key(cfg.unnorm_key)
        self._loaded = True

    # ------------------------------------------------------------------

    def reset(self) -> None:
        """无内部状态：action chunk 的排队由 harness 负责。"""
        return None

    def predict(self, obs: Observation, task_language: str) -> np.ndarray:
        """返回完整 action chunk（长度 NUM_ACTIONS_CHUNK）。"""
        self._ensure_loaded()

        import sys

        if self._openvla_oft_root not in sys.path:
            sys.path.insert(0, self._openvla_oft_root)
        from experiments.robot.robot_utils import get_action  # type: ignore

        observation = {
            "full_image": obs.full_image,
            "wrist_image": obs.wrist_image,
            "state": obs.state,
        }
        actions = get_action(
            self._cfg,
            self._model,
            observation,
            task_language,
            processor=self._processor,
            action_head=self._action_head,
            proprio_projector=self._proprio_projector,
            noisy_action_projector=self._noisy_action_projector,
            use_film=False,
        )
        raw = np.asarray(actions, dtype=np.float64)

        # 保留原始输出，供 action causality trace 区分四个环节：
        #   model(raw) -> postprocess(processed) -> controller -> physics
        # 没有这一步就无法判断"不闭夹爪"到底发生在哪一层。
        self.last_raw_actions = raw.copy()
        processed = self.process_action(raw)
        self.last_processed_actions = np.asarray(processed, dtype=np.float64).copy()
        return processed

    # ------------------------------------------------------------------
    # 动作反归一化 key：**必须按 task 所属 suite 切换**
    # ------------------------------------------------------------------

    def _resolve_unnorm_key(self, key: str) -> str:
        """把 suite 名解析成 checkpoint 里真实存在的 norm_stats key。"""
        norm_stats = getattr(self._model, "norm_stats", {}) or {}
        resolved = key
        if resolved not in norm_stats and f"{resolved}_no_noops" in norm_stats:
            resolved = f"{resolved}_no_noops"
        if resolved not in norm_stats:
            raise KeyError(
                f"动作反归一化 key {key!r} 不在 checkpoint 的 norm_stats 中。"
                f"可用 key: {sorted(norm_stats)}"
            )
        # _cfg 只在实际加载后才存在；未加载时把结果写回 cfg_kwargs，
        # 由 _ensure_loaded 在建 cfg 时带进去。
        if getattr(self, "_cfg", None) is not None:
            self._cfg.unnorm_key = resolved
        else:
            self._cfg_kwargs["unnorm_key"] = resolved
        self._current_unnorm_key = resolved
        return resolved

    def set_unnorm_key(self, suite: str) -> None:
        """按当前 task 的 suite 切换动作反归一化统计量。

        为什么必须切：动作反归一化用的 quantile 是**按 suite 分别统计**的，
        各 suite 差别不小。实测本 checkpoint：

            libero_goal    dim0 q01/q99 = [-0.879, 0.938]   (跨度 1.82)
            libero_object  dim0 q01/q99 = [-0.538, 0.846]   (跨度 1.38)

        若拿 libero_goal 的统计量去反归一化 libero_object 的动作，
        平移/旋转幅度会被放大到约 1.3 倍 —— 不会报错，只是默默变差。
        官方 eval 是每个 suite 单独跑、`unnorm_key = task_suite_name`，
        所以不会碰到这个问题；而 Mini-PAB 一个进程里混了多个 suite，
        必须显式切换。
        """
        if not self._loaded:
            self._cfg_kwargs["unnorm_key"] = suite
            return
        if getattr(self, "_current_unnorm_key", None) == suite or \
                getattr(self, "_current_unnorm_key", None) == f"{suite}_no_noops":
            return
        resolved = self._resolve_unnorm_key(suite)
        print(f"[OpenVLAOFTAdapter] unnorm_key -> {resolved!r} (suite={suite})", flush=True)

    # ------------------------------------------------------------------
    # 动作后处理：必须与官方 run_libero_eval.py 完全一致
    # ------------------------------------------------------------------

    @staticmethod
    def process_action(action: np.ndarray, model_family: str = "openvla") -> np.ndarray:
        """把模型输出转成环境可执行的动作。

        **这一步不能省。** 官方 ``run_libero_eval.py`` 里有一个
        ``process_action``：

          1. ``normalize_gripper_action(binarize=True)``
             模型输出夹爪在 [0,1]（0=close, 1=open），环境要 [-1,+1]；
             并按 0.5 二值化。
          2. ``invert_gripper_action``
             OpenVLA 的 dataloader 在训练时翻过夹爪符号，
             推理时要翻回来（-1=open, +1=close）。

        早期版本的适配器直接把 ``get_action`` 的原始输出交给环境，
        相当于**每一步的夹爪指令都是反的** —— 抓取永远失败，
        所有 episode 都不成功，而表面上看只是"模型比较弱"。
        这种错误很容易被误读成模型的真实能力，所以特别记在这里。
        """
        action = np.asarray(action, dtype=np.float64).copy()
        if action.size < 7:
            return action

        # 1) [0,1] -> [-1,+1]，再二值化。
        #
        # 必须逐步对齐官方实现：
        #   normalize_gripper_action: y = 2*(x-0)/(1-0) - 1 = 2x - 1
        #                             y = np.sign(y)        # 注意是 sign，不是 x>0.5
        #   invert_gripper_action:    y = -y   (OpenVLA)
        #
        # 早期这里写成 ``(x > 0.5) * 2 - 1``，在 x 恰好等于 0.0 / 0.5 时
        # 与 sign() 不一致（sign(0)=0，而 (0>0.5)->-1），属于会被忽略的偏差。
        # 直接照抄官方的两步，别自己发明等价形式。
        action[..., -1] = 2.0 * action[..., -1] - 1.0
        action[..., -1] = np.sign(action[..., -1])

        if model_family == "openvla":
            action[..., -1] *= -1.0

        return action
