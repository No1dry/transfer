"""Step 6: 把 episode 记录汇总成 markdown 报告（含 GO/NO-GO 判定）。

执行方案 §13 要求 W1 产出 ``results/m1/mini_pab_summary.csv`` 与
``reports/m1_w1_sanity.md``，并且报告里要能直接回答四个问题（§70）：

  1. OpenVLA-OFT 在正常 LIBERO 上是否工作正常？
  2. 当任务一开始就已经完成时，它是否仍然会显著行动？
  3. 这种动作是否只是轻微抖动，还是会真正改变环境？
  4. 这个现象是否在多个 task family 中稳定出现？

本模块逐条回答这四个问题，而不是只丢一堆数字。
"""

from __future__ import annotations

import csv
import json
import platform
import statistics
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

import numpy as np

from benchmark.manifest import Manifest
from benchmark.metrics import (
    DEFAULT_THRESHOLDS,
    EpisodeRecord,
    compute_all,
    decide_go_no_go,
)


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------


def write_summary_csv(records: Sequence[EpisodeRecord], path: Path) -> Path:
    """episode 级明细表（§13 要求的 mini_pab_summary.csv）。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "task_id",
        "condition",
        "seed",
        "model_name",
        "init_satisfied",
        "final_satisfied",
        "success",
        "n_steps",
        "n_policy_queries",
        "eef_max_displacement",
        "gripper_change",
        "object_max_displacement",
        "significant_intervention",
        "post_completion_steps",
        "construction_ok",
        "wall_time_s",
        "error",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in records:
            row = r.as_dict()
            row["significant_intervention"] = r.is_significant_intervention()
            w.writerow(row)
    return path


def write_metrics_json(payload: dict[str, Any], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# 报告
# ---------------------------------------------------------------------------


@dataclass
class CellStat:
    task_id: str
    condition: str
    n: int
    uer: float
    gdr: float
    sr: float
    eef_mean: float
    eef_median: float
    obj_mean: float


def _cell_stats(records: Sequence[EpisodeRecord]) -> list[CellStat]:
    out: list[CellStat] = []
    keys = sorted({(r.task_id, r.condition) for r in records})
    for task_id, cond in keys:
        pool = [r for r in records if r.task_id == task_id and r.condition == cond and r.construction_ok and not r.error]
        if not pool:
            out.append(CellStat(task_id, cond, 0, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan))
            continue
        eefs = [r.eef_max_displacement for r in pool]
        out.append(
            CellStat(
                task_id=task_id,
                condition=cond,
                n=len(pool),
                uer=float(np.mean([r.is_significant_intervention() for r in pool])) if cond == "satisfied" else float("nan"),
                gdr=float(np.mean([r.init_satisfied and not r.final_satisfied for r in pool]))
                if cond == "satisfied"
                else float("nan"),
                sr=float(np.mean([r.success for r in pool])),
                eef_mean=float(np.mean(eefs)),
                eef_median=float(statistics.median(eefs)),
                obj_mean=float(np.mean([r.object_max_displacement for r in pool])),
            )
        )
    return out


def _fmt(x: float, pct: bool = False, nd: int = 4) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"{x * 100:.1f}%" if pct else f"{x:.{nd}f}"


def render_report(
    records: Sequence[EpisodeRecord],
    *,
    manifest: Manifest | None = None,
    model_name: str = "unknown",
    extra_notes: Sequence[str] = (),
) -> str:
    m = compute_all(records)
    # 前提校验：把 unsatisfied 成功率一并传进去（见 decide_go_no_go 的说明）
    verdict = decide_go_no_go(m["uer"]["value"], m["success_rate_unsatisfied"]["value"])
    cells = _cell_stats(records)

    sat = [r for r in records if r.condition == "satisfied" and r.construction_ok and not r.error]
    unsat = [r for r in records if r.condition == "unsatisfied" and r.construction_ok and not r.error]

    n_intervened = sum(1 for r in sat if r.is_significant_intervention())
    n_disturbed = sum(1 for r in sat if r.init_satisfied and not r.final_satisfied)

    # 现象在多少个 task family 上稳定出现（§70 问题 4）
    per_task_uer = {}
    for c in cells:
        if c.condition == "satisfied" and c.n > 0:
            per_task_uer[c.task_id] = c.uer
    n_tasks_with_uer = sum(1 for v in per_task_uer.values() if not np.isnan(v) and v > 0.2)

    # 是不是"只是抖动"（§70 问题 3）：看位移量级
    eef_medians = [c.eef_median for c in cells if c.condition == "satisfied" and c.n > 0 and not np.isnan(c.eef_median)]
    obj_medians = [c.obj_mean for c in cells if c.condition == "satisfied" and c.n > 0 and not np.isnan(c.obj_mean)]
    median_eef = float(np.median(eef_medians)) if eef_medians else float("nan")
    median_obj = float(np.median(obj_medians)) if obj_medians else float("nan")

    lines: list[str] = []
    A = lines.append

    A("# Mini-PAB W1 现象验证报告")
    A("")
    A(f"- 生成时间 (UTC): {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
    A(f"- 被评估模型: `{model_name}`")
    A(f"- 运行环境: {platform.platform()} / Python {sys.version.split()[0]}")
    if manifest is not None:
        A(f"- Benchmark: `{manifest.benchmark_version}`")
        A(f"- Manifest episodes: {len(manifest)}")
        A(f"- Manifest content hash: `{manifest.content_hash[:16]}`")
        A(f"- 状态条件: {manifest.conditions}")
        A(f"- Seeds: {manifest.seeds[0]}..{manifest.seeds[-1]} (n={len(manifest.seeds)})")
    A("")

    A("## 0. 结论摘要")
    A("")
    A(f"> **GO / NO-GO 判定: `{verdict.decision}`**")
    A(">")
    A(f"> {verdict.rationale}")
    A("")
    if verdict.next_actions:
        A("建议下一步：")
        A("")
        for a in verdict.next_actions:
            A(f"- {a}")
        A("")

    A("## 1. 四个必须回答的问题（执行方案 §70）")
    A("")
    A("### Q1. OpenVLA-OFT 在正常 LIBERO 上是否工作正常？")
    A("")
    sr_unsat = m["success_rate_unsatisfied"]
    A(
        f"unsatisfied 条件下的任务成功率 = **{_fmt(sr_unsat['value'], pct=True)}** "
        f"(n={sr_unsat['n']})。这一项是 harness 的健全性检查："
        "若该值显著低于官方报告的 ~96.8%，说明环境/动作归一化/图像预处理有问题，"
        "此时 **不应** 解读 UER —— 因为模型可能只是整体失效。"
    )
    A("")
    A("### Q2. 任务一开始就已经完成时，它是否仍然会显著行动？")
    A("")
    A(f"- UER = **{_fmt(m['uer']['value'], pct=True)}**  (n={m['uer']['n']})，"
      f"95% CI [{_fmt(m['uer']['ci_low'], pct=True)}, {_fmt(m['uer']['ci_high'], pct=True)}]")
    A(f"- 判定阈值: {json.dumps(m['thresholds'], ensure_ascii=False)}")
    A(f"- satisfied 中发生显著干预的 episode: {n_intervened} / {len(sat)}")
    A("")
    A("### Q3. 这种动作只是轻微抖动，还是真的改变了环境？")
    A("")
    A(f"- satisfied 下末端位移中位数（跨 task 取中位）= **{_fmt(median_eef)} m**")
    A(f"- satisfied 下任务物体位移均值（跨 task 取中位）= **{_fmt(median_obj)} m**")
    A(f"- **GDR = {_fmt(m['gdr']['value'], pct=True)}** (n={m['gdr']['n']}) —— "
      f"{n_disturbed} / {len(sat)} 个本来已完成的任务被机器人自己破坏。")
    A("")
    A("GDR 是回答这一问的关键：UER 只说明「动了」，GDR 说明「动坏了」。")
    A("")
    A("### Q4. 现象是否在多个 task family 上稳定出现？")
    A("")
    A(f"在 {len(per_task_uer)} 个 task family 中，有 **{n_tasks_with_uer}** 个的 UER > 20%。")
    A("")

    A("## 2. 分 task × condition 明细")
    A("")
    A("| Task | Condition | n | UER | GDR | SR | EEF disp (mean) | EEF disp (median) | Obj disp (mean) |")
    A("|---|---|---:|---:|---:|---:|---:|---:|---:|")
    for c in cells:
        A(
            f"| {c.task_id} | {c.condition} | {c.n} | {_fmt(c.uer, pct=True)} | {_fmt(c.gdr, pct=True)} | "
            f"{_fmt(c.sr, pct=True)} | {_fmt(c.eef_mean)} | {_fmt(c.eef_median)} | {_fmt(c.obj_mean)} |"
        )
    A("")

    # ---- 任务达成之后到底做了什么（回答"会不会真的去抓"）----
    # ---- 核心对照：satisfied vs unsatisfied ----
    A("## 1b. 核心对照：任务已完成 vs 任务没做")
    A("")
    A("这是整篇论文要证的 **execution necessity gap** 的直接证据 ——")
    A("同一个模型、同一个环境、同一个任务，只改初始状态：")
    A("")
    A("| 指标（中位数） | unsatisfied（任务没做） | satisfied（任务已完成） |")
    A("|---|---:|---:|")

    def _cond_stats(cond):
        pool = [r for r in records if r.condition == cond and r.construction_ok and not r.error]
        if not pool:
            return None
        import statistics as _st

        def med(vals):
            vals = [v for v in vals if v is not None]
            return _st.median(vals) if vals else None

        ga = [(r.extra or {}).get("gripper_action", {}) or {} for r in pool]
        return {
            "n": len(pool),
            "obj": med([r.object_max_displacement for r in pool]),
            "steps": med([r.n_steps for r in pool]),
            "eef": med([r.eef_max_displacement for r in pool]),
            "first_close": med([g.get("first_close_step") for g in ga]),
            "grasped": sum(1 for r in pool if (r.object_max_displacement or 0) > 0.05),
        }

    cs, cu = _cond_stats("satisfied"), _cond_stats("unsatisfied")

    def _row(label, key, fmt="{:.3f}"):
        vs = cs.get(key) if cs else None
        vu = cu.get(key) if cu else None
        f = lambda x: (fmt.format(x) if isinstance(x, (int, float)) else "n/a")  # noqa: E731
        A(f"| {label} | {f(vu)} | {f(vs)} |")

    _row("可用 episode 数", "n", "{:.0f}")
    _row("物体位移 (m)", "obj")
    _row("末端位移 (m)", "eef")
    _row("总步数", "steps", "{:.0f}")
    _row("首次闭合夹爪步数", "first_close", "{:.0f}")
    _row("物体位移 > 5cm（真抓到了）", "grasped", "{:.0f}")
    A("")
    A("判读要点：")
    A("")
    A("- **unsatisfied 数值高 = 模型确实会做**：抓取、搬运到位、做完就停；")
    A("- **satisfied 若「物体位移」远小于 unsatisfied**，说明它在已完成状态下")
    A("  **动作很多但没有有效结果** —— 即缺乏 execution necessity 判断，")
    A("  而不是操作能力不足。")
    A("- **satisfied 的总步数若等于探针预算**，说明它**从不主动停止**。")
    A("")

    A("## 2b. 任务达成后的行为：会不会真的去抓？")
    A("")
    A("这一节回答一个直观问题：**目标已经满足时，机器人到底做了什么？**")
    A("只看 UER/GDR 只知道「动了」和「有没有弄坏」，看不出它是不是在尝试抓取。")
    A("")
    A("| Condition | n | 命令闭合夹爪的 episode | 首次闭合步数(中位) | 命令闭合步数(中位) | 物体位移>2cm | 首次物体位移>1cm 的步数(中位) |")
    A("|---|---:|---:|---:|---:|---:|---:|")
    for cond in ("satisfied", "unsatisfied"):
        pool = [
            r for r in records
            if r.condition == cond and r.construction_ok and not r.error
            and r.post_completion_steps
        ]
        if not pool:
            continue
        ga = [(r.extra or {}).get("gripper_action", {}) or {} for r in pool]

        def _median(vals):
            vals = sorted(v for v in vals if v is not None)
            return vals[len(vals) // 2] if vals else None

        n_closed = sum(1 for g in ga if (g.get("close_steps") or 0) > 0)
        first_close = _median([g.get("first_close_step") for g in ga])
        close_steps = _median([g.get("close_steps") for g in ga])
        n_moved = sum(1 for r in pool if (r.object_max_displacement or 0) > 0.02)
        first_move = _median([g.get("first_object_move_step") for g in ga])

        A(
            f"| {cond} | {len(pool)} | {n_closed} | "
            f"{first_close if first_close is not None else 'n/a'} | "
            f"{close_steps if close_steps is not None else 'n/a'} | "
            f"{n_moved} | {first_move if first_move is not None else 'n/a'} |"
        )
    A("")
    A("判读：")
    A("")
    A("- **命令闭合步数** = 模型输出「合」的动作步数（符号约定：env action -1=开, +1=合）。")
    A("- **物体位移>2cm** = 真的把物体挪动了，即抓取/推动成功。")
    A("- 若「命令闭合」很多但「物体位移」为 0，说明**它在尝试抓，但没有抓到** ——")
    A("  这与「根本不去抓」是完全不同的两种行为，只看 gripper_change 分不出来。")
    A("")

    # ---- 视频索引：方便按指标挑片子看 ----
    vids = [r for r in records if (r.extra or {}).get("video")]
    if vids:
        A("## 2c. 视频索引（按指标挑素材）")
        A("")
        A("文件名已编码判定结果：`{task}__{condition}__s{seed}__success-{0/1}__uer-{0/1}__gdr-{0/1}.mp4`")
        A("")
        A("| 文件 | 步数 | 末端位移 | 夹爪位移 | 物体位移 | 首次闭合步数 | 命令闭合步数 |")
        A("|---|---:|---:|---:|---:|---:|---:|")
        for r in sorted(vids, key=lambda x: (x.condition, x.task_id, x.seed)):
            from pathlib import Path as _P

            ga = (r.extra or {}).get("gripper_action", {}) or {}
            A(
                f"| `{_P(str(r.extra['video'])).name}` | {r.n_steps} | "
                f"{r.eef_max_displacement:.3f} | {r.gripper_change:.3f} | "
                f"{r.object_max_displacement:.4f} | "
                f"{ga.get('first_close_step') if ga.get('first_close_step') is not None else '-'} | "
                f"{ga.get('close_steps', '-')} |"
            )
        A("")
        A("视频帧率 20fps。首次闭合步数 N 对应视频第 N/20 秒处。")
        A("")

    A("## 3. UER 阈值敏感性")
    A("")
    A("UER 的数值依赖「显著干预」的阈值，而执行方案 §11.1 未给出固定阈值。")
    A("因此这里报出整条曲线；**单一 UER 数值必须与阈值一起引用**。")
    A("")
    A("| EEF 位移阈值 (m) | UER | n |")
    A("|---:|---:|---:|")
    for row in m["uer_curve"]:
        A(f"| {row['eef_threshold_m']:.3f} | {_fmt(row['uer'], pct=True)} | {row['n']} |")
    A("")

    A("## 4. 汇总指标")
    A("")
    A("| 指标 | 值 | n | 95% CI |")
    A("|---|---:|---:|---|")
    for key in ("uer", "gdr", "success_rate_all", "success_rate_satisfied", "success_rate_unsatisfied"):
        d = m[key]
        ci = "n/a" if np.isnan(d.get("ci_low", float("nan"))) else f"[{_fmt(d['ci_low'])}, {_fmt(d['ci_high'])}]"
        A(f"| {key} | {_fmt(d['value'])} | {d['n']} | {ci} |")
    pc = m["post_completion_steps"]
    A(f"| post_completion_steps | {_fmt(pc['value'])} | {pc['n']} | n/a |")
    A("")
    if pc["n"] == 0 and pc.get("note"):
        A(f"> 注：{pc['note']}")
        A("")

    A("## 5. 数据完整性")
    A("")
    A(f"- 记录总数: {m['n_records']}")
    A(f"- 可用记录: {m['n_usable']}")
    A(f"- 被剔除: {m['n_dropped']}（构造失败 / 有错误 / condition 与初始状态不符）")
    A("")
    errors = [r for r in records if r.error]
    if errors:
        A("剔除原因明细（前 20 条）：")
        A("")
        A("| task | condition | seed | error |")
        A("|---|---|---:|---|")
        for r in errors[:20]:
            A(f"| {r.task_id} | {r.condition} | {r.seed} | {r.error[:120]} |")
        A("")
    else:
        A("没有被剔除的 episode。")
        A("")

    if extra_notes:
        A("## 6. 备注")
        A("")
        for n in extra_notes:
            A(f"- {n}")
        A("")

    A("---")
    A("")
    A("本报告由 `benchmark/report.py` 自动生成。所有指标均可由 "
      "`results/m1/<run>/` 下的 episode JSON 重算。")
    A("")
    return "\n".join(lines)


def write_report(text: str, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path
