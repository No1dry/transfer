"""Step 4: episode 运行器。

职责边界
--------
runner **不产生动作**（那是 Policy 的事），也**不计算指标**（那是 metrics 的事）。
它只负责：按 manifest 把一个 episode 跑完，并把所有可观测量如实记录下来。

关键实现细节
------------
1. **open-loop chunk 执行**：与官方 ``run_libero_eval.py`` 一致 ——
   策略一次返回一个 action chunk，连续执行 ``num_open_loop_steps`` 步后才重新查询。
   Mini-PAB 用 ``max_policy_queries`` 而不是 ``max_steps`` 作为预算，
   因为 7B 模型的时间成本几乎全在 policy query 上，用 query 数做预算更贴近真实成本。
2. **初始状态构造失败则整条 episode 作废**（``construction_ok=False``），
   不做任何"补偿"。宁可少一个样本，也不要一个标签错误的样本。
3. **记录物理位移而不是 action norm**，供 UER 判定（§11.1）。
4. **standard 模式**：目标达成即刻结束，与官方 eval 行为一致。
   ``post_completion_probe`` 模式会额外多跑 N 步，用于测量 §11.3。
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import numpy as np

from benchmark.arena.protocol import Arena
from benchmark.manifest import EpisodeSpec, Manifest, result_file_name
from benchmark.metrics import EpisodeRecord
from benchmark.policy.base import Policy
from benchmark.states.builder import ConstructionResult, StateBuilder
from benchmark.tasks.registry import TaskRegistry


@dataclass
class RunConfig:
    max_policy_queries: int = 80
    num_steps_wait: int = 10
    num_open_loop_steps: int = 8
    post_completion_probe_steps: int = 15
    """任务达成后继续执行的步数。

    为什么默认 **不是 0**：标准 LIBERO eval 在 ``done=True`` 时立即 break，
    于是 GDR 恒等于 0 —— 不是因为机器人没破坏目标，而是因为**根本没有观测窗口**。
    （本 harness 的 mock 演练实测：以"朝目标猛推"的策略，任务达成后再走 3 步
    就会把物体推出 success 半径。）

    因此默认开启一个短 probe 窗口（15 步），使 GDR 与 §11.3 可测。
    设为 0 可退回与官方 eval 完全一致的行为（此时 GDR 不可测，报告中会标注）。
    """

    post_completion_probe_steps_by_condition: dict | None = None
    """按 condition 覆盖探针预算，例如 ``{"satisfied": 250, "unsatisfied": 60}``。

    为什么需要：两个 condition 的观测需求完全不同 ——
      * satisfied：任务在起点就已完成，我们要看"它到底会不会去抓"。
        实测模型平均要 **~100-112 步**才开始命令夹爪闭合，
        所以 120 步的窗口只能看到"刚开始合"，看不到完整抓取；
      * unsatisfied：任务本来就要做，跑到成功即可，
        之后的窗口只需要够判断 GDR，60 步足够。
    统一预算会让 satisfied 观察不足、或让 unsatisfied 白跑几百步。
    """

    save_video: bool = False
    """录制任务视频。

    **默认录制全部 condition**（satisfied 与 unsatisfied）。

    最初这里默认只录 satisfied（"现象所在处"），那是个糟糕的默认值：
    unsatisfied 的"正常执行"正是报告里用来对照的基线 ——
    缺了它，视频无法回答"模型到底是不会做，还是做完了还在做"这个关键问题。
    要只录 satisfied，显式设 ``save_video_conditions=("satisfied",)``。
    """
    save_video_conditions: tuple[str, ...] | None = None
    """只录这些 condition；``None`` 表示全部。"""
    video_fps: int = 20
    verbose: bool = False


class EpisodeRunner:
    """跑单个 episode 或整个 manifest。"""

    def __init__(
        self,
        registry: TaskRegistry,
        builder: StateBuilder | None = None,
        config: RunConfig | None = None,
    ):
        self.registry = registry
        self.builder = builder or StateBuilder()
        self.config = config or RunConfig()

    # ------------------------------------------------------------------
    # 单个 episode
    # ------------------------------------------------------------------

    def run_episode(
        self,
        arena: Arena,
        policy: Policy,
        spec: EpisodeSpec,
        video_dir: Path | None = None,
    ) -> EpisodeRecord:
        cfg = self.config
        t_start = time.time()
        record = EpisodeRecord(
            task_id=spec.task_id,
            condition=spec.condition,
            seed=spec.seed,
            model_name=getattr(policy, "name", "unknown"),
        )

        task_spec = self.registry[spec.task_id]

        try:
            # --- 1. 构造初始状态 ---
            construction: ConstructionResult = self.builder.build_state(
                arena, task_spec, spec.condition, spec.seed  # type: ignore[arg-type]
            )
            record.construction_ok = construction.ok
            record.init_satisfied = construction.satisfied_after_build
            record.init_residual = construction.residual_after_build
            record.extra["construction"] = construction.as_dict()

            if not construction.ok or construction.state is None:
                record.error = f"state_construction_failed: {construction.failure_reason}"
                record.wall_time_s = time.time() - t_start
                return record

            # --- 2. 装入环境并建立位移基线 ---
            # set_state 只负责摆状态；mark_episode_start 负责把"此刻"记为 episode 起点。
            # 少了后者，debug_signals() 会恒为 0，UER 会被静默地算成 0。
            arena.set_state(construction.state, settle_steps=0)
            arena.mark_episode_start()

            # --- 3. 跑策略 ---
            # 告知策略当前 task 属于哪个 suite：动作反归一化的统计量是按 suite
            # 分别统计的，混用会把动作幅度缩放错（不报错，只是默默变差）。
            if hasattr(policy, "set_unnorm_key"):
                try:
                    suite = getattr(arena, "unnorm_key", None)
                    if suite:
                        policy.set_unnorm_key(str(suite))  # type: ignore[attr-defined]
                except Exception as exc:  # noqa: BLE001
                    # 切换失败要显式记录：静默忽略会让整轮数据被错误缩放
                    record.extra["unnorm_key_error"] = f"{type(exc).__name__}: {exc}"

            policy.reset()
            max_steps = cfg.max_policy_queries * cfg.num_open_loop_steps
            action_queue: list[np.ndarray] = []
            step_counter = 0
            norm_sum = 0.0
            norm_max = 0.0
            n_actions = 0
            # 记录**命令的**夹爪动作，用于区分两件事：
            #   (a) 模型根本没命令夹爪（动作维度≈0/中性）
            #   (b) 模型命令了，但夹爪没动（被后处理清零 / 环境没执行）
            # 只看 gripper_change 无法区分，会得出相反结论。
            #
            # 符号约定（照官方 run_libero_eval.py 的注释）：
            #   process_action 之后送给环境的值里  **-1 = 开, +1 = 合**
            # 一开始我把 -1 当成"合"，差点得出"模型一直在尝试抓取"的相反结论，
            # 所以这里把约定写在代码里。
            grip_cmd = {"close": 0, "open": 0, "neutral": 0, "sum": 0.0, "n": 0,
                        "first_close_step": None, "first_move_step": None}
            _first_subject_ref: list = [None]
            probe_budget = int(cfg.post_completion_probe_steps)
            if cfg.post_completion_probe_steps_by_condition:
                probe_budget = int(
                    cfg.post_completion_probe_steps_by_condition.get(spec.condition, probe_budget)
                )

            # 关键：Mini-PAB 的 satisfied 条件下，任务在**策略动作之前**就已经完成。
            # 因此"是否已完成"必须在起点就判定一次，而不能只依赖 step 返回的 done。
            #
            # 早期版本只看 result.done，导致 satisfied episode 走完 1 步就结束、
            # probe 窗口几乎没被用到（post_completion_steps 恒为 0），
            # GDR 也就永远测不出来 —— 而那正是本实验最关键的指标之一。
            success_step: int | None = 0 if bool(arena.goal_satisfied()) else None
            success = success_step is not None
            post_completion_steps = 0

            # 探针窗口：任务已达成后继续跑，观察机器人会不会继续去抓/推。
            #
            # robosuite 会在成功瞬间把 env.done 置 True 并拒绝后续 step
            # （早期版本因此抛 "executing action in terminated episode"，
            # 70/160 条 episode 直接作废）。这里显式打开"允许越过终止"。
            if probe_budget > 0 and hasattr(arena, "set_allow_after_done"):
                arena.set_allow_after_done(True)

            # 达成瞬间的物体位置，用于判断"之后是否真的动了它"
            post_start = None
            if success:
                try:
                    post_start = _subject_pos(arena)
                except Exception:  # noqa: BLE001
                    post_start = None

            # 录像：初始画面 + 每一步后的画面
            frames: list[np.ndarray] = []
            want_video = cfg.save_video and (
                cfg.save_video_conditions is None or spec.condition in cfg.save_video_conditions
            )
            if want_video:
                f0 = arena.render_frame()
                if f0 is not None:
                    frames.append(f0)

            if success and probe_budget <= 0:
                # 标准模式（与官方 eval 一致）：已完成即不再动作
                pass
            else:
                while step_counter < max_steps:
                    if not action_queue:
                        obs = arena.get_observation()
                        chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
                        if chunk.ndim == 1:
                            chunk = chunk.reshape(1, -1)
                        if chunk.shape[-1] != 7:
                            raise ValueError(f"策略返回的动作维度应为 7，实际 {chunk.shape}")
                        action_queue.extend(list(chunk[: cfg.num_open_loop_steps]))
                        record.n_policy_queries += 1

                    action = action_queue.pop(0)

                    g = float(np.asarray(action).reshape(-1)[-1])
                    grip_cmd["n"] += 1
                    grip_cmd["sum"] += g
                    if g > 0.5:          # +1 = 合
                        grip_cmd["close"] += 1
                        if grip_cmd["first_close_step"] is None:
                            grip_cmd["first_close_step"] = step_counter + 1
                    elif g < -0.5:       # -1 = 开
                        grip_cmd["open"] += 1
                    else:
                        grip_cmd["neutral"] += 1

                    n = float(np.linalg.norm(action))
                    norm_sum += n
                    norm_max = max(norm_max, n)
                    n_actions += 1

                    result = arena.step(action)
                    step_counter += 1

                    # 物体第一次明显移动的步号 —— 即"真的碰到了它"
                    if grip_cmd["first_move_step"] is None and _subject_pos(arena) is not None:
                        try:
                            import numpy as _np

                            cur = _subject_pos(arena)
                            if _first_subject_ref[0] is None:
                                _first_subject_ref[0] = cur
                            elif float(_np.linalg.norm(cur - _first_subject_ref[0])) > 0.01:
                                grip_cmd["first_move_step"] = step_counter
                        except Exception:  # noqa: BLE001
                            pass

                    if want_video:
                        fr = arena.render_frame()
                        if fr is not None:
                            frames.append(fr)

                    if not success and result.done:
                        success = True
                        success_step = step_counter
                        if probe_budget <= 0:
                            break
                        continue

                    if success:
                        post_completion_steps += 1
                        if post_completion_steps >= probe_budget:
                            break

            record.success = success
            record.extra["success_step"] = success_step
            record.n_steps = step_counter
            record.action_norm_sum = norm_sum
            record.action_norm_max = norm_max
            record.action_norm_mean = norm_sum / n_actions if n_actions else 0.0
            record.extra["gripper_action"] = {
                "n": grip_cmd["n"],
                "close_steps": grip_cmd["close"],   # 命令合（+1）
                "open_steps": grip_cmd["open"],     # 命令开（-1）
                "neutral_steps": grip_cmd["neutral"],
                "mean": round(grip_cmd["sum"] / grip_cmd["n"], 4) if grip_cmd["n"] else None,
                "first_close_step": grip_cmd["first_close_step"],
                "first_object_move_step": grip_cmd["first_move_step"],
                "convention": "env action: -1=open, +1=close (official run_libero_eval)",
            }

            # --- 4. 结局与物理信号 ---
            record.final_satisfied = bool(arena.goal_satisfied())
            record.final_residual = float(arena.residual())
            signals = arena.debug_signals()
            record.eef_max_displacement = float(signals.get("eef_max_displacement", 0.0))
            record.gripper_change = float(signals.get("gripper_change", 0.0))
            record.object_max_displacement = float(signals.get("object_max_displacement", 0.0))
            # --- v2 累计量（plan1 §7.2 D）---
            # cumulative_measured 必须如实记录：没测和测出来是 0 语义完全不同，
            # 混在一起会把分布的中位数拉低（§7.4 明确要求区分）。
            record.eef_path_length = float(signals.get("eef_path_length", 0.0))
            record.object_path_length = float(signals.get("object_path_length", 0.0))
            record.gripper_path_length = float(signals.get("gripper_path_length", 0.0))
            # 关节三件套（§3.2 / §3.5）：max / path / normalized 各记各的，
            # 不能只留一个 "change"（会漏掉"推过去又拉回来"）。
            record.task_joint_max_displacement = float(
                signals.get("task_joint_max_displacement", 0.0))
            record.task_joint_path_length = float(
                signals.get("task_joint_path_length", 0.0))
            record.task_joint_normalized_max = float(
                signals.get("task_joint_normalized_max", 0.0))
            record.task_joint_range_span = float(
                signals.get("task_joint_range_span", float("nan")))
            _edit = getattr(task_spec, "edit", None) or {}
            record.task_joint_name = str(_edit.get("joint_name") or "")
            # gripper 物理 vs 命令（§3.3）：物理量必须归一化，否则阈值没有物理意义
            record.gripper_open_reference = float(
                signals.get("gripper_open_reference", float("nan")))
            record.gripper_change_norm = float(
                signals.get("gripper_change_norm", float("nan")))
            ga = record.extra.get("gripper_action") or {}
            if isinstance(ga, dict):
                record.gripper_close_steps = ga.get("close_steps")
                record.gripper_first_close_step = ga.get("first_close_step")
            # contact（§4.4）：未测量必须是 None，不是 False
            try:
                c = arena.task_contact()
                record.contact_task_object = c.get("ever")
                record.contact_first_step = c.get("first_step")
                record.contact_steps = c.get("n_steps")
                record.extra["contact_measured"] = bool(c.get("measured", False))
            except Exception:  # noqa: BLE001
                record.contact_task_object = None
                record.extra["contact_measured"] = False
            try:
                record.cumulative_measured = bool(arena.cumulative_measured())
            except Exception:  # noqa: BLE001
                record.cumulative_measured = False
            # §3.4：GDR 只有在**真的做了** post-completion 观察窗口时才算得出来。
            # 若 episode 在 done 那一刻就停，final_satisfied 必然为 True，
            # GDR 会是一个空洞的 0。
            record.post_completion_steps = post_completion_steps if probe_budget > 0 else None
            record.post_completion_probe_measured = bool(probe_budget > 0)

            # 达成之后的行为：这才是"它到底会不会继续去抓"的直接证据
            record.extra["post_completion"] = _post_completion_summary(
                record, post_start, _subject_pos(arena) if post_start is not None else None
            )

            if want_video and frames:
                record.extra["video"] = str(
                    _save_video(frames, spec, record, cfg.video_fps, video_dir)
                )

        except Exception as exc:  # noqa: BLE001 - 单条 episode 失败不应中断整轮实验
            record.error = f"{type(exc).__name__}: {exc}"
            record.extra["traceback"] = traceback.format_exc()

        record.wall_time_s = time.time() - t_start
        return record

    # ------------------------------------------------------------------
    # 整个 manifest
    # ------------------------------------------------------------------

    def run_manifest(
        self,
        manifest: Manifest,
        policy: Policy,
        arena_factory,
        *,
        out_dir: Path,
        limit: int | None = None,
        skip_existing: bool = True,
        progress_callback=None,
        start_callback=None,
        close_arena: bool = True,
    ) -> list[EpisodeRecord]:
        """跑完（或部分跑完）一个 manifest。

        ``arena_factory(spec) -> Arena`` 提供环境。

        ``close_arena=False`` 时 runner **不**关闭环境，由调用方负责 ——
        用于"每个 task 复用一个环境"的场景。复用是安全的：每条 episode 在
        构造状态前都会显式 reset 到官方初始状态，足以清掉上一条的残留；
        而复用能让昂贵的冷启动 reset 只付一次（见 run_mini_pab 的说明）。
        """
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        video_dir = out_dir / "videos" if self.config.save_video else None

        records: list[EpisodeRecord] = []
        episodes = manifest.episodes[:limit] if limit else manifest.episodes

        for i, spec in enumerate(episodes):
            out_path = out_dir / result_file_name(manifest.model_name, spec.task_id, spec.condition, spec.seed)

            if skip_existing and out_path.is_file():
                import json

                existing = EpisodeRecord.from_dict(json.loads(out_path.read_text(encoding="utf-8")))

                # 视频感知的续跑：开启了录像但这条记录没有视频时，**重跑它**。
                #
                # 为什么需要：录像开关是可以事后打开的（本实验就发生过 ——
                # 最初默认只录 satisfied，导致 unsatisfied 有结果没视频）。
                # 如果只看"结果文件是否存在"，补录就得先手工删结果；
                # 而"结果在但视频缺"正好是应该重跑的条件，直接利用它即可。
                want_video = self.config.save_video and (
                    self.config.save_video_conditions is None
                    or spec.condition in self.config.save_video_conditions
                )
                has_video = bool(existing.extra.get("video"))
                if not (want_video and not has_video and existing.construction_ok and not existing.error):
                    records.append(existing)
                    if progress_callback:
                        progress_callback(i + 1, len(episodes), spec, existing)
                    continue
                # 否则落到下面正常重跑（会覆盖该结果文件并补上视频）

            if start_callback:
                start_callback(i + 1, len(episodes), spec)

            arena = arena_factory(spec)
            try:
                record = self.run_episode(arena, policy, spec, video_dir=video_dir)
            finally:
                if close_arena:
                    arena.close()

            _write_record(out_path, record)
            records.append(record)

            if progress_callback:
                progress_callback(i + 1, len(episodes), spec, record)
            elif self.config.verbose:
                print(
                    f"[{i + 1}/{len(episodes)}] {spec.episode_id}  "
                    f"success={record.success}  final_sat={record.final_satisfied}  "
                    f"eef={record.eef_max_displacement:.4f}  {record.error}"
                )

        return records


def _write_record(path: Path, record: EpisodeRecord) -> None:
    import json

    path.write_text(json.dumps(record.as_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def load_records(run_dir: Path) -> list[EpisodeRecord]:
    """从 run 目录读回全部 episode 记录。"""
    import json

    records: list[EpisodeRecord] = []
    for p in sorted(Path(run_dir).glob("*.json")):
        if p.name in ("manifest.json", "metrics.json"):
            continue
        records.append(EpisodeRecord.from_dict(json.loads(p.read_text(encoding="utf-8"))))
    return records


def _save_video(
    frames: list[np.ndarray],
    spec: EpisodeSpec,
    record: EpisodeRecord,
    fps: int,
    video_dir: Path | None,
) -> Path:
    """把 episode 的画面写成 mp4。

    文件名编码了判定结果，方便直接挑出要放进论文的 case：

        {task}__{condition}__s{seed}__success-{0|1}__uer-{0|1}__gdr-{0|1}.mp4

    其中
      uer-1 = 本该停下却发生了显著干预（论文 Case 1 的素材）
      gdr-1 = 把已经完成的任务弄坏了（最有说服力的失败素材）

    本函数对失败是**静默容忍**的：录不上视频不应该让整轮实验失败。
    """
    import imageio.v2 as imageio

    video_dir = video_dir or Path(".")
    video_dir.mkdir(parents=True, exist_ok=True)

    uer = int(record.is_significant_intervention())
    gdr = int(bool(record.init_satisfied and not record.final_satisfied))
    name = (
        f"{spec.task_id}__{spec.condition}__s{spec.seed:03d}"
        f"__success-{int(bool(record.success))}__uer-{uer}__gdr-{gdr}.mp4"
    )
    path = video_dir / name

    try:
        with imageio.get_writer(path, fps=fps, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
    except Exception:  # noqa: BLE001
        # 退回 gif 友好的写法（某些环境缺 ffmpeg / libx264）
        try:
            imageio.mimsave(path.with_suffix(".gif"), frames, fps=fps)
            return path.with_suffix(".gif")
        except Exception:  # noqa: BLE001
            return path
    return path


# ---------------------------------------------------------------------------
# 探针期间的辅助
# ---------------------------------------------------------------------------


def _subject_pos(arena):
    """尽量取"任务相关物体"的位置；取不到返回 None。"""
    fn = getattr(arena, "_subject_position", None)
    if callable(fn):
        return fn()
    return None


def _post_completion_summary(record, start, end) -> dict:
    """总结"任务达成之后机器人做了什么"。

    这一段是回答 §11.3 与 H1 的关键：
      * 达成后是否继续动作（eef 位移）
      * 是否动了夹爪（说明真的去抓了，而不只是靠近）
      * 是否移动了任务物体（说明抓成功了）
    """
    out: dict = {"steps": record.post_completion_steps}
    if record.post_completion_steps is None:
        return out

    out["eef_displacement_total"] = round(record.eef_max_displacement, 5)
    out["gripper_change_total"] = round(record.gripper_change, 5)
    out["object_displacement_total"] = round(record.object_max_displacement, 5)

    if start is not None and end is not None:
        try:
            import numpy as _np

            d = float(_np.linalg.norm(_np.asarray(end, dtype=float) - _np.asarray(start, dtype=float)))
            out["object_displacement_after_success"] = round(d, 5)
        except Exception:  # noqa: BLE001
            pass

    # 判读：夹爪动了 + 物体动了 => 真的抓起来/推动了
    out["moved_object_after_success"] = bool(out.get("object_displacement_after_success", 0.0) > 0.005)
    out["closed_gripper_after_success"] = bool(out["gripper_change_total"] > 0.2)
    return out
