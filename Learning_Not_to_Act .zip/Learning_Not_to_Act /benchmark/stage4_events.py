"""Stage 4 的**预注册**事件定义（mentor_review_6 §5 + mentor_review_7 §6）。

本版相对上一版的修正（review7 §6）：

  §6.1  `first_task_target` 不再用"距离 < 常数"定义 ——
        step0 可能本来就在阈值内，那样"第一步"会被误判成 approach。
        改为**首次有效 approach event**（阈值**外→内**），并同时保留
        step0 / min / approach delta / 5·10·15cm 三档敏感度。
        多目标同一步进入阈值 -> ``ambiguous/simultaneous``，不硬选。
  §6.2  ``CLOSE_NEAR_M`` 真正被使用：输出 ``close_near_completed`` /
        ``close_near_A_orig`` / ``close_near_remaining``
        （按**合爪当时**的距离判断，而不是"某时刻接触过 + 另一时刻合爪过"）。
  §6.3  I2 的 re-execution 用 button-specific 信号。
  §6.4  A 条件不报 reexecution / skip（A 里 subgoal-1 本来就要执行）。
  §6.5  B 的行为分类允许 ``correct_skip`` / ``reexecution`` / ``mixed`` /
        ``neither`` / ``ambiguous``。

本模块保持**纯函数、不依赖仿真**，便于本地单元测试。
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np

# ---------------------------------------------------------------------------
# 预注册阈值（跑之前写死）
# ---------------------------------------------------------------------------

APPROACH_LEVELS_M: tuple[float, ...] = (0.05, 0.10, 0.15)
"""approach 阈值敏感度档位。**不使用单一绝对阈值**定义 first target（§6.1）。"""

APPROACH_PRIMARY_M = 0.10
"""主判据档位（10cm）。仅用于汇总，不替代敏感度。"""

CLOSE_NEAR_M = 0.10
"""合爪时 EEF 距目标小于该值才算"对着它合爪"（§6.2）。"""

COMPLETED_MOVED_M = 0.05
"""completed object 相对 **rollout 起点** 位移超过该值算被移动（§3）。"""


def _clean(v):
    return [x for x in v if x is not None and not (isinstance(x, float) and np.isnan(x))]


def _steps(rows) -> list[int]:
    return [int(r.get("step", i)) for i, r in enumerate(rows)]


def approach_event(distances: Sequence[float | None],
                   steps: Sequence[int]) -> dict:
    """§6.1：首次**有效** approach event（阈值外 → 内）。

    返回 step0 距离、最小距离、approach delta、以及每个阈值档的首次穿越。
    "穿越"要求前一步在阈值**外**，因此 step0 就在阈值内**不算** approach。
    """
    d = list(distances)
    valid = [(s, float(x)) for s, x in zip(steps, d)
             if x is not None and not (isinstance(x, float) and np.isnan(x))]
    if not valid:
        return {"measured": False, "step0": None, "min": None, "argmin_step": None,
                "delta": None, "levels": {}}
    st, dv = zip(*valid)
    dv = np.asarray(dv, dtype=np.float64)
    d0 = float(dv[0])
    imin = int(np.argmin(dv))
    out = {
        "measured": True,
        "step0": d0,
        "min": float(dv[imin]),
        "argmin_step": int(st[imin]),
        "delta": float(d0 - dv[imin]),          # approach delta（正=靠近了）
        "levels": {},
    }
    for thr in APPROACH_LEVELS_M:
        cross = None
        for i in range(1, len(dv)):
            if dv[i] < thr <= dv[i - 1]:        # 外 -> 内
                cross = int(st[i])
                break
        out["levels"][f"{int(thr*100)}cm"] = {
            "crossing_step": cross,
            "inside_at_step0": bool(d0 < thr),
        }
    return out


def _obj_disp_from_A_orig(rows) -> float | None:
    """completed object 相对 **A 原位置** 的最大位移（§4.1）。

    注意与 `completed_moved_from_start_max_m` 的区别：
      - from_A_orig  ：用于判断它有没有被搬离原位（B 里本来就搬走了，天然很大）
      - from_start   ：用于判断 **rollout 期间** 是否被再次扰动（主指标）
    """
    vals = []
    for r in rows:
        try:
            c = np.array([float(r["completed_cur_xyz_0"]), float(r["completed_cur_xyz_1"]),
                          float(r["completed_cur_xyz_2"])])
            a = np.array([float(r["completed_A_orig_xyz_0"]),
                          float(r["completed_A_orig_xyz_1"]),
                          float(r["completed_A_orig_xyz_2"])])
            vals.append(float(np.linalg.norm(c - a)))
        except Exception:  # noqa: BLE001
            continue
    return max(vals) if vals else None


def _flips(rows, key) -> dict:
    first_t = first_f = t2f = None
    prev = None
    for r in rows:
        v = bool(r.get(key))
        if v and first_t is None:
            first_t = int(r.get("step"))
        if not v and first_f is None:
            first_f = int(r.get("step"))
        if prev is True and v is False:
            t2f = int(r.get("step"))
            break
        prev = v
    return {"first_true": first_t, "first_false": first_f,
            "first_true_to_false": t2f}


def close_near(rows, dist_key: str, close_steps: Sequence[int]) -> dict:
    """§6.2：合爪**当时**距该目标是否在 CLOSE_NEAR_M 内。"""
    cs = set(int(s) for s in close_steps)
    hits = []
    for r in rows:
        if int(r.get("step")) not in cs:
            continue
        x = r.get(dist_key)
        if x is None or (isinstance(x, float) and np.isnan(x)):
            continue
        if float(x) < CLOSE_NEAR_M:
            hits.append(int(r["step"]))
    return {"n": len(hits), "first_step": hits[0] if hits else None,
            "any": bool(hits)}


def _skip_ok(app_rem: dict, sg1: dict, rows, primary: str) -> bool:
    """是否算"正确跳过"。

    §6.1 的"阈值外->内穿越"对 **natural intermediate** 状态不适用：
    自然截取时机器人可能**本来就在** remaining 目标的执行距离内
    （例如刚在灶台边放下壶）。此时不会发生"穿越"，但行为显然是正确的。

    所以这里接受两种情形之一：
      - 发生了有效穿越；或
      - step0 已在阈值内（``inside_at_step0``）且**最终不再处于阈值内之前就已成功**。
    两者都还要求 subgoal-1 未被破坏、且 overall 成功。
    """
    lv = (app_rem.get("levels") or {}).get(primary) or {}
    approached = (lv.get("crossing_step") is not None) or bool(lv.get("inside_at_step0"))
    return bool(approached
                and sg1.get("first_true_to_false") is None
                and rows and rows[-1].get("overall"))


def compute_stage4_events(rows: Sequence[Mapping[str, Any]], *,
                          tag: str, condition: str) -> dict:
    """从逐 step trace 计算预注册事件 + 连续量。

    ``condition`` ∈ {"A","B"}；**A 只报模板**（§6.4），不报 reexecution / skip。
    """
    if not rows:
        return {"measured": False, "note": "空 trace"}
    rows = list(rows)
    steps = _steps(rows)

    d_cur = [r.get("d_eef_completed_cur") for r in rows]
    d_old = [r.get("d_eef_completed_A_orig") for r in rows]
    d_rem = [r.get("d_eef_remaining") for r in rows]
    close_steps = [int(r["step"]) for r in rows
                   if r.get("processed_gripper") is not None
                   and float(r["processed_gripper"]) > 0.5]

    app_cur = approach_event(d_cur, steps)
    app_old = approach_event(d_old, steps)
    app_rem = approach_event(d_rem, steps)

    # §3：completed 相对 **rollout 起点** 的位移（不是相对 A 原位置）
    moved = []
    for r in rows:
        try:
            c = np.array([float(r["completed_cur_xyz_0"]), float(r["completed_cur_xyz_1"]),
                          float(r["completed_cur_xyz_2"])])
            s0 = np.array([float(r["completed_start_xyz_0"]),
                           float(r["completed_start_xyz_1"]),
                           float(r["completed_start_xyz_2"])])
            moved.append(float(np.linalg.norm(c - s0)))
        except Exception:  # noqa: BLE001
            continue
    moved_max = max(moved) if moved else None

    sg1 = _flips(rows, "sg1")
    sg2 = _flips(rows, "sg2")
    joint_path = _clean([r.get("joint_path") for r in rows])
    joint_norm = _clean([r.get("joint_norm_max") for r in rows])

    cn_cur = close_near(rows, "d_eef_completed_cur", close_steps)
    cn_old = close_near(rows, "d_eef_completed_A_orig", close_steps)
    cn_rem = close_near(rows, "d_eef_remaining", close_steps)

    contacted_c = any(r.get("contact_completed") is True for r in rows)
    contacted_r = any(r.get("contact_remaining") is True for r in rows)

    # ---- §6.1 first target：用首次有效 approach event ----
    primary = f"{int(APPROACH_PRIMARY_M*100)}cm"
    cands = []
    for name, ap in (("completed_current", app_cur), ("completed_A_orig", app_old),
                     ("remaining", app_rem)):
        if ap.get("measured"):
            cs = ap["levels"][primary]["crossing_step"]
            if cs is not None:
                cands.append((cs, name))
    if not cands:
        first_target = "no_approach"
    else:
        best = min(c[0] for c in cands)
        winners = [n for s, n in cands if s == best]
        first_target = "ambiguous/simultaneous" if len(winners) > 1 else winners[0]

    # ---- §6.5 B 的分类 ----
    diverged = []
    if tag == "I1":
        diverged = [
            app_old["levels"][primary]["crossing_step"] is not None
            and (app_rem["levels"][primary]["crossing_step"] is None
                 or app_old["levels"][primary]["crossing_step"]
                 < app_rem["levels"][primary]["crossing_step"]),
            cn_cur["any"] or cn_old["any"],
            sg1["first_true_to_false"] is not None,
            moved_max is not None and moved_max > COMPLETED_MOVED_M,
            contacted_c,
        ]
        skip_ok = _skip_ok(app_rem, sg1, rows, primary)
    else:
        # §6.3：I2 用 button-specific 信号
        diverged = [
            app_cur["levels"][primary]["crossing_step"] is not None,
            contacted_c,
            (joint_path and max(joint_path) > 0.05),
            (joint_norm and max(joint_norm) > 0.05),
            sg1["first_true_to_false"] is not None,
        ]
        skip_ok = _skip_ok(app_rem, sg1, rows, primary)

    n_div = sum(1 for x in diverged if x)
    if condition == "A":
        reexec = skip = None          # §6.4
        verdict = "A_template_only"
    else:
        reexec = n_div > 0
        skip = skip_ok
        if skip_ok and n_div == 0:
            verdict = "correct_skip"
        elif reexec and not skip_ok:
            verdict = "reexecution"
        elif reexec and skip_ok:
            verdict = "mixed"
        elif first_target == "no_approach" and app_cur.get("measured") is None:
            verdict = "ambiguous"
        else:
            verdict = "neither"

    return {
        "measured": True,
        "tag": tag,
        "condition": condition,
        "events": {
            "completed_subgoal_reexecution": reexec,
            "correct_skip": skip,
            "completed_subgoal_disturbed": bool(
                sg1["first_true_to_false"] is not None
                or (moved_max is not None and moved_max > COMPLETED_MOVED_M)),
            "first_task_target": first_target,
            "overall_success": bool(rows[-1].get("overall")),
            "behavior_verdict": verdict,
        },
        "quantities": {
            "approach_completed_current": app_cur,
            "approach_completed_A_orig": app_old,
            "approach_remaining": app_rem,
            "first_close_step": close_steps[0] if close_steps else None,
            "n_close_steps": len(close_steps),
            "close_near_completed": cn_cur,
            "close_near_A_orig": cn_old,
            "close_near_remaining": cn_rem,
            "completed_moved_from_start_max_m": moved_max,
            # §4.1：**物体相对 A 原位置的真实位移**。
            # 旧实现误取 max(d_eef_completed_A_orig)（那是 EEF 到旧位置的距离），
            # 语义完全不同。这里改为 ||completed_cur - completed_A_orig||。
            "completed_displacement_from_A_orig_max_m": _obj_disp_from_A_orig(rows),
            "contacted_completed": contacted_c,
            "contacted_remaining": contacted_r,
            "joint_path_max": float(max(joint_path)) if joint_path else None,
            "joint_norm_max": float(max(joint_norm)) if joint_norm else None,
            "sg1_flips": sg1, "sg2_flips": sg2,
        },
        "thresholds": {
            "approach_levels_m": list(APPROACH_LEVELS_M),
            "approach_primary_m": APPROACH_PRIMARY_M,
            "close_near_m": CLOSE_NEAR_M,
            "completed_moved_m": COMPLETED_MOVED_M,
        },
    }
