"""Step 3: satisfied / unsatisfied 状态的程序化构造。

执行方案 §9 要求 ``build_state(task_id, condition, seed)`` 提供统一接口；
§65.2 要求不同 condition **尽可能共享** camera / 机器人初始位姿 / 光照 / 场景布局，
**只改变任务相关状态**。本模块严格遵守这一点：机器人 qpos 一律不动，
只改被操作物体（或关节）的状态。

两个 condition 的定义（Fast 版本只有这两态）
-------------------------------------------
satisfied
    目标已满足，正确行为是 **STOP**。
    构造后必须通过 ``arena.goal_satisfied()`` 校验 —— 校验失败说明构造失败，
    绝不能把"看起来像完成"的状态当 ground truth（这正是 PAB-H 要研究的东西，
    但在 PAB-S 里必须干净）。

unsatisfied
    目标未满足且需要完整执行，正确行为是 **EXECUTE**。
    构造方式是相对官方初始状态施加**受控扰动**，而不是随手乱放：
    扰动距离要落在"需要完整执行"的量级（Mini-PAB 用 12cm），
    且必须通过 ``goal_satisfied() == False`` 校验。
"""

from __future__ import annotations

import copy
import math
import os
import time
from dataclasses import dataclass, field
from typing import Any, Literal, Sequence

_TRACE = os.environ.get("MINIPAB_TRACE", "") not in ("", "0", "false")


def _trace(msg: str) -> None:
    """构造过程的阶段级追踪。

    排查"构造卡住"这类问题时，光看 episode 边界日志不够 ——
    必须知道卡在 reset / settle / 候选搜索 的哪一步。
    设 MINIPAB_TRACE=1 打开。
    """
    if _TRACE:
        print(f"    [build] {msg}", flush=True)

import numpy as np

from benchmark.arena.protocol import Arena
from benchmark.states import mujoco_state as ms
from benchmark.tasks.registry import Condition, TaskSpec

MAX_ROBOT_JOINTS_NO_TOUCH = 9
"""LIBERO 机器人的前 9 个关节：7 个臂关节 + 2 个夹爪手指关节。
构造状态时绝不改动它们，以保证不同 condition 的机器人初始位姿一致（§65.2）。

实测（服务器 LIBERO + robosuite 1.4.1）这 9 个关节是：

    robot0_joint1..7, gripper0_finger_joint1, gripper0_finger_joint2

注意夹爪的前缀是 ``gripper0_`` 而不是 ``robot0_``。
"""

ROBOT_JOINT_PREFIXES = ("robot0_", "gripper0_")
"""合法的机器人关节前缀。用在防守性检查里。"""


@dataclass
class ConstructionAttempt:
    """一次构造尝试的记录，用于报告与排错。"""

    method: str
    clearance: float
    subject_pos: list[float] | None
    satisfied: bool
    residual: float
    ok: bool
    note: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "method": self.method,
            "clearance": round(self.clearance, 5),
            "subject_pos": None if self.subject_pos is None else [round(v, 5) for v in self.subject_pos],
            "satisfied": self.satisfied,
            "residual": round(self.residual, 5),
            "ok": self.ok,
            "note": self.note,
        }


@dataclass
class ConstructionResult:
    """构造结果。``ok=False`` 时 **不得** 把该 episode 计入统计。"""

    task_id: str
    condition: Condition
    seed: int
    ok: bool
    state: np.ndarray | None
    satisfied_after_build: bool
    residual_after_build: float
    attempts: list[ConstructionAttempt] = field(default_factory=list)
    robot_joints_untouched: bool = True
    failure_reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "condition": self.condition,
            "seed": self.seed,
            "ok": self.ok,
            "satisfied_after_build": self.satisfied_after_build,
            "residual_after_build": round(self.residual_after_build, 6),
            "robot_joints_untouched": self.robot_joints_untouched,
            "n_attempts": len(self.attempts),
            "attempts": [a.as_dict() for a in self.attempts],
            "failure_reason": self.failure_reason,
        }


class StateBuilder:
    """按 task spec 构造初始状态。

    参数
    ----
    settle_steps:
        改写状态后让物理收敛的空转步数。太少 -> 物体还在下落/穿插；
        太多 -> 慢。默认 30 步对 LIBERO 桌面任务足够。
    clearances:
        放置类任务尝试的**抬高量**序列（米），相对 subject 静止在桌面时的高度。
        从最小的抬高量开始（最贴近"已经放好了"的自然姿态），失败则抬高重试。
        这个自适应很关键：不同任务的接触高度差很多
        （放盘子上只有几厘米，放进篮子更深），写死一个值必然在某些场景失败。
    """

    def __init__(
        self,
        *,
        settle_steps: int = 30,
        clearances: Sequence[float] = (0.01, 0.03, 0.06, 0.10, 0.16),
        perturb_distance_m: float | None = None,
    ):
        self.settle_steps = int(settle_steps)
        self.clearances = tuple(float(c) for c in clearances)
        self.perturb_distance_m = perturb_distance_m
        # 每个 task 上次成功的放置偏移，用于把搜索成本摊到第一个 seed 上
        self._offset_cache: dict[str, tuple[float, float, float]] = {}

    # ------------------------------------------------------------------
    # 对外统一接口（执行方案 §9）
    # ------------------------------------------------------------------

    def build_state(
        self,
        arena: Arena,
        spec: TaskSpec,
        condition: Condition,
        seed: int,
    ) -> ConstructionResult:
        """构造并返回状态。调用方负责把 ``result.state`` 装进环境。"""
        t0 = time.time()
        _trace(f"{spec.id}/{condition}/seed={seed}: start")
        if condition == "satisfied":
            out = self._build_satisfied(arena, spec, seed)
        elif condition == "unsatisfied":
            out = self._build_unsatisfied(arena, spec, seed)
        elif condition == "partial":
            raise NotImplementedError(
                "partial 状态属于 M1-W2（PAB-S v0）。Fast 版本只有 satisfied / unsatisfied。"
            )
        else:
            raise ValueError(f"未知 condition: {condition!r}")
        _trace(
            f"{spec.id}/{condition}/seed={seed}: done ok={out.ok} "
            f"attempts={len(out.attempts)} in {time.time() - t0:.1f}s"
        )
        return out

    # ------------------------------------------------------------------
    # satisfied
    # ------------------------------------------------------------------

    def _build_satisfied(self, arena: Arena, spec: TaskSpec, seed: int) -> ConstructionResult:
        self._assert_robot_untouched_policy(arena)
        # reset 是这里最贵的单步操作（LIBERO 要重建场景，实测 8~29s），
        # 因此每种 condition 只做一次，且下游复用同一份 base_state。
        # 关键：**两个 condition 必须从同一个官方初始状态出发**（§65.2）。
        #
        # 早期实现里 satisfied 直接拿 arena.get_state() 当基底，而 unsatisfied
        # 先 reset 再改 —— 两条路径的机器人位姿不同，于是
        # verify_robot_joints_unchanged() 在真实 LIBERO 上直接判 False。
        # 机器人位姿不同会让 UER 被"机器人起始位置差异"污染，
        # 所以这里统一成：先 reset 到同一个 official init，再只改任务相关状态。
        t0 = time.time()
        _reset_to_official_init(arena, seed)
        _trace(f"reset -> {time.time() - t0:.1f}s")
        base_state = arena.get_state()

        if spec.residual_kind == "joint":
            return self._build_satisfied_joint(arena, spec, seed, base_state)
        return self._build_satisfied_placement(arena, spec, seed, base_state)

    def _build_satisfied_placement(
        self, arena: Arena, spec: TaskSpec, seed: int, base_state: np.ndarray
    ) -> ConstructionResult:
        """把 subject 放到 target 上/中，然后校验 predicate。

        为什么用"物理搜索"而不是"几何推算"
        ----------------------------------
        最初的实现尝试用 MuJoCo 几何推算落点高度
        （target 顶面 + subject 半高 + clearance）。在真实 LIBERO 上这条路失败了，
        原因很具体：robosuite 的 ``binding_utils`` 暴露的 ``data.geom_xpos``
        是 **body 局部坐标**，不是世界坐标 ——
        于是"顶面高度"算出来是 0.10 这种量级，而物体实际在世界系的 z≈0.9。
        在此基础上推算落点必然错得离谱（实测：碗被放到 z=0.19，直接掉下桌子）。

        既然 ground truth 就在眼前（slack = 到接触面的间隙，越大说明还悬着），
        就直接**搜索**它：从"贴着当前静止高度"开始逐步抬高，
        每一步都让物理 settle 并用 predicate 验证。
        这既绕开了坐标系/包围盒的所有坑，也能正确处理"放进篮子"这类
        落点低于目标顶面的情况。
        """
        model = arena.model
        subject, target = spec.subject, spec.target
        assert target is not None, f"{spec.id} 是 placement 任务但没有 target"

        # 注意：这里**不再**重复 reset / settle。
        #
        # 早期实现每次构造都要 reset()（实测首次 28.7s、后续 8.4s，
        # 因为 LIBERO 要重建整个场景），还额外 settle 一次。
        # 一个 episode 里因此要花掉 ~49s 在状态准备上，
        # 160 个 episode 光准备就超过 2 小时。
        # 现在 _build_satisfied / _build_unsatisfied 各 reset 一次，
        # 并复用同一份 base_state（同时也保证了机器人位姿一致）。
        try:
            target_pos = self._target_anchor(arena, spec, target)
        except (KeyError, TypeError, ValueError) as exc:
            return self._fail(spec, "satisfied", seed, f"读取目标位置失败: {exc}")

        subject_pos = ms.get_object_pos(base_state, model, subject)
        # 参考高度：subject 静止在桌面上的 z。所有候选落点都从这里往上找。
        base_z = float(subject_pos[2])

        attempts: list[ConstructionAttempt] = []
        for dx, dy, dz in self._iter_placement_candidates(spec.id):
            pos = [float(target_pos[0] + dx), float(target_pos[1] + dy), base_z + float(dz)]

            state = ms.set_object_pos(base_state, model, subject, pos)
            state = ms.clear_object_velocity(state, model, subject)
            state = ms.clear_all_velocities(state, ms.StateLayout.from_model(model))

            t_s = time.time()
            arena.set_state(state, settle_steps=self.settle_steps)
            satisfied = bool(arena.goal_satisfied())
            _trace(f"  settled dz={dz:.3f} in {time.time() - t_s:.1f}s satisfied={satisfied}")
            residual = float(arena.residual())
            final_state = arena.get_state()
            final_pos = ms.get_object_pos(final_state, model, subject)

            attempts.append(
                ConstructionAttempt(
                    method="placement_on_target",
                    clearance=float(dz),
                    subject_pos=list(final_pos),
                    satisfied=satisfied,
                    residual=residual,
                    ok=satisfied,
                    note=(
                        f"落点 = target_xy + ({dx:+.3f},{dy:+.3f}), z = base_z({base_z:.4f}) + {dz:.3f}；"
                        f"settle 后水平偏移="
                        f"{float(np.linalg.norm(final_pos[:2] - np.asarray(target_pos[:2]))):.4f}"
                    ),
                )
            )
            if satisfied:
                self._offset_cache[spec.id] = (float(dx), float(dy), float(dz))
                return self._finalize(
                    arena,
                    ConstructionResult(
                        task_id=spec.id,
                        condition="satisfied",
                        seed=seed,
                        ok=True,
                        state=final_state,
                        satisfied_after_build=True,
                        residual_after_build=residual,
                        attempts=attempts,
                    ),
                )

        return ConstructionResult(
            task_id=spec.id,
            condition="satisfied",
            seed=seed,
            ok=False,
            state=None,
            satisfied_after_build=False,
            residual_after_build=float("nan"),
            attempts=attempts,
            failure_reason=(
                f"所有 clearance {self.clearances} 都未能让 predicate 成立。"
                "可能原因：目标锚点选错 / 物体包围盒异常 / success 阈值比放置精度更严。"
                "请用 scripts/inspect_constructed_state.py 可视化排查。"
            ),
        )

    def _finalize(
        self,
        arena: Arena,
        result: ConstructionResult,
        *,
        then_settle: bool = False,
    ) -> ConstructionResult:
        """构造收尾：把机器人关节强制写回官方值，并复核 predicate。

        为什么必须"强制写回"
        -------------------
        LIBERO 的机器人是位置控制的，``mj_step`` 期间手臂仍会因重力/PD 误差
        产生 ~1e-3 rad 的漂移，且漂移量取决于跑了多少 settle 步。
        两种 condition 的 settle 路径不同（satisfied 要试多个落点），
        于是实测机器人位姿差可达 1e-2 rad ——
        足以污染 UER，也直接违反 §65.2。

        做法：以 ``arena.official_robot_qpos()`` 为权威值覆盖前 9 维，
        物体自由度保持不变；随后可选地再 settle 一次
        （此时机器人已复位，settle 不会再让物体跑掉）。
        """
        if not result.ok or result.state is None:
            return result

        try:
            robot_qpos = arena.official_robot_qpos()
        except Exception:  # noqa: BLE001 - 拿不到就不强制，由 verify 兜底报告
            return result

        layout = ms.StateLayout.from_model(arena.model)
        fixed = ms.set_robot_qpos(result.state, layout, robot_qpos)
        arena.set_state(fixed, settle_steps=self.settle_steps if then_settle else 0)

        result.state = arena.get_state()
        result.satisfied_after_build = bool(arena.goal_satisfied())
        result.residual_after_build = float(arena.residual())
        return result

    def _resolve_joint_key(self, model: Any, spec: TaskSpec) -> str:
        """确定要操作的关节名。

        配置里给的可能是精确名字，也可能只是一个前缀（例如 ``middle_level``）。
        用 ``resolve_single_dof_joint`` 解析成唯一关节，避免把前缀直接当名字用。
        解析失败时退回原字符串，让下游抛出带候选列表的可读错误。
        """
        key = (spec.edit or {}).get("joint_name") or spec.subject
        try:
            return ms.resolve_single_dof_joint(model, key).name
        except KeyError:
            return key

    def _build_satisfied_joint(
        self, arena: Arena, spec: TaskSpec, seed: int, base_state: np.ndarray
    ) -> ConstructionResult:
        """关节类任务（开抽屉）：把关节推到**正确的**一端。

        关键坑：不能假定"开 = 关节 range 的上限"。
        实测 LIBERO 的抽屉是 slide joint，range 为 ``[-0.16, 0.01]``，
        **打开对应负端 -0.16**。早期实现只往 fraction=0.95（接近 hi）推，
        在真实环境里会把抽屉推成关闭状态。

        因此这里直接**两端都试**，用 predicate 决定哪一端才是目标状态。
        这比在配置里写死方向更稳：方向由 simulator ground truth 决定。
        """
        model = arena.model
        joint_key = self._resolve_joint_key(model, spec)

        try:
            lo, hi = ms.get_joint_range(model, joint_key)
        except (KeyError, ValueError, TypeError) as exc:
            return self._fail(spec, "satisfied", seed, f"读取关节范围失败: {exc}")

        span = hi - lo
        attempts: list[ConstructionAttempt] = []

        # 候选：两端极点 + 若干内插点（predicate 阈值不一定等于 range 端点）
        candidates = [
            hi,
            lo,
            lo + 0.95 * span,
            lo + 0.05 * span,
            lo + 0.75 * span,
            lo + 0.25 * span,
        ]

        best_state: np.ndarray | None = None
        goal_value: float | None = None

        for value in candidates:
            state = ms.set_joint_pos(base_state, model, joint_key, value)
            state = ms.clear_all_velocities(state, ms.StateLayout.from_model(model))
            arena.set_state(state, settle_steps=self.settle_steps)
            satisfied = bool(arena.goal_satisfied())
            residual = float(arena.residual())
            attempts.append(
                ConstructionAttempt(
                    method="joint_probe_end",
                    clearance=float(value - lo),
                    subject_pos=None,
                    satisfied=satisfied,
                    residual=residual,
                    ok=satisfied,
                    note=(
                        f"joint={joint_key!r} qpos={value:.5f} "
                        f"(range {lo:.5f}..{hi:.5f}, {'LO' if value == lo else 'HI' if value == hi else 'mid'})"
                    ),
                )
            )
            if satisfied:
                best_state = arena.get_state()
                goal_value = float(value)
                break

        if best_state is None:
            return ConstructionResult(
                task_id=spec.id,
                condition="satisfied",
                seed=seed,
                ok=False,
                state=None,
                satisfied_after_build=False,
                residual_after_build=float("nan"),
                attempts=attempts,
                failure_reason=(
                    f"关节 {joint_key!r} 在 range [{lo:.5f}, {hi:.5f}] 的两端与内插点"
                    "都无法满足 predicate。可能该 task 的成功条件不由这一个关节决定。"
                ),
            )

        # 把"哪一端是目标"告知 arena，供 residual() 使用
        if hasattr(arena, "set_joint_goal_value"):
            arena.set_joint_goal_value(joint_key, goal_value)  # type: ignore[attr-defined]

        return self._finalize(
            arena,
            ConstructionResult(
                task_id=spec.id,
                condition="satisfied",
                seed=seed,
                ok=True,
                state=best_state,
                satisfied_after_build=True,
                residual_after_build=float(arena.residual()),
                attempts=attempts,
            ),
        )

    # ------------------------------------------------------------------
    # unsatisfied
    # ------------------------------------------------------------------

    def _build_unsatisfied(self, arena: Arena, spec: TaskSpec, seed: int) -> ConstructionResult:
        """unsatisfied = **LIBERO 官方 task 初始状态**（默认，不做人为扰动）。

        为什么改成这样（重要修正）
        -------------------------
        最初把 unsatisfied 定义成"把物体放到距目标 12cm 的圆上"，想法是
        "保证离目标足够远"。实测这是错的，原因很具体：

        * 官方初始状态**本来就是 unsatisfied**（任务没做），它才是真实的任务起点；
        * 自己扰动会把物体摆到任意方向 —— 包括柜子旁、桌子边缘、物体背面等
          "很难夹"的位置。于是 unsatisfied 的失败反映的是"夹取姿势被障碍物挡住"，
          而不是模型能力；
        * 实测对照（本机 4090，官方 `run_libero_eval.py`）：
          `put_the_bowl_on_the_plate` 官方 **4/4 成功**，
          而 12cm 扰动版本 20 个 seed 只成功 3 个。差异全部来自起始位置。

        所以现在默认直接采用官方 init state（每个 seed 一个固定初始状态，
        与 satisfied 用同一个 index，保证两者可比）。
        只有显式在配置里写 ``perturb.enabled: true``（或构造器传
        ``perturb_distance_m``）时才做扰动 —— 保留给将来做"受控难度梯度"。
        """
        self._assert_robot_untouched_policy(arena)
        # 从官方初始状态出发（seed 同时用作 official init index），
        # 保证同 seed -> 同状态，可复现。
        t0 = time.time()
        _reset_to_official_init(arena, seed)
        _trace(f"reset -> {time.time() - t0:.1f}s")
        base_state = arena.get_state()
        model = arena.model

        _cfg = (spec.edit or {}).get("perturb", {}) or {}
        _use_perturb = bool(_cfg.get("enabled", False)) or self.perturb_distance_m is not None

        # ---- 默认路径：官方初始状态原样使用 ----
        if not _use_perturb:
            arena.set_state(base_state, settle_steps=0)
            satisfied = bool(arena.goal_satisfied())
            residual = float(arena.residual())
            attempt = ConstructionAttempt(
                method="official_init_state",
                clearance=0.0,
                subject_pos=None,
                satisfied=satisfied,
                residual=residual,
                ok=not satisfied,
                note=f"官方 task 初始状态（未扰动）；residual={residual:.4f}",
            )
            if satisfied:
                return ConstructionResult(
                    task_id=spec.id,
                    condition="unsatisfied",
                    seed=seed,
                    ok=False,
                    state=None,
                    satisfied_after_build=True,
                    residual_after_build=residual,
                    attempts=[attempt],
                    failure_reason=(
                        "官方初始状态已满足 predicate —— 该 task 的 unsatisfied "
                        "条件不成立，应换 task 或换 seed。"
                    ),
                )
            return self._finalize(
                arena,
                ConstructionResult(
                    task_id=spec.id,
                    condition="unsatisfied",
                    seed=seed,
                    ok=True,
                    state=arena.get_state(),
                    satisfied_after_build=False,
                    residual_after_build=residual,
                    attempts=[attempt],
                ),
            )

        # ---- 显式启用扰动时才走下面（受控难度梯度）----
        if spec.residual_kind == "joint":
            return self._build_unsatisfied_joint(arena, spec, seed, base_state)

        subject, target = spec.subject, spec.target
        assert target is not None, f"{spec.id} 是 placement 任务但没有 target"

        cfg = _cfg
        distance = float(self.perturb_distance_m or cfg.get("distance_m", 0.12))

        try:
            target_anchor = self._target_anchor(arena, spec, target)
        except (KeyError, TypeError, ValueError) as exc:
            return self._fail(spec, "unsatisfied", seed, f"读取目标位置失败: {exc}")

        subject_pos = ms.get_object_pos(base_state, model, subject)

        # 关键：扰动的参照系是**目标**，不是 subject 当前位置。
        #
        # 早期版本写成 `subject_xy + direction * distance`，这是一个真实 bug：
        # 如果 subject 本来就离目标很近，朝目标方向扰动反而会把它**推近**目标，
        # 于是 predicate 仍为 True，"unsatisfied" 构造失败（或更糟：静默地
        # 变成了一个 satisfied 样本）。
        #
        # 正确做法是把 subject 放到"以目标为圆心、半径 = distance"的圆上，
        # 这样 residual 恰好被控制在目标距离上，与它在官方初始状态里离目标多远无关。
        attempts: list[ConstructionAttempt] = []
        min_residual = float(cfg.get("min_residual_m", distance * 0.75))

        # 候选按"代价递增"排列，命中即停。
        #
        # 早期实现是 12 个方向 × 4 个半径的全网格，一旦首选失败就要跑满
        # 48 次"改状态 + settle"；在 object_in_basket 这种几何体多的场景里
        # 实测单次 settle 0.35s × 15 步，20 个 seed 会拖到近一小时。
        # 而绝大多数 seed 其实第一个候选就成功（甚至第一个半径就成功），
        # 所以把候选做成惰性序列：先在首选方向上试几个半径，
        # 不行再向两侧微调方向，最后才铺开全方向。
        best: tuple[np.ndarray, bool, float] | None = None
        for direction, radius in self._iter_candidate_placements(seed, distance):
            new_xy = target_anchor + direction * radius
            new_pos = [float(new_xy[0]), float(new_xy[1]), float(subject_pos[2])]

            state = ms.set_object_pos(base_state, model, subject, new_pos)
            state = ms.clear_object_velocity(state, model, subject)
            state = ms.clear_all_velocities(state, ms.StateLayout.from_model(model))

            arena.set_state(state, settle_steps=self.settle_steps)
            satisfied = bool(arena.goal_satisfied())
            residual = float(arena.residual())
            final_state = arena.get_state()
            far_enough = residual >= min_residual
            ok = (not satisfied) and far_enough

            note = (
                f"radius={radius:.3f} dir={np.round(direction, 3).tolist()} "
                f"residual={residual:.4f} (min {min_residual:.4f})"
            )
            attempts.append(
                ConstructionAttempt(
                    method="place_on_circle_around_target",
                    clearance=radius,
                    subject_pos=list(ms.get_object_pos(final_state, model, subject)),
                    satisfied=satisfied,
                    residual=residual,
                    ok=ok,
                    note=note,
                )
            )

            if best is None:
                best = (final_state, satisfied, residual)
            if ok:
                return self._finalize(
                    arena,
                    ConstructionResult(
                        task_id=spec.id,
                        condition="unsatisfied",
                        seed=seed,
                        ok=True,
                        state=final_state,
                        satisfied_after_build=False,
                        residual_after_build=residual,
                        attempts=attempts,
                    ),
                )

        # 所有方向/距离都失败：如实报告，不做补偿
        best_state, best_sat, best_res = best  # type: ignore[misc]
        return ConstructionResult(
            task_id=spec.id,
            condition="unsatisfied",
            seed=seed,
            ok=False,
            state=None,
            satisfied_after_build=best_sat,
            residual_after_build=best_res,
            attempts=attempts,
            failure_reason=(
                f"把 subject 放到距目标 {distance}m 的圆上仍未得到合法 unsatisfied 状态"
                f"（最好情况 residual={best_res:.4f}, satisfied={best_sat}）。"
                "可能原因：success 阈值过宽（物体被放到很远仍算成功）/ "
                "subject 的 xy 无法自由移动（例如被放在抽屉里）。"
            ),
        )

    def _iter_placement_candidates(self, task_id: str = ""):
        """生成 satisfied 放置的 (dx, dy, dz) 候选，按代价递增。

        为什么需要 xy 偏移：目标 fixture 的**几何中心不一定等于 success 区域**。
        实测 ``put_the_bowl_on_the_stove``：``flat_stove_1_main`` 在世界坐标
        (-0.404, 0.202)，但炉子的 cook region 在 burner 一侧
        （``flat_stove_1_burner`` 在 (-0.254, 0.202)，偏 +0.15m）。
        只按 body 中心放置，20 个 seed 全部失败；而 predicate 本身是可以通过
        放置满足的。

        所以先试几何中心（覆盖大多数 task），失败再在中心附近做小范围 xy 搜索。
        候选总数有上限，避免搜索把单次构造拖到几分钟。
        """
        # 0) 先试上次成功的那个偏移。
        #
        # 同一 task 的成功区域是固定的（例如炉子的 cook region 恒定偏 +0.08m），
        # 所以把上次成功的候选提到最前面，能把后续 seed 的构造从 18 次尝试
        # 降到 1 次。这不是"作弊"：状态仍然每个 seed 独立构造并逐次用
        # predicate 验证，只是省掉了重复的搜索代价。
        cached = self._offset_cache.get(task_id)
        if cached is not None:
            yield cached

        # 1) 再试几何中心，逐个抬高 —— 大多数 task 在这里就成功
        for dz in self.clearances:
            yield 0.0, 0.0, float(dz)

        # 2) 中心附近的小范围 xy 搜索（应对 success 区域偏离几何中心）
        offsets = [
            (0.0, 0.0),
            (0.04, 0.0), (-0.04, 0.0), (0.0, 0.04), (0.0, -0.04),
            (0.08, 0.0), (-0.08, 0.0), (0.0, 0.08), (0.0, -0.08),
            (0.12, 0.0), (-0.12, 0.0),
            (0.16, 0.0), (-0.16, 0.0),
            (0.04, 0.04), (-0.04, 0.04), (0.04, -0.04), (-0.04, -0.04),
        ]
        for dx, dy in offsets:
            if dx == 0.0 and dy == 0.0:
                continue
            for dz in (0.03, 0.06, 0.10):
                yield float(dx), float(dy), float(dz)

    @staticmethod
    def _iter_candidate_placements(seed: int, distance: float):
        """惰性生成 (方向, 半径) 候选，按"最可能成功且最省时"排序。

        顺序：
          1. seed 决定的朝向 × 3 个半径（大多数 seed 在这里就命中）
          2. 该朝向左右各偏 30° / 60° × 2 个半径
          3. 全方向均匀铺开（兜底，只在前面的都失败时才走到）

        同 seed 仍然完全可复现；只是不再无条件跑满全部组合。
        """
        rng = np.random.default_rng(seed)
        base = float(rng.uniform(0.0, 2.0 * math.pi))

        def unit(angle: float):
            return np.array([math.cos(angle), math.sin(angle)])

        # 1) 首选方向
        for scale in (1.0, 1.25, 1.5):
            yield unit(base), distance * scale

        # 2) 左右微调
        for offset in (math.pi / 6, -math.pi / 6, math.pi / 3, -math.pi / 3):
            for scale in (1.0, 1.5):
                yield unit(base + offset), distance * scale

        # 3) 兜底：全方向
        for k in range(12):
            yield unit(base + 2.0 * math.pi * k / 12), distance * 1.5

    def _build_unsatisfied_joint(
        self, arena: Arena, spec: TaskSpec, seed: int, base_state: np.ndarray
    ) -> ConstructionResult:
        """把关节推到"非目标"的一端。

        与 satisfied 对称：用 predicate 判断当前值是否已满足，
        若已满足则换到另一端。不假定方向。
        """
        model = arena.model
        joint_key = self._resolve_joint_key(model, spec)

        try:
            lo, hi = ms.get_joint_range(model, joint_key)
        except (KeyError, ValueError, TypeError) as exc:
            return self._fail(spec, "unsatisfied", seed, f"读取关节范围失败: {exc}")

        attempts: list[ConstructionAttempt] = []
        for value in (lo, hi, lo + 0.5 * (hi - lo)):
            state = ms.set_joint_pos(base_state, model, joint_key, value)
            state = ms.clear_all_velocities(state, ms.StateLayout.from_model(model))
            arena.set_state(state, settle_steps=self.settle_steps)

            satisfied = bool(arena.goal_satisfied())
            residual = float(arena.residual())
            final_state = arena.get_state()
            attempts.append(
                ConstructionAttempt(
                    method="joint_probe_unsatisfied",
                    clearance=float(value - lo),
                    subject_pos=None,
                    satisfied=satisfied,
                    residual=residual,
                    ok=not satisfied,
                    note=f"joint={joint_key!r} qpos={value:.5f} (range {lo:.5f}..{hi:.5f})",
                )
            )
            if not satisfied:
                return self._finalize(
                    arena,
                    ConstructionResult(
                        task_id=spec.id,
                        condition="unsatisfied",
                        seed=seed,
                        ok=True,
                        state=final_state,
                        satisfied_after_build=False,
                        residual_after_build=residual,
                        attempts=attempts,
                    ),
                )

        return ConstructionResult(
            task_id=spec.id,
            condition="unsatisfied",
            seed=seed,
            ok=False,
            state=None,
            satisfied_after_build=True,
            residual_after_build=float("nan"),
            attempts=attempts,
            failure_reason=(
                f"关节 {joint_key!r} 在整个 range 上都满足 predicate，"
                "无法构造 unsatisfied 状态。请检查关节名是否选对。"
            ),
        )

    # ------------------------------------------------------------------
    # 辅助
    # ------------------------------------------------------------------

    def _target_anchor(self, arena: Arena, spec: TaskSpec, target: str) -> np.ndarray:
        """确定 subject 应被放到的水平锚点 (x, y)。

        容器类（basket）与平面类（plate / stove）都用目标实体的 xy 作为锚点。

        **必须走 ``arena.entity_pos``**（保证世界坐标）。早期这里自己写了一份
        "取不到自由物体就读 data.xpos" 的回退逻辑，而 robosuite 的 data.xpos
        对 fixture 是**局部坐标**（返回 [0,0,0]）—— 于是"把碗放到炉子上"
        实际是把碗放到桌子原点，satisfied 构造必然失败。
        修了 arena 却漏了 builder 里这份重复实现，所以这里改为统一委托。
        """
        pos = arena.entity_pos(target)
        return np.array(pos[:2], dtype=np.float64)

    @staticmethod
    def _subject_half_height(model: Any, data: Any, subject: str) -> float:
        """subject 在当前姿态下的半高。"""
        body_id = ms.find_body_id(model, subject)
        z_min, z_max, _ = ms.geom_vertical_extent(model, data, body_id)
        return 0.5 * (z_max - z_min)

    @staticmethod
    def _assert_robot_untouched_policy(arena: Arena) -> None:
        """确认 arena 的 model 里前 9 个关节确实是机器人关节。

        这是一个便宜的防守性检查：如果 LIBERO 某版本把机器人关节排到别处，
        我们在构造状态时的"不动前 9 维"假设就会静默失效 ——
        而那种失效会让不同 condition 的机器人位姿不一致（§65.2 reset artifact），
        进而污染 UER。

        实测教训：最初只接受 ``robot0_`` 前缀，在真实 LIBERO 上直接误报 ——
        夹爪关节实际叫 ``gripper0_finger_joint1/2``。所以前缀列表要包含两种。
        """
        names = [j.name for j in ms.iter_joints(arena.model)]
        if len(names) < MAX_ROBOT_JOINTS_NO_TOUCH:
            return
        head = names[:MAX_ROBOT_JOINTS_NO_TOUCH]
        if not all(n.startswith(ROBOT_JOINT_PREFIXES) for n in head):
            raise RuntimeError(
                "假设失效：model 的前 9 个关节不是机器人关节。"
                f"实际前 9 个为 {head}。构造状态时'不改动机器人'的策略需要更新。"
            )

    def _fail(self, spec: TaskSpec, condition: Condition, seed: int, reason: str) -> ConstructionResult:
        return ConstructionResult(
            task_id=spec.id,
            condition=condition,
            seed=seed,
            ok=False,
            state=None,
            satisfied_after_build=False,
            residual_after_build=float("nan"),
            failure_reason=reason,
        )


def verify_robot_joints_unchanged(
    state_a: np.ndarray,
    state_b: np.ndarray,
    model: Any,
    *,
    n_robot_joints: int = MAX_ROBOT_JOINTS_NO_TOUCH,
) -> bool:
    """校验两个状态的机器人关节完全相同（§65.2 的 reset artifact 检查）。"""
    layout = ms.StateLayout.from_model(model)
    qa = ms.get_qpos(state_a, layout)[:n_robot_joints]
    qb = ms.get_qpos(state_b, layout)[:n_robot_joints]
    return bool(np.allclose(qa, qb))


def _reset_to_official_init(arena: Arena, index: int) -> None:
    """重置到官方初始状态。

    LIBERO 的 ``task_suite.get_task_init_states(task_id)`` 每个 task 提供 50 个
    **固定**初始状态，官方 eval 用 ``initial_states[episode_idx]`` 选取 ——
    也就是说"episode 编号"决定初始状态，而不是一个随机种子。

    本项目的 ``seed`` 字段即对应这个 official init index（取模到可用数量）。
    MockArena 与 LiberoArena 都接受该参数；不支持时退化为普通 reset。
    """
    try:
        arena.reset(official_init_index=int(index) % 50)  # type: ignore[call-arg]
        return
    except TypeError:
        pass
    arena.reset()
