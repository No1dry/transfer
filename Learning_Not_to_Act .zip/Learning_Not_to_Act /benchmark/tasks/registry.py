"""Step 2: Mini-PAB task registry。

把 ``configs/mini_pab.yaml`` 里的任务定义读成 ``TaskSpec`` 对象。

设计要点
--------
1. **不手写 task_id。** ``task_id`` 是 task 在该 LIBERO suite 列表中的下标，
   手写极易出错。本模块用 ``task_name`` 去 ``data/libero_task_ids.json``
   （由 ``scripts/extract_libero_task_ids.py`` 从 LIBERO 官方源码生成）里查下标，
   查不到就报错。
2. **语言指令不手写。** LIBERO 的 ``task.language`` 来自 BDDL 文件，
   本模块只存一个 *期望值* 供校验；运行时一律使用 ``task.language``。
   这一点很重要：指令措辞影响 VLA 行为，不能凭记忆写。
3. **残差函数只声明不实现。** ``residual_kind`` 是给 M2 的 partial 状态和
   ``n_t`` 连续标签用的；Fast 版本不构造 partial，所以这里只做声明。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Literal

# benchmark/tasks/registry.py -> benchmark/tasks -> benchmark -> <repo root>
REPO_ROOT = Path(__file__).resolve().parents[2]

Condition = Literal["satisfied", "partial", "unsatisfied"]
ResidualKind = Literal["placement", "joint", "relation"]
ConstructionMethod = Literal["scene_edit", "trajectory_truncation"]


@dataclass(frozen=True)
class TaskSpec:
    """Mini-PAB 中的一个 task family（LIBERO 官方任务）。"""

    id: str
    """本项目内部的短 id，例如 ``bowl_on_plate``。用于文件名与结果 key。"""

    display_name: str
    """给人看的名字。"""

    suite: str
    """LIBERO suite，例如 ``libero_goal``。"""

    task_name: str
    """LIBERO 官方 task 名，用于在 suite task map 中查 task_id。"""

    task_id: int
    """LIBERO ``task_suite.get_task(task_id)`` 的下标（自动解析得到）。"""

    expected_language: str
    """期望的 ``task.language``。运行时用于一致性校验，不作为真实指令来源。"""

    mode: Literal["STOP", "EXECUTE"]
    """Fast 版本本项目只构造 satisfied / unsatisfied 两态，
    因此该 task 在 satisfied 时的正确 mode 恒为 STOP。"""

    residual_kind: ResidualKind
    """该任务的残差 D(s,l) 类型（M2 用）。"""

    construction_method: ConstructionMethod
    """satisfied 状态的首选构造方法。"""

    edit: dict[str, Any]
    """场景编辑参数（对象名、目标名等），具体含义见 configs/mini_pab.yaml 注释。"""

    notes: str = ""
    tags: dict[str, Any] = field(default_factory=dict)

    # ---- 便捷属性 -------------------------------------------------------

    @property
    def subject(self) -> str:
        """被操作的对象名（MuJoCo body/joint 名前缀）。"""
        return self.edit["subject"]

    @property
    def target(self) -> str | None:
        """目标对象/区域名。``open_drawer`` 这类任务没有 subject->target 关系。"""
        return self.edit.get("target")

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "display_name": self.display_name,
            "suite": self.suite,
            "task_name": self.task_name,
            "task_id": self.task_id,
            "expected_language": self.expected_language,
            "mode": self.mode,
            "residual_kind": self.residual_kind,
            "construction_method": self.construction_method,
            "edit": self.edit,
            "notes": self.notes,
            "tags": self.tags,
        }


@dataclass
class TaskRegistry:
    tasks: list[TaskSpec]
    meta: dict[str, Any]

    def __iter__(self) -> Iterator[TaskSpec]:
        return iter(self.tasks)

    def __len__(self) -> int:
        return len(self.tasks)

    def __getitem__(self, task_id: str) -> TaskSpec:
        for t in self.tasks:
            if t.id == task_id:
                return t
        raise KeyError(f"未知 task id: {task_id!r}；可用: {[t.id for t in self.tasks]}")

    def by_suite(self) -> dict[str, list[TaskSpec]]:
        out: dict[str, list[TaskSpec]] = {}
        for t in self.tasks:
            out.setdefault(t.suite, []).append(t)
        return out


# --------------------------------------------------------------------------
# task_id 解析
# --------------------------------------------------------------------------


def load_libero_task_ids(path: Path | None = None) -> dict[str, dict[str, str]]:
    """读 ``data/libero_task_ids.json``，返回 ``suite -> {task_id: task_name}``。"""
    path = path or (REPO_ROOT / "data" / "libero_task_ids.json")
    if not path.is_file():
        raise FileNotFoundError(
            f"找不到 {path}。请先运行：python scripts/extract_libero_task_ids.py"
        )
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["suites"]


def resolve_task_id(
    suite: str,
    task_name: str,
    suites: dict[str, dict[str, str]] | None = None,
) -> int:
    """在 suite 中查找 ``task_name`` 的下标。找不到则抛错并给出近似候选。"""
    suites = suites or load_libero_task_ids()
    if suite not in suites:
        raise KeyError(f"未知 suite {suite!r}；可用: {sorted(suites)}")

    lookup = {name: int(idx) for idx, name in suites[suite].items()}
    if task_name in lookup:
        return lookup[task_name]

    # 给出候选，方便排错（例如 LIBERO 版本差异导致的名字变动）
    import difflib

    close = difflib.get_close_matches(task_name, list(lookup), n=5, cutoff=0.5)
    raise KeyError(
        f"在 suite {suite!r} 中找不到 task {task_name!r}。\n"
        f"  最接近的候选: {close}\n"
        f"  提示: LIBERO 各版本任务名可能不同，请用 --libero_root 重新生成 "
        f"data/libero_task_ids.json。"
    )


# --------------------------------------------------------------------------
# 载入
# --------------------------------------------------------------------------


def load_registry(config_path: Path | None = None) -> TaskRegistry:
    """载入 Mini-PAB task registry。

    只用标准库解析 YAML 会失败（本项目 YAML 很简单，但依赖 PyYAML 更稳妥）。
    """
    config_path = config_path or (REPO_ROOT / "configs" / "mini_pab.yaml")
    if not config_path.is_file():
        raise FileNotFoundError(f"找不到配置文件 {config_path}")

    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - 环境问题
        raise ImportError("需要 PyYAML：pip install pyyaml") from exc

    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    suites = load_libero_task_ids()

    tasks: list[TaskSpec] = []
    seen: set[str] = set()
    for raw in cfg["tasks"]:
        tid = raw["id"]
        if tid in seen:
            raise ValueError(f"重复的 task id: {tid!r}")
        seen.add(tid)

        suite = raw["suite"]
        task_name = raw["task_name"]
        spec = TaskSpec(
            id=tid,
            display_name=raw.get("display_name", tid),
            suite=suite,
            task_name=task_name,
            task_id=resolve_task_id(suite, task_name, suites),
            expected_language=raw["expected_language"],
            mode=raw.get("mode", "STOP"),
            residual_kind=raw["residual_kind"],
            construction_method=raw.get("construction_method", "scene_edit"),
            edit=raw["edit"],
            notes=raw.get("notes", ""),
            tags=raw.get("tags", {}) or {},
        )
        tasks.append(spec)

    meta = {
        "config_path": str(config_path),
        "n_tasks": len(tasks),
        "conditions": cfg.get("conditions", ["satisfied", "unsatisfied"]),
        "episodes_per_condition": cfg.get("episodes_per_condition", 20),
        "benchmark_version": cfg.get("benchmark_version", "mini-pab-v0"),
    }
    return TaskRegistry(tasks=tasks, meta=meta)


def episode_budget(registry: TaskRegistry) -> dict[str, int]:
    """按 4 任务 × 2 状态 × N seeds 计算 episode 预算。"""
    n_tasks = len(registry)
    n_cond = len(registry.meta["conditions"])
    n_seeds = int(registry.meta["episodes_per_condition"])
    return {
        "n_tasks": n_tasks,
        "n_conditions": n_cond,
        "n_seeds": n_seeds,
        "total_episodes": n_tasks * n_cond * n_seeds,
    }
