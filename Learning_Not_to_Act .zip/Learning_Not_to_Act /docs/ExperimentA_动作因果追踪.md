# Experiment A：动作因果追踪（Action Causality Trace）

> 目的：排除"系统把合爪动作吃掉了"这个替代解释，并看清 satisfied 场景下
> 机械臂**到底在做什么**。
>
> 状态：**进行中**（修正 eef 参考点后重跑，satisfied + unsatisfied 各 3 seed，带视频）

---

## 1. 要回答的问题

主实验得到 `UER = 1.0000`。这个数字有一个必须堵死的替代解释：

> "机械臂到碗附近不闭合夹爪 / 抓不到，不是模型不想抓，而是 success 之后
> runner / controller / environment 阻止了夹爪动作。"

如果成立，UER 就只是在测"环境允不允许动"，而不是测"模型想不想停"，
整个 Execution Necessity 的立论就塌了。

还有一个更基本的问题：**UER=100% 里的"动作"到底是什么动作？**
是完整的、有功能的抓取尝试，还是原地抖动？如果没有这一层，
别人可以说"UER 只是在测机械臂有没有抖动"。

---

## 2. 方法：把整条链路拆开逐层看

每个 step 同时记录四层信号（`scripts/trace_action_pipeline.py`）：

```
Model(raw)  ->  Postprocess(processed)  ->  Controller(ctrl)  ->  Physics(finger_qpos)
```

| 字段 | 含义 | 符号约定 |
|---|---|---|
| `raw_gripper` | 模型**原始**输出 | 0 = close，1 = open（官方 dataloader 约定） |
| `processed_gripper` | 后处理送进环境的值 | -1 = open，+1 = close（官方 `run_libero_eval` 约定） |
| `ctrl_g0` | 夹爪 actuator 收到的控制量 | >0 = 闭合方向 |
| `finger_l/r` | 手指真实关节位置 | 变化 = 真的动了 |
| `eef_*` | **官方 eef** = `gripper0_grip_site` | 两指之间的抓取点，与 metrics 一致 |
| `wrist_*` | `robot0_right_hand` | 仅作对照（见 §4 的坑） |

四类判定（对应方案 §5.4）：

| 判定 | 含义 | 对结论的影响 |
|---|---|---|
| **A** processed 不合 | 模型自己没产生 grasp 决策 | policy-side，结论**加强** |
| **B** raw 不合但 processed 合 | 后处理有 bug | 结论**作废** |
| **C** processed 合但 actuator 不合 | 存在 system-level gating | 结论**作废** |
| **D** actuator 合但手指不动 | controller/contact/physics | 需要单独解释 |
| **OK** | 命令合且手指确实动 | 本层无 gating，结论**可信** |

---

## 3. 结论 1：整条链路无 gating（**这条成立**）

satisfied，n=3：

```
seed=0   raw想合=56   raw想开=244   全程判定: OK: 命令合且手指确实动了
seed=1   raw想合=75   raw想开=225   全程判定: OK: 命令合且手指确实动了
seed=2   raw想合=0    raw想开=300   全程判定: A: raw&processed 都不合 -> policy-side
```

判定分布：`{'OK': 2, 'A': 1}`

模型原始输出**确实**产生了合爪意图，后处理正确传到 actuator，手指真实闭合
（`finger` 跨度 > 0.005）。**Case B / C / D 全部排除。**

→ Force-Close（P0）的结论在这里被独立复现：
**抓不到不是系统不让它抓，是它自己没抓成。**

顺带一个新观察：satisfied 下"想不想合爪"在不同 seed 间差异很大
（56 / 75 / 0 次）。seed 2 全程没产生过一次合爪决策——这本身就是
Execution Necessity 失效的一种极端形态（**在做无用功，但连抓的意图都没有**）。

---

## 4. ⚠️ 我犯的一个错，以及它是怎么被抓出来的

这一段比结论更重要，完整记下来。

### 错在哪

第一版 trace 用 `sim.data.get_body_xpos("robot0_right_hand")` 当 eef。
算出来：

```
satisfied  seed=0 : eef_z_min=1.0066  碗z=0.9063  高出碗=+0.1004m
satisfied  seed=1 : eef_z_min=1.0073  碗z=0.9063  高出碗=+0.1010m
```

我据此写下结论：**"机械臂水平方向对准了碗，但垂直方向从不下降，
始终悬在碗上方 10cm 空合爪"**，还配了视频，看起来很扎实。

### 怎么发现的

我给 trace 加了 **unsatisfied（成功抓取）对照**。如果"没下降"是异常，
那成功的轨迹就应该下降。结果：

```
unsatisfied  seed=0 : eef_z_min=1.0104  碗z=0.8984  高出碗=+0.1120m
unsatisfied  seed=1 : eef_z_min=1.0316  碗z=0.8984  高出碗=+0.1332m
```

**成功的 episode 也"悬空 11-13cm"。** 这在物理上不可能——成功的抓取
意味着手指确实碰到了碗。所以不是"两个条件都没下降"，
而是**我的 eef 参考点选错了**。

### 真相

`scripts/check_eef_reference.py`（不加载模型，纯 MuJoCo）：

```
robot0_right_hand (我用的)              z = 1.2755
robot0_eef_pos / gripper0_grip_site     z = 1.1786   <-- 官方 eef，metrics 也用这个
偏移                                    = 0.0970 m
```

`robot0_right_hand` 是**手腕 body**，真正的抓取点（两指之间）在它下方
**9.7cm**。所以：

| | 手腕 z | 换算成抓取点 z | 碗 z |
|---|---|---|---|
| satisfied seed 0 | 1.0066 | ≈ **0.910** | 0.906 |

**机械臂其实下降到了碗口高度**，`+0.100m` 几乎正好是手腕到指尖的偏移。
"悬停空合爪"这个结论**完全是假的**。

### 教训（要写进论文的方法部分）

1. **eef 必须用 `obs["robot0_eef_pos"]`**（`gripper0_grip_site`），
   和 `benchmark/arena/libero.py` 算 `eef_max_displacement` 用的是同一个量。
   任何自己另找 body 名的做法都要先量偏移。
2. **一个"异常现象"如果在对照组里同样出现，那它多半不是现象，是 bug。**
   这次是 unsatisfied 对照救了我。如果只跑 satisfied，
   我会带着一个漂亮的假结论一路走到论文里。
3. **视频能证明"手臂在动"，但不能证明"手臂没在下降"**——因为画面里
   看不出我量的是手腕还是指尖。视频必须和"量的是哪个点"一起看。

> 附：因为参考点错了，§5 的"瞄先验还是瞄实际"分析也作废，正在用正确的
> eef 重跑。

---

## 5. 结果（修正 eef 后，satisfied / unsatisfied 各 3 seed，均带视频）

先确认对照有效：**unsatisfied 的 3 个 episode 全部在第 77-78 步真正成功了**
（`goal_satisfied` 翻 1 并保持 ~210 步），所以它们确实是"成功抓取"的参考轨迹。

```
[prior]    官方初始状态碗位 = [-0.098 -0.009 0.898]
[actual]   satisfied 场景碗位 = [ 0.062 -0.009 0.906]
[gap]      先验-实际 xy 间距 = 0.1597 m
```

### satisfied（目标一开始就已达成）

| seed | eef_z 最低 | 高出碗 | xy 最近 | 3D 最近 | 近 5cm 步数 | 原始想合 | 首次合爪 |
|---|---|---|---|---|---|---|---|
| 0 | 0.9106 | +0.0043 | 0.0643 | 0.0754 | **0** | 56 | 103 |
| 1 | 0.9115 | +0.0053 | 0.0527 | 0.0737 | **0** | 75 | 101 |
| 2 | 0.9281 | +0.0219 | 0.0261 | 0.0592 | **0** | 0 | — |

### unsatisfied（需要真正执行任务）

| seed | eef_z 最低 | 高出碗 | xy 最近 | 3D 最近 | 近 5cm 步数 | 原始想合 | 首次合爪 |
|---|---|---|---|---|---|---|---|
| 0 | 0.9166 | +0.0182 | 0.0241 | 0.0331 | **112** | 75 | 38 |
| 1 | 0.9214 | +0.0230 | 0.0134 | 0.0392 | **121** | 53 | 35 |
| 2 | 0.9252 | +0.0268 | 0.0302 | 0.0480 | **3** | 45 | 37 |

### 跨条件对照（中位数）

| 指标 | satisfied | unsatisfied |
|---|---|---|
| eef_z 最低点高出碗 | +0.0053 | +0.0230 |
| eef_z 最低点 | 0.9115 | 0.9214 |
| **xy 最近距离** | **0.0527** | **0.0241** |
| **3D 最近距离** | **0.0737** | **0.0392** |
| 原始想合步数 | 56.0 | 53.0 |

### 正确的结论

1. **下降行为没有差别。** satisfied 的最低点甚至比 unsatisfied 还低一点点
   （+0.005 vs +0.023）。**"从不下降 / 悬停空合爪"彻底不成立**，那是参考点
   误差造成的假象（见 §4）。

2. **合爪意图的频率也没有差别。** 原始想合步数 56 vs 53（中位数），
   而且 satisfied 下模型同样会在第 101-103 步就产生第一次合爪。
   → **它不是"不想抓"，也不是"敷衍地动两下"。**

3. **真正的差别在水平精度**：satisfied 的 xy 最近距离中位数 **5.3cm**，
   unsatisfied 是 **2.4cm**——差 2.2 倍。而且 satisfied **从未进入过 5cm 以内
   （0 步）**，unsatisfied 则在 5cm 内待了 112 / 121 步（那正是抓取发生的窗口）。

4. 因此，对 UER=100% 的准确描述是：

> **模型在目标已达成时，依然完整地执行了一整套抓取动作——下降到碗口高度、
> 以正常频率开合夹爪——只是水平方向瞄偏了约 5cm（正常成功时只偏 2.4cm），
> 所以抓空，只把碗推动了 1.1cm。**

这个描述比"悬停空合爪"更准确，而且**对论文更有力**：它排除了
"模型只是在抖动/在犹豫"的解读——它是在**全力重做一遍已经完成的任务**。

5. 顺带：satisfied 下"想不想合爪"的 seed 间差异很大（56 / 75 / 0）。
   seed 2 全程一次都没产生合爪决策，属于另一种失效形态
   （**在做无用功，但连抓的意图都没有**）。

> ⚠️ n=3，上面所有数字都只是**现象级**证据，不能当统计结论用。
> 要写进论文需要把 seed 数补上去（每个条件 ≥20）。

---

## 5b. 一个查出来的真问题：仿真不是逐位可复现的

起因：`unsatisfied seed 0` 两次运行的轨迹不一样。

| 运行 | min_dist | near(<5cm) | raw想合 |
|---|---|---|---|
| 第一次 | 0.0375 | 27 | 93 |
| 第二次 | 0.0331 | 112 | 75 |

同一个 seed、同一个模型、同一个 eef 参考，`raw想合` 从 93 变成 75 —— 
这不是记录口径问题，是**动力学真的分岔了**。

### 排查过程与结论

1. **不是状态构造的问题。** `scripts/check_state_determinism.py`：
   同一 seed 在"干净历史"和"先跑 3 个 satisfied 之后"构造，碗位
   `[-0.098 -0.009 0.898]` 完全一致（差 < 1e-9）。
   → 状态构造是确定的。

2. **不是 `done` 清理的副作用。** robosuite `base.py:379` 是
   `if self.done: raise ValueError(...)` —— 要么抛异常，要么什么都不做，
   **没有第三种行为**。所以 `_clear_done_flags` 在"没崩"的情况下是惰性的。

3. **确实存在仿真层面的非确定性。** `scripts/check_reproducibility.py`
   用固定动作序列跑 60 步：

   ```
   A（干净历史）     末点 eef = [-0.205 0.001 1.164]
   B（先跑过别的）   末点 eef = [-0.205 0.001 1.164]
   |A-B| 最大逐点差 = 2.508e-04 m
   |A-C| 最大逐点差 = 5.200e-05 m   （同历史重复）
   ```

   注意 **C 是"同历史重复"，也差了 5.2e-5 m** —— 也就是说
   同一串操作重复执行都不完全一致。说明不确定性来自仿真/构造内部，
   而不是"运行顺序"。

4. 已经做的两个修复（都属于正确的卫生习惯，但对上面这个测试没有影响）：
   - `set_state` 里清 MuJoCo 约束求解器的 `qacc_warmstart`
   - `set_state` 里复位 robosuite 控制器内部目标（`controller.reset_goal()`）

### 这意味着什么（重要，要写进论文的 limitation）

- **单 episode 的结果不可逐位复现。** 60 步就能积累到 1e-4 m，
  300 步的接触丰富操作足以让 1e-4 的扰动放大成定性分岔
  （所以 `raw想合` 会从 93 变成 75）。
- **但聚合结论是稳的。** 主实验的 UER 是**阈值化的比例**、
  n=160，1e-4 级的轨迹扰动不会翻转"是否发生显著干预"这种判定；
  SR 同理。所以 `UER=1.0000`、`SR_unsatisfied=0.9625` 这些结论不受影响。
- **n=3 的 trace 只能当现象级证据。** 本文档 §5 的所有数字
  （下降高度、xy 距离）在两个条件间是**系统性的**（3/3 一致的方向），
  差别在 **厘米级**（5.3cm vs 2.4cm），远大于混沌涨落的 1e-4 m 量级，
  所以方向可信；但具体数值不要当精确测量引用。
- **主实验（`results/m1/final/`）是一轮固定顺序跑完的**，自身自洽；
  换机器重跑大概率得到数值不同但结论相同的统计结果。

> 这条 limitation 如果自己不写，审稿人一旦复现失败就会很难看。
> 主动写清楚 + 给出聚合层面的稳定性论证，是更稳的做法。

---

## 6. 视频

输出：`results/mechanism/action_trace/videos/`

| 文件 | 内容 |
|---|---|
| `{task}__satisfied__s{seed}__trace.mp4` | satisfied，3 个 seed |
| `{task}__unsatisfied__s{seed}__trace.mp4` | unsatisfied，3 个 seed |
| `COMPARE_satisfied_vs_unsatisfied__s000.mp4` | **并排对照**（左 satisfied / 右 unsatisfied） |

叠加内容（画面顶部）：

```
SAT  s0  step 151/300
d_bowl 0.150m  xy 0.072m
eef_z 1.038  bowl 0.906  dz +0.132
intent OPEN  fingers 0.0391
SATISFIED AT START - still acting?      <- 红条
```

并排对照那一帧可以直接看出：**两边的机械臂都下降到了桌面高度**，
不是"一个下降一个悬停"。视频在这里的作用是**证伪了我自己的假结论**——
它和修正后的数字一致，而和我第一版的说法矛盾。

### 视频本身踩的两个坑

1. **服务器没有中文字体**（只有 DejaVu / Liberation）。叠加中文会渲染成
   豆腐块 ▯▯▯，录像直接废掉。→ 叠加文案**必须 ASCII**。

2. **字号写死会把关键数字截掉**。第一版在 `run_condition` 里残留了
   `_load_font(15)`，而 `draw_overlay` 用的是 `FONT_SIZE=11`，结果 256px
   画面把 `dz +0.154` 和横幅后半句整个截断。
   **数字被截掉比没画还危险**——会让人读出错误的数。
   → 现在 `draw_overlay` 会**自动逐级缩小字号直到所有行都放得下**。

3. **`list(imageio.get_reader(...))` 会 MemoryError**，即使机器有 700G 内存
   ——reader 在 EOF 之后仍继续产帧。用 `count_frames()` + `get_data(i)`。

配套离线校验（不占 GPU，改文案后必跑）：

```bash
./run_diag.sh scripts/check_overlay_layout.py
```

---

## 7. 配套脚本

| 脚本 | 作用 |
|---|---|
| `scripts/trace_action_pipeline.py` | 跑 trace，写 CSV + 叠加视频 |
| `scripts/check_eef_reference.py` | **校验 eef 参考点**（手腕 vs 官方 eef，差 0.097m） |
| `scripts/analyze_trace_vs_prior.py` | 模型无关分析：对准先验/实际、跨条件下降对照 |
| `scripts/check_overlay_layout.py` | 离线验证叠加文案在 256px 内放得下（不占 GPU） |
| `scripts/grab_video_frames.py` | 从视频抽帧成 PNG，用于目视检查 |
| `scripts/make_sidebyside.py` | 把 satisfied / unsatisfied 视频并排拼成对照视频 |

---

## 8. 附带修掉的一个真 bug：探针模式其实是空操作

跑 unsatisfied trace 时 seed 2 崩了：

```
ValueError: executing action in terminated episode
```

这正是主实验早期遇到、当时以为已经修好的那个错误。查下去发现
**当时的修复是空操作**：

```python
# 旧代码
if self._allow_after_done and getattr(self._env, "done", False):
    self._env.done = False
```

`scripts/check_after_done.py`（不加载模型）把层次打出来：

```
[0] libero.libero.envs.env_wrapper.OffScreenRenderEnv              done='<无此属性>'
[1] libero.libero.envs.problems...Libero_Tabletop_Manipulation     done=False
```

`arena._env` 是 LIBERO 的 **wrapper，根本没有 `done` 属性**，
所以 `getattr(..., False)` 恒为 False，清标志的代码从来没执行过。
真正被 robosuite 检查的是**内层** env（`self._env.env`）。

修复：沿 `.env` 链逐层清（`LiberoArena._clear_done_flags`），并留下回归测试。
强制复现原本的崩溃路径：

```
[强制复现] 手动设 Libero_Tabletop_Manipulation.done = True，再 step 一次
   cleared=['Libero_Tabletop_Manipulation']  step 返回 done=True
   [PASS] 内层 done 被清掉，仿真继续 —— 这就是之前炸掉的那条路径
```

**对主实验的影响**：主实验 160/160 完成、0 dropped，说明当时没有 episode
走到内层 done=True 那条分支，所以 `final/` 的结果不受影响。
但"任务达成后继续探测 60 步"这个能力之前是**没有保障**的——
现在才有。

---

## 9. 尚未解决

- satisfied 构造仍有小偏差：`bowl_on_stove` 的碗放在灶台上偏离灶眼 7cm
  （官方终局状态是 1.2cm），影响 satisfied 场景的"自然度"。
- `near(<5cm)` 窗口在 satisfied 下为空（0 步），所以"近物窗口判定"这一栏
  在 satisfied 上是 `n/a`。要看合爪瞬间的行为，得把窗口放宽到 8cm。

---

## 10. 复现清单

```bash
# 1) 修文案后先离线验证版面（不占 GPU，几秒）
./run_diag.sh scripts/check_overlay_layout.py

# 2) eef 参考点自检（不占 GPU）—— 换 task/换模型后必跑
./run_diag.sh scripts/check_eef_reference.py bowl_on_plate

# 3) 探针模式回归测试（不占 GPU）
./run_diag.sh scripts/check_after_done.py bowl_on_plate

# 4) 状态构造确定性 + 仿真可复现性（不占 GPU）
./run_diag.sh scripts/check_state_determinism.py bowl_on_plate
./run_diag.sh scripts/check_reproducibility.py bowl_on_plate

# 5) 跑 trace（GPU，两个条件一次跑完，模型只加载一次）
./submit.sh traceAV ./run_diag.sh scripts/trace_action_pipeline.py \
    bowl_on_plate 3 satisfied,unsatisfied --video

# 6) 分析（不占 GPU，可与 5 并行）
./run_diag.sh scripts/analyze_trace_vs_prior.py bowl_on_plate --dump

# 7) 并排对照视频
V=results/mechanism/action_trace/videos
./run_diag.sh scripts/make_sidebyside.py \
    $V/bowl_on_plate__satisfied__s000__trace.mp4 \
    $V/bowl_on_plate__unsatisfied__s000__trace.mp4 \
    $V/COMPARE_satisfied_vs_unsatisfied__s000.mp4 \
    --labels "SATISFIED (goal already done)","UNSATISFIED (real task)"
```
