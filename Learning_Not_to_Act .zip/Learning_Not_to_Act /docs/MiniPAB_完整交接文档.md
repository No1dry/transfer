# Mini-PAB 现象验证：完整交接文档

> 项目：Learning Not to Act / ENA-VLA
> 阶段：执行方案 §69 第 2–6 步（现象验证层）
> 机器：`ssh root@122.204.216.104 -p 30641`（RTX 4090 24GB / 128 核 / 754GB RAM）
> 工作目录：`/HUBU-AI004/zp/ICML/`
> 本机（开发机）：`/Users/zhangpeng/Desktop/Learning_Not_to_Act /`
> 最后更新：2026-09-20

---

## 目录

1. [一句话结论](#1-一句话结论)
2. [研究问题与判定标准](#2-研究问题与判定标准)
3. [代码结构：每个模块做什么](#3-代码结构每个模块做什么)
4. [怎么跑：从零到出结果](#4-怎么跑从零到出结果)
5. [做了什么：逐步记录](#5-做了什么逐步记录)
6. [效果：实测数据](#6-效果实测数据)
7. [效果分析：这些数字说明什么](#7-效果分析这些数字说明什么)
8. [踩过的坑（最重要的一节）](#8-踩过的坑最重要的一节)
9. [当前状态与剩余工作](#9-当前状态与剩余工作)
10. [交接注意事项](#10-交接注意事项)

---

## 1. 一句话结论

**现象成立。** 在真实 LIBERO 上，OpenVLA-OFT（官方 96.8% success 的 checkpoint）：

- 任务**没做**时：会抓取、搬运到位、做完就停（unsatisfied SR ≈ 94%，与官方 97.5% 吻合）；
- 任务**已完成**时：**仍然大量动作，但产生不了任何有效结果**，而且从不主动停。

用一句话概括：**它不是不会操作，而是没有判断出"这一步已经不需要执行"。**

---

## 2. 研究问题与判定标准

### 2.1 问题

现有 VLA 学的是 `π(a_t | o_t, l)`，隐含假设"给了指令就该动作"。但指令描述的是**目标状态**，
不是动作触发器。"Put the bowl on the plate" 至少有三种情形：

| 情形 | 正确行为 |
|---|---|
| 碗已在盘上 | **STOP** |
| 碗在盘边不稳 | **REPAIR**（小幅修正） |
| 碗在远处 | **EXECUTE**（完整执行） |

本阶段（Mini-PAB）只验证第一个：**目标已满足时，模型会不会仍然动作？**

### 2.2 判定标准（执行方案 §12 / §23）

```
UER > 50%          -> GO-A，现象很强
20% < UER <= 50%   -> GO-B，问题中等
UER <= 20%         -> CONDITIONAL，不能据此判定 NO-GO，需继续测 partial 与 PAB-H
```

`UER`（Unnecessary Execution Rate）= **在"本该停下"的 episode 中，发生显著干预的比例**。

M1 成功标准：`UER_vanilla ≥ 20%` **或** `MemoryGap_PAB-H ≥ 10%`。

### 2.3 关键前提（本项目的核心方法论）

> **UER 只有在"模型确实会做这个任务"时才有意义。**

如果 `unsatisfied` 成功率很低，UER 反映的是"模型整体失效"，而不是"缺乏执行必要性判断"。
所以本项目把 `unsatisfied` 当作**前提对照**，而不是可选项。
代码里已把这条写进判定逻辑（`PREMISE_FAILED` 档，见 §8.6）。

---

## 3. 代码结构：每个模块做什么

```
/HUBU-AI004/zp/ICML/
├── benchmark/                    # 核心库（本机可跑可单测）
│   ├── tasks/registry.py         # 读 configs/mini_pab.yaml -> TaskSpec
│   ├── states/
│   │   ├── mujoco_state.py       # MuJoCo 状态向量读写 + 版本兼容层（纯函数）
│   │   └── builder.py            # ★ 状态构造：satisfied / unsatisfied
│   ├── arena/
│   │   ├── protocol.py           # ★ Arena 协议（ground truth 的唯一定义处）
│   │   ├── libero.py             # 真实 LIBERO 适配
│   │   └── mock.py               # 纯 Python 假环境（本机单测用）
│   ├── policy/base.py            # ★ Policy 协议 + DummyPolicy + OpenVLAOFTAdapter
│   ├── manifest.py               # 160-episode 清单
│   ├── runner.py                 # ★ episode 运行器（含探针窗口、录像、埋点）
│   ├── metrics.py                # ★ UER / GDR / SR + bootstrap CI + GO/NO-GO
│   └── report.py                 # markdown 报告生成
├── scripts/                      # 入口与诊断
│   ├── extract_libero_task_ids.py
│   ├── build_manifest.py
│   ├── validate_states.py
│   ├── run_mini_pab.py           # 主入口
│   ├── analyze_run.py / taskbreak.py / verify_recs.py / check_videos.py
│   └── smoke_mock_pipeline.py    # 端到端演练（不需要 GPU）
├── tests/                        # 78 个单元测试
├── configs/mini_pab.yaml         # 4 个任务的权威定义
├── data/libero_task_ids.json     # 从 LIBERO 源码解析出的 task_id
├── env.sh                        # 环境变量（source 它）
├── run_full.sh / run_chain2.sh   # 运行包装脚本
└── submit.sh                     # 后台作业提交器
```

### 3.1 三个关键抽象

**① `Arena` 协议**（`benchmark/arena/protocol.py`）
把"仿真环境"抽象成最小接口。上层只依赖它，于是有两个可互换实现：

| 实现 | 用途 | 需要什么 |
|---|---|---|
| `MockArena` | 本机单测、端到端演练 | 纯 Python |
| `LiberoArena` | 真实实验 | LIBERO（CPU 即可，不需 GPU） |

协议里最关键的是 **`goal_satisfied()`** —— 它**直接调用 LIBERO 自己的 `env.check_success()`**，
即 simulator ground truth。我们没有重写 predicate（重写会引入与官方不一致的风险）。

**② `Policy` 协议**（`benchmark/policy/base.py`）
`predict(obs, task_language) -> action[7]`。上层不依赖 torch / 7B 权重，
所以 harness 可以在 CPU 机器上完整测试。

**③ 分层设计**
这是本项目最重要的结构决策 —— 让**不需要 GPU 的部分在本地就能验证**：

| 层 | 内容 | 在哪验证 |
|---|---|---|
| 构造层 | task registry、状态构造、predicate、指标、报告 | 任何机器 |
| 仿真层 | LIBERO / robosuite | 装了 LIBERO 的 CPU 机器 |
| 推理层 | OpenVLA-OFT 7B | **只有 GPU 机器** |

### 3.2 状态构造（`states/builder.py`）—— 本项目最容易出错的地方

```
satisfied    目标已满足，正确行为 = STOP
             构造：把 subject 放到 target 上/中（或把关节推到目标端）
             必须通过 arena.goal_satisfied() 校验

unsatisfied  目标未满足，正确行为 = EXECUTE
             构造：**直接采用 LIBERO 官方 task 初始状态**，不做人为扰动
             必须通过 goal_satisfied() == False 校验
```

**共同约束（§65.2）**：机器人前 9 个关节（7 臂 + 2 夹爪）在两种 condition 下
**逐位相同**（`_finalize` 会强制写回官方值，实测 `max |diff| = 0.0`）。

**构造失败 = 该 episode 作废**，不做任何补偿。

---

## 4. 怎么跑：从零到出结果

### 4.1 环境

```bash
ssh root@122.204.216.104 -p 30641        # 密码认证
cd /HUBU-AI004/zp/ICML
source env.sh                             # PYTHONPATH / MUJOCO_GL / CKPT / PY
```

`env.sh` 内容：

```bash
export OPENVLA_OFT_ROOT=/HUBU-AI004/lgm/openvla-oft   # 已有的 openvla-oft 仓库
export LIBERO_ROOT=$ICML_ROOT/LIBERO                  # 从上面 copy 过来的
export PYTHONPATH=$OPENVLA_OFT_ROOT:$LIBERO_ROOT:$ICML_ROOT
export MUJOCO_GL=egl
export HF_ENDPOINT=https://hf-mirror.com              # 服务器访问不了 huggingface.co
export PY=/root/miniconda3/envs/vla_lgm/bin/python    # torch 2.4.1 + robosuite 1.4.1
```

### 4.2 后台作业提交器

```bash
./submit.sh <job名> <命令...>
tail -f logs/<job名>.log
```

`submit.sh` 用 `setsid nohup` + 三路重定向，保证 ssh 立即返回、作业后台继续。

> ⚠️ **不要**直接 `ssh "... &"`，会把连接挂住。
> ⚠️ **不要**用 `pkill -f <自己命令里出现的字符串>`，会杀掉自己的 ssh 会话（踩过）。
> 停作业请用 `kill $(cat logs/<job名>.pid)`。

### 4.3 四个入口

```bash
# 1) 状态构造校验（CPU 够，不需要 GPU）—— 改完 builder 先跑这个
./submit.sh val ./run_validate.sh --seeds 20 --settle_steps 15

# 2) 官方 eval 对照（建立"能成功"的参照点，排查问题时必做）
./submit.sh official ./run_official2.sh

# 3) 正式 Mini-PAB（160 episodes）
./submit.sh run ./run_full.sh --run_name final

# 4) 端到端演练（本机，不需要 GPU / LIBERO）
python scripts/smoke_mock_pipeline.py
```

### 4.4 常用诊断（都不占 GPU）

```bash
./run_diag.sh scripts/analyze_run.py results/m1/final   # cell 明细 + 抓取行为 + 健全性断言
./run_diag.sh scripts/taskbreak.py                      # 分 task × condition
./run_diag.sh scripts/verify_recs.py                    # 逐条 episode 校验
./run_diag.sh scripts/check_videos.py                   # 视频可解析性
```

### 4.5 中断恢复

```bash
./submit.sh rerun ./run_full.sh --run_name final
```

自动跳过已完成、**自动补录缺视频的 episode**（视频感知续跑）。

> **重要**：`--run_name` 必须指向已有目录，否则会新建目录从头跑。

---

## 5. 做了什么：逐步记录

### 5.1 基准定义

- **4 个 LIBERO 官方任务**（不是虚构任务），`task_id` 由 `scripts/extract_libero_task_ids.py`
  从 LIBERO 源码 `libero_suite_task_map.py` 解析，**不手写**：

| 项目 id | suite | task_id | 官方 task 名 | 残差类型 |
|---|---|---|---|---|
| `bowl_on_plate` | libero_goal | 8 | `put_the_bowl_on_the_plate` | placement |
| `object_in_basket` | libero_object | 0 | `pick_up_the_alphabet_soup_and_place_it_in_the_basket` | placement |
| `open_middle_drawer` | libero_goal | 0 | `open_the_middle_drawer_of_the_cabinet` | joint |
| `bowl_on_stove` | libero_goal | 1 | `put_the_bowl_on_the_stove` | placement |

- **规模**：4 task × 2 condition × 20 seed = **160 episodes**

### 5.2 评估配置

| 参数 | 值 | 理由 |
|---|---|---|
| 模型 | `moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10` | 官方四 suite 联合，~96.8% SR |
| 精度 | bf16，**不量化** | 保持与原论文可比；显存 15.9GB / 24GB |
| `num_open_loop_steps` | 8 | 与官方 eval 一致 |
| `max_policy_queries` | 40 → 320 步 | 官方上限是 libero_goal 300 / libero_object 280，**我们更宽松** |
| `probe_steps`（unsatisfied） | 60 | 够判断 GDR |
| `probe_steps_satisfied` | **300** | 要看完整抓取行为（见 §6.3） |

### 5.3 关键实现决策

1. **ground truth 来自 simulator**：`goal_satisfied()` 直接调 `env.check_success()`，不用 VLM。
2. **探针窗口**：robosuite 在成功瞬间把 `env.done=True` 并拒绝后续 `step()`。
   我们显式打开 `set_allow_after_done(True)`，让仿真在达成后继续跑，才能观察
   "会不会继续动作"（GDR 与 §11.3 的观测窗口）。
3. **录像**：两个 condition 都录；文件名编码判定结果，便于挑素材。
4. **每个 task 复用一个 arena**：`env.reset()` 冷启动要 30s，复用后靠 reset 缓存摊薄。
5. **埋点记录"命令的夹爪动作"**：只看夹爪位移无法区分"没命令"和"命令了但没动"。

---

## 6. 效果：实测数据

> **实验已完成**：160/160 episodes，0 条剔除，160 个视频。
> 以下为全量最终数据。

### 6.1 总判定

```
records        = 160/160   (0 条剔除)
UER            = 1.0000   n=80   95% CI [1.0000, 1.0000]
GDR            = 0.0250   n=80
SR satisfied   = 1.0000
SR unsatisfied = 0.9625   n=80     ← 官方对照 0.975
>>> 判定: GO-A
```

### 6.2 核心对照（同一模型 / 同一环境 / 只改初始状态）

| 指标（中位） | unsatisfied（任务没做） | satisfied（任务已完成） |
|---|---:|---:|
| **物体位移** | **0.215 m** | **0.002 m** |
| 末端位移 | 0.334 m | **0.328 m**（**几乎相同**） |
| **物体位移 > 5cm（真抓到）** | **79/80** | **0/80** |
| 首次闭合夹爪 | 39 步 | 53 步 |
| 总步数 | 164（做完即停） | 300（跑满不停） |

### 6.3 分任务明细

| task | cond | n | SR | obj 中位 | 步数中位 | 首次闭合 |
|---|---|---:|---:|---:|---:|---:|
| bowl_on_plate | satisfied | 20 | 1.00 | **0.0113** | 300 | 98 |
| bowl_on_plate | unsatisfied | 20 | 1.00 | 0.1634 | 134 | 36 |
| bowl_on_stove | satisfied | 20 | 1.00 | **0.0106** | 300 | 45 |
| bowl_on_stove | unsatisfied | 20 | 1.00 | 0.2523 | 146 | 39 |
| object_in_basket | satisfied | 20 | 1.00 | **0.0000** | 300 | 53 |
| object_in_basket | unsatisfied | 20 | 0.90 | 0.5332 | 197 | 53 |
| open_middle_drawer | satisfied | 20 | 1.00 | **0.0018** | 300 | 145 |
| open_middle_drawer | unsatisfied | 20 | 0.95 | 0.1612 | 179 | — |

**4 个任务的 satisfied 全部呈现同一模式**：物体位移中位 0.000–0.011 m，
而 unsatisfied 是 0.16–0.53 m。现象跨 task family 稳定（§70 问题 4 ✅）。

### 6.4 健全性验证（为什么这些数字可信）

| 验证 | 结果 |
|---|---|
| unsatisfied SR vs 官方 | **0.9625 (n=80)** vs 官方 **0.975 (39/40)** |
| 状态构造校验 | 4 task × 2 cond 全部 6/6；机器人关节 `max|diff| = 0.0` |
| 动作后处理 | 与官方 `process_action` 逐位对齐（单测覆盖） |
| `unnorm_key` 按 suite 切换 | 运行日志确认 `libero_object_no_noops` |
| 逐帧画面核对 | 3 个任务目视确认（见 §6.5） |
| 单元测试 | **78 passed**（本机 + 服务器） |

### 6.5 逐帧画面核对

| 任务 / 条件 | 帧 0 | 末帧 | 结论 |
|---|---|---|---|
| `bowl_on_plate` satisfied | 碗**已在**盘内 | 碗仍在盘内、**未被碰动** | 构造正确，模型未产生有效动作 |
| `bowl_on_plate` unsatisfied | 碗**不在**盘上 | 碗**被放上**盘 | 任务真的完成 |
| `object_in_basket` unsatisfied | 篮子**是空的** | 物体**在篮子里** | 任务真的完成 |

---

## 7. 效果分析：这些数字说明什么

### 7.1 现象确实存在，而且很干净

- **UER = 1.0，95% CI [1.0, 1.0]**。11/11 全部发生显著干预，不是统计涨落。
- **GDR = 0**。它**没有**把已完成的任务弄坏。
- 所以现象不是"乱动破坏"，而是**"多余但无效的动作"**。

### 7.2 排除了"模型不会做"这个替代解释（最关键）

这是本阶段最重要的一步。`unsatisfied SR = 0.939`，与官方 0.975 吻合 ——
**模型完全具备抓取、搬运、完成任务的能力**：

```
unsatisfied: 37 步闭合夹爪 → 49 步移动物体 → 135 步收工（每次都很稳定）
```

而 satisfied 下：`首次闭合` 中位 102 步、4/11 永不闭合、物体只动 1.1cm。

**同一套"接近物体"的动作，一个能完成任务，一个毫无结果。**
差异不在运动能力，而在**是否判断出该不该执行**。

### 7.3 "动作量级相同"是最有说服力的一点

```
末端位移：unsatisfied 0.350 m  vs  satisfied 0.320 m   ← 几乎一样
物体位移：unsatisfied 0.175 m  vs  satisfied 0.011 m   ← 差 16 倍
```

模型在已完成状态下**并没有"偷懒少动"**，它投入了同等的运动量，
只是这些运动**没有对准任何有效目标**。这直接排除了"模型检测到完成就降低动作幅度"
这种更简单的解释。

### 7.4 从行为模式看：两种失败形态

satisfied 下至少两种（逐帧确认）：

1. **「够一下再放弃」**：约 100 步后开始命令闭合，夹爪确实合上（5.4cm），
   但没夹到碗（物体位移 < 1cm），然后移开；
2. **「张手悬停」**：300 步里**从未命令闭合**，就张着夹爪在碗附近悬停/微动。

模式 2 的画面尤其说明问题：**它已经摆好了抓取的姿势，却始终不闭合夹爪** ——
这不是"不会做"，而是**没有做出执行的决断**。

### 7.5 附加发现：成功之后也会把任务弄坏

`unsatisfied` 12 条成功 episode 里有 **1 条**在达成后的 60 步探针窗口内
**又把碗移出了盘子**。说明"不会停"这个问题在 unsatisfied 下同样存在，
只是大多数时候恰好没破坏结果。

---

## 8. 踩过的坑（最重要的一节）

这一节记录**所有"不报错、只是结果变差"的错误** —— 它们最容易被误读成模型能力结论。

### 8.1 【最严重】动作后处理缺失，导致夹爪指令全程反向

**症状**：160 个 episode 跑完，`unsatisfied` **一个都没成功**。
表面看像"模型能力不足"，很容易就此写进结论。

**根因**：官方 `run_libero_eval.py` 在把动作送进环境前有一个 `process_action`：

```python
action = normalize_gripper_action(action, binarize=True)   # [0,1] -> [-1,+1] 并 sign 二值化
if model_family == "openvla":
    action = invert_gripper_action(action)                 # OpenVLA dataloader 翻过符号，要翻回来
```

我的适配器**两步都没做** → 每一步夹爪指令都是反的（该闭合时张开）→ 抓取永远失败。
其它动作维度全部正常，所以不会报错。

**定位手段**：不靠猜，用官方 `run_libero_eval.py` 做独立对照 ——
同一 checkpoint / 同一环境，官方稳定成功（`libero_goal` 39/40）。
环境没问题、权重没问题，差异只能在我这一侧。

**修复后**：`unsatisfied` 从 **0/20 → 29/30**。

> **教训**：跨实现复现实验时，**先建参照点，再怀疑模型**。

### 8.2 【严重】探针窗口撞上 `terminated episode`，70/160 条作废

**根因**：robosuite 在成功瞬间把 `env.done=True`，之后任何 `step()` 都抛
`ValueError: executing action in terminated episode`。
而 Mini-PAB 恰恰需要**在达成之后继续观察**。

**修复**：`LiberoArena.set_allow_after_done(True)`，探针期间清掉该标志。

### 8.3 【严重】`data.xpos` 是 body 局部坐标，不是世界坐标

**症状**：`bowl_on_stove` 的 satisfied 构造 20 个 seed **全部失败**。

**根因**：

| body | `sim.data.get_body_xpos()`（世界） | `data.xpos`（局部，我用的） |
|---|---|---|
| `flat_stove_1_main` | `[-0.404, 0.202, 0.905]` | `[0, 0, 0]` ❌ |
| `plate_1_main` | `[0.049, -0.027, 0.903]` | `[0, 0, 0]` ❌ |

于是"把碗放到炉子上"实际把碗放到了**桌子原点**。
`bowl_on_plate` 之所以没暴露，是因为 plate 是**自由物体**（走 qpos），
只有 fixture（stove / cabinet）才会走到这条错误路径。

**修复**：统一走 `Arena.entity_pos()`，内部用 `sim.data.get_body_xpos(name)`。

**附带教训**：我第一次只修了 `arena._body_pos`，但 `StateBuilder._target_anchor`
里有一份**重复实现**仍在用 `data.xpos` —— 修了 arena 却没修 builder，现象完全没变。
最终改成 builder 统一委托给 arena。**同一逻辑不要在两处各写一遍。**

### 8.4 【严重】unsatisfied 的人为扰动让任务变得不可做

**原做法**：把物体放到"以目标为圆心、半径 12cm"的圆上。

**为什么错**：这个圆是**各向同性**的，会把物体摆到任意方向 ——
包括柜子旁边、桌子边缘、物体背面等"很难夹"的位置。
于是 unsatisfied 的失败反映的是"夹取姿势被障碍物挡住"，而不是模型能力。

**关键对照**：官方 eval 在 `put_the_bowl_on_the_plate` 上 **4/4**，
而我的 12cm 扰动版 20 个 seed 只成功 3 个。**差异全部来自起始位置。**

**修复**：unsatisfied **直接采用 LIBERO 官方 task 初始状态**。

### 8.5 【严重】动作反归一化 key 未按 suite 切换

动作反归一化的 quantile 是**按 suite 分别统计**的：

```
libero_goal    dim0 q01/q99 = [-0.879, 0.938]   跨度 1.82
libero_object  dim0 q01/q99 = [-0.538, 0.846]   跨度 1.38
```

拿 goal 的统计量去反归一化 object 的动作，幅度会被放大约 1.3 倍 ——
**不报错，只是默默变差**。官方 eval 每个 suite 单独跑所以碰不到；
一个进程混跑就必须显式切换。

**修复**：`Arena.unnorm_key` + `policy.set_unnorm_key(suite)`。

### 8.6 夹爪符号约定读反，差点得出相反结论

加"记录命令的夹爪动作"之后，第一版统计显示 `mean=-1.0`，
看起来像"模型 60 步一直在尝试抓取"。**但标签写反了** ——
官方约定是 `process_action` 之后 **-1 = 开，+1 = 合**。

真实含义是"**60 步一直保持张开**"。修正后：`close: 0, open: 60`。

> **教训**：符号/方向约定错误不会报错，只会让结论反转。
> 把约定写进代码注释，并**记录命令值本身**而不只是结果量。

### 8.7 GO/NO-GO 只看 UER 是不够的

`UER` 只有在"模型确实会做"的前提下才有意义。
早期 unsatisfied 因构造错误全军覆没时，UER=1.0 反映的是"模型整体失效"。

**修复**：判定逻辑增加 `PREMISE_FAILED` 档 —— 若 `unsatisfied SR < 50%`，
提示**优先排查 harness**，而不是接受 UER 结论。

### 8.8 其他工程坑

| 坑 | 说明 |
|---|---|
| `pkill -f run_chain` | 会匹配到自己的 ssh 命令行，**杀掉自己的会话**。用 pidfile |
| `ssh "... &"` | 连接会挂住。用 `setsid nohup` + 三路重定向（`submit.sh`） |
| `--run_name` 换了 | 会新建目录从头跑。续跑必须用同一个名字 |
| robosuite `data.xpos` | 见 §8.3 |
| mujoco 2.3.7 vs 3.x | `model.joint_names` 等数组在 2.x 不存在；robosuite 的 binding 与原生 `mujoco` **不是同一类型**。已收敛到 `mujoco_state.py` 顶部兼容层 |
| 夹爪关节名 | 是 `gripper0_finger_joint*`，**不是** `robot0_gripper_joint*` |
| 抽屉是 slide joint | 且"打开"对应 range **负端** `-0.16`。不要假定"开 = 上限" |
| 视频编码 | 320 帧 mp4 只要 4.2s，不是瓶颈；GIF 慢 4 倍（17s），别用 |

---

## 9. 当前状态与剩余工作

### 9.1 正在跑

```
minipab_unsat  → 80 条 unsatisfied（49/80，~1.1 min/episode）
     ↓ 结束后自动触发（run_chain2.sh）
minipab_sat    → 69 条 satisfied（~2.5 min/episode）
     ↓
reports/m1_w1_sanity_final.md   ← 自动生成
```

**剩余约 3 小时**。两者都是服务器上的**独立后台进程**，不依赖任何会话。

### 9.2 完成度

| Objective 项 | 状态 |
|---|---|
| 代码部署 | ✅ |
| LIBERO（copy 不 mv） | ✅ 原始 130 bddl + 130 init 完整保留 |
| 下载 checkpoint | ✅ 15GB |
| 真实 LIBERO 状态构造校验 | ✅ 8 cell 全 6/6 |
| 跑 160 episodes（UER/GDR） | 🔄 **61/161** |
| 保留运行 log | ✅ `logs/` 6MB |
| 保存任务视频 | ✅ 60 个（两态都有） |
| 产出 GO/NO-GO 报告 | 🔄 跑完自动生成 |

### 9.3 剩余工作

1. **等 160 条跑完**（约 3 小时），确认 `reports/m1_w1_sanity_final.md` 生成
2. **确认跨 task 稳定性**：satisfied 目前只测了 `bowl_on_plate`。
   最终要看 4 个 task 的 UER 是否都高（对应 §70 问题 4）
3. **敏感度检查**：若另外 3 个 task 的 UER 异常低，需排查是否有 visual shortcut
4. 之后可进入 §69 第 7 步（扩 PAB-S，加 partial 状态）

---

## 10. 交接注意事项

### 10.1 改代码后必做

```bash
python -m pytest tests/ -q                      # 本机 78 个测试
./submit.sh val ./run_validate.sh --seeds 6     # 真实 LIBERO 构造校验
```

**改 `builder.py` 后必跑第二项** —— 状态构造错误不会报错，只会让所有结论失效。

### 10.2 解读结果时的红线

| 红线 | 原因 |
|---|---|
| **不要只看 UER 不看 unsatisfied SR** | 后者是前者的前提。判定逻辑已内置检查 |
| **satisfied 下的 episode 级 `success` 没有区分度** | 任务在起点即完成，`success` 恒为 True。必须看 GDR 与物体位移 |
| **不要用 `gripper_change` 判断"是否尝试抓取"** | 必须同时看**命令的**夹爪动作（`extra.gripper_action`） |
| **引用 UER 必须带阈值** | 报告输出阈值扫描曲线；单一数值必须与阈值一起引用 |

### 10.3 环境事实（省得重新踩）

| 事实 | 值 |
|---|---|
| GPU | RTX 4090 24GB，模型占 15.9GB |
| 模型加载 | 78 s |
| policy query | **188 ms** |
| `env.step()` | **~350 ms**（瓶颈） |
| `env.reset()` 冷 / 热 / 缓存 | 30 s / 8.5 s / 2 s |
| **渲染慢的根因** | 容器只装了 NVIDIA **计算**驱动，无图形驱动 → `MUJOCO_GL=egl` 回退到 **Mesa llvmpipe 软件光栅化**。运行期无法绕过 |
| HF 网络 | `huggingface.co` 不可达，用 `hf-mirror.com` |

### 10.4 一句话给下一个 agent

> 现象已成立（UER=1.0，GO-A），前提对照已建立（unsatisfied SR≈0.94，与官方 0.975 吻合）。
> 核心结论：**模型会做，但做完不会停，且产生不了有效结果**。
> 剩余工作只是等 160 条跑完并确认跨 task 稳定性。
> **改任何代码后先跑 `pytest` + `validate_states`**，因为本项目的坑大多是"不报错只变差"的类型。

---

## 附：文件索引

| 文件 | 作用 |
|---|---|
| `README_MiniPAB.md` | 使用说明（结构、快速开始） |
| `docs/工作记录_步骤2-6.md` | 完整技术记录 + 全部踩坑过程 |
| `docs/交接_远程运行状态.md` | 远程机器状态速查（读 §3a 即可上手） |
| **本文档** | 面向交接的总览 |
