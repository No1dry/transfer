# Mini-PAB 运行环境配置（服务器专用）
# 用法: source /HUBU-AI004/zp/ICML/env.sh

export ICML_ROOT=/HUBU-AI004/zp/ICML
export OPENVLA_OFT_ROOT=/HUBU-AI004/lgm/openvla-oft
export LIBERO_ROOT=$ICML_ROOT/LIBERO
export CKPT=$ICML_ROOT/checkpoints/openvla-7b-oft-libero-sog10

export PYTHONPATH=$OPENVLA_OFT_ROOT:$LIBERO_ROOT:$ICML_ROOT
export MUJOCO_GL=egl
export PYOPENGL_PLATFORM=egl
export TF_CPP_MIN_LOG_LEVEL=3
export TOKENIZERS_PARALLELISM=false
# 服务器访问不了 huggingface.co，走镜像
export HF_ENDPOINT=https://hf-mirror.com

export PY=/root/miniconda3/envs/vla_lgm/bin/python
