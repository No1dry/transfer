# 00 — Stage 0：环境与基线冻结

> plan1 §6。本文件在实验开始前写定，作为后续一切数字的参照系。

生成方式（可复跑）：

```bash
./run_diag.sh scripts/plan1_env_report.py --hash
```

---

## 1. 硬件与系统

| 项 | 值 |
|---|---|
| 主机名 | `1k19deebm5pdo-0` |
| 平台 | Linux-5.15.0-60-generic-x86_64-with-glibc2.36 |
| CPU | 128 核 |
| 内存 | 754 GB |
| GPU | NVIDIA GeForce RTX 4090, 24564 MiB |
| 驱动 | 550.100 |
| CUDA | 12.4 |
| 冻结时刻 GPU 占用 | 2 MiB（空闲） |

冻结时无本项目作业在跑；只有系统自带的 jupyter-lab（PID 26），不占 GPU。

## 2. 软件版本

| 组件 | 版本 |
|---|---|
| Python | 3.10.20 |
| torch | 2.4.1+cu121 |
| transformers | 4.40.1 |
| numpy | 1.24.4 |
| **mujoco** | **2.3.7** |
| robosuite | 1.4.1 |
| LIBERO | `/HUBU-AI004/zp/ICML/LIBERO` git `8f1084e` |
| imageio | 2.37.3 |
| Pillow | 12.2.0 |

> mujoco 是 **2.x 而不是 3.x** —— 这决定了 `benchmark/states/mujoco_state.py`
> 里那套 2.x/3.x 兼容层是必需的，不能删。

## 3. Checkpoint

路径：`/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10`

| 文件 | 大小 |
|---|---|
| `model-00001-of-00004.safetensors` | 4925.1 MB |
| `model-00002-of-00004.safetensors` | 4947.4 MB |
| `model-00003-of-00004.safetensors` | 4947.4 MB |
| `model-00004-of-00004.safetensors` | 262.7 MB |
| `action_head--300000_checkpoint.pt` | 302.2 MB |
| `proprio_projector--300000_checkpoint.pt` | 67.3 MB |

### dataset_statistics.json 的 key（共 4 个）

```
libero_spatial_no_noops
libero_object_no_noops
libero_goal_no_noops
libero_10_no_noops
```

**关键点**：checkpoint 里只有 `*_no_noops` 后缀的 key。
代码里传的是 `libero_goal` 这种 suite 名，靠
`OpenVLAOFTAdapter._resolve_unnorm_key()` 自动补 `_no_noops` 后缀，
补不上就抛 `KeyError`（不会静默用错统计量）。

这与 plan1 §0 的判断一致：**当前 checkpoint 用的是 `*_no_noops` 数据**，
所以"没有 no-op 动作"这件事本身就有数据层面的解释，不能直接当成
"模型不会停"的因果证据。

> 目录里堆积了大量 `config.json.back.*` 备份（约 45 个），是 openvla-oft
> 加载时自动生成的，无功能影响。**未删除**（§3 禁止删除历史产物）。

## 4. 基线产物计数

| 目录 | per-episode JSON | 视频 |
|---|---:|---:|
| `results/m1/final` | 160（+manifest/metrics） | 160 |
| `results/m1/final_v1` | 160 | 71 |
| `results/m1/fixed_action_v1` | 21 | 21 |
| `results/m1/control_A` | **0** | 20 |
| `results/m1/control_B` | **0** | 10 |
| `results/m1/smoke_video_default` | 1 | 1 |

`results/m1/final/metrics.json` 摘要（Stage 0 冻结值）：

```
n_records   = 160
n_usable    = 160
n_dropped   = 0
uer         = 1.0000  [1.0, 1.0]  n=80
gdr         = 0.0250  [0.0, 0.0625]  n=80
thresholds  = {eef 0.01m, gripper 0.2, object 0.01m}
```

## 5. 核心文件 SHA256

### Stage 0 冻结时（v1 终点）

```
0986d94fb2ad807537052284c5f17fc85faa97e76aa795fa413c0cdf4ff40e56  benchmark/metrics.py
d1ebd1211b18a0341b8a31de4575589ba149e9a96342a80a0975c89dd55ea0a3  benchmark/runner.py
d8d40668eb1b2f61cba0d9916d6533e2188ed0ab9b1826ed1035c95e998c667d  benchmark/arena/libero.py
0fec6a055a0ec1e19884b767798ae973d1e198f05f4f32897452cf209a0fe3d8  benchmark/arena/mock.py
```

原文件已备份到 `results/plan1/_pre_stage1_backup/`，
哈希清单：`results/plan1/pre_stage1_sha256.txt`（满足 §5.6）。

### Stage 1 改动后

```
ee9b2db812d8318901a9dfd0de1fba0a4b1f9b3e5de3b0b7e0a04e29d6f5c1f7  benchmark/metrics.py
e917220975d18cf6a06f16c1487f97a8d5347a2451ab6b48adaf5b81e21ee3f9  benchmark/runner.py
d9a6635568302bc0b3932450e181ebe68f213246d5d52dcb3d0111ce12129ed6  benchmark/arena/libero.py
ec7417f27ec2d3225e19bada27766d5abb6d4d73e76c00ff5982c595fda68607  benchmark/arena/mock.py
```

改动内容见 `decisions.md` 与 `01_metric_audit.md`。

## 6. 测试与 smoke

| 检查 | 结果 |
|---|---|
| `python -m pytest tests/ -q`（本地，Stage 0） | **78 passed** |
| `python -m compileall -q benchmark scripts tests` | OK |
| 远端 predicate smoke（`validate_states.py --seeds 4`） | 见下 |

远端 smoke（不加载 7B 模型）逐任务结果：

| task | satisfied 构造 | unsatisfied 构造 | 跨 condition 机器人关节一致 |
|---|---|---|---|
| `bowl_on_plate` | 4/4 | 4/4 | True |
| `object_in_basket` | 4/4 | 4/4 | True |
| `open_middle_drawer` | 4/4 | 4/4 | True |
| `bowl_on_stove` | 见 `execution.log` | 同左 | 同左 |

产物：`results/plan1/stage0_state_validation.json`

## 7. 安全问题：明文凭据

plan1 §4 要求"密码不得写入任何文件、命令脚本或日志"。

- 仓库内**没有**任何密码明文。已有的三份交接文档只含
  `ssh root@<ip> -p <port>`（主机与端口），不含口令。
- 远端连接凭据保存在仓库之外（`/tmp/rsh.env` + askpass），
  不进入项目目录，也不会被写进 `execution.log`。
- 本文件同样不含口令。

## 8. 与 plan1 §1 的差异

plan1 §1 列出的"已确认事实"里，**有一条在本阶段被推翻**：

> "场景编辑 satisfied 的 legacy UER = 80/80 = 1.0"

这个数字本身没算错，但它是**三通道混合口径**。拆开之后
UTIR（真正干预任务的比例）只有 **0.325**。
详见 `01_metric_audit.md` —— 这是 Stage 1 最重要的产出。
