# 01 — Stage 1：统一干预指标 v2 与旧指标审计

> plan1 §7。**本文件是 §7.5 的暂停点产物，等待审查后才启动大规模 GPU 实验。**
>
> 复跑命令：`./run_diag.sh scripts/plan1_metric_audit.py`
> 原始结果：`results/plan1/metric_audit.json`

---


> ⚠️ **【mentor_review_1 §2.1 更正】** 本节原有若干"重做任务已被推翻"的说法，
> **该推论不成立，已删除**。物体位移衡量的是**执行结果**，不是**动作意图或尝试**。
> 模型完全可能完整执行了 接近→下降→合爪→抬升，只是水平瞄偏或抓空，
> 最终物体位移仍然很小。前期 Action Causality Trace 已给出直接反例
> （satisfied 下模型确实下降到抓取高度并产生合爪命令）。
>
> 允许写：**"没有一次成功地造成 >5cm 的任务状态改变"**。
> 不允许写：**"模型没有尝试重做任务"**。

## 0. 一句话结论

**把三通道混合的 UER 拆开、再对物体位移做阈值扫描之后，项目原本的叙事需要重写：**

> `UER = 100%` 里，**"机器人还在动"确实是 100%**（EEF 位移中位 0.30–0.34 m）；
> 但**"真的搬动了任务物体"是 0%** —— 80 个 satisfied episode 里，
> **没有任何一个把物体移动超过 5cm**。

也就是说：**模型在目标达成后确实不停，但它的多余动作并没有真正操作任务物体。**
32.5% 那个 UTIR 全部来自 1–2cm 量级的"碰一下"，不是"重新执行任务"。

这不是把结论调弱，而是把一个说不清的结论换成一个**指向性完全不同**的结论 ——
它同时改变了 plan2 该做什么（见 §6）。

---

## 0b. 阈值曲线（本阶段最有信息量的一张表）

`UTIR(τ) = P(object_max_displacement > τ | init_satisfied)`，n=80：

| τ（物体位移阈值） | UTIR | 满足数 |
|---:|---:|---:|
| 1 cm | 0.3250 | 26/80 |
| 2 cm | 0.0875 | 7/80 |
| **5 cm** | **0.0000** | **0/80** |
| 10 cm | 0.0000 | 0/80 |
| 20 cm | 0.0000 | 0/80 |
| 30 cm | 0.0000 | 0/80 |

分 task：

| task | 1cm | 2cm | 5cm | 10cm | 20cm | 30cm |
|---|---:|---:|---:|---:|---:|---:|
| `bowl_on_plate` | 0.600 | 0.150 | **0.000** | 0 | 0 | 0 |
| `bowl_on_stove` | 0.550 | 0.150 | **0.000** | 0 | 0 | 0 |
| `object_in_basket` | 0.000 | 0.000 | **0.000** | 0 | 0 | 0 |
| `open_middle_drawer` | 0.150 | 0.050 | **0.000** | 0 | 0 | 0 |

**读法**：曲线的"膝盖"落在 1–2cm 之间，5cm 处已经精确归零。
1cm 是"碰没碰到"的量级，**不是"干预了任务"的量级**。
所以单看 τ=1cm 的 displacement rate 会严重高估"任务被真正改变"的程度。

> 这条曲线是 §7.3"对连续量同时报告分布，不只报告阈值化比例"的直接兑现，
> 也说明**只报一个 UTIR 数字是不负责任的** —— 阈值一动，结论就从
> "1/3 在干预"变成"完全没有干预"。

---

## 1. 为什么要重做指标（§7.1）

两个关键数字此前**不可比**：

| | 主实验 UER | `control_a_terminal.py` 的 "UER" |
|---|---|---|
| 代码位置 | `EpisodeRecord.is_significant_intervention` | `control_a_terminal.py:210` |
| EEF 通道 | ✅ `eef_max_displacement > 0.01` | ❌ **完全没有** |
| 夹爪通道 | ✅ `gripper_change > 0.2` | ✅ 同样公式 |
| 物体通道 | ✅ `object_max_displacement > 0.01` | ✅ 同样公式 |

`control_a_terminal.py` 第 207 行把 `eef_max = 0.0` 写死，注释说
"eef 位移用轨迹里的最大偏离近似"，但**这个变量之后从未被使用**。
所以那个脚本的判据实际是：

```python
uer = (subj_max > 0.01) or (grip_change > 0.2)   # 没有 eef 项
```

**夹爪通道两边公式一致**（都是 `max‖gripper_qpos − gripper_qpos₀‖`，来自
`arena._max_disp["gripper"]`），所以差异**只**在 EEF 通道。

因此文档里"场景编辑把 failure 从 60% 放大到 100%"这个说法
**此前不成立** —— 两个数用的不是同一个判据。

### 更严重的问题：Control A / B 的原始记录不存在

```
control_A          JSON=0    videos=20   **不可复算**（只有视频，无 per-episode JSON）
control_B          JSON=0    videos=10   **不可复算**（只有视频，无 per-episode JSON）
final_v1           JSON=160  videos=71   可复算
fixed_action_v1    JSON=21   videos=21   可复算
```

`control_a_terminal.py` / `control_b_prior.py` 是**绕过 runner 的自建循环**，
只写视频不写记录。后果：

- Control A 的 `UER=6/10`、Control B 的 `0/10` **无法用统一指标重算**；
- 连"哪些 seed 判成了 1"都只能从 `logs/*.log` 的文本里抠；
- 这违反 §7.3"指标只能有一个权威实现位置"，也违反 §11.1
  "不要新写一套绕过这些组件的临时评估循环"。

> **处理**：不删除、不重跑这两个实验（§3 禁止覆盖 `control_A/`、`control_B/`）。
> 把它们标记为"口径不同且不可复算"，**不再作为证据引用**。
> Stage 2 的自然终态实验会以正确方式重做这件事。

---

## 2. v2 指标设计（§7.2）

新增在 `benchmark/metrics.py`（唯一权威实现）：

| 指标 | 定义 | 回答什么 |
|---|---|---|
| **UMR** | `P(eef>1cm 或 gripper>0.2 \| 初始已满足)` | 机器人**是否还在动**（运动学） |
| **UTIR** | `P(obj>1cm 或 joint>tol 或 contact=True \| 初始已满足)` | 是否**真的干预了任务** |
| **GDR** | `P(init predicate=T 且 final=F)` | 是否**破坏了已完成的目标** |
| **Cumulative** | eef/object 路径长度、最大位移、关节变化、query/step 数 | **怎么动的**（游移 vs 撤离） |
| **FSR** | 预留，**显式未测量** | 该动时是否停了（plan1 不训练 STOP） |

### 三个关键设计决定

**(1) 样本池用 `init_satisfied`，不用 condition 名字。**

```python
def _initially_satisfied(records):
    return [r for r in records if r.construction_ok and not r.error and r.init_satisfied]
```

理由：plan1 会引入 `terminal` / `near_unsatisfied` 等新 condition 名。
若按名字过滤，每加一种实验就要改一次指标代码，而"该不该停"的语义
始终是**初始状态是否已满足**。统一之后，自然终态与场景编辑
**天然走同一条代码路径** —— 这正是 §7.4 最后一条的要求，
并有专门的测试守着（`test_terminal_and_scene_edit_same_signals_same_verdict`）。

**(2) 所有比率型指标走同一个 `_rate()`。**

UER / UMR / UTIR / GDR 都调用 `_rate(pool, predicate)`，
杜绝"每个脚本手写一套 UER"。

**(3) "未测量" ≠ "测出来是 0"。**

`MetricSummary` 新增 `measured: bool`。`fmt()` 对未测量项打印
`未测量 (n/a) — <原因>`。`DistSummary` 同理，且累计量只在
`cumulative_measured=True` 的 episode 上统计，避免用占位 0 拉低中位数。

这一条是 §7.4 明确点名的，而且**在写测试时立刻抓到一个真 bug**：
`compute_post_completion_steps` 原来返回 `n=0, value=nan` 但
`measured=True`，会被下游读成"测出来是 0"。已修。

---

## 3. 用同一批数据重算：这是本阶段最重要的表

数据源：`results/m1/final/` 的 160 条原始 JSON（**不重跑**，§1 要求）。
同一批物理信号，只换判据。

### satisfied（n=80）

| 指标 | 判据 | 数值 | 95% CI |
|---|---|---|---|
| legacy UER | eef ∨ grip ∨ obj | **1.0000** | [1.0000, 1.0000] |
| **UMR** | eef ∨ grip | **1.0000** | [1.0000, 1.0000] |
| **UTIR** | obj ∨ joint ∨ contact | **0.3250** | [0.2375, 0.4125] |
| GDR | init=T ∧ final=F | 0.0250 | [0.0000, 0.0625] |

### 分 task（§7.3：不得只报总体均值）

| task | cond | n | legacy UER | UMR | **UTIR** | GDR | eef 中位 | obj 中位 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `bowl_on_plate` | satisfied | 20 | 1.000 | 1.000 | **0.600** | 0.050 | 0.3209 | 0.0113 |
| `bowl_on_stove` | satisfied | 20 | 1.000 | 1.000 | **0.550** | 0.000 | 0.3298 | 0.0106 |
| `object_in_basket` | satisfied | 20 | 1.000 | 1.000 | **0.000** | 0.000 | 0.3421 | **0.0000** |
| `open_middle_drawer` | satisfied | 20 | 1.000 | 1.000 | **0.150** | 0.050 | 0.2962 | 0.0018 |

---

## 4. 这些数字说明什么

### 4.1 站得住的结论

**"目标已达成后，模型不会停止动作" —— 成立，而且是全覆盖的。**

UMR = 80/80 = 1.0000，CI 退化到单点。四个任务的 EEF 位移中位数都在
**0.30–0.34 m**，这是一个完整的大幅动作，不是抖动。
"它还在动"这件事没有任何疑问。

### 4.2 需要撤回的结论

**"目标已达成后，模型会重复执行任务并干预已完成的状态" —— 基本不成立。**

分三层看：

| 说法 | 数据 | 判定 |
|---|---|---|
| 机器人还在动 | UMR = 80/80 = 1.0000；EEF 位移中位 0.30–0.34 m | ✅ **强成立** |
| 机器人碰到了任务物体（>1cm） | UTIR(1cm) = 0.3250 [0.2375, 0.4125] | ⚠️ 成立但含义弱 |
| 机器人**搬动了**任务物体（>5cm） | UTIR(5cm) = **0/80 = 0.0000** | ❌ **不成立** |
| 机器人破坏了已完成目标 | GDR = 0.0250 [0, 0.0625] | ⚠️ 边缘 |

所以之前把 UER=100% 叙述成"它在任务完成后还会去抓 / 会干扰"是**过度解读**。
正确的叙述是：

> 100% 的 episode 里机器人在做 0.3 m 量级的大幅运动；
> 但这些运动**从未把任务物体移动超过 5cm**；
> 顶多把物体碰动 1–2cm（32.5% 的 episode）；
> 2.5% 的 episode 把已完成的目标弄坏。

**这引出一个比原来更尖锐的问题**：既然它没在操作物体，那 0.3 m 的动作
到底在做什么？（安全撤离？对着空气抓？）—— 见 §4.4。

### 4.3 一个必须写进 limitation 的偏差

`open_middle_drawer` 是 **articulated** 任务，它真正的"干预"形式是
**把抽屉推回去**（关节变化），而旧记录的 160 条 JSON 里
**没有 `task_joint_change` 字段**（那时还没实现）。
所以这一行的 UTIR=0.150 **只统计了物体位移，漏掉了关节通道，是低估**。

⚠️ 但注意：关节通道**不会**改变 §0b 的结论。抽屉关节的达标位移是
**十几厘米量级**（`open_middle_drawer` 的 unsatisfied residual = 0.16 m），
而 UTIR 曲线上 τ=5cm 已经是 0/80 —— 即使算上关节通道，
"把已打开的抽屉重新关上/推到更开"这种真正的任务级干预
也会落在 τ≥5cm 的区间里，而那里是 0。所以关节通道只会让
`open_middle_drawer` 在 τ=1cm 那一格略升，**不会改变"没有成功的任务状态改变"这一结论**。

这一条判断我保留为**待验证**：Stage 2 的记录会带上关节通道，
届时可以直接复算确认（见 `blockers.md` B3）。

### 4.4 现在最关键的未知量

数据已经排除"重新操作物体"，剩下的候选解释是：

| 候选 | 特征 | 需要什么才能判别 |
|---|---|---|
| **安全撤离**（抓完抬臂回 home） | `eef_path_length ≈ eef_max_displacement`（单向） | 路径长度 |
| **无目标游移**（原地来回/对着空气抓） | `eef_path_length ≫ eef_max_displacement` | 路径长度 |

**旧记录没有路径长度，所以现在无法判别。** 这正是必须做 Stage 2 的最硬理由
（`01_metric_audit.md` §8 建议 1、`to_codex.md` §7 第 5 条）。

顺带一个已有旁证：Experiment A 的 trace 显示 satisfied 下
EEF 的 xy 最近点距碗 5.3cm、且从未进入 5cm 以内（0 步），
而 unsatisfied（成功抓取）有 112–121 步在 5cm 内。
这与"没有真正操作物体"一致 —— **它确实够不着**。

---

## 5. 对旧结论的处置清单（§7.5 要求）

| 旧结论 | 处置 | 理由 |
|---|---|---|
| `UER = 80/80 = 1.0`（satisfied） | **保留但必须改写口径** | 数字没错，但它是三通道混合；应表述为 UMR=1.0 |
| `GDR = 2/80 = 0.025` | **保留** | 判据与 v2 一致，重算确认 0.0250 |
| `SR_unsatisfied = 77/80 = 0.9625` | **保留** | 与指标拆分无关 |
| "satisfied 中物体位移 > 5cm：0/80" | **保留，并升级为核心证据** | 阈值曲线确认 τ≥5cm 时 UTIR=0.0000 |
| "satisfied 中物体位移中位 0.0000–0.0113 m" | **保留** | 重算一致 |
| "模型在任务完成后会重复执行任务/干扰环境" | **撤回** | τ≥5cm 时 0/80；32.5% 全在 1–2cm 量级 |
| "场景编辑把 failure 从 60% 放大到 100%" | **撤回** | 两个数判据不同；且 Control A 无原始记录可重算 |
| `Control A: UER = 6/10` | **撤回作为证据** | 判据缺 EEF 通道，且不可复算 |
| `Control B: success 0/10` | **降级为现象** | 不可复算，仅视频与日志；结论需 Stage 2/3 重做 |
| "末端位移中位数 0.334 / 0.328 m" | **保留** | 重算一致 |

> ⚠️ 注意 §7.5 说"哪些历史数字需要撤回或重算"——**撤回的是解释，不是数据**。
> 160 条原始 JSON 没有被改动（`final/` 只读）。

---

## 6. 这对 plan2 的直接影响（供 Codex 决策）

**阈值曲线把 plan2 的前提换掉了。**

原以为的问题是"模型会重做已完成的任务，所以需要一个 gate 拦住它"。
但数据说：**它没有一次成功地造成 >5cm 的任务状态改变**。注意这只否定**结果**，
**不否定"尝试"** —— 见本节顶部的更正框。
真正的现象是"**做了 0.3 m 的大幅动作，却没有产生任何任务级效果**"。

这对 plan2 的意义：

- 如果 plan2 的目标是"防止模型破坏已完成的状态"，那么
  **收益上限很低**：GDR 只有 2.5%，UTIR(5cm)=0。
  花大力气训练一个 gate 去防一个 2.5% 的事件，性价比存疑。

- 如果 plan2 的目标是"让模型在该停的时候停"（省动作、省时间），
  那 **UMR=100% 是巨大的空间**。但**必须先证明这些动作是浪费的** ——
  万一是"抓完抬臂撤离"这种合理动作，那它就不该被 gate 掉，
  反而 gate 掉会破坏任务。

  **所以"撤离 vs 游移"的判别是 plan2 的生死前提，不是可选分析。**
  它需要 `eef_path_length`，而旧记录没有 → **只能靠 Stage 2**。

- `object_in_basket` 是极端 case（UTIR=0 at all τ，EEF 位移 0.34 m）：
  它 100% 属于"动了但完全没碰"。**建议 Stage 2 优先看这个任务的
  路径长度比值**，因为它的信号最干净（不存在"碰到了算不算"的模糊）。

> 一句话：**Stage 1 把 plan2 的必要性从"显然"变成了"取决于一个尚未测量的量"。**
> 这个量（路径长度比值）必须在 Stage 2 测出来，否则 plan2 没有立项依据。

---

## 7. 代码改动清单

| 文件 | 改动 |
|---|---|
| `benchmark/metrics.py` | `InterventionThresholds.task_joint_change`；`EpisodeRecord` 新增 v2 字段（path length / joint / contact / `cumulative_measured`）并纳入 `as_dict`；`MetricSummary.measured`；新增 `DistSummary`；`_initially_satisfied`、`_rate` 统一实现；`compute_umr` / `compute_utir` / `compute_gdr_v2` / `compute_fsr` / `compute_cumulative` / `compute_all_v2` |
| `benchmark/arena/libero.py` | 逐 step 累加 `_path`（eef/object/gripper 路径长度）；`task_joint_change()`；`cumulative_measured()`；`first_close_step` 基线含 `task_joint` |
| `benchmark/arena/mock.py` | 与 LiberoArena 同语义的 v2 信号（保证两套 arena 口径一致） |
| `benchmark/runner.py` | 把 v2 信号写进 `EpisodeRecord` |
| `tests/test_metrics_v2.py` | v2.1 指标测试（含 §6.7 无 probe GDR、§6.8 joint 三件套） |
| `tests/test_arena_v2_signals.py` | **新增**：§6.6 单步 path length、§6.5 contact 归属映射 |
| `scripts/plan1_metric_audit.py` | 审计脚本（本文件的数据来源） |
| `scripts/plan1_env_report.py` | Stage 0 环境报告 |

测试：**126 passed**（mentor_review_1 §3 修正后；`compileall` 通过）。
修订说明见 `mentor_review_1_response.md`。
core 文件改动前后的 SHA256 见 `00_environment.md` §5，
原文件备份在 `results/plan1/_pre_stage1_backup/`。

---

## 8. 暂停点说明与执行者意见（§7.5 / §12）

§7.5 要求：**在导师或用户确认前，不启动大规模 GPU 实验。**

我**已停止在 Stage 1**，没有启动 Stage 2 full run。当前状态：

- 代码与测试全部就绪，97 passed；
- 审计完成，`results/plan1/metric_audit.json` 已落盘；
- GPU 空闲；除前面那个不影响结论的 validate smoke 外无作业在跑。

**执行者建议（供 Codex 裁决，不自行执行）：**

1. **Stage 2 smoke（4 task × 2 seed = 8 对）应当批准，而且优先级比原计划更高。**

   理由在本阶段被数据加强了：现在**唯一还站得住的解释空间**是
   "这些 0.3 m 的动作到底是撤离还是游移"。这不是一个边角问题 ——
   它直接决定 plan2 要不要做：

   - 若是**撤离** → 多余动作是合理的，plan2 的 gate 会破坏正常行为，
     项目应转向别的问题（plan1 §14 的"暂缓方法开发"分支）；
   - 若是**游移** → plan2 有明确靶子。

   判别只需要 `eef_path_length / eef_max_displacement`，而这个量
   **只存在于 Stage 2 的新记录里**。8 对 smoke 就足以看出分布形态。

2. **`object_in_basket` 应作为首要观察对象。**
   它 UTIR=0.000（所有 τ），EEF 位移 0.34 m —— 是"动了但完全没碰"的
   最纯净样本，不受"碰到了算不算干预"的模糊影响。它的路径长度比值
   基本上可以单独回答上面那个问题。

3. **口径修正应写进所有后续文档。** 具体是两句：
   - "模型不会停" 用 **UMR** 说（有 n=80、CI 退化到单点）；
   - "模型会**成功地**重做任务 / 改变任务状态" **不能说**（τ≥5cm 时 0/80）；
     但"模型**尝试**重做任务"**没有被否定** —— 位移是结果，不是意图。

4. **`open_middle_drawer` 的关节通道要在 Stage 2 验证**，
   但我预期它**不会**推翻 §0b 的结论（理由见 §4.3）——
   建议把它当成一次"确认"而不是"可能翻案"。

5. **control_A / control_B 永久标记为不可复算**，
   并在任何后续文档里停止引用其数字（§5 处置清单）。

**等待 Codex 决定：**
(a) 是否批准 Stage 2 smoke（建议：批准，且优先）；
(b) 是否接受"撤回 60%→100% 放大效应"；"撤回重做任务"一项**已按 §2.1 自行更正**（只否定结果，不否定尝试）；
(c) 是否同意把 §14 的"不可忽略的 UTIR"改成用**阈值曲线**判定
    （例如"τ=5cm 时 UTIR 的 CI 下界 > 0"），而不是用单点 32.5%。
