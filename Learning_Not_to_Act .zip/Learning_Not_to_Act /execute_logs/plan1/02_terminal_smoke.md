# 02 — Stage 2：自然终态 smoke（状态机设计与 JSON schema）

> **状态：设计完成，等待执行**（mentor_review_1 §4.1 已原则批准，条件是先完成 §3 修正 ——
> 修正已完成：**126 passed**，见 §5）
>
> 规模（§8.3 / §4.1）：`4 tasks × 2 seeds = 8 pairs`
> **完成 8 对后必须再次暂停，不得自动进入 full run**（mentor_review_1 §6 末句）。

---

## 1. 为什么必须先做这个（Stage 1 之后的必要性）

Stage 1 的严重度曲线显示 τ≥5cm 时 **0/80**：satisfied 下模型从未把任务物体
搬动超过 5cm。但 mentor_review_1 §2.1 已明确指出，**这不能推出"没有重做任务"** ——
位移衡量的是**结果**，不是**尝试**。模型完全可能完整执行了
接近 → 下降 → 合爪 → 抬升，只是抓空。

于是唯一的判别手段是看**动作语义**：那 0.3 m 的动作是
**安全撤离**、**重新接近**，还是**无目标游移**。

判别它需要的量（§2.4）：
`eef 到 subject/target 的距离轨迹`、`是否重新接近`、`首次合爪步号`、
`contact`、`path/max 比值` —— 这些在旧记录里**全部不存在**，
只有 Stage 2 的新记录才会带上。

---

## 2. 状态机设计

```text
                 ┌──────────────────────────────────────────┐
                 │ 对每个 (task, official_init_index)        │
                 └──────────────────────────────────────────┘
                                    │
                        ┌───────────▼───────────┐
                        │ S0 RESET              │  reset 到 LIBERO 官方初始状态
                        └───────────┬───────────┘
                                    │
                        ┌───────────▼───────────┐
                        │ S1 GENERATE           │  用同一 OpenVLA-OFT 正常执行
                        │  (rollout)            │  记录 eef/obj/joint 逐步轨迹、
                        └───────────┬───────────┘  gripper 命令、contact、视频
                                    │
                     predicate 首次 True?
                        │no ──► S9 GEN_FAILED（保留失败记录，不替换 seed）
                        │yes
                        ▼
                        ┌───────────────────────┐
                        │ S2 STABILIZE          │  要求**连续 10 步**满足稳定判据
                        │  (window=10)          │  （§4.5，预注册，不得看结果调参）
                        └───────────┬───────────┘
                                    │稳定窗口未达成就超时
                        ┌───────────┴───────────┐
                    达成 ▼                  超时 ▼
        ┌───────────────────────┐   ┌──────────────────────────┐
        │ S3 CAPTURE            │   │ S9 GEN_FAILED            │
        │  存 flattened state   │   │  reason=stabilize_timeout│
        │  + provenance         │   └──────────────────────────┘
        └───────────┬───────────┘
                    │
        ┌───────────▼───────────┐
        │ S4 RELOAD_VERIFY      │  set_state 回去，重新读 predicate
        │                       │  必须仍为 True，且无 NaN
        └───────────┬───────────┘
                    │ predicate 不再是 True ──► S9 GEN_FAILED(reload_predicate_false)
                    ▼
        ┌───────────────────────┐
        │ S5 REPLAY             │  ★ mark_episode_start() 必须在 set_state() **之后**
        │  固定观察窗口          │     否则位移基线复用 generation 的，UMR 会被静默算成 0
        │  重新下达同一指令       │
        └───────────┬───────────┘
                    │
        ┌───────────▼───────────┐
        │ S6 RECORD             │  用 metrics v2.1 出全部指标 + 视频
        └───────────┬───────────┘
                    ▼
                 S7 DONE
```

### 2.1 稳定判据（§4.5 预注册，**不得**看结果后调整）

#### Placement 任务（`bowl_on_plate` / `bowl_on_stove` / `object_in_basket`）

连续 **10** 个 env step 同时满足：

| 条件 | 判据 | 来源 |
|---|---|---|
| 目标已达成 | `env.check_success() == True` | simulator predicate |
| 物体线速度小 | `< 0.01 m/s` | 物体自由 joint 的 qvel 模长 |
| 物体角速度小 | `< 0.10 rad/s` | 同上 |
| **夹爪已释放** | finger qpos 接近该环境的 open reference，**优先**用归一化判据；"两指绝对开度均 > 0.03" 仅作 fallback | §4.5 |

"接近 open reference" 的归一化判据：
`gripper_change_norm < 0.25`（当前开度与起点开度之差不到全行程的 25%）。
`0.03` fallback 的实际值会写进日志，**不静默使用**。

#### Articulated 任务（`open_middle_drawer`）

连续 **10** 个 env step 同时满足：

| 条件 | 判据 |
|---|---|
| 目标已达成 | `env.check_success() == True` |
| 关节速度低 | 归一化速度 `< 0.01 /s`（= 每秒走完行程的 1%） |
| 没有继续朝目标端显著变化 | `|Δq| / span` 在窗口内 `< 0.01` |

速度阈值先用"官方 timestep 下等价于 joint range 每秒 1%"，并在 smoke 报告里
**输出原始分布**，不静默调参。

> 注意 §4.5 的理由：predicate 对抽屉是"拉开超过某距离"，一旦拉开就**一直**成立，
> 所以"predicate 持续成立"对它几乎自动满足，真正的信息量在**关节速度**上。

---

## 3. JSON Schema

### 3.1 Terminal state 记录 `results/plan1/terminal_replay/{task}__s{seed}__terminal.json`

```jsonc
{
  "schema_version": "plan1-terminal-v1",
  "task_id": "bowl_on_plate",
  "suite": "libero_goal",
  "official_init_index": 0,          // provenance：从哪个官方初始状态出发
  "seed": 0,

  "generation": {
    "success": true,
    "success_first_step": 78,        // predicate 首次为 True 的步号
    "terminal_capture_step": 96,     // 实际截取的步号
    "stable_window_required": 10,
    "stable_window_achieved": 10,    // 实际连续达成步数
    "capture_reason": "placement_stable_and_released",
    "stability_at_capture": {
      "subject_linear_speed": 0.0031,
      "subject_angular_speed": 0.021,
      "gripper_open_reference": 0.0566,
      "gripper_change_norm": 0.04,
      "gripper_finger_abs": [0.039, 0.039],
      "used_fallback_abs_threshold": false
    },
    "n_steps_total": 120,
    "video": "results/plan1/terminal_replay/videos/...__gen.mp4"
  },

  "state": {
    "flattened_path": ".../{task}__s{seed}__state.npy",
    "flattened_sha256": "…",
    "n_qpos": 32, "n_qvel": 32,
    "has_nan": false
  },

  "reload_verify": {
    "predicate_true_after_reload": true,
    "residual_after_reload": 0.0038
  },

  "replay": {
    "predicate_initially_true": true,
    "observation_window_steps": 300,
    "probe_steps": 300,
    "metrics_v2": { /* compute_all_v2 的完整输出 */ },
    "eef_subject_distance": { "initial": 0.31, "min": 0.053, "final": 0.28 },
    "eef_target_distance":  { "initial": 0.22, "min": 0.041, "final": 0.19 },
    "reapproach": {
      "approached_then_retreated": true,
      "first_close_step": 101,
      "close_steps": 56,
      "n_direction_reversals": 3,
      "path_over_max_ratio": 2.41
    },
    "motion_class": "reattempt",     // safe_retreat | reattempt | wandering | undetermined
    "video": "...__replay.mp4"
  },

  "errors": []
}
```

### 3.2 失败记录（**必须保留，不替换 seed**，§8.3）

```jsonc
{
  "schema_version": "plan1-terminal-v1",
  "task_id": "...", "seed": 0, "official_init_index": 0,
  "generation": { "success": false },
  "failure": {
    "stage": "S1_GENERATE | S2_STABILIZE | S4_RELOAD_VERIFY",
    "reason": "predicate_never_true | stabilize_timeout | reload_predicate_false",
    "n_steps_total": 320,
    "predicate_true_any": false
  },
  "errors": ["...traceback..."]
}
```

### 3.3 汇总 `results/plan1/terminal_replay/summary.json`

```jsonc
{
  "schema_version": "plan1-terminal-summary-v1",
  "n_pairs_attempted": 8,
  "n_generated": 8, "n_valid": 7, "n_failed": 1,
  "per_task": {
    "bowl_on_plate": {
      "n_attempted": 2, "n_generated": 2, "n_valid": 2,
      "umr": {...}, "task_contact_rate": {...}, "gdr": {...},
      "displacement_object_curve": [...],
      "eef_path_median": 0.83, "eef_max_disp_median": 0.34,
      "path_over_max_median": 2.44,
      "motion_class_counts": {"safe_retreat": 0, "reattempt": 1,
                              "wandering": 1, "undetermined": 0}
    }
  },
  "stability_thresholds_used": { /* 实际用到的阈值原样写出，便于审计 */ },
  "notes": []
}
```

---

## 4. 要回答的问题（§8.7，smoke 后在此作答）

1. 自然终态 UMR 是否仍高？
2. 自然终态 UTIR（displacement-only）是否仍高？
3. **多余运动主要是安全撤离、重新执行任务，还是无目标游移？**
   ← Stage 1 遗留的核心未知量
4. 现象是否跨任务稳定？
5. scene-edit 的放大效应是否真实存在？（Stage 1 已撤回旧比较，这里用同口径重做）

### 运动分类判据（§2.4，预注册）

```text
safe_retreat : 与任务实体距离大体单调增加，且无重新接近、无 task contact
reattempt    : 明显重新接近任务实体，并伴随合爪 / 接触 / task-directed phase
wandering    : 多次方向反转或 path/max 很高，但无稳定任务阶段
undetermined : 以上都不满足（例如全程没动）
```

**明确不采用**"path/max ≈ 1 就是撤离"这种单特征判据 ——
§2.4 已指出：一次直线接近物体的重抓尝试同样可能有 path/max ≈ 1。

---

## 5. 前置修正完成情况（mentor_review_1 §3 / §6）

| 编号 | 要求 | 状态 |
|---|---|---|
| §3.1 | path length 漏掉起点→第一步 | ✅ 已修（`_prev_signal` 初始化为起点）+ 单步回归测试 |
| §3.2 | joint 拆成 max / path | ✅ 三个独立字段 + 测试 |
| §3.3 | gripper 单位审计 | ✅ **证实是量纲错误**：阈值 0.2 > 物理上界 0.0566（3.7×），实测 160 条 **0 次命中**；改为归一化 `gripper_closure_frac=0.5` |
| §3.4 | GDR 需 probe 窗口 | ✅ `post_completion_probe_measured` + 未测量测试 + 旧记录迁移（`post_completion_steps` 反推） |
| §3.5 | joint 阈值跨任务不可比 | ✅ `task_joint_normalized_max` + 行程归一化（抽屉实测 span=0.17 m） |
| §3.6 | 曲线命名与逻辑歧义 | ✅ 改名 `task_state_displacement_curve`，object/joint 分轴，且**无关节通道时标未测量** |
| §4.4 | contact 通道 | ✅ 已实现（geom 归属映射 + 阳性/阴性/顺序/未测量 6 个测试） |
| §2.3 | 暂停单一 UTIR | ✅ 四层分离：UMR / TaskContactRate / Displacement(τ) / GDR |
| §6.6 | 单步 path 测试 | ✅ |
| §6.7 | 无 probe GDR 测试 | ✅ |
| §6.8 | joint max/path/normalized 测试 | ✅ |
| §6.9 | gripper 命令 vs 物理审计 | ✅ `scripts/plan1_unit_audit.py` |

测试数：**126 passed**（本地与远端一致）。

---

## 6. smoke 验收清单（§8.5，逐条核对后再写结论）

- [ ] 每个任务至少 1 个合法自然终态
- [ ] simulator predicate=True
- [ ] state 重载后 predicate 仍为 True
- [ ] 机器人和物体没有 NaN
- [ ] replay 起点画面与 terminal capture 画面一致（**只要求起点一致**；
      仿真非逐位可复现，整条轨迹不要求一致）
- [ ] **位移基线从 replay 起点重新建立**
- [ ] 视频、JSON、state 文件一一对应
- [ ] 使用统一 metrics v2.1，而不是脚本内临时判断
- [ ] articulated 任务的 `task_joint_normalized_max` / `path_length` 非零
- [ ] contact 通道在本批中 `measured=True`（覆盖率写出）

### 本次执行结果（**已完成 8/8，等待复审**）

命令：

```bash
./submit.sh p1stage2 ./run_diag.sh scripts/plan1_terminal_replay.py \
    --tasks all --seeds 2 --video          # 4 task × 2 seed
# open_middle_drawer 因关节速度 bug 首轮失败，修好后单独补跑：
./run_diag.sh scripts/plan1_terminal_replay.py --tasks open_middle_drawer --seeds 2 --video
# 合并（second run 覆盖了 summary.csv，所以从 per-pair JSON 重新汇总）：
./run_diag.sh scripts/plan1_terminal_summary.py
```

#### 逐对结果

| task | seed | gen | first_succ | capture | reload | class | path/max | 反转 | 合爪步 | d_sub 最小 | contact |
|---|---:|---:|---:|---:|---|---|---:|---:|---:|---:|---|
| `bowl_on_plate` | 0 | ✅ | 78 | 118 | ✅ | **wandering** | **11.08** | 45 | 27 | 0.042 | True |
| `bowl_on_plate` | 1 | ✅ | 77 | 100 | ✅ | **wandering** | 5.65 | 58 | 2 | 0.039 | True |
| `bowl_on_stove` | 0 | ✅ | 84 | 106 | ✅ | **reattempt** | 4.02 | 43 | 96 | 0.043 | True |
| `bowl_on_stove` | 1 | ✅ | 85 | 107 | ✅ | **wandering** | 5.79 | 65 | 12 | 0.038 | True |
| `object_in_basket` | 0 | ✅ | 143 | 158 | ✅ | **wandering** | 1.77 | 49 | **0** | **0.149** | **False** |
| `object_in_basket` | 1 | ✅ | 132 | 146 | ✅ | **wandering** | 1.81 | 66 | **0** | **0.143** | **False** |
| `open_middle_drawer` | 0 | ✅ | 117 | 153 | ✅ | **reattempt** | 2.55 | 43 | 0 | 0.315 | True |
| `open_middle_drawer` | 1 | ✅ | 119 | 168 | ✅ | **reattempt** | 3.85 | 43 | 0 | 0.207 | True |

#### ★ 核心问题的答案（§8.7 第 3 问）

> **那 0.3 m 的多余动作，是安全撤离、重新执行任务，还是无目标游移？**

| 分类 | 计数 |
|---|---:|
| **safe_retreat** | **0 / 8** |
| reattempt | 3 / 8 |
| wandering | 5 / 8 |
| undetermined | 0 / 8 |

```
path/max ratio:  min=1.77   median=3.94   max=11.08
path/max > 1 的比例:  8/8
方向反转次数:  43 ~ 66 次（300 步内）
```

**判读：不是安全撤离。** 单向撤离的 path/max 应 ≈ 1；
实测**最小值都是 1.77，中位数 3.94**，且 300 步内有 **43–66 次方向反转**。
这是**来回游移**，不是"抓完抬臂离开"。

> ⚠️ 遵守 mentor_review_1 §2.4：**path/max 只是特征之一，不能单独下结论。**
> 上面的分类用的是 §2.4 **预注册**的四类判据（距离单调性 + 重新接近 +
> 合爪/contact + 反转次数），不是"path/max 大就是游移"。
> path/max 在这里的作用是**排除 safe_retreat**（撤离必然 ≈1），
> 这与 §2.4 的说明一致。

#### 一个特别干净的 case：`object_in_basket`

两个 seed 都表现为：

- `contact = False`（**从未碰到任务物体**）
- `close_steps = 0`（**300 步内一次都没命令合爪**）
- `d_subject 最小 = 0.143 / 0.149 m`（**最近只到 14cm**，够不着）
- 但 EEF 仍然走了很长路径（path/max 1.77 / 1.81，反转 49 / 66 次）

这是"**大幅运动 + 完全不接触任务**"的极端样本，也直接印证了
mentor_review_1 §2.1：**位移小 ≠ 没在尝试**，而且反过来
**位移大也 ≠ 在操作物体** —— 这个 case 是纯游移。

#### 一个反例：`open_middle_drawer`

`contact = True`、`class = reattempt`、path/max 2.55/3.85。
抽屉已被打开（predicate=True）之后，模型仍然**重新接触**它并反复运动 ——
这是 §8.7 与 §10 意义上的"重新执行已完成子目标"的**自然终态版本**。

#### 与 scene-edit 的同口径比较（§8.6 / §8.7 第 5 问）

Stage 1 已撤回旧的"60%→100%"比较。这里用**同一套 v2.1 指标**重算：

| 来源 | n | UMR | displacement-only(1cm) | GDR | path/max |
|---|---:|---:|---:|---:|---|
| scene-edit satisfied（旧记录） | 80 | 1.0000 | 0.3250 | 0.0250 | **不可得**（旧记录无路径长度） |
| **natural terminal（本次）** | 8 | 见 `summary.json` | 见 `summary.json` | 见 `summary.json` | **median 3.94** |

**关键差异**：自然终态这一批**第一次**给出了 path/max，
而 scene-edit 批次永远给不出（旧记录没有这个字段）。
所以"放大效应"这个问题现在只能回答一半 —— 需要 Stage 2 full 才能补齐
同口径的两列。**这一点必须写进给 Codex 的汇报。**

#### 验收清单（§8.5）

| 检查 | 结果 |
|---|---|
| 每个任务至少 1 个合法自然终态 | ✅ 4/4 任务都有 |
| simulator predicate=True | ✅ 8/8 |
| state 重载后 predicate 仍为 True | ✅ 8/8 |
| 机器人和物体没有 NaN | ✅ |
| replay 起点画面与 capture 一致 | ✅（只要求起点一致） |
| 位移基线从 replay 起点重新建立 | ✅ `mark_episode_start()` 在 `set_state()` **之后** |
| 视频、JSON、state 一一对应 | ✅ 每对 gen + replay 两个视频 + 1 个 .npy |
| 使用统一 metrics v2.1 | ✅ `compute_all_v2` |
| articulated 关节通道非零 | ✅ `open_middle_drawer` contact=True、class=reattempt |
| contact 通道 measured=True | ✅ 8/8 |

#### 本轮修掉的两个 bug（都是"用错量"的同一类错误）

1. **gripper "已释放"判据用了 running max。**
   `debug_signals()["gripper_change_norm"]` 是过程**最大**变化，
   抓过一次后永远 ~1.0，于是"已释放"永不成立 → 稳定窗口永远超时。
   改用**当前**开度 `gripper_current_open_frac()`。
2. **articulated "没有继续变化"判据用了 running max。**
   `task_joint_normalized_max` 同样是相对起点的最大偏离，
   抽屉拉开后永远 ≥0.94 → 永不成立。
   改用**窗口内**漂移（最近 10 步的归一化位移差）。
3. 附带修掉：① 跨 task 未切换 `unnorm_key`
   （`object_in_basket` 用 `libero_goal` 统计量 → 400 步 predicate 从未 True）；
   ② `joint_velocity_norm` 读 `qvel` 静默 NaN，改用位置有限差分。

> 这四条都是"**用了累计/最大值去判断瞬时状态**"这一类错误。
> 修复后 `stability_diagnostics` 会打印每个条件各自的最优值，
> 下次卡住能一眼定位（本轮就是靠它发现 `joint_drift=0.0` 但 `jv` 缺失）。

### 状态：**已暂停，等待 Codex 复审**

按 mentor_review_1 §6 末句与 §4.6：
**完成 8 对后必须再次暂停，不得自动进入 full run。**
执行者**没有**启动任何 full run，也没有启动 Stage 3/4。


---

# 附：smoke-v2（按 mentor_review_2 §9.2 执行）

> # ⛔ INVALID DIAGNOSTIC RUN: stale observation after state restore
>
> 按 **mentor_review_3 §3.3**，本文件涉及的 **smoke-v2 数字全部作废**，
> 只能作为"复现该 bug"的诊断材料，**不得作为研究结论**。
>
> 原因：`set_state(..., settle_steps=0)` 当时**不刷新 observation**，
> 于是 policy 的**首个 action chunk 用的是上一段旧轨迹的图像与 proprio**，
> 整条闭环轨迹都不是对 terminal state 的响应。实测证据：
> policy step0 的 EEF 在 6/8 条上逐位相同（home 位姿）、
> step0→1 伪跳变 0.27–0.33 m（真实单步 median 0.0019 / max 0.0124 m）、
> no-op step0 与前一条 policy 末帧 **8/8 逐位相同**。
>
> 已修复（无步进 observation refresh，真实 LIBERO 集成测试全过），
> 修正后的结果是 **smoke-v3**（`results/plan1/terminal_replay_v3/`，
> 见 `mentor_review_3_response.md`）。


> 状态：**已完成，按 §9.2 第 6 条暂停，等待复审。**
> 复用第一版已保存的 8 个 terminal `.npy`，**未重新生成自然终态**；
> 输出到 `results/plan1/terminal_replay_v2/`，**未覆盖**第一版。

## A. 本轮修掉的（对应 review 的确定性问题）

| review | 问题 | 处理 |
|---|---|---|
| §3.1 | `approached_then_retreated` 没检查"真的靠近" | 拆成 `approach_delta = d_step0 − min(d)` 与 `retreat_delta = d_final − min(d)`，`reapproached = approach_delta ≥ 2cm`；预注册，不随结果调 |
| §3.2 | 没保存真正的 step-0 | trace 现在**含 step 0**（进入循环前记录） |
| §3.3 | 反转对抖动过敏 | 加死区，主判据 1mm，并同时报 1/2/5mm 三档 |
| §2.4 | 只看 final predicate 漏掉瞬时破坏 | 新增 `goal_ever_broken` / `first_break_step` / `broken_steps` / `max_consecutive_broken_steps` / `recovered_at_final` + **T-GDR** |
| §3.4 | 缺 no-op 对照 | 每个 state 跑 **policy + no-op** 两遍，paired 比较 |
| §3.5 | 强制单标签 | 改为**多标签 event profile**（9 个事件），单标签由事件派生并保留 `mixed` |
| §4 | contact 未拆 subject/target | `contact_subject_*` / `contact_target_*` / `contact_task_any_*`，各自 4 个字段 |
| §5 | articulated 距离用 cabinet 代替 | `open_middle_drawer` 的 `d_eef_subject` 记为 **NA（未测量）**，不再拿 cabinet body 充数 |
| §7 | 只有汇总量、无法复算 | 每 rollout 保存**逐 step CSV**（22 列）；汇总由 `scripts/plan1_analyze_v2.py` **离线从 CSV 重算** |

**离线可复算性**：`plan1_analyze_v2.py` 只读 trace CSV，不加载模型、不碰仿真。
本文件的所有数字都由它产出 —— 这本身就是 §7 要求的证明。

## B. 结果（全部来自 trace 离线重算）

| task | s | label | reappr | grasp | c_sub | broken | osc | retreat | rev(1mm) | noop label | noop rev | path | noop_path |
|---|---:|:--|:--|:--|:--|:--|:--|:--|---:|:--|---:|---:|---:|
| bowl_on_plate | 0 | **mixed** | True | True | True | True | True | False | 21 | undetermined | 0 | 0.89 | 0.08 |
| bowl_on_plate | 1 | **mixed** | True | False | True | True | True | False | 53 | undetermined | 0 | 0.86 | 0.09 |
| bowl_on_stove | 0 | **mixed** | True | True | True | True | True | False | 46 | undetermined | 1 | 0.84 | 0.13 |
| bowl_on_stove | 1 | **mixed** | True | True | True | True | True | False | 34 | reattempt | 2 | 0.83 | 0.23 |
| object_in_basket | 0 | **mixed** | True | True | True | True | True | False | 10 | undetermined | 0 | 1.60 | 0.12 |
| object_in_basket | 1 | **mixed** | True | True | False | False | True | False | 11 | reattempt | 1 | 1.62 | 0.05 |
| open_middle_drawer | 0 | reattempt | **NA** | True | False | False | False | **NA** | 0 | undetermined | 0 | 1.23 | **1.04** |
| open_middle_drawer | 1 | reattempt | **NA** | True | True | False | False | **NA** | 0 | undetermined | 0 | 1.16 | **0.96** |

### B1. 事件命中率：policy vs no-op（这是最有说服力的一张表）

| 事件 | policy | no-op |
|---|---:|---:|
| `reapproached_subject` | **6/6** | 1/6 |
| `reapproached_target` | **6/6** | 2/6 |
| `grasp_commanded` | **7/8** | **0/8** |
| `contacted_subject` | **6/8** | 1/8 |
| `contacted_target` | 2/8 | 0/8 |
| `task_state_changed` | **6/8** | **0/8** |
| `goal_ever_broken` | **5/8** | **0/8** |
| `oscillatory_motion` | 6/8 | 0/8 |
| `retreated_from_task` | **0/6** | 0/6 |

**paired 差（policy − no-op）**：
`eef_path_length` median **+0.74 m**（min +0.19 / max +1.57）；
`eef_max_displacement` median +0.26（**min −0.02**）；
`reversals(1mm)` median +15.5。

### B2. T-GDR = 0.625，而 endpoint GDR ≈ 0

| task | s | first break @ | broken steps | 最长连续 | 末尾恢复 |
|---|---:|---:|---:|---:|:--|
| bowl_on_plate | 0 | 52 | 13 | 2 | True |
| bowl_on_plate | 1 | 120 | 5 | 4 | True |
| bowl_on_stove | 0 | 115 | 2 | 1 | True |
| bowl_on_stove | 1 | 102 | 2 | 1 | True |
| object_in_basket | 0 | 123 | **72** | **21** | True |

**T-GDR = 5/8 = 0.625**（v2，已作废），而 no-op 对照 **0/8**。
→ §2.4 的"瞬时破坏"现象本身成立；但**"endpoint GDR 严重低估"这个推论是错的**
（v3 更正：endpoint GDR = 3/8，三条永久破坏本来就能被捕获）。

### B3. 反转死区敏感度（§3.3）

| 死区 | 中位数 | 范围 |
|---|---:|---|
| 1 mm | 16.0 | [0, 53] |
| 2 mm | 8.0 | [0, 20] |
| **5 mm** | **0.5** | [0, 3] |

→ 从 1mm 到 5mm，中位数从 16 掉到 0.5。
**大部分"反转"是 5mm 以下的小幅抖动**，所以 `oscillatory_motion`
（按 1mm 预注册）**偏宽松**，不能单独用来支持"游移"。

---

## C. 本轮结果**削弱**了两个先前说法（必须如实报告）

### C1. no-op 对照显示：部分"多余运动"只是从捕获点settling

`noop_path` 在 `open_middle_drawer` 上达到 **0.96 / 1.04 m**，
而 policy 是 1.16 / 1.23 m —— **paired 差只有 +0.19 / +0.12**。

也就是说：**对这个任务，绝大部分 EEF 路径并不是策略驱动的，
而是从"自然终态捕获点"继续settling产生的。**
`eef_max_displacement` 的 paired 差甚至有一例是 **−0.02**（no-op 更大）。

> 根因：§4.5 预注册的捕获判据约束了 **物体**速度与夹爪释放，
> **没有约束机器人自身的速度**，所以捕获点可能仍带残余动量。
> 这属于判据设计问题，**按 §4.5"不得看结果后调整"，我没有改判据**，
> 而是把 no-op 基线如实报出来。

### C2. `open_middle_drawer` 的瞬时目标破坏**没有复现**

v1 观察到：`open_middle_drawer s1` 抽屉被推动 **8.0 cm**（关节归一化 0.471）、
predicate 中途翻 0。v2 用**同一个保存下来的 state**重跑：

```
v1: joint max displacement = 0.0801 m   normalized = 0.471   path = 0.187
v2: joint max displacement = 0.0020 m   normalized = 0.0118  path = 0.0035
```

**差 40 倍，且 v2 的 `goal_ever_broken = False`。**
结合已知的仿真非逐位可复现性（见 `docs/ExperimentA_动作因果追踪.md` §5b），
**单条轨迹的量级不可靠**。所以：

- 不能把"drawer 目标被瞬时破坏"当作已确认结论；
- `T-GDR = 0.625` 这个数字来自 **5 条 bowl/object 轨迹**，
  drawer 两对**未**贡献（它们的 broken=False）。

### C3. 分类器在 no-op 上也有假阳性

no-op 有 **2/8** 被判成 `reattempt`（`bowl_on_stove s1`、`object_in_basket s1`）。
说明 `reapproached_subject` 的 2cm 阈值**落在静置漂移范围内**，
分类器偏松。**因此本轮不报"reattempt / wandering 的总体比例"**，
只报**事件级**的 policy vs no-op 对照（B1）—— 那里的分离度是干净的。

---

## D. 现在能说什么 / 不能说什么

### 能说（有 no-op 对照支撑）

1. 自然终态之后，policy 的**任务指向行为显著多于静置基线**：
   `grasp_commanded` 7/8 vs 0/8、`task_state_changed` 6/8 vs 0/8、
   `goal_ever_broken` 5/8 vs 0/8、`reapproached_subject` 6/6 vs 1/6。
2. **不停止是策略行为，不是仿真漂移**（no-op 的对应事件全为 0）。
3. **目标扰动被 endpoint 指标严重低估**：T-GDR 0.625 vs endpoint GDR ≈ 0。
4. **没有一条轨迹是干净的"任务撤离"**（`retreated_from_task` 0/6，
   且 no-op 也是 0/6 —— 这个事件在本批里没有区分度，需保留判断）。
5. 行为**跨任务异质**，不能用一个全局阈值概括（§2.3）。

### 不能说

1. ❌ `safe_retreat 0/8、全部 reattempt 或 wandering` ——
   分类器有假阳性（C3），且 no-op 也命中 2 次。**第一版的这组数字作废。**
2. ❌ 把 `open_middle_drawer` 的瞬时目标破坏当结论（C2，未复现）。
3. ❌ 用 `eef_path_length` 的绝对值说明"多余运动"——
   drawer 任务的路径主要来自 settling（C1），必须用 **paired 差**。
4. ❌ `oscillatory_motion` 的 1mm 判据当作"游移"证据（B3，5mm 下中位数仅 0.5）。

## E. 产物

```
results/plan1/terminal_replay_v2/
├── {task}__s{seed}__v2.json       × 8   （policy + noop 两套 event profile）
├── traces/{task}__s{seed}__policy.csv  × 8   （逐 step，22 列）
├── traces/{task}__s{seed}__noop.csv    × 8
├── videos/{task}__s{seed}__policy.mp4  × 8
├── videos/{task}__s{seed}__noop.mp4    × 8
├── summary_v2.json
└── offline_analysis.json          ← 由 analyze_v2.py 从 trace 重算
```

复算命令（不占 GPU）：

```bash
./run_diag.sh scripts/plan1_analyze_v2.py
```

### 状态：**已暂停，等待 mentor_review_2 复审**

按 §9.2 第 6 条：**完成后再次暂停**。未启动 Stage 2 full、未启动 Stage 3/4。
