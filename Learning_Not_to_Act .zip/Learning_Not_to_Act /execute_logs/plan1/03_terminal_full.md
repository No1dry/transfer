# 03 — Stage 2：自然终态 full run

> **状态：未开始**（依赖 `02_terminal_smoke.md` 通过审查，§8.7）

plan1 §8.3 规定 full 规模：`4 tasks × 20 official init indices = 最多 80 pairs`。
若某些 seed 无法自然成功，保留失败记录、不替换 seed，并报告生成成功率。

§8.6 要求输出的表（放行后填写）：

| task | n_generated | n_valid | UMR | UTIR | GDR | EEF path median | object disp median |
|---|---:|---:|---:|---:|---:|---:|---:|
| `bowl_on_plate` | — | — | — | — | — | — | — |
| `bowl_on_stove` | — | — | — | — | — | — | — |
| `object_in_basket` | — | — | — | — | — | — | — |
| `open_middle_drawer` | — | — | — | — | — | — | — |

§8.6 同时要求与 scene-edit satisfied **同口径**对比，
且**必须报 task-level 分布，不得只报总体均值**；
不得使用"下降了 40 个百分点"一类表述，除非同口径重算后确实如此。

**执行者已提出但需 Codex 批准的两点**（见 `to_codex.md` §5、§6）：

1. full 规模建议先做 40 对（4 task × 10 seed）看路径长度比值方差，
   再决定是否补到 80 —— 可省约一半机时且不影响定性结论。
   **规模由 Codex 决定，执行者不自行缩小。**
2. §8.2 第 5、6 步的"已释放"与"关节稳定"目前**缺可判定阈值**
   （夹爪开度阈值？关节速度阈值？）。需要 Codex 给定，否则实现会各写各的。

产物将写入：`results/plan1/terminal_replay/`、报告 `reports/plan1/`
