# 04 — Stage 4：Intermediate Completed-Subgoal Pilot（结果）

> plan1 §10 的判决性实验 + mentor_review_11 §4 要求的 natural control。
> **两者都已完成，Plan 1 收尾。**
>
> 数据：
> - **scene-edited**：2 tasks × 2 conditions × 5 paired seeds
>   = **20 policy episodes + 20 no-op controls**
>   （不是"40 个独立实验样本" —— 分母必须分开报，见 §5）
> - **natural control**：2 tasks × 5 attempted seeds = **8 eligible**
>   （+ 2 ineligible，未替换；见 §6）
>
> 原始产物：`results/plan1/intermediate/pilot_full/`（scene-edited）、
> `results/plan1/intermediate/natural_v2/`（natural）
> 汇总：`stage4_summary.{json,csv,md}`、`natural_offline_summary.{json,csv}`
> （**全部由 trace 离线重算**）

---

## 0. 一句话结论

> **两个多阶段任务在"第一个子目标已由外部状态干预完成"时都从 5/5 掉到接近 0/5，
> 但失败机制完全不同**：I1 是**照着已完成对象的旧位置重放动作**（5/5），
> I2 是**既不重做也不切换到剩余子目标**（5/5）。
>
> **natural intermediate control 已跑完（§6），结论是相反的**：
> 从**自然轨迹**里截取"subgoal-1 刚完成、subgoal-2 未完成"的状态后重新下指令，
> **8/8 eligible 全部正确跳过已完成子目标、直接完成 remaining 并成功，0/8 re-execution。**
>
> 因此本节的 B 条件失败**不能**被解释成
> "模型普遍缺少 execution-necessity reasoning"；
> 它说明的是 **B 这一类状态分布**（外部构造的完成状态 + 初始机器人位姿）
> 上的脆弱性。⚠️ **但"外部完成"与"位姿不匹配"尚未被分开** ——
> 两类状态同时在 robot pose、task-object configuration 及其联合关系上不同，
> 因果因子由 plan2 §3.1 的因子设计识别（mentor_review_14 §3.1/§3.2）。

---

## 1. 任务与配对状态

两个任务都**从官方 BDDL 的 `:goal` 解析**出两个真正独立的谓词
（不是按任务名猜的 —— `open_the_top_drawer_and_put_the_bowl_inside` 就因此被剔除，
它的 goal 只有 1 个谓词）。

| | I1 | I2 |
|---|---|---|
| suite / task | libero_10 `LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket` | libero_10 `KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it` |
| subgoal-1 | `(in alphabet_soup_1 basket_1_contain_region)` | `(turnon flat_stove_1)` |
| subgoal-2 | `(in tomato_sauce_1 basket_1_contain_region)` | `(on moka_pot_1 flat_stove_1_cook_region)` |
| completed object | `alphabet_soup_1`（预注册） | `flat_stove_1_button`（joint 反查 body） |

**配对构造**（每个 official init index）：

- **A** = official init + **恰好 10 步官方 dummy action**（稳定后）
- **B** = 从**同一个 A** 原地构造，只改与 subgoal-1 直接相关的量

逐维 diff 白名单实测：

```
I1: changed=3  unexpected=[]   （只动 soup 的 free-joint 位置 xyz）
I2: changed=1  unexpected=[]   （只动 flat_stove_1_button 一个 qpos 维）
robot 前 9 关节 A/B 一致 : True (5/5 × 2 tasks)
no-op 稳定窗口标签不变    : True
```

I2 的关节取值来自**扫描出的 predicate-valid 区间中点**：
`joint_range=[-0.005,2.1]`、`predicate_valid=[0.521,2.1]`、`chosen=1.3106`。

---

## 2. 核心结果

| task | cond | n | Overall SR | Re-execution | Correct skip | Disturbed | first target |
|---|---|---:|---:|---:|---:|---:|---|
| I1 | A | 5 | **5/5** | n/a（模板） | n/a | 5/5 | `ambiguous/simultaneous` ×5 |
| **I1** | **B** | 5 | **1/5** | **5/5** | 1/5 | 0/5 | **`completed_A_orig` ×5** |
| I2 | A | 5 | **5/5** | n/a（模板） | n/a | 0/5 | `ambiguous/simultaneous` ×5 |
| **I2** | **B** | 5 | **0/5** | **0/5** | **0/5** | 0/5 | **`no_approach` ×5** |

- **A 条件 10/10 成功**；**B 条件 1/10 成功**。
- A 的 `first target` 全是 `ambiguous/simultaneous` —— 两个目标同一步进入 10cm，
  按 §6.1 预注册规则**拒绝硬选**（这是正确行为，不是缺陷）。
- **A 条件不纳入 re-execution / skip rate**（A 里 subgoal-1 本来就要执行）。

### 2.1 ★ 决定性的一个量：I1 的 approach 敏感度

| 目标 | step0 中位 | min 中位 | 穿越 5cm | 穿越 10cm | 穿越 15cm |
|---|---:|---:|---:|---:|---:|
| soup 的 **A 原位置** | 0.272 | **0.031** | **4/5** | **5/5** | 5/5 |
| soup 的**当前**位置（篮内） | 0.317 | 0.130 | **0/5** | **0/5** | 5/5 |
| tomato（remaining） | 0.224 | 0.065 | 2/5 | 3/5 | 4/5 |

**模型在 4/5 个 seed 里进入"旧位置"5cm 以内，却一次都没有进入"当前位置"5cm 以内。**
这不是"两边都靠一靠"，而是**明确指向旧位置**。

> 这一列（`completed_A_orig`）在 review7 里曾因参考系错误而作废；
> 修正后它成了最强的证据。相关经验记在 `mentor_review_7_response.md`。

### 2.2 I2 是**另一种**失败模式

| 目标 | min 中位 | 穿越 5cm | 穿越 10cm | 穿越 15cm |
|---|---:|---:|---:|---:|
| stove button | 0.177 | 0/5 | 0/5 | 0/5 |
| moka pot | 0.147 | 0/5 | 0/5 | 3/5 |

**0/5 重新操纵 button、0/5 合爪、0/5 让 moka subgoal 取得进展。**
准确表述（mentor_review_10 §1）：

> The policy showed weak directional approach toward the moka pot in some seeds,
> but never entered the preregistered 10cm execution zone, issued a close
> command, or advanced the remaining subgoal.

精确计数（mentor_review_12 §2）：

```
button：0/5 进入 15/10/5cm
moka  ：3/5 进入 15cm，0/5 进入 10/5cm
close ：0/5
sg2 进展：0/5
success：0/5
```

**不要**写成"三档都没有 approach"或"完全无方向运动"——
moka 方向 3/5 进过 15cm，是有弱方向性的。

### 2.3 no-op 对照干净

| | task_contact | re-execution | SR |
|---|---:|---:|---:|
| I1 A/B | 0 / 0 | 0 / 0 | 0/5, 0/5 |
| I2 A/B | 0 / 0 | 0 / 0 | 0/5, 0/5 |

→ 上述行为来自 **policy**，不是仿真 settling 或漂移。
no-op 仅作 drift / predicate 稳定性对照，**不与 policy SR 混合**。

---

## 3. 两类失败的区分（这是本项目核心命题的直接证据）

```text
Visual / state sensitivity
   != Execution Necessity decision
   != Explicit STOP / SKIP / transition control
```

- **I1**：模型"看见"了 subgoal-1 已完成吗？行为上**没有** ——
  它照旧朝旧位置伸手（action prior / 旧位置 replay）。
- **I2**：模型**没有**重做 button，说明它对完成状态**有一定敏感性**；
  但它也**没有**切换去 moka pot —— 敏感性没有转化成
  `SKIP → next subgoal` 的显式控制。

两种模式**不能合并成一个 re-execution rate**。

---

## 4. 与 terminal 实验的关系

| | Stage 2（terminal） | Stage 4（intermediate） |
|---|---|---|
| 整体任务 | 已完成 | **未完成** |
| 正确行为 | STOP（有争议：可能该撤离） | **继续执行 subgoal-2（无争议）** |
| 混淆 | terminal 之后无行为克隆监督 | **该混淆不存在** |
| 现象 | 8/8 仍有任务指向动作 | **B 条件 1/10 成功** |

**Stage 4 的价值正是把"terminal 无监督"这个解释堵死**：
这里整体任务明确未完成、且 subgoal-2 有充分监督，
正确行为没有歧义 —— 模型仍然失败。

---

## 5. 统计与结论边界（mentor_review_11 §3 + review13 §4）

- 每个 task **只有 5 个 paired seeds**，任务级置信区间仍宽；
- **不应**把 `A 10/10 vs B 1/10` 当作十个独立 task 做总体外推；
- I1 的 5/5 re-execution 与 I2 的 5/5 neither 都是
  **强一致性 pilot 信号**，不是总体发生率；
- 只评估了**一个** OpenVLA-OFT checkpoint；
- **B 是严格 state-intervention pair**，但"subgoal 已完成 + 机器人仍在 initial pose"
  已被 §6 的 natural control 证实是**关键变量**（不是可有可无的 caveat）；
- natural control 侧：**8 eligible**（2 ineligible 未替换），
  8/8 正确 skip + 成功 —— 方向一致性极强，但 n=8 仍属 pilot 规模；
- **不得**把 B 条件的失败写成"模型不会 skip 已完成的子目标"（见 §6.6）。

---

## 6. natural intermediate control —— **已执行：失败与状态分布绑定，但因子未识别**

### 6.1 动机（回顾）

B 状态是外部构造的：subgoal-1 已完成，但机器人仍在初始位姿。
训练数据里"汤已进篮/炉子已开"时，机器人几乎总是在**别的姿位**。
所以"组合 OOD"是本轮结果的**头号替代解释**。

### 6.2 做法

从每个任务的**成功 rollout** 中截取"subgoal-1 已满足、subgoal-2 未满足"的
自然状态（机器人/对象/控制器状态都来自自然轨迹），落盘 `.npy`，再重新加载、
清 action queue、重下同一指令。产物：`results/plan1/intermediate/natural_v2/`。

脚本：`scripts/plan1_natural_intermediate.py`（`54376a6677e5ce9e…`），
离线汇总：`scripts/plan1_natural_offline.py`（`9622b3d669163180…`）。

### 6.3 结果（5 attempted seeds/task，**不替换失败 seed**）

| task | attempted | **eligible** | continuation ok | restart ok | correct skip | re-execution | first target |
|---|---:|---:|---:|---:|---:|---:|---|
| I1 | 5 | **4** | 4/4 | **4/4** | **4/4** | **0/4** | `remaining` ×4 |
| I2 | 5 | **4** | 4/4 | **4/4** | **4/4** | **0/4** | `no_approach` ×4（见 §6.5） |
| **合计** | 10 | **8** | 8/8 | **8/8** | **8/8** | **0/8** | — |

未替换的 2 个 ineligible（按 review13 §1，seed 保留不补）：

```
I1 s0  continuation 未在官方 520 步预算内成功（修复前的超预算假成功已作废）
I2 s2  continuation 与 restart 都失败（基线轨迹失败，不能用于判断 necessity）
```

### 6.4 ★ scene-edited B vs natural restart（**方向相反**）

| task | scene-edited B（外部构造） | natural restart（自然截取，eligible） |
|---|---|---|
| I1 | SR **1/5**；re-execution **5/5**；first target `completed_A_orig` ×5 | SR **4/4**；correct skip **4/4**；re-exec 0/4；first target `remaining` ×4 |
| I2 | SR **0/5**；re-exec 0/5 且 remaining 也无进展 | SR **4/4**；correct skip **4/4**；remaining 子目标 4/4 完成 |

连续量的对照（I1，最能说明问题）：

| 量 | scene-edited B | natural restart |
|---|---:|---:|
| 到 **soup 旧位置** 的最小距离 | **0.031**（中位） | **0.163 – 0.229** |
| 到 **tomato（remaining）** 的最小距离 | 0.065（中位） | **0.011 – 0.022** |

即：自然截取状态下，模型**根本不往旧位置去**（最近 16–23 cm），
而是一头扎向 remaining（1–2 cm）；B 条件下正好相反。

> **读法限制**：这两列同时受 robot pose 与 task-object configuration 影响。
> 例如"到 soup 旧位置的距离"在两组里**定义都不同**：
> B 组的旧位置在桌面原处，natural 组的旧位置由各自轨迹的抓取前位置决定。
> 因此上表是**描述性对照**，不能单独用来判断是位姿还是物体配置在起作用
> （mentor_review_14 §3.2）。

### 6.5 ⚠️ 一个必须写清楚的口径陷阱：I2 的 `no_approach` 是同名不同义

I2 的 natural restart 与 scene-edited B **都**报 `first_task_target = no_approach`，
但含义完全相反，**不能并列引用**：

- scene-edited B：moka 最近只到 **0.147 m**，从未进入 10cm 执行区 → 真·没接近；
- natural restart：捕获时 moka **已经在 10cm 内**（step0 = 0.068–0.089 m），
  `approach` 是**基于穿越**（outside→inside）定义的，已在区内就没有穿越事件
  → 标签退化成 `no_approach`，**但 4/4 成功、合爪步 37–58**。

所以 I2 的判别量应该用 **(success, closed-gripper-near-remaining, 子目标进展)**，
不要用 `first_task_target`。I1 则没有这个问题（两侧都不在区内，穿越判据有效）。

### 6.6 判定

按 mentor_review_11 §4 的预注册判读表：

```
自然 B **能**正确继续、而 scene-edited B 失败
  → 失败与"当前状态分布"绑定，而两类分布在 robot pose、
    task-object configuration 与其联合关系上同时不同
  → 主张收紧为"对这类 counterfactual 状态分布不鲁棒"
```

**判定边界（mentor_review_14 §1.1 / §3.1）**：

- 本节初稿的表述"同一中间状态、只差外部构造还是自然产生"**不成立、已作废** ——
  两组当前状态并不相同；对无历史策略而言 provenance 不可观察，
  不可能是因果变量；
- 两类状态同时变了三件事（robot pose / task-object configuration / 联合关系），
  **Plan 1 没有正交操纵，因此因果因子未识别**；
- 正确写法见 `summary.md` §14.2 的 erratum；
  因子识别是 plan2 N1（§3.1）的任务。

因此本节的结论只到"**两类状态分布 → 相反结果**"这一层，
不再往下归因。

### 6.7 记录但未改变判据的两点

1. **10/10 次捕获都发生在 action chunk 中间（剩 7 步）** —— 已记录；
   由于 restart 会 `policy.reset()` 清 queue 并重下指令，这不影响 restart 分支，
   仅意味着"捕获点"不是 chunk 边界。
2. **continuation 与 restart 的步数预算不对等**：continuation 用 generation 的
   剩余预算（295–373 步），restart 拿全新 520 步。因此**不要把两侧成功率直接相减**；
   本文只把 continuation 当作 eligibility 判据（§1），不当作对照臂。
   若 plan2 要比较两分支，必须先对齐预算。

> 另：natural_v2 只保存了 restart 视频（10 个）。
> continuation 分支按 §2.1 定义为 generation 自身的切片，
> 因此**没有单独渲染**（generation 的帧当时未落盘）。
> 关键分支（restart）视频齐全；generation 视频缺失已记入
> `artifacts_manifest.md` §10 诚实清单。

---

## 7. 关键数字（可追溯）

- 数据：`results/plan1/intermediate/pilot_full/`（40 trace + 40 video）
- 汇总：`stage4_summary.{json,csv,md}`（由 `plan1_stage4_offline.py` 从 trace 重算）
- **online/offline 核心事件 mismatch = 0**
- 运行源码 hash：`plan1_stage4_pilot.py = 509e79df44a0d718`（本地 = 远端）
- 增强 gate：12/12 PASS（`results/plan1/intermediate/gate_report.json`）

### 代表视频（mentor_review_11 §5.7）

| 用途 | 文件（`pilot_full/videos/` 下） |
|---|---|
| I1 B s0（旧位置 replay 且失败） | `LIVING_ROOM_SCENE2_..._basket__s0__B__policy.mp4` |
| **I1 B s1（唯一成功，判 mixed）** | `LIVING_ROOM_SCENE2_..._basket__s1__B__policy.mp4` |
| I2 B s0（neither / no approach） | `KITCHEN_SCENE3_..._moka_pot_on_it__s0__B__policy.mp4` |
| A baseline（I1） | `LIVING_ROOM_SCENE2_..._basket__s0__A__policy.mp4` |
| A baseline（I2） | `KITCHEN_SCENE3_..._moka_pot_on_it__s0__A__policy.mp4` |

---

## 8. 工程备注：本轮踩过的两个"在线值不可信"教训

1. **coverage 去重 bug**：`contact_container` 同时出现在 required 与 optional，
   被重复计数成 `2n` → 误判 missing → I1 全部 `cov=False`。
   → 修好后 40/40 `cov=True`；并且 **gate 改为从 trace 重算** coverage。
2. **参考系错误**（review7）：`completed_A_orig` 写在 condition 循环内，
   B 条件下记的是 B 自己的起点 → "去旧位置抓空"的结论一度作废。
   → 修好后该量成为 §2.1 的最强证据。

**共同教训**：在线算出来的派生量必须能从 trace 独立复算，
且 gate 不能只验 schema、必须验 **provenance**。

---

## 9. 状态

**Plan 1 已完成收尾（含 §6 natural control）。** 产物：

```
scene-edited（正式）: results/plan1/intermediate/pilot_full/   40 trace + 40 video
natural control     : results/plan1/intermediate/natural_v2/   20 trace + 10 video
```

未启动（且本轮仍不启动）：Stage 2 Terminal Full、Stage 3 Matched Pair full、
ENA Head、Counterfactual Memory、任何模型训练。

下一步见 `plan2.md`（本目录）。
