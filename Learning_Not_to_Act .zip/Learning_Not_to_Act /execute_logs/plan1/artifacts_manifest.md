# artifacts_manifest.md — 正式产物索引

> # ⛔ INVALID DIAGNOSTIC RUN: stale observation after state restore
>
> 按 **mentor_review_3 §3.3**，本文件涉及的 **smoke-v2 数字全部作废**，
> 只能作为"复现该 bug"的诊断材料，**不得作为研究结论**。
>
> 原因：`set_state(..., settle_steps=0)` 当时**不刷新 observation**，
> 于是 policy 的**首个 action chunk 用的是上一段旧轨迹的图像与 proprio**，
> 整条闭环轨迹都不是对 terminal state 的响应。实测证据：
> policy step0 的 EEF 在 6/8 条上逐位相同（home 位姿）、
> step0→1 伪跳变 0.27–0.33 m（真实单步 median 0.0019 / max 0.0124 m）、
> no-op step0 与前一条 policy 末帧 **8/8 逐位相同**。
>
> 已修复（无步进 observation refresh，真实 LIBERO 集成测试全过），
> 修正后的结果是 **smoke-v3**（`results/plan1/terminal_replay_v3/`，
> 见 `mentor_review_3_response.md`）。


> plan1 §4 要求：列出远端所有正式产物的绝对路径、文件数和 SHA256。
>
> 快照：**Plan 1 收尾（mentor_review_13 之后）**。
> 哈希为 SHA256 前 16 位（完整值用 `sha256sum <path>` 复算）。
>
> 修订历史：曾在 Stage 1 快照停留（7 个文件、写"Stage 2/3/4 无数据"）；
> 经 mentor_review_2 §8、mentor_review_11 §5.5、**mentor_review_13 §5.6**
> 三次更新，现覆盖 Stage 2 smoke-v3 / Stage 4 scene-edited / natural control。

远端根目录：`/HUBU-AI004/zp/ICML/`

---

## 1. 汇总计数

实测（`find results/plan1 -type f | wc -l`，2026 收尾快照）：

| 范围 | 文件数 |
|---|---:|
| `results/plan1/` 全部 | **411**（38 MB） |
| └ `results/plan1/intermediate/`（Stage 4 全部） | **283** |
| &nbsp;&nbsp;├ `pilot_full/`（scene-edited 正式） | 40 trace + 40 mp4 + 1 json + 3 汇总 |
| &nbsp;&nbsp;├ `natural_v2/`（natural control 正式） | 10 npy + 20 trace + 10 mp4 + 2 汇总 |
| &nbsp;&nbsp;├ `natural_full/`（**已作废**，保留） | 6 npy + 12 trace + 12 mp4 + 1 json |
| &nbsp;&nbsp;├ `capability/` | 1 json + 10 trace + 10 mp4 |
| &nbsp;&nbsp;├ `pairs_v2/` | 1 json + 20 npy + 20 png |
| &nbsp;&nbsp;└ `pilot/` `pilot_v2/` `pilot_v2_i2/`（诊断） | 保留 |
| `results/plan1/terminal_replay*/` | v1 / v2 / v3 三套（v2 已作废） |

> 早期 Stage 1 快照里"`results/plan1/` 全部 85 个文件"的数字已过期；
> 以上为收尾时的实测值。

## 2. `results/plan1/` 顶层（Stage 0/1）

| SHA256(16) | 字节 | 路径 |
|---|---:|---|
| `70a67719b5a9646d` | 11604 | `results/plan1/metric_audit.json` |
| `02be4a87f657a1c9` | 3119 | `results/plan1/stage0_state_validation.json` |
| `19cbb69b90a8ba17` | 355 | `results/plan1/pre_stage1_sha256.txt` |
| — | — | `results/plan1/_pre_stage1_backup/`（4 个核心文件改动前副本，§5.6） |

## 3. Stage 2 v1：`results/plan1/terminal_replay/`

- `{task}__s{seed}__terminal.json` × **8**（per-pair，含 metrics_v2 全量）
- `{task}__s{seed}__state.npy` × **8**（自然终态 flattened state）
- `summary.csv` / `summary.json`（由 `plan1_terminal_summary.py` **从 per-pair JSON 重算**）
- `videos/` 共 **18** 个 mp4，其中：
  - **16 个正式产物**：每对 `__gen.mp4` + `__replay.mp4`
  - **2 个失败诊断产物**：`*__gen_failed.mp4`
    （第一轮 `open_middle_drawer` 因 joint-velocity bug 失败时留下，
    **不计入正式视频数**；按 §3 未删除）

> ⚠️ smoke 分两次跑（4 task 一次、`open_middle_drawer` 补一次），
> 第二次调用覆盖了中间 `summary.csv`，因此汇总**一律从 per-pair JSON 重算**。

## 4. Stage 2 smoke-v2：`results/plan1/terminal_replay_v2/`（本轮新增）

| 类别 | 数量 | 说明 |
|---|---:|---|
| `{task}__s{seed}__v2.json` | 8 | policy + no-op 两套 event profile + paired 差 |
| `traces/…__policy.csv` | 8 | **逐 step 22 列**，汇总的唯一来源（§7） |
| `traces/…__noop.csv` | 8 | no-op 对照，同一 state / 同一窗口 |
| `videos/…__policy.mp4` | 8 | policy replay |
| `videos/…__noop.mp4` | 8 | no-op replay |
| `summary_v2.json` | 1 | 运行汇总 |
| `offline_analysis.json` | 1 | **由 `plan1_analyze_v2.py` 从 trace 离线重算** |

复算（不占 GPU、不碰仿真）：

```bash
./run_diag.sh scripts/plan1_analyze_v2.py
```

## 5. 日志

| 路径 | 内容 |
|---|---|
| `logs/p1validate.log` | Stage 0 remote predicate smoke |
| `logs/p1stage2.log` | Stage 2 v1（含首轮失败与修复过程） |
| `logs/p1smokev2.log` | **Stage 2 smoke-v2**（§9.2 批准运行） |

## 5b. Stage 2 smoke-v3：`results/plan1/terminal_replay_v3/`（最新一轮）

| 类别 | 数量 | 说明 |
|---|---:|---|
| `{task}__s{seed}__v3.json` | 8 | 含 **trace_guard** 结果 |
| `traces/…__policy.csv` / `__noop.csv` | 16 | 逐 step，配对同起点 |
| `videos/…__policy.mp4` / `__noop.mp4` | 16 | |
| `summary_v3.json` | 1 | 含 `trace_guard_all_pass: true` |
| `offline_analysis.json` | 1 | 离线重算（含 T-GDR 严重度曲线、approach 敏感度） |

**state/observation 一致性验证**：`results/plan1/state_obs_refresh_check.json`
（ALL PASS；`physics_not_advanced = 0.0`）

复算：

```bash
./run_diag.sh scripts/plan1_analyze_v2.py --dir terminal_replay_v3
./run_diag.sh scripts/plan1_state_obs_refresh_check.py
```

> **smoke-v2（`terminal_replay_v2/`）为 INVALID DIAGNOSTIC RUN**
> （stale observation），保留供复现 bug，数字不得引用。

## 6. 仍未开始（等待放行）

```
results/plan1/matched_pairs/       Stage 3（§9.3：排在 Stage 4 之后；
                                   Stage 4 已给出结论，Plan 1 未启动它）
reports/plan1/                     尚无报告产出
```

`results/plan1/intermediate/` **已完成**（Stage 4 scene-edited + natural control），
明细见 §11。`results/plan1/terminal_replay/`（v1）与 `terminal_replay_v3/`
为有效产物；`terminal_replay_v2/` 已作废（§5）。

## 7. 只读引用的历史产物（**未被本计划修改**）

| 路径 | per-episode JSON | 视频 |
|---|---:|---:|
| `results/m1/final/` | 160 | 160 |
| `results/m1/final_v1/` | 160 | 71 |
| `results/m1/fixed_action_v1/` | 21 | 21 |
| `results/m1/control_A/` | **0** | 20 |
| `results/m1/control_B/` | **0** | 10 |

`results/m1/final/` 的 160 条被**只读重算**用于审计；
其 `metrics.json` 的 `uer=1.0 / gdr=0.025 / n_dropped=0` 与 Stage 0 冻结值一致。

## 8. 代码改动与哈希

### Stage 0 冻结时（v1 起点）

```
0986d94fb2ad8075  benchmark/metrics.py
d1ebd1211b18a034  benchmark/runner.py
d8d40668eb1b2f61  benchmark/arena/libero.py
0fec6a055a0ec1e1  benchmark/arena/mock.py
```

### 当前（mentor_review_1 §3 + mentor_review_2 §3/§4 修正后，本地 = 远端）

```
76df37139c487e05  benchmark/metrics.py
135323a63fee2a0f  benchmark/runner.py
86123436aa87e52d  benchmark/arena/libero.py
697131f800111d2f  benchmark/arena/mock.py
38804fa0529ab293  benchmark/states/mujoco_state.py
4282af59bbefec65  benchmark/event_profile.py
```

```
753c2bf95779039b  benchmark/event_profile.py
853024b61deb9ede  benchmark/arena/libero.py
```

（本地与远端逐字节一致，已核对；smoke-v3 修正后的最终值。）

### 新增文件（本计划）

| 路径 | 说明 |
|---|---|
| `benchmark/event_profile.py` | **多标签 event profile**、approach/retreat 独立量、带死区反转、T-GDR |
| `scripts/plan1_env_report.py` | Stage 0 环境冻结报告 |
| `scripts/plan1_metric_audit.py` | 旧指标审计（同数据换判据重算） |
| `scripts/plan1_unit_audit.py` | **gripper 单位审计**（证实 0.2 阈值是量纲错误） |
| `scripts/plan1_terminal_replay.py` | Stage 2 v1 自然终态生成 + replay |
| `scripts/plan1_terminal_summary.py` | 从 per-pair JSON 重算 v1 汇总 |
| `scripts/plan1_terminal_replay_v2.py` | **smoke-v2**：paired policy/no-op + 逐 step trace |
| `scripts/plan1_analyze_v2.py` | **离线**从 trace 重算全部汇总 |
| `tests/test_metrics_v2.py` | v2.1 指标测试 |
| `tests/test_arena_v2_signals.py` | 单步 path、contact 归属与分离、守卫测试 |
| `tests/test_event_profile.py` | §3.1 重接近逻辑、§3.3 死区、§2.4 T-GDR |

测试：**155 passed**（本地与远端一致）；`compileall` 通过。

## 9. 本地↔远端一致性校验

```bash
sha256sum benchmark/metrics.py        # 远端
shasum -a 256 benchmark/metrics.py    # 本地，应一致
```

## 10. 诚实清单：未产出 / 已作废

- **Stage 3 无数据**（`results/plan1/matched_pairs/` 为空）：§9.3 排序在 Stage 4 之后，
  而 Stage 4 已给出结论（见 `summary.md` §13/§14）。
- **Stage 2 full run 无数据**：smoke-v3 已足以定靶，未获放行。
- **`reports/plan1/` 为空**：`benchmark/report.py` 尚未接入 v2 输出块 ——
  等指标定义稳定后再一次性接（见 `summary.md` §11 建议 3）。
- **第一版的 `safe_retreat 0/8 / reattempt 3/8 / wandering 5/8` 已作废**
  （§3.1 分类器有确定性错误；且 no-op 对照下也出现 2/8 假阳性）。
  原始文件保留未删，但**不要再引用那组数字**。
- **`natural_full/` 已作废**（review13 §2.1/§2.2/§2.3）：
  continuation 超官方预算、含捕获前动作、restart 缺真 step0。
  保留不删，数字不得引用；正式版为 `natural_v2/`。
- **`natural_v2/videos/` 缺 generation（continuation）视频**（见 §11 末尾）。
- **I1 s0 / I2 s2 两个 seed 未替换**：按 review13 §1 保留为 ineligible，
  不计入分母。

---

## 11. Stage 4 产物（mentor_review_11 §5.5 新增）

```
results/plan1/intermediate/
├── feasibility.json                     （I1 原候选不可用的证据）
├── pairs_v2/
│   ├── pairs.json                       （2 tasks × 5 seeds 配对验证）
│   ├── states/{task}__s{0..4}__{A,B}.npy  × 20
│   └── images/{task}__s{0..4}__{A,B}.png  × 20
├── capability/
│   ├── capability.json                  （能力门槛 5/5 + 5/5 PASS）
│   ├── traces/{task}__ep{0..4}.csv      × 10
│   └── videos/{task}__ep{0..4}.mp4      × 10
├── pilot/                               ⛔ diagnostic only（参考系错误）
├── pilot_v2/                            I1 seed0（有效单例）
├── pilot_v2_i2/                         I2 seed0（anchor 修正后）
├── pilot_full/                          ★ 正式 Stage 4 pilot（scene-edited）
│   ├── pilot_v2.json
│   ├── stage4_summary.{json,csv,md}     ← 由 trace 离线重算
│   ├── traces/{task}__s{0..4}__{A,B}__{policy,noop}.csv  × 40
│   └── videos/{task}__s{0..4}__{A,B}__{policy,noop}.mp4  × 40
├── natural_full/                        ⛔ 旧版 natural run（口径有 bug，§12）
│   ├── natural_intermediate.json
│   ├── states/  × 6
│   ├── traces/  × 12
│   └── videos/  × 12
├── natural_v2/                          ★ natural intermediate control（review13）
│   ├── states/{task}__s{0..4}__natural.npy   × 10
│   ├── traces/{task}__s{0..4}__{continuation,restart}.csv  × 20
│   ├── videos/{task}__s{0..4}__restart.mp4   × 10
│   └── natural_offline_summary.{json,csv}    ← 由 trace 离线重算
└── gate_report.json                     （增强 gate 12/12 PASS）
```

### natural_v2 的汇总口径（review13 §5.4/§5.5）

`natural_offline_summary.json` 的 `summary` 字段按 **eligibility** 分开报：

```
I1: attempted 5, eligible 4, cont ok 4, restart ok 4, correct_skip 4, reexec 0
I2: attempted 5, eligible 4, cont ok 4, restart ok 4, correct_skip 4, reexec 0
ineligible（保留不替换）: I1 s0（continuation 超预算/未成功）、I2 s2（基线失败）
```

**不覆盖 `natural_full/`**（review13 §5.2）；
旧 run 的 continuation 口径有 bug，其数字不得引用（§12）。

### ⚠️ natural_v2 缺 generation/continuation 视频

`videos/` 只有 **10 个 restart mp4**。按 review13 §2.1，
continuation 被定义为 generation rollout 的切片，因此没有单独渲染帧
（generation 阶段当时未落盘帧）。
关键分支（restart）视频齐全；若后续需要 generation 视频，
需重跑 generation 并在 `gen_rows` 循环里同样采集 `frames`。

### 新增脚本与模块

| 路径 | 说明 |
|---|---|
| `benchmark/bddl_goal.py` | **纯函数** BDDL `:goal` 解析器（本地可测，与仿真解耦） |
| `benchmark/stage4_events.py` | Stage 4 **预注册**事件（多标签 + 连续量 + 5/10/15cm 敏感度） |
| `scripts/plan1_stage4_feasibility.py` | Stage 4-A 可行性（发现 I1 只有 1 个 goal 谓词） |
| `scripts/plan1_stage4_pairs.py` | paired A/B 构造（官方 wait + 原地构造 + 白名单） |
| `scripts/plan1_stage4_capability.py` | 完整任务能力门槛（官方 init / 520 步预算） |
| `scripts/plan1_stage4_pilot.py` | Stage 4 pilot 主脚本（paired policy/no-op + 逐 step trace） |
| `scripts/plan1_stage4_gate.py` | **语义** gate（anchors provenance + step0 + coverage 从 trace 重算） |
| `scripts/plan1_stage4_offline.py` | **离线汇总**（从 trace 重算 + online/offline mismatch 清单） |
| `scripts/plan1_natural_intermediate.py` | natural intermediate control 主脚本（捕获 + continuation 切片 + restart） |
| `scripts/plan1_natural_offline.py` | **离线**从 trace 重算 natural 汇总（主脚本崩溃后的恢复路径） |
| `tests/test_bddl_goal.py` | 解析器单测 9 个 |
| `tests/test_stage4_events.py` | 事件单测 14 个 |

### 运行源码 hash（§5.6）

```
509e79df44a0d718  scripts/plan1_stage4_pilot.py    （本地 = 远端，运行时冻结）
c2521b4c115de2be  scripts/plan1_stage4_offline.py
54376a6677e5ce9e  scripts/plan1_natural_intermediate.py   （natural_v2 运行时冻结）
9622b3d669163180  scripts/plan1_natural_offline.py
```

## 12. plan2 准备的**只读**产物（mentor_review_14 §3.1/§5.5）

> 只做只读核对：**不加载 policy、不跑 episode、不训练**。

| 路径 | 说明 |
|---|---|
| `scripts/plan2_state_index_map.py` | 导出 flattened state 的 joint→下标映射与 R/O 角色划分 |
| `results/plan2/state_index_map.json` | 实测白名单（I1/I2 各一份，含 qpos 与 qvel 下标） |

实测结果摘要：

```text
I1 LIVING_ROOM_SCENE2_...basket   nq=65 nv=57 total=123
   R = {1..9}（robot0_joint1..7 + gripper0_finger_joint1/2）
   completed alphabet_soup_1 {10..16} | remaining tomato_sauce_1 {24..30}
   container basket_1 {59..65} | 非任务物体 {17..23, 31..58}
I2 KITCHEN_SCENE3_...moka_pot     nq=24 nv=22 total=47
   R = {1..9}
   completed flat_stove_1_button {24} | remaining moka_pot_1 {17..23}
   container flat_stove_1 无自由关节（固定 fixture）
num_steps_wait_inside_reset = 10（两任务）
```

### 本轮只读核对发现的两处 provenance 问题

1. **`capability/` 没有保存状态**（脚本无 `np.save`），且其起点是 **double wait**：
   `LiberoArena.reset()` 内部已含 10 步官方 dummy，
   `plan1_stage4_capability.py` 之后又跑了 10 步 `no_op_action()` → 共 20 步。
   → 它**不能**并入 `NORM` 状态集；`NORM` 的 n = **10**（只用 `pairs_v2 A`）。
   `pilot_full`（`set_state`）与 `natural_v2`（reset 后直接进 policy）**无此问题**。
2. **`natural_v2` 缺 generation 视频的真因**：
   `plan1_natural_intermediate.py` 采集了 `gen_frames`，
   但收尾用 `cont_frames = []` 覆盖 → **渲染了没写**（不是没渲染）。
   按 mentor_review_14 §1 无需为 Plan 1 重跑；plan2 脚本改为在 `finally` 前落盘。

### 已记录的 coverage 元数据 bug（§5.6）

`contact_container` 同时出现在 `required` 与 `optional` 参数里，
计数循环按出现次数累加 → `2n` → 被误判为 missing → I1 全部 `cov=False`。
修法：计数前对列名去重。修后 40/40 `cov=True`；
并把 gate 的 coverage 检查改为**从 trace 重算**（不再信任在线 JSON）。
