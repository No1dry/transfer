# blockers.md — 阻塞与待裁决事项

> **更新（mentor_review_1 之后）**：
> - B1 已由 mentor_review_1 §4.1 **原则批准**，且 §3 修正已全部完成（126 passed）；
>   Stage 2 smoke **已执行完毕（8/8）**，现按 §6 末句**再次暂停**，等待复审。
> - B2 已由 §4.2 **裁决接受**撤回。
> - B3 已由 §4.3 裁决为"必须在 smoke 中验证，且先按 §3.2/§3.5 修正"—— 已完成。
> - §4.4 contact 通道已按裁决**在 smoke 前实现**，实测覆盖 8/8。
>
> 当前无硬阻塞；待裁决项见 `mentor_review_1_response.md` §6。

> plan1 §12 格式。**当前没有硬阻塞**，Stage 1 是计划内暂停点（§7.5）。
> 下面 3 条是"需要导师/Codex 裁决才能继续"的事项。

---

## B1. ~~Stage 1 暂停点放行~~ —— **已解决**（Stage 2 smoke 已完成）

```text
现象：
    plan1 §7.5 要求"在导师或用户确认前，不启动大规模 GPU 实验"。
    Stage 1（统一指标 v2 + 旧指标审计）已完成，代码 97 tests passed，
    审计结果已落盘，现停在暂停点。

已经排查：
    - 确认 Stage 1 的所有交付物已完成：见 01_metric_audit.md §7
    - 确认测试全绿：pytest 97 passed；compileall OK
    - 确认 GPU 空闲（2 MiB），无遗留作业
    - 确认未触碰 results/m1/final/（只读重算）

原始证据路径：
    results/plan1/metric_audit.json
    results/plan1/stage0_state_validation.json
    logs/p1validate.log
    execute_logs/plan1/01_metric_audit.md

可选方案 A：
    只批准 Stage 2 smoke（4 task × 2 seed = 8 对，约 1-2 小时 GPU）。
    拿到 eef_path_length 之后再做 full。

可选方案 B：
    直接批准 Stage 2 smoke + full（4 task × 20 = 最多 80 对）。

可选方案 C：
    先解决 articulated 任务的关节通道低估问题，再统一开跑。

执行者建议：
    A。理由：Stage 1 暴露出的最大空白是"无法区分安全撤离 vs 无目标游移"
    ——这需要 eef_path_length / eef_max_displacement 比值，只有 Stage 2
    的新记录才有。smoke 规模小、信息量大，且 §8.7 本来就设了
    smoke 后的审查点，天然是安全的下一步。

等待导师决定：
    是否放行 Stage 2 smoke。
```

---

## B2. "60% → 100% 放大效应"的撤回需要确认

```text
现象：
    旧文档写过"场景编辑把 failure 从 60%（自然终态）放大到 100%"。
    审计发现这两个数判据不同：
      - 主实验 UER = eef ∨ grip ∨ obj（三通道）
      - control_a_terminal.py 的 UER = obj ∨ grip（缺 EEF 通道，
        且第 207 行 eef_max = 0.0 写死后从未使用）
    且 control_A / control_B 目录下 **只有视频、没有 per-episode JSON**，
    数字无法用统一指标重算。

已经排查：
    - 逐行比对两个判据：夹爪通道公式一致，差异只在 EEF
    - 确认 control_A/control_B 无记录文件（JSON=0, videos=20/10）
    - 确认这两个实验由绕过 runner 的自建循环产生

原始证据路径：
    scripts/control_a_terminal.py:207-210
    benchmark/metrics.py  is_significant_intervention
    execute_logs/plan1/01_metric_audit.md §1、§5

可选方案 A：
    撤回该表述，control_A/B 标记不可复算，全部结论等 Stage 2 重做。

可选方案 B：
    保留结论但降级为"现象级观察"，并显式标注口径差异。

可选方案 C：
    在 Stage 2 之后补跑一轮规范版 Control A（超出 plan1 范围）。

执行者建议：
    A。§3 禁止覆盖 control_A/ 目录，所以原地重跑不可行；
    Stage 2 的自然终态实验本来就是这件事的正确做法。

等待导师决定：
    是否接受撤回，以及是否需要在 plan2 里补规范版对照。
```

---

## B3. ~~articulated 关节通道低估~~ —— **已修正并验证**

```text
现象：
    open_middle_drawer 的 UTIR = 0.150，但这个数是**低估**。
    它真正的"干预"形式是把抽屉推回去（关节变化），而旧记录的
    160 条 JSON 里没有 task_joint_change 字段（当时还没实现），
    所以这一行只统计了物体位移，漏掉关节通道。

已经排查：
    - 确认旧记录 has_cumulative=0（审计脚本第一行输出）
    - 已在 EpisodeRecord 加入 task_joint_change 并接上 arena 的
      task_joint_change()（LiberoArena 与 MockArena 都实现了）

原始证据路径：
    results/plan1/metric_audit.json  ->  per_task[open_middle_drawer]
    benchmark/arena/libero.py  task_joint_change()
    benchmark/metrics.py  compute_utir()

可选方案 A：
    Stage 2 起自动带上关节通道，届时重算 articulated 的 UTIR。

可选方案 B：
    单独为 open_middle_drawer 跑一轮小实验专门量关节通道。

执行者建议：
    A。关节通道的代码已经就位且有单测覆盖，Stage 2 的记录天然会带上它，
    不需要额外实验。但**在 Stage 2 报告里必须标明**：
    "articulated 任务的 UTIR 在 Stage 1 审计中为低估值"。

等待导师决定：
    是否需要在 Stage 2 的验收标准里，为 articulated 任务单独设一条
    "关节通道确实非零"的检查。
```

---

## 无阻塞项

以下均**不构成**阻塞，仅记录：

- GPU 空闲，无作业冲突。
- 本地与远端核心代码 SHA256 已对齐（见 `artifacts_manifest.md` §4）。
- 仓库内无明文口令（见 `00_environment.md` §7）。
