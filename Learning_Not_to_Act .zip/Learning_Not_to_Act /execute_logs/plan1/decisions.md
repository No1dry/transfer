# decisions.md — 执行过程中的判断记录

> plan1 §4 要求。凡是我**自己做主**而没有回头问导师的决定，都记在这里。
> 格式：现象 / 可选方案 / 选择 / 依据 / 影响面。

---

## D1. v2 指标样本池改用 `init_satisfied` 而非 condition 名字

- **日期**：Stage 1
- **现象**：plan1 会引入 `terminal` / `near_unsatisfied` / `intermediate_A|B`
  等新 condition 名。若指标按 `condition == "satisfied"` 过滤，
  每加一种实验都要改一次 `benchmark/metrics.py`，而 terminal 与 scene-edit
  就会走**不同代码路径** —— 那正是 §7.1 要消除的口径混淆。
- **可选方案**：
  A. 按 condition 名字枚举白名单；
  B. 按 `init_satisfied` 语义过滤。
- **选择**：**B**。
- **依据**："该不该停"的判据始终是**初始状态是否已满足**这一个语义，
  与实验叫什么名字无关。§7.4 最后一条明确要求
  "terminal 和主实验相同信号得到相同判定"。
- **影响面**：`_initially_satisfied()` 成为 UMR/UTIR/GDR 的唯一样本池定义。
  有测试守着：`test_terminal_and_scene_edit_same_signals_same_verdict`。
- **风险**：若将来出现"初始满足但不该停"的实验（例如故意设置
  predicate 为真但其实该继续动），这个语义会失效。届时需要显式的
  `expected_behavior` 字段，而不是靠 condition 名。

## D2. 新增 `measured` 标志，把"未测量"与"测出来是 0"分开

- **现象**：§7.4 要求"没有 probe：GDR / post-completion 指标必须明确标成未测，
  而不是伪装成 0"。但旧代码里 `MetricSummary(n=0, value=nan)` 的
  `measured` 隐含为真，下游很容易把 nan 当 0 处理。
- **选择**：`MetricSummary.measured: bool = True`；未测量时
  `fmt()` 打印 `未测量 (n/a) — <原因>`；`DistSummary` 同样处理；
  累计量只在 `cumulative_measured=True` 的 episode 上统计。
- **依据**：§7.4。
- **影响面**：**写测试时立刻抓到一个真 bug** ——
  `compute_post_completion_steps` 原本返回 `n=0, nan` 但 `measured=True`。已修。
- **兼容性**：`measured` 默认 True，旧调用方行为不变；`as_dict()` 多一个键，
  旧 JSON 读取不受影响。

## D3. `control_A` / `control_B` 标记为不可复算，停止引用其数字

- **现象**：
  ```
  control_A   JSON=0  videos=20
  control_B   JSON=0  videos=10
  ```
  两者都由**绕过 runner 的自建循环**产生（`control_a_terminal.py` /
  `control_b_prior.py`），只写视频不写 `EpisodeRecord`。
  且 `control_a_terminal.py:207` 把 `eef_max = 0.0` 写死且从未使用，
  其 UER 判据**缺 EEF 通道**，与主实验 UER 不可比。
- **可选方案**：
  A. 重跑这两个实验，产出规范记录；
  B. 保留现状，标记为不可复算并停止引用；
  C. 删除这两个目录。
- **选择**：**B**。
- **依据**：
  - §3 明确禁止"覆盖 `control_A/`、`control_B/`"和"删除历史日志、视频"，
    所以 A（会覆盖）和 C（会删除）都被排除；
  - §7.1 的诉求是"要么同口径，要么别比"。Stage 2 的自然终态实验
    会以正确方式重做 Control A 的意图，所以不需要原地重跑。
- **影响面**：文档里"场景编辑把 failure 从 60% 放大到 100%"**撤回**。
  处置清单见 `01_metric_audit.md` §5。
- **留给导师**：若导师认为必须保留 Control A 的可比性，则需要在
  Stage 2 之后单独补一轮（不在 plan1 范围内）。

## D4. 不重跑旧的 160 条，只做离线重算

- **依据**：§1 明确"不要重跑旧的 160 条，除非本计划明确要求"。
  v2 的阈值型指标（UMR/UTIR/GDR）只需 `eef/grip/obj` 三个已有字段，
  可以纯离线重算，无需 GPU。
- **影响面**：可离线重算的部分已全部重算（见 `01_metric_audit.md` §3）。
  **不可重算的部分**：`eef_path_length` / `object_path_length` /
  `task_joint_change` —— 旧 JSON 没有这些字段，`cumulative_measured=False`，
  只能等 Stage 2 的新记录。
- **后果**：Stage 1 结束时**仍然无法区分"安全撤离"与"无目标游移"**。
  我认为这是继续推进 Stage 2 smoke 的最强理由（见 `01_metric_audit.md` §8）。

## D5. 在 Stage 1 暂停点停下，不启动 Stage 2 full

- **依据**：§7.5 明文"在导师或用户确认前，不启动大规模 GPU 实验"。
- **我做了什么**：只跑了两个**不加载 7B 模型、不占 GPU** 的 smoke
  （`plan1_env_report.py`、`validate_states.py --seeds 4`）。
- **我没做什么**：没有启动 terminal replay、没有启动 matched pair、
  没有启动 intermediate pilot。
- **等待**：见 `01_metric_audit.md` §8 的三个问题。

## D6. 修 `MetricSummary` 时顺手修了 `compute_post_completion_steps`

- **说明**：属于 D2 的直接后果，不单独构成研究决定，但记录以免被当成
  "悄悄改了指标"。改动只影响"未测量"的标注方式，**不影响任何已发布数字**
  （主实验 `post_completion_steps` 非空，走的是另一个分支）。
