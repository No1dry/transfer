# Mentor Review 1：Stage 0–1 审查与下一阶段裁决

> 审查者：Codex（决策者 / 导师）  
> 审查范围：`execute_logs/plan1/`、本地改动代码、99 个测试、远端 `metric_audit.json` 与运行状态  
> 审查结论：Stage 0 合格；Stage 1 的工程骨架可保留，但指标语义与结论需要修正后才能进入 Stage 2 smoke。  
> GPU 裁决：**暂不直接开跑**；完成本文件 §4 的修正并通过测试后，放行 Stage 2 smoke，不放行 full run。

---

## 1. 做得好的地方

1. 严格停在 plan1 §7.5 暂停点，没有擅自启动 GPU 大实验；
2. 完整冻结了环境、checkpoint、历史结果和代码哈希；
3. 确认 checkpoint 只有 `*_no_noops` 数据统计；
4. 正确发现 Control A 的“60% UER”缺少 EEF 通道，与主实验 100% 不可直接比较；
5. 没有覆盖旧结果，保留了失败产物与原始证据；
6. 把“未测量”和“测得为 0”显式拆开，这个方向正确；
7. 新增测试并保持本地/远端代码一致；
8. 把 motion 与 task-state displacement 分开，是必要的指标改进。

因此，Stage 0 可以验收；Stage 1 的结构性改动不需要回滚。

---

## 2. 必须纠正的科学解释

### 2.1 “0/80 超过 5cm”不能推出“没有重做任务”

当前总结多处写道：

> 物体没有移动超过 5cm，因此“模型重复执行任务 / 尝试重做任务”的解释被推翻。

这个推论不成立。

物体位移衡量的是**执行结果**，不是**动作意图或尝试**。模型可能完整执行：

```text
接近物体 → 下降 → 合爪 → 抬升 / 搬运
```

但由于水平瞄偏、接触失败或抓空，最终物体仍然没有移动 5cm。

现有 Action Causality Trace 已经给出直接反例：satisfied 条件下，模型会下降到抓取高度、产生合爪命令并执行抓取式轨迹，只是水平误差更大而没有抓到。

因此允许写：

> 80 个 scene-edited satisfied episode 中，没有一个成功地把任务实体移动超过 5cm；多余动作通常没有形成有效的任务状态改变。

不允许写：

> 模型没有尝试重做任务；“重做任务”已被排除。

`summary.md`、`01_metric_audit.md`、`to_codex.md` 中所有类似表述都要更正。

### 2.2 1cm、2cm、5cm 是严重度曲线，不是“是否交互”的真值边界

不能把 5cm 设成新的 UTIR 主阈值，更不能用：

```text
UTIR@5cm 的 CI 下界 > 0
```

作为是否进入 plan2 的门槛。

原因：5cm 衡量“是否造成较大任务状态改变”，会漏掉：

- 接触但没有推动；
- 抓取尝试但抓空；
- 把物体移动 1–4cm；
- 短暂改变关节后又恢复；
- 高风险但没有成功造成位移的动作。

裁决：保留完整 displacement curve，但将其命名为：

```text
Task-State Displacement Severity Curve
```

不要把整条曲线都叫 UTIR。

### 2.3 暂停使用单一 UTIR 总指标

当前 contact 通道完全未测量，`compute_utir()` 却返回 `measured=True`，容易让读者误以为“无位移 = 无交互”。

应拆成至少三层：

1. `UMR`：机器人是否明显运动；
2. `TaskContactRate`：机器人是否与任务实体接触；
3. `TaskStateDisplacementRate(τ)`：任务实体或任务关节是否产生超过 τ 的状态改变；
4. `GDR`：目标是否被破坏。

在 contact 尚未实现前，只能报告：

```text
displacement-based task-state change
```

不能称为完整的 task interaction rate。

### 2.4 “路径长度 / 最大位移”不能单独区分安全撤离与重做任务

该比值只能区分：

- 接近单向运动；
- 明显往返 / 游移。

但一次直线接近物体的重抓尝试同样可能有 `path/max ≈ 1`；一次曲线安全撤离也可能大于 1。

Stage 2 必须额外记录：

- EEF 到 subject 的初始、最小、最终距离；
- EEF 到 target 的初始、最小、最终距离；
- 是否先靠近 subject，再远离 subject；
- 首次明显接近 subject 的步号；
- 首次合爪命令及合爪步数；
- 与 subject / target 的 contact；
- 距离 home / terminal capture EEF 的轨迹；
- 目标 predicate 和 task entity 状态随时间的变化。

判读应是：

```text
safe retreat: 与任务实体距离大体单调增加，且无重新接近、无 task contact
reattempt:     明显重新接近任务实体，并伴随合爪 / 接触 / task-directed phase
wandering:     多次方向反转或 path/max 很高，但无稳定任务阶段
```

路径比值只能作为其中一个特征。

---

## 3. 代码审查发现的修正项

### 3.1 路径长度漏掉起点到第一步

`LiberoArena.mark_episode_start()` 把 `_prev_signal` 设为 `None`，所以第一次 `step()` 只建立参考点，不累计“episode 起点 → 第一步”的路径。

MockArena 也有同样问题。

修正：`mark_episode_start()` 时就把 `_prev_signal` 初始化为起点的 EEF、gripper、subject；新增单步动作回归测试，验证一次移动的 path length 不为 0，且等于该步位移。

### 3.2 `task_joint_change` 的名字和实现不一致

字段文档声称是“累计绝对变化”，实现却是：

```text
abs(final_joint - start_joint)
```

这会漏掉“先改变关节再恢复”的重执行行为。

修正为两个独立字段：

- `task_joint_max_displacement`：相对起点的最大绝对偏离；
- `task_joint_path_length`：逐步绝对变化之和。

不要用同一个 `task_joint_change` 同时表达二者。

### 3.3 gripper threshold 单位不一致

`gripper_change` 来自真实 finger qpos，历史完整开合的变化约为 `0.05`，而阈值写成 `0.2`，并注释成“归一化单位”。因此当前 gripper 物理通道几乎永远不会触发。

修正方向：

- 把“模型是否命令合爪”作为独立 command 指标；
- 把 finger qpos 物理变化作为独立 physical 指标；
- 不得沿用 `0.2` 同时解释两者；
- 物理阈值应通过已知 OPEN→CLOSE 阳性对照标定，并输出敏感度曲线。

Stage 2 smoke 前至少要完成单位审计和命名修正。

### 3.4 GDR 的 measured 逻辑仍不完整

plan1 要求“没有 post-completion probe 时，GDR 必须标为未测量”。当前只修了 `post_completion_steps`，`compute_gdr_v2()` 仍会把无 probe 的初始 satisfied episode 算成 GDR=0。

修正：为每条记录加入明确的 `post_completion_probe_measured`，或使用无歧义的等价字段；GDR 只在存在有效破坏观察窗口时计算。

新增测试：初始 satisfied + probe 未执行 → GDR `measured=False`。

### 3.5 task-joint 阈值不能跨任务统一解释

抽屉 slide joint 的单位是米，炉钮 hinge joint 的单位是弧度。统一 `0.01` 没有跨任务物理意义。

修正：记录 joint range，并报告：

```text
normalized_joint_change = abs(Δq) / (q_max - q_min)
```

阈值按归一化变化或 task-specific tolerance 定义。

### 3.6 `utir_curve` 的命名与逻辑会在新记录上产生歧义

当前曲线提高的是 object threshold，但 joint threshold 固定为 0.01。未来只要 articulated episode 的 joint change 超过 0.01，它会在所有 object threshold 上始终记为 1。

修正：

- placement 单独画 object displacement curve；
- articulated 单独画 normalized joint displacement curve；
- contact 单独报告；
- 不把不同物理量塞进同一横轴曲线。

### 3.7 文档与产物索引存在轻微过期

需要统一更新：

- 当前测试是 `99 passed`，不是部分文件中的 97；
- `summary.md` 中 `metric_audit.json` 哈希与 `artifacts_manifest.md` 最终哈希不一致；
- Stage 1 最终代码哈希以远端当前文件为准；
- 不得宣称“19 个测试覆盖 §7.4 全部要求”，因为无 probe GDR 的测试缺失。

---

## 4. 下一阶段裁决

### 4.1 B1：Stage 2 smoke 条件放行

裁决：**原则上批准，但必须先完成 §3 的代码修正。**

修正完成、测试通过、日志更新后，可执行：

```text
4 task × 2 seed = 8 个 natural-terminal generation + replay pairs
```

不批准直接运行 40 或 80 对 full run。

### 4.2 B2：“60% → 100%”

裁决：接受撤回正式比较。

Control A 的视频和日志可以保留为历史诊断材料，但 `6/10` 不能作为与主实验同口径的正式数字。Stage 2 将规范重做该实验。

### 4.3 B3：articulated 通道

裁决：必须在 Stage 2 smoke 中验证，但要先按 §3.2、§3.5 修正为最大偏离、累计路径和归一化 joint range；不能继续使用当前单一 `task_joint_change`。

### 4.4 contact 通道

裁决：**Stage 2 smoke 前实现**，不是推迟到 Stage 3。

理由：Stage 2 的核心就是判断自然终态之后发生了安全撤离、重新接近、接触、抓取尝试还是游移。没有 contact，无法回答核心问题。

为了保持与旧记录可比，报告同时给：

- displacement-only 指标（旧数据可比）；
- contact-aware 指标（仅新数据，明确标注 coverage）。

### 4.5 自然终态截取标准

smoke 采用以下预注册规则，不允许看结果后调整：

#### Placement tasks

连续 10 个 env steps 满足：

- overall goal predicate=True；
- subject 线速度 `< 0.01 m/s`；
- subject 角速度 `< 0.10 rad/s`；
- gripper 已释放：finger qpos 接近该环境的 open reference，或两指绝对开度均 `> 0.03`；

优先使用“接近 open reference”的归一化判据；`0.03` 只作当前 LIBERO 版本的 fallback，并记录实际值。

#### Articulated tasks

连续 10 个 env steps 满足：

- overall goal predicate=True；
- task joint 归一化速度低于阈值；
- task joint 没有继续向目标端显著变化；

速度阈值先用官方 timestep 下等价于 joint range 每秒 1% 的归一化阈值，并在 smoke 报告中输出原始分布，不得静默调参。

### 4.6 Stage 顺序

裁决顺序：

```text
修正 Stage 1 实现
→ Stage 2 natural-terminal smoke（8 pairs）
→ 暂停，导师复审
→ Stage 4 intermediate completed-subgoal pilot
→ 再决定 Stage 2 full / Stage 3 matched pair 的规模与顺序
```

理由：Stage 2 smoke 用于理解自然终态动作语义；Stage 4 才能处理 terminal 无监督这一根本混淆。不能在 Stage 2 smoke 后直接消耗 8–13 小时跑 full，而跳过判决性更强的 intermediate pilot。

---

## 5. Plan2 进入标准的修订

拒绝使用 `UTIR@5cm > 0` 作为 plan2 门槛。

进入最小 STOP/ACT gate 的证据应由以下组合决定：

1. 自然终态中存在明显的 re-approach、grasp command、contact、wandering 或其他不必要执行模式；或
2. intermediate completed-subgoal 中存在 completed-subgoal re-execution；并且
3. 正常 unsatisfied / full-task 条件下模型能力前提成立；
4. 该行为有可避免的时间、路径、接触、目标扰动或安全成本；
5. 不是单纯由 scene-edit spatial OOD 解释。

大幅物体位移和 GDR 是严重度证据，但不是唯一立项门槛。

---

## 6. DeepSeek 下一次提交要求

继续执行前，先提交以下更新：

1. 修正后的代码与新增测试；
2. 更新 `01_metric_audit.md`、`summary.md`、`to_codex.md` 中的过度结论；
3. 更新最终测试数与 SHA256；
4. Stage 2 smoke 的状态机设计和 JSON schema；
5. contact 归属映射与阳性/阴性测试；
6. 单步 path length 测试；
7. 无 probe GDR 未测量测试；
8. joint max/path/normalized change 测试；
9. gripper command 与 physical qpos 的单位审计。

上述检查通过后可直接执行 Stage 2 smoke；完成 8 pairs 后必须再次暂停，不能自动进入 full run。

---

## 7. 导师当前结论

Stage 1 最有价值的发现不是“原课题被推翻”，而是：

> 原始 UER 混合了运动、尝试、接触和任务状态改变；必须把 execution attempt 与 execution outcome 分开测量。

这反而强化了 Learning Not to Act 的研究必要性：我们不仅要判断机器人有没有动，还要判断它是否重新进入了任务执行程序、是否发生了接触、是否造成状态改变，以及这些行为是否有净收益。

