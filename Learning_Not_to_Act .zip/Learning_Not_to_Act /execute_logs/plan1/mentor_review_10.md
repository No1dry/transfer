# Mentor Review 10：Full Pilot 运行中检查

> 结论：I1 smoke 机制证据通过；I2 button anchor provenance 通过，I2 seed0 可标为 `no_decisive_approach / neither` 的单例。增强 gate 足以放行完整 pilot，正在运行的作业无需中断。  
> 注意：完整 pilot 的在线 JSON 与 coverage 字段不能直接作为最终结果，必须从 trace 离线重算。

## 1. 已确认

- I1 B seed0 确实回到 soup 的 A-state 旧位置并在附近合爪；
- I2 distance/contact provenance 均来自 `flat_stove_1_button` joint body；
- I2 B seed0 到 button 最近约 18.9cm，到 moka 最近约 16.6cm，未进入预注册 15/10/5cm approach 区间；
- I2 B 没有合爪、button joint path、button contact 或 subgoal-2 progress；
- policy/no-op step0、A-orig、completed-start、contact coverage 等语义 gate 通过；
- full pilot 启动在既有授权范围内。

I2 的准确说法应为：

> No decisive approach event was detected under the preregistered 15/10/5cm thresholds; the policy neither re-executed the button subgoal nor progressed to the moka-pot subgoal in this seed.

不要把它扩写成模型完全没动或没有任何方向性；连续量显示它仍向两者靠近约 14–16cm，只是没有进入有效执行距离。

## 2. 运行时源码版本问题

当前运行进程通过环境变量：

```text
PILOT_OUT=results/plan1/intermediate/pilot_full
```

写入 `pilot_full/`，但磁盘当前 `scripts/plan1_stage4_pilot.py` 的 `OUT` 已固定为 `pilot_v2/`，没有读取 `PILOT_OUT`。

这说明作业启动后源码被改过，进程内加载的是较早版本。

处理要求：

- 不因此中断当前运行；
- 在 execution log 中记录该事实；
- 记录作业启动时间、当时已知改动（coverage 去重修复前）；
- 当前运行产物以 trace 为权威；
- 运行结束后修复脚本，使输出目录成为显式 `--out` 参数，而不是隐式环境变量；
- 后续任何复跑先冻结 source hash，再启动。

## 3. 完整 pilot 结束后的硬要求

1. 不直接引用在线 `contact_coverage.complete`；用修正后的 gate 从 trace 重算；
2. 写独立 offline analyzer，真正调用 `compute_stage4_events()` 从每条 trace 重算，并与在线 JSON 比对；
3. 输出 mismatch 清单；任何核心 event mismatch 都必须解释；
4. 明确分母：20 个 policy episodes + 20 个 no-op controls，不要统称 40 个实验样本；
5. A 条件只作为正常行为模板，不纳入 re-execution / skip rate；
6. B 条件按 task 分别报告：correct_skip / reexecution / mixed / neither / ambiguous；
7. 报 overall SR、subgoal disturbance、first target、steps to SG2；
8. 保留 approach 连续量和 5/10/15cm 敏感度；
9. paired seed 明细必须可追溯到 trace 和视频；
10. 运行完成后暂停，不进入训练。

## 4. 当前执行决定

让 `p1pilotfull` 继续完成。完成后由 DeepSeek生成离线汇总、运行增强 gate，并提交 review；在此之前不做最终研究判断。

