# mentor_review_10 回应：运行时版本问题确认 + 完整 pilot 重启

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_10.md`
> 状态：**§2 的源码版本问题已确认并已按要求处理；发现并修复了 pilot 中断的真实原因；
> 完整 pilot 已用 5-seed 配对重启。**

---

## 1. §1 I2 的措辞：接受

按你给的精确表述记录（已写入本文档与后续报告口径）：

> No decisive approach event was detected under the preregistered 15/10/5cm
> thresholds; the policy neither re-executed the button subgoal nor progressed
> to the moka-pot subgoal in this seed.

并且**不扩写**成"模型完全没动或没有方向性" —— 连续量显示它仍向两者靠近
约 14–16 cm，只是没进入有效执行距离。

---

## 2. §2 源码版本不一致：**确认成立**，并已定位成因

### 2.1 事实核对

```
磁盘脚本 OUT = ROOT / "results/plan1/intermediate/pilot_v2"   ← 不含 PILOT_OUT
运行进程   通过 PILOT_OUT=... 写入 pilot_full/               ← 进程内是较早版本
```

### 2.2 成因（是我的操作失误）

`PILOT_OUT` 支持是我**只在远端**用一次性 python 脚本加上的（没有同步回本地）。
后来我为修 coverage 去重 bug 从**本地**重新上传 `plan1_stage4_pilot.py`，
**把远端那份带 PILOT_OUT 的版本覆盖掉了**。

所以：运行中的进程加载的是"含 PILOT_OUT、未含去重修复"的版本；
磁盘上的是"含去重修复、不含 PILOT_OUT"的版本。两者确实不一致。

补充一个更严重的同类问题：我随后本地加 `--out` 时，
replace 的目标串（`--task` 那一行）只存在于远端，**replace 静默没匹配**，
我却以为改好了 —— 第一次重启因此报 `unrecognized arguments: --out`。
**根因是"replace 不校验匹配"**，已在这次修正里对每处替换都加 `assert`。

### 2.3 按你的要求处理

| 要求 | 落实 |
|---|---|
| 不因此中断当前运行 | ✅ 当时未中断（该作业后来因**别的原因**结束，见 §3） |
| 在 execution log 记录该事实 | ✅ 已写入 |
| 记录作业启动时间与当时已知改动 | ✅ 旧作业 `p1pilotfull` 启动于 coverage 去重修复**之前**，含 PILOT_OUT、不含去重修复 |
| 当前运行产物以 trace 为权威 | ✅ 已确认 trace 本身正确（`contact_container` 逐行非空） |
| 运行结束后把输出目录改为显式 `--out` | ✅ 已实现 `--out` / `--pairs`，并**保留 PILOT_OUT 回退**同时生效 |
| 后续复跑先冻结 source hash | ✅ 本轮重启前记录了脚本 SHA256（见 §5） |

---

## 3. ⚠️ 旧作业其实**没有跑完**（这是我查出来的新事实）

你 review 10 写的是"让 p1pilotfull 继续完成"。我去核对时发现它**已经结束，而且只跑了 16/40 条**：

```
  ... 共 16 条 rollout（I1 s0/s1、I2 s0/s1 各 4 条）
  ERROR: FileNotFoundError:
    pairs_v2/states/KITCHEN_SCENE3_..._moka_pot_on_it__s2__A.npy
```

**原因**：`pairs_v2` 只构造了 **seed 0 和 1** ——
配对构造脚本里写死了 `for seed in range(2)`，而 pilot 需要 seed 0–4。
于是跑到 I2 的 seed 2 时找不到配对 state 就退出了。

**这不是覆盖率 bug 造成的，也不是被中断的，是配对数据不足。**

### 3.1 顺带证实了 coverage 去重 bug 的诊断

那 16 条里：

```
I1 全部 8 条 cov=False     ← I1 有 container 列，被 required+optional 重复计数
I2 全部 8 条 cov=True      ← I2 没有 container，不触发重复计数
```

与我在 review9 response §8 给出的诊断**完全一致**，可以确认定位无误。

### 3.2 一个需要你注意的早期信号（仅作提示，不作结论）

那 16 条里 I1 出现了**异质**结果：

```
I1 B/policy s0: 521 步  ok=False  verdict=reexecution  target=completed_A_orig
I1 B/policy s1: 304 步  ok=True   verdict=mixed        target=completed_A_orig
```

即 **B 条件并非一律失败**：seed 1 是成功的，且被判为 `mixed`。
**n=2，我不据此下任何结论**，只是提醒完整 pilot 的结果可能不是单一模式。

---

## 4. 已完成的修复

1. **配对构造支持任意 seed 数**：`PAIR_SEEDS` 环境变量（默认 2）。
   已用 `PAIR_SEEDS=5` 重建，**2 tasks × 5 seeds = 10 个配对全部 `pair_valid=True`**
   （A: F/F/False；B: T/F/False；robot_same / wl_valid / noop_stable 全 True）。
2. **输出目录改为显式 `--out`**（§2 要求），并新增 `--pairs`、`--task`；
   同时保留 `PILOT_OUT` 回退，避免再出现"进程与磁盘不一致"。
3. **所有 patch 加 `assert`**，防止 replace 静默失配再次发生。

---

## 5. 完整 pilot 已重启（冻结 hash 后启动）

```
$ sha256sum scripts/plan1_stage4_pilot.py
  <见 execution.log 的 source_hash 记录>

$ ./submit.sh p1pilotfull ./run_diag.sh scripts/plan1_stage4_pilot.py \
      --seeds 5 --out results/plan1/intermediate/pilot_full
STARTED pid=3166311
```

规模：2 tasks × 2 conditions × 5 seeds × {policy, noop}
= **20 个 policy episodes + 20 个 no-op controls**（按你 §3.4 的分母口径，
不统称"40 个实验样本"）。

**状态：运行中，尚未完成。** 因此本轮仍报不出 §3 要求的汇总表。

---

## 6. §3 的 10 条硬要求：我逐条确认理解，待运行结束后执行

| # | 要求 | 我的执行方式 |
|---|---|---|
| 1 | 不引用在线 `contact_coverage.complete` | gate 已改为**从 trace 重算** coverage |
| 2 | 独立 offline analyzer 调用 `compute_stage4_events()` 重算 | 将写 `scripts/plan1_stage4_offline.py` |
| 3 | 输出 mismatch 清单并解释 | 同上，逐 episode 比对在线 JSON |
| 4 | 分母：20 policy + 20 no-op | 报告中显式分列 |
| 5 | A 只作模板，不入 re-exec/skip rate | 代码里 A 已返回 `None` |
| 6 | B 按 task 分别报 5 分类 | `behavior_verdict` |
| 7 | 报 SR / disturbance / first target / steps to SG2 | 待 analyzer |
| 8 | 保留 approach 连续量 + 5/10/15cm 敏感度 | 已在 trace/事件里 |
| 9 | paired seed 明细可追溯到 trace 与视频 | 每条 episode 都记 `trace` / `video` 路径 |
| 10 | 完成后暂停，不进入训练 | ✅ |

**在完整 pilot 跑完并提交 review 之前，不做最终研究判断**（§4）。

---

## 7. 一个环境记录

本轮开始时发现远端连接辅助脚本 `/tmp/rsh.sh`、`/tmp/rsh.env`、askpass
已被系统清理。我重建了它们，并且这次**把口令改为只从环境变量传入、不写入任何文件**
（plan1 §4 要求）—— 三个文件里 grep 口令均为 0 次命中。

GPU 空闲；测试 183 passed。
