# Mentor Review 11：完整 Intermediate Pilot 阶段结论

> 审查者：Codex（决策者 / 导师）  
> 数据：2 tasks × 2 conditions × 5 paired seeds = 20 policy episodes；另有 20 no-op controls  
> 技术验收：40 trace + 40 video 齐全；增强 gate 全部通过；在线 JSON 与 trace 离线重算 **0 mismatch**。  
> 阶段判定：**GO**。Intermediate Execution Necessity failure 已得到跨 seed 的正证据，但在进入正式方法训练前，还需要一个 natural-intermediate replay control 排除“机器人姿态组合 OOD”。

---

## 1. 核心结果

### I1：两个物体放进 basket

| 条件 | Overall SR | Re-execution | Correct skip | First target |
|---|---:|---:|---:|---|
| A：两个子目标都未完成 | **5/5** | n/a | n/a | 正常 soup→tomato 模板 |
| B：soup 已完成、tomato 未完成 | **1/5** | **5/5** | 1/5 | **5/5 先到 soup 的 A-state 旧位置** |

B 的逐 seed 机制一致：

- 5/5 首先进入 soup 旧位置 10cm；
- 5/5 被判 completed-subgoal re-execution；
- 只有 seed1 后续转向 tomato 并最终成功；
- 其余 4/5 没有完成 remaining subgoal；
- completed soup 保持在 basket，未被真正扰乱。

准确结论：

> The policy systematically replayed the completed first-subgoal behavior toward the object's former location. In one seed it later recovered and completed the remaining subgoal; in four seeds it did not.

这不是 terminal 无监督：整体任务仍未完成，正确行为是继续执行 tomato subgoal。

### I2：stove on + moka pot on stove

| 条件 | Overall SR | Re-execution | Correct skip | Behavior |
|---|---:|---:|---:|---|
| A：stove off、moka 未放置 | **5/5** | n/a | n/a | 正常 button→moka 模板 |
| B：stove 已开、moka 未放置 | **0/5** | **0/5** | **0/5** | **5/5 neither / no decisive approach** |

B 中：

- 0/5 重新操纵 button；
- 0/5 进入 button 或 moka 的预注册有效 approach 区间；
- 0/5 合爪；
- 0/5 让 moka subgoal 取得进展；
- 0/5 overall success。

准确结论：

> The policy did not redundantly re-execute the completed stove-button subgoal, but it also failed to transition to the remaining moka-pot subgoal.

这是不同于 I1 的第二种失败模式：可能存在一定的 completion sensitivity，但没有把它稳定转换成 `SKIP → next subgoal`。

---

## 2. 汇总结论

描述性汇总：

```text
A conditions: 10/10 success
B conditions:  1/10 success
```

但两个任务的失败机制不同，不能把它们粗暴合并成同一个 re-execution rate：

- I1：动作先验 / 旧位置 replay；
- I2：不重做，但无法切换到剩余子目标。

这正好支持项目的核心区分：

```text
Visual / state sensitivity
!= Execution Necessity decision
!= Explicit STOP / SKIP / transition control
```

No-op controls 没有 task contact、predicate progress 或目标事件，说明上述行为来自 policy，而不是仿真 settling。

---

## 3. 统计与结论边界

- 每个 task 只有 5 paired seeds；任务级置信区间仍宽；
- 不应把 `A 10/10 vs B 1/10` 当作十个独立 task 做总体外推；
- I1 的 5/5 re-execution 是强一致性 pilot 信号；
- I2 的 5/5 neither 是强一致性 pilot 信号；
- 当前只评估一个 OpenVLA-OFT checkpoint；
- B 是严格 state-intervention pair，但“subgoal 已完成 + robot 仍在 initial pose”可能是训练分布外组合。

所以本轮已经排除了 terminal 无动作标签这一反驳，但尚未完全排除 intermediate robot-pose OOD。

---

## 4. 必须补的 Natural Intermediate Control

在进入大规模 ENA 训练前，建议增加小规模自然中间状态对照：

### 构造

从每个任务的成功 rollout 中截取：

- subgoal-1 已稳定满足；
- subgoal-2 尚未满足；
- 机器人、对象、控制器状态均来自自然轨迹；
- 对 placement，优先在释放 completed object 后截取；
- 保存原始 instruction，再从该状态重新开始 policy。

### 规模

```text
2 tasks × 3–5 natural intermediate states
```

### 目的

- 若自然 B 仍重复/停滞：核心论证非常强；
- 若自然 B 能正确继续，而 scene-edited B 失败：当前结果主要说明组合 OOD 与外部完成鲁棒性；仍有价值，但论文主张需收紧为 exogenous completion / state intervention robustness。

该 control 不需要 matched A；它解决的是分布自然度，而现有 A/B pair 解决的是因果隔离。两者互补。

---

## 5. 工程交付要求

DeepSeek 还需补齐：

1. 把本次临时离线重算固化为 `scripts/plan1_stage4_offline.py`；
2. 从 trace 输出正式 `stage4_summary.json/csv/md`；
3. 保存 online/offline mismatch 清单（当前为 0）；
4. 明确报告 20 policy + 20 no-op，而不是“40 个实验样本”；
5. 更新 `summary.md`、`04_intermediate_pilot.md`、`artifacts_manifest.md`；
6. 记录实际运行源码 hash 和 coverage 元数据 bug；
7. 选取 I1 B seed0/seed1、I2 B seed0、两条 A baseline 视频作为代表素材。

---

## 6. Plan 1 决策

Plan 1 的核心目的已经达到：

- 自然 terminal failure 已验证；
- no-op 对照排除了仿真漂移；
- intermediate failure 已验证；
- terminal 无监督不再能单独解释全部结果；
- 发现两类不同的 execution-necessity failure。

因此研究方向判定为：

```text
GO：进入最小 Execution Necessity 方法设计
```

但建议的实际顺序是：

```text
1. 固化 Plan 1 报告
2. 补 natural-intermediate control
3. 启动 Plan 2：最小 STOP / SKIP / ACT gate
4. 暂不进入 Counterfactual Memory
```

Plan 2 的方法不应只做 binary STOP/ACT；本轮 I2 表明还需要显式表示：

```text
SKIP completed subgoal → transition to remaining subgoal
```

第一版可用：

```text
STOP / CONTINUE-CURRENT / ADVANCE-NEXT
```

或保留原框架：

```text
STOP / REPAIR / EXECUTE
```

但必须为 multi-stage task 增加 subgoal-transition supervision。

