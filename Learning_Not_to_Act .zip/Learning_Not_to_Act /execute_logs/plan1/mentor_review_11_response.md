# mentor_review_11 回应：Stage 4 工程交付完成

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_11.md`
> 状态：**§5 的 7 项工程交付全部完成。** 接受 GO 判定与下一步顺序。

---

## 1. 我先独立复核了你的核心数字

用自己写的离线分析器（从 trace 重算，不看在线 JSON）复核，与你的表**完全一致**：

| task | cond | n | Overall SR | Re-execution | Correct skip | first target |
|---|---|---:|---:|---:|---:|---|
| I1 | A | 5 | 5/5 | n/a（模板） | n/a | `ambiguous/simultaneous` ×5 |
| **I1** | **B** | 5 | **1/5** | **5/5** | 1/5 | **`completed_A_orig` ×5** |
| I2 | A | 5 | 5/5 | n/a（模板） | n/a | `ambiguous/simultaneous` ×5 |
| **I2** | **B** | 5 | **0/5** | **0/5** | **0/5** | **`no_approach` ×5** |

**online/offline 核心事件 mismatch = 0。**

---

## 2. 一个你的表格里没有、但很有力的量

离线分析器把 §3.8 要求的 approach 连续量摊开后，I1-B 出现了一个**干净的分离**：

| 目标 | step0 中位 | min 中位 | 穿越 5cm | 穿越 10cm | 穿越 15cm |
|---|---:|---:|---:|---:|---:|
| soup 的 **A 原位置** | 0.272 | **0.031** | **4/5** | **5/5** | 5/5 |
| soup 的**当前**位置（篮内） | 0.317 | 0.130 | **0/5** | **0/5** | 5/5 |
| tomato（remaining） | 0.224 | 0.065 | 2/5 | 3/5 | 4/5 |

> **模型在 4/5 个 seed 里进入"旧位置"5cm 以内，却一次都没有进入"当前位置"5cm 以内。**

这不是"两边都靠一靠、精度不够"，而是**明确指向旧位置**。
`min 中位 0.031 m` vs `0.130 m` 也说明：它到旧位置是**真的接近到可抓距离**，
到当前位置则始终停在 13cm 外。

我建议这条作为 I1 结论的主要量化支撑 —— 它比"5/5 re-execution"更难被反驳，
因为它给出的是连续量的分离，而不是阈值化标签。

（另注：I2 的 `approach_completed_A_orig` 与 `approach_completed_current` 相同 ——
因为炉钮是原地旋转，A 原位置与当前位置本来就只有 1.9cm 差，符合物理。）

---

## 3. §5 的 7 项工程交付

| # | 要求 | 状态 |
|---|---|---|
| 1 | 固化为 `scripts/plan1_stage4_offline.py` | ✅ 已建，**真正调用 `compute_stage4_events()`** 从每条 trace 重算 |
| 2 | 从 trace 输出正式 `stage4_summary.{json,csv,md}` | ✅ 三份齐全，均标注"由 trace 离线重算" |
| 3 | 保存 online/offline mismatch 清单 | ✅ **0 mismatch**，写入 `stage4_summary.json` |
| 4 | 明确 20 policy + 20 no-op | ✅ 汇总首行即写明"**不要统称 40 个实验样本**" |
| 5 | 更新 `summary.md` / `04_intermediate_pilot.md` / `artifacts_manifest.md` | ✅ 三份都已更新 |
| 6 | 记录运行源码 hash 与 coverage bug | ✅ `summary`、`04`、`manifest` 均记录 |
| 7 | 选取代表素材视频 | ✅ 5 条已列在 `04_intermediate_pilot.md` §7 |

### 3.1 交付细节

**`stage4_summary.md`**（正式汇总，markdown 表格）：

```
| task | cond | n | Overall SR | Re-execution | Correct skip | Disturbed | first target |
| I1   | A    | 5 | 5/5        | n/a (A 只作模板) | n/a        | 5/5       | {'ambiguous/simultaneous': 5} |
| I1   | B    | 5 | 1/5        | 5/5             | 1/5        | 0/5       | {'completed_A_orig': 5} |
| I2   | A    | 5 | 5/5        | n/a             | n/a        | 0/5       | {'ambiguous/simultaneous': 5} |
| I2   | B    | 5 | 0/5        | 0/5             | 0/5        | 0/5       | {'no_approach': 5} |
```

汇总里同时包含：**表2** A 条件模板（sg1/sg2 首次达成中位：
I1 142/265、I2 84/234）、**表3** no-op 对照（task_contact / reexec / SR 全 0）、
**表4** approach 敏感度三档。

**运行源码 hash**（本地 = 远端，运行时冻结）：

```
509e79df44a0d718  scripts/plan1_stage4_pilot.py
c2521b4c115de2be  scripts/plan1_stage4_offline.py
```

**coverage 元数据 bug** 已按 §5.6 记录在两处：
`contact_container` 同时进了 required 与 optional，被按出现次数重复计数成 `2n`，
`2n != n` 于是被判 missing → I1 全部 `cov=False`。
修法是计数前去重；并且 gate 的 coverage 检查已改为**从 trace 重算**。

**代表视频**（`pilot_full/videos/`）：

- I1 B s0（旧位置 replay 且失败）
- **I1 B s1（唯一成功，判 mixed）**
- I2 B s0（neither / no approach）
- A baseline ×2（I1 / I2）

---

## 4. 接受 §6 的顺序与 Plan 2 的形态建议

```text
1. 固化 Plan 1 报告          ← 本轮已做
2. 补 natural-intermediate control
3. 启动 Plan 2：最小 STOP / SKIP / ACT gate
4. 暂不进入 Counterfactual Memory
```

**Plan 2 不应只做 binary STOP/ACT** —— 你的判断我完全同意，而且本轮数据给了直接理由：

- 如果只有 STOP/ACT，I1-B 的失败会被读成"没停"，但真实问题是
  **它在执行一个已经不需要执行的子目标**（且方向还是旧位置）；
- I2-B 的失败则是**该前进时没前进**。这两种用同一个二分类头都表达不出来。

所以第一版至少需要你列的
`STOP / CONTINUE-CURRENT / ADVANCE-NEXT`（或原框架的
`STOP / REPAIR / EXECUTE` + **subgoal-transition supervision**）。

---

## 5. 待你确认

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | natural-intermediate control 的截取判据 | 建议沿用 §2.1 的口径（subgoal-1 稳定满足 + subgoal-2 未满足 + 已释放 completed object），并在跑之前预注册稳定窗口 |
| 2 | 该 control 用多少 seed | 建议每任务 3 个（与你 §4 的下界一致），先看方向再决定是否加 |
| 3 | 是否要我把 I1-B 的 approach 分离（§2 上表）补进正式汇总 md | 建议补（它比阈值化标签更硬） |

**未启动**：Stage 2 Terminal Full、Stage 3 Matched Pair full、ENA Head、
Counterfactual Memory、natural-intermediate control。
GPU 空闲；测试 183 passed。
