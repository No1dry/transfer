# Mentor Review 12：Plan 1 工程验收与 Natural-Intermediate Control

> 结论：Stage 4 完整 pilot 工程交付通过；Plan 1 核心判定为 GO。  
> 下一步：补 2 tasks × 3 natural intermediate states，随后结束 Plan 1 并进入 Plan 2 设计。

## 1. 验收结论

- 20 policy episodes + 20 no-op controls 齐全；
- 40 trace + 40 video 齐全；
- 增强 gate 全通过；
- online/offline 核心事件 mismatch = 0；
- 离线 summary JSON/CSV/MD 齐全；
- paired states、能力门槛、predicate provenance 均已审计；
- 没有进入训练或 memory。

Stage 4 的正式结果可以接受。

## 2. I2 文案修正

I2 B：

```text
button：0/5 进入 15/10/5cm
moka：3/5 进入 15cm，0/5 进入 10/5cm
close：0/5
sg2 progress：0/5
success：0/5
```

因此准确表述是：

> The policy showed weak directional approach toward the moka pot in some seeds, but never entered the preregistered 10cm execution zone, issued a close command, or advanced the remaining subgoal.

不要写成“三档都没有 approach”或“完全无方向运动”。

## 3. Natural-Intermediate Control 设计

### 3.1 规模

```text
I1 × 3 official seeds
I2 × 3 official seeds
```

### 3.2 状态生成

从正常成功 rollout 中自然截取：

```text
subgoal-1=True
subgoal-2=False
overall=False
```

I1 额外要求：

- soup predicate 连续 10 步为 True；
- soup 速度稳定；
- gripper 已释放 soup；
- tomato predicate仍为 False。

I2 额外要求：

- turnon 连续 10 步为 True；
- button joint 稳定；
- moka predicate仍为 False。

保存：

- flattened state；
- step 0 observation；
- robot pose / velocity；
- controller refresh provenance；
- subgoal predicates；
- capture 前完整 trace；
- completed object 的 A 原位置。

### 3.3 两个分支

每个捕获状态运行：

1. `natural continuation`：原 episode 继续，确认该状态能够通向成功；
2. `restart replay`：从保存状态重新加载、清 action queue、重新下达同一完整指令。

必要时增加 no-op，只用于稳定性检查。

### 3.4 判读

```text
continuation 成功 + restart 失败
    -> restart / chunk-boundary / controller reset 敏感，需要单独解释

continuation 成功 + restart 仍重复或停滞
    -> 很强的 execution-necessity failure

restart 正确进入 subgoal-2
    -> scene-edited B 的失败主要来自机器人姿态组合 OOD；
       论文主张收紧为 exogenous completion robustness
```

### 3.5 记录要求

沿用 Stage 4 trace schema 和离线 event analyzer，额外记录：

- capture step；
- 是否处于 action chunk 中间；
- capture 后剩余 chunk 长度；
- restart 首次 query step；
- continuation / restart 的 first target、sg2 progress、overall SR；
- I1 是否回旧位置；
- I2 是否回 button / 转向 moka。

## 4. 执行顺序

```text
1. 写 natural-intermediate 脚本和 capture tests
2. 每任务 seed0 smoke
3. smoke 通过后扩到每任务 3 seeds
4. 离线汇总
5. 更新 Plan 1 总结
6. 暂停，准备 plan2.md
```

Natural control 完成前不启动模型训练。

