# mentor_review_12 回应：Natural-Intermediate Control（smoke 结果）

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_12.md`
> 状态：**§2 文案已修正；§3 脚本与捕获测试已写；§4.2 smoke 已跑完，
> 结果指向"组合 OOD"分支；§4.3 的 3-seed 扩展正在跑。**

---

## 1. §2 I2 文案修正：已改

`04_intermediate_pilot.md` §2.2 已按你的精确表述替换，并补上计数：

```
button：0/5 进入 15/10/5cm
moka  ：3/5 进入 15cm，0/5 进入 10/5cm
close ：0/5
sg2 进展：0/5
success：0/5
```

并显式写明**不要**写成"三档都没有 approach"或"完全无方向运动"。

---

## 2. §4.2 smoke 结果：**指向"组合 OOD"分支**

```
$ ./run_diag.sh scripts/plan1_natural_intermediate.py --seeds 1
  I1 s0: cap@225 mid_chunk=True | continuation ok=True | restart ok=True
  I2 s0: cap@185 mid_chunk=True | continuation ok=True | restart ok=True
```

| | scene-edited B（5 seeds） | **natural restart（1 seed）** |
|---|---|---|
| **I1** | 1/5 成功；5/5 re-execution；first target = **旧位置** | **成功**，`correct_skip`，first target = **remaining** |
| **I2** | 0/5 成功；0/5 re-execution；`neither` | **成功** |

### 2.1 I1 的细节（这是最关键的一条）

```
capture        : step 225，sg1=1 sg2=0 overall=0，mid_chunk（剩 7 步）
continuation   : 成功（原 episode 不打断）
restart        : 成功，96 步，correct_skip，first target = remaining
  approach_remaining          min=0.014  穿越 5cm @step 26，10cm @step 18
  approach_completed_A_orig   min=0.207  从未穿越 10cm
```

**注意对比**：scene-edited B 里 `approach_completed_A_orig` 是 4/5 穿越 5cm、
`approach_remaining` 只是 3/5 穿越 10cm；而 natural restart 里**完全反过来** ——
先接近 remaining（5cm 内，14mm），从不接近旧位置（最近 20.7cm）。

按你 §3.4 的判读矩阵，这落在**第三支**：

> restart 正确进入 subgoal-2
>     -> scene-edited B 的失败主要来自机器人姿态组合 OOD；
>        论文主张收紧为 exogenous completion robustness

**即：I1 那条"照旧位置重放"的强机制主张，在自然中间状态下没有复现。**
这正是一个 control 该起的作用 —— 它把一个我原本准备写强的结论压了回去。

### 2.2 I2 的细节

```
capture      : step 185，sg1=1 sg2=0 overall=0，mid_chunk（剩 7 步）
restart      : 成功，38 步
  approach_remaining  min=0.075  但 crossing=None（step0 已在 10cm 内）
```

⚠️ 这里暴露出我的判据一个缺陷，**已修**：
`correct_skip` 原本要求"阈值外→内穿越"（§6.1）。但**自然截取时机器人可能本来就在**
remaining 的执行距离内（刚在灶台边放完东西），此时不会发生穿越 ——
于是行为正确却被判成 `neither`。

修法：`_skip_ok()` 接受两种情形之一（发生穿越 **或** step0 已在阈内），
仍要求 subgoal-1 未被破坏且 overall 成功。
新增 2 个单测（`test_correct_skip_when_already_inside_at_step0` /
`test_already_inside_but_failed_is_not_correct_skip`）。测试 **185 passed**。

---

## 2.3 ★ 3-seed 完整结果（§4.3）

```
I1 s0: cap@225 | continuation ok=True | restart ok=True | correct_skip | target=remaining
I1 s1: cap@164 | continuation ok=True | restart ok=True | correct_skip | target=remaining
I1 s2: cap@147 | continuation ok=True | restart ok=True | correct_skip | target=remaining
I2 s0: cap@185 | continuation ok=True | restart ok=True | correct_skip | target=no_approach
I2 s1: cap@189 | continuation ok=True | restart ok=True | correct_skip | target=no_approach
I2 s2: cap@195 | continuation ok=False| restart ok=False| neither      | target=no_approach
```

### 与 scene-edited B 的对照

| task | scene-edited B（5 seeds） | **natural restart（3 seeds）** |
|---|---|---|
| I1 | **1/5** 成功；5/5 re-execution；target = 旧位置 | **3/3 成功**；3/3 `correct_skip`；target = remaining |
| I2 | **0/5** 成功；0/5 re-execution；`neither` | **2/3 成功**（第 3 例 **continuation 也失败**） |

### 判读：落在 §3.4 的**第三支**

> restart 正确进入 subgoal-2
>     -> scene-edited B 的失败主要来自机器人姿态组合 OOD；
>        论文主张收紧为 exogenous completion robustness

**结论：Stage 4 那条强主张（"模型缺少 execution necessity 判断 / 照旧位置重放"）
在自然中间状态下没有复现。**

- I1 是最干净的：3/3 自然重启都**正确跳过**并完成 remaining；
  而 scene-edited B 里 5/5 奔向旧位置。
- I2 的 2/3 成功也支持同一方向；剩下 1 例要注意：
  它 **continuation 与 restart 都失败**，即**未打断的原 episode 本身也没做完**
  —— 所以它**不是** restart 造成的，按 §3.4 应当**单列**，
  不能算作"restart 失败"的证据。

### 这意味着什么

Stage 4 的 `B 条件 1/10 vs A 条件 10/10` 这个差距，
**主要由"subgoal 已完成 + 机器人仍在初始位姿"这个组合的分布外性质解释**，
而不是由"模型不会判断该不该继续执行"解释。

论文主张需要按你 §3.4 收紧为：

> **exogenous completion / state intervention robustness**

仍然是有价值的结论（模型对外部把子目标做完这件事鲁棒性不足），
但比"缺少 execution necessity 判断"小一号，且不能再声称"旧位置 replay 是普遍机制"。

---

## 3. 我现在**不**下的结论

n=1/任务。按 §3 的判读矩阵，smoke 的**方向**是清楚的，但：

- 我不能说"I1 的 scene-edited 失败已确定为组合 OOD"——需要 3 seeds 确认；
- 我也不能说"I2 的失败与 OOD 无关"——I2 的 smoke 虽然成功，
  但它是**唯一一个 38 步就成功**的 case，也可能只是这个 seed 好做；
- **Stage 4 的强主张（execution-necessity failure）目前处于"待定"状态**，
  取决于 3-seed 结果。

如果 3 seeds 都是 restart 成功，那么论文主张需要按你 §3.4 收紧为
**exogenous completion / state intervention robustness** ——
这仍然是有价值的结论（模型对"外部把子目标做完了"这件事鲁棒性不足），
但比"模型缺少 execution necessity 判断"小一号。

---

## 4. §3 的实现对照

| §3 要求 | 实现 |
|---|---|
| §3.1 规模 I1×3 + I2×3 | 正在跑（`--seeds 3`） |
| §3.2 捕获判据：sg1=T / sg2=F / overall=F | ✅ 三者同时要求 |
| I1 额外：soup predicate 连续 10 步 True | ✅ `STABLE_WINDOW=10` |
| I1 额外：soup 速度稳定 | ✅ 自由关节线速度 `< 0.01 m/s` |
| I1 额外：gripper 已释放 soup | ✅ `gripper_current_open_frac() > 0.75` |
| I2 额外：turnon 连续 10 步 + button joint 稳定 | ✅ 关节速度 `< 0.01` |
| 保存 flattened state / step-0 obs / robot pose+vel | ✅ state 存 `.npy`；obs 与姿态在 trace step 0 |
| 保存 controller refresh provenance | ✅ 经 `set_state()` 的 refresh 路径（含 `physics_not_advanced=0` 验证） |
| 保存 capture 前完整 trace | ✅ `continuation` trace 从 step 1 起完整 |
| 保存 completed object 的 A 原位置 | ✅ `completed_A_orig_xyz` 三列 |
| §3.3 两分支 continuation / restart | ✅ 都跑；restart 会 `policy.reset()` 清 queue 并重下同一指令 |
| §3.5 记录 capture step / mid-chunk / 剩余 chunk / first query | ✅ 都在 JSON 里（smoke 两条都是 `mid_chunk=True, chunk_left=7`） |

> ⚠️ **一个需要你注意的 confound**：smoke 两条的 capture **都发生在 action chunk 中间**
> （各剩 7 步）。所以 continuation 是"chunk 中途继续"，而 restart 是"chunk 边界重启"。
> 你 §3.4 第一支正是为这种情况准备的（"restart / chunk-boundary 敏感，需单独解释"）。
> 目前 continuation 与 restart **都成功**，所以这个 confound 还不构成问题；
> 但如果 3-seed 里出现"continuation 成功而 restart 失败"，就必须按第一支解释。

---

## 5. 待办（按 §4 顺序）

```
1. 写脚本与捕获测试          ✅ 完成
2. 每任务 seed0 smoke        ✅ 完成（结果见 §2）
3. 扩到每任务 3 seeds        ⏳ 正在跑 (p1natfull)
4. 离线汇总                  ⏳ 待跑
5. 更新 Plan 1 总结          ⏳ 待做
6. 暂停，准备 plan2.md       ⏳
```

**Natural control 完成前不启动模型训练**（§4 末句），已遵守。
GPU 正在跑 natural_full；测试 185 passed。
