# Mentor Review 13：Natural-Intermediate Control 审查

> 结论：Natural control 的方向清楚，但“3/3 I1 + 2/3 I2”口径不严格。按官方预算和 continuation eligibility，当前有效样本是 I1 2 条、I2 2 条；4/4 restart 都正确跳过并完成。  
> 科学含义：scene-edited B 的失败主要来自 exogenous completion 与 robot-pose 组合 OOD；“模型普遍缺少 execution-necessity reasoning”的强主张不成立，需要收紧。

## 1. 有效样本重新定义

Natural control 的前提是：

```text
被截取状态位于一个在官方预算内能够自然完成的 rollout 上
```

### I1

- seed1：原始 rollout / continuation 在官方预算内成功；restart 成功；有效。
- seed2：原始 rollout / continuation 在官方预算内成功；restart 成功；有效。
- seed0：`gen_success=False`，脚本在官方 520 步结束后又继续执行，最终 `continuation_n_steps=583` 才成功；不满足原定“正常成功 rollout”前提。

因此 I1 正式分母是：

```text
2 eligible natural states；2/2 restart correct skip + success
```

### I2

- seed0：continuation 成功；restart 成功；有效。
- seed1：continuation 成功；restart 成功；有效。
- seed2：continuation 与 restart 都失败；属于基线轨迹失败，不能用于判断 restart / necessity。

因此 I2 正式分母是：

```text
2 eligible natural states；2/2 restart correct skip + success
```

合计：

```text
4 eligible natural intermediate states；4/4 restart 正确进入 remaining subgoal 并成功
```

不能再写 I1 3/3。

---

## 2. 脚本中两个需要修正的问题

### 2.1 Continuation 超预算

generation 已经运行到 MAX_STEPS 后，若失败，脚本又从 `cap_step+1` 继续循环，导致总轨迹超过官方预算且 step 编号重复。

修正：

- generation 本身就是 uninterrupted continuation；
- `cont_rows = gen_rows[capture_index:]`，以 capture row 作为 continuation step0；
- 不在 MAX_STEPS 后额外追加动作；
- continuation success 只按 official budget 判断。

### 2.2 Continuation event profile 包含捕获前动作

当前 `cont_rows=list(gen_rows)`，包含正常执行 subgoal-1 的前半段，却用 condition B 计算事件，因此 continuation 被错误标成 reexecution / disturbed。

修正：

- continuation trace 从 capture state 开始；
- capture row 重编号为 step0；
- 只分析 capture 之后的行为。

### 2.3 Restart trace 缺真正 step0

restart 当前在第一步 action 后才 append。

修正：reload + mark_episode_start 后，执行 action 前 emit step0；沿用 Stage 2/4 的 state-observation guard。

---

## 3. 当前仍然可信的证据

尽管 trace 口径需修，以下方向不依赖错误的 continuation event 标签：

### I1 eligible states

- 2/2 restart success；
- 2/2 first target = remaining；
- 2/2 不回 soup 旧位置；
- 2/2 不扰动 completed soup；
- 2/2 正确完成 tomato。

### I2 eligible states

- 2/2 restart success；
- 2/2 capture 时已经在 moka 执行距离内；
- 2/2 不重新操作 button；
- 2/2 完成 moka subgoal。

所以最稳妥的结论是：

> In naturally occurring intermediate states from successful rollouts, all eligible restart cases correctly continued to the remaining subgoal. The failures observed in scene-edited matched states therefore appear to be driven primarily by the counterfactual combination of completed subgoal state and initial robot pose.

---

## 4. 研究主张的调整

当前数据不支持：

> OpenVLA-OFT generally cannot infer that a completed subgoal should be skipped.

当前数据支持：

> OpenVLA-OFT can continue correctly from natural in-trajectory completion states, but is brittle when task progress is externally altered while the robot remains in an incongruent pose. This reveals poor robustness to exogenous completion and counterfactual state interventions.

这仍然与 Learning Not to Act 有关，但核心问题从“普遍没有 necessity reasoning”收紧为：

```text
是否能在 demonstration correlation 被打破时，
根据当前目标状态重新决定该执行、跳过还是停止。
```

这其实更具体，也更可防守。

---

## 5. 下一步要求

1. 修复 natural script 的 continuation budget / trace slicing / restart step0；
2. 不覆盖本轮产物，输出 `natural_v2/`；
3. 至少运行 5 个 attempted seeds / task，不替换失败 seed；
4. 按 eligibility 分开报告：capture success、continuation success、restart success；
5. 对 eligible cases 报 restart skip / reexecution；
6. 更新 Plan 1 最终总结，明确 scene-edited 与 natural 的相反结果；
7. 完成后 Plan 1 收尾，开始编写 `plan2.md`。

Plan 2 方法应针对：

- exogenous goal/subgoal completion；
- counterfactual scene–robot pose combinations；
- STOP / SKIP / ADVANCE 决策；
- false-stop 与正常 continuation 保持。

暂不引入 Memory。

