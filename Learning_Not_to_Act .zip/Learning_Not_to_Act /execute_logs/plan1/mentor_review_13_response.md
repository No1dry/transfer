# mentor_review_13 回应：natural_v2 完成 —— 强主张正式收紧

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_13.md`
> 状态：**§2 三个 trace bug 已修；§5.3 已跑 5 seeds/task；§5.4/§5.5 按 eligibility 报告。
> 结果确认你的 §4 主张调整。**

---

## 1. §1 eligibility 重新定义：接受，并已用脚本强制执行

你说得对，我之前写的 "I1 3/3" 口径不严。
根因正是 §2.1 的 bug：generation 跑到官方 520 步后，我又从 `cap_step+1`
续跑，把 I1 seed0 拉到 **583 步**才"成功" —— 那条 rollout
**不满足"在官方预算内自然完成"**的前提。

现在 eligibility 由脚本自动判定（`eligible = continuation_success`），
不再手写分母。

---

## 2. §2 三个 trace bug：已修

| 编号 | 问题 | 修法 |
|---|---|---|
| §2.1 | continuation 超预算（583 步、step 号重复） | **generation 本身就是 uninterrupted continuation**；删掉额外的续跑循环；`cont_rows = gen_rows[cap_idx:]` |
| §2.2 | continuation trace 含捕获前的 subgoal-1 执行段，却用 condition B 算事件 → 被误标 reexecution | continuation trace **从捕获行切片**，且把该行**重编号为 step 0** |
| §2.3 | restart trace 缺真正 step 0（首步 action 之后才 append） | reload + `mark_episode_start` 后、**动作之前** emit step 0 |

修正后的证据：I1 s0 现在正确显示 `continuation ok=False`（而不是旧的"583 步成功"）。

---

## 3. §5.3 结果：5 seeds/task，按 eligibility 报告

```
$ ./run_diag.sh scripts/plan1_natural_intermediate.py --seeds 5 \
      --out results/plan1/intermediate/natural_v2
```

| task | attempted | **eligible** | cont ok | **restart ok** | **skip** | reexec | first_target |
|---|---:|---:|---:|---:|---:|---:|---|
| I1 | 5 | **4** | 4 | **4** | **4** | 0 | `remaining` ×4 |
| I2 | 5 | **4** | 4 | **4** | **4** | 0 | `no_approach` ×4 |
| **合计** | 10 | **8** | 8 | **8/8** | **8/8** | **0** | — |

**ineligible 的 2 例**（按 §1 规则排除，**未替换 seed**）：

- `I1 s0`：continuation 未在官方预算内成功；
- `I2 s2`：continuation 与 restart 都失败 —— 基线轨迹失败，不能用于判断 necessity。

### 3.1 与 scene-edited B 的对照（**相反结果**）

| task | scene-edited B | **natural restart（eligible）** |
|---|---|---|
| I1 | **1/5** 成功；**5/5 reexecution**；target = **旧位置** | **4/4 成功**；**4/4 correct_skip**；target = **remaining** |
| I2 | **0/5** 成功；0/5 reexecution | **4/4 成功**；**4/4 correct_skip** |

**8/8 eligible 自然重启都正确跳过已完成的子目标并完成 remaining，
0/8 出现 reexecution。**

---

## 4. §4 主张调整：确认

**当前数据不支持**：
> OpenVLA-OFT generally cannot infer that a completed subgoal should be skipped.

**当前数据支持**（你的措辞，我完全同意）：
> OpenVLA-OFT can continue correctly from natural in-trajectory completion states,
> but is brittle when task progress is externally altered while the robot
> remains in an incongruent pose. This reveals poor robustness to exogenous
> completion and counterfactual state interventions.

核心问题收紧为：

```text
是否能在 demonstration correlation 被打破时，
根据当前目标状态重新决定该执行、跳过还是停止。
```

我认同这**更具体也更可防守**。Stage 4 建立的 harness（配对构造、语义 gate、
trace 离线复算、no-op 对照、natural control）全部可复用于这个新问题。

---

## 5. 工程备注：本轮我犯的两个错

1. **`Counter` 未导入** —— 主脚本在**写 JSON 之前**崩了，
   `natural_intermediate.json` 没落盘。
   好在 **trace / state / video 全部已落盘**，所以我写了
   `scripts/plan1_natural_offline.py` **从 trace 重算**出完整结果表
   （`natural_offline_summary.{json,csv}`）。
   这也顺带再次验证了"在线值崩了也不影响结论"这条原则。
2. **我第一次的 block 替换把 `finally: arena.close()` 一起删掉了**，
   导致语法错误；已修回并逐处确认两个 `finally` 都在。

### 一个我观察到、但**未**据此改判据的点

`continuation` 与 `restart` 的**步数预算不对等**：
continuation 用的是 generation 剩余预算（捕获在 147–225 步，
即只剩 295–373 步），而 restart 从捕获点起拿到**全新 520 步**。
`I1 s0` 正是这种情况（cont 失败但 restart 成功）。

按 §1 的 eligibility 规则它已被排除，所以不影响结论；
但如果将来要直接比较两个分支的成功率，**必须先把预算对齐**。
我把它记在这里，供 plan2 设计参考。

---

## 6. §5 待办状态

| # | 要求 | 状态 |
|---|---|---|
| 1 | 修 continuation budget / trace slicing / restart step0 | ✅ 完成 |
| 2 | 不覆盖旧产物，输出 `natural_v2/` | ✅ 旧 `natural_full/` 保留 |
| 3 | 至少 5 attempted seeds/task，不替换失败 seed | ✅ 5/5，2 例 ineligible 保留 |
| 4 | 按 eligibility 分开报 capture / continuation / restart | ✅ 脚本自动判定并输出 |
| 5 | 对 eligible cases 报 restart skip / reexecution | ✅ 4/4 + 4/4，reexecution 0 |
| 6 | 更新 Plan 1 最终总结，明确 scene-edited 与 natural 的相反结果 | ✅ 完成（见 §7） |
| 7 | Plan 1 收尾，开始写 `plan2.md` | ✅ 完成（见 §8） |

**Plan 2 方法应针对**（你的 §5 末段，我认同）：
exogenous goal/subgoal completion；counterfactual scene–robot pose combinations；
STOP / SKIP / ADVANCE 决策；**false-stop 与正常 continuation 保持**。
**暂不引入 Memory。**

未启动任何模型训练。GPU 空闲（2 MiB / 24564 MiB，0% util）。

---

## 7. §5.6 完成：Plan 1 最终总结已更新

改动文件与内容：

| 文件 | 改了什么 |
|---|---|
| `summary.md` | 头部执行状态改为"Plan 1 收尾"；§2 未完成表按实际更新（Stage 2 smoke / Stage 4 已完成，**Stage 2 full / Stage 3 未启动**）；§7 新增第 7、8 条可写结论；**§8 新增第 8/9/10 条禁止结论**（含最重要的一条撤回）；新增 **§14 Natural Intermediate Control**（含 14.2 相反结果表、14.3 主张收紧、14.4 三个 trace bug、14.5 判定） |
| `04_intermediate_pilot.md` | §0 一句话结论加入 natural 结果；**§6 由"尚未排除的替代解释"改写为"已执行，确认为主因"**（6.3 结果、6.4 相反结果表 + I1 连续量对照、6.5 `no_approach` 同名不同义陷阱、6.6 判定、6.7 两个记录未改判据点）；§5 边界加入 natural 与"不得写'模型不会 skip'"；§9 状态更新 |
| `artifacts_manifest.md` | 头部快照与修订历史更新；§1 汇总计数改为实测（**411 / 283**）；§6 未开始清单更新；§10 诚实清单新增 `natural_full` 作废、`natural_v2` 缺 generation 视频、2 例 ineligible；§11 补入 `natural_v2` 目录树、汇总口径、**缺 generation 视频的说明**、两个新脚本 hash |

### §8 里最重要的一条撤回（原文）

```text
❌ "OpenVLA-OFT 普遍无法判断已完成的子目标应当被跳过"
   —— 本轮最重要的撤回（mentor_review_13 §4）。
   natural intermediate control 显示：从自然轨迹截取的同一中间状态，
   8/8 eligible 全部正确跳过并成功、0/8 重做。
   因此只能写"在外部改变了任务进度、而机器人位姿与之不匹配时脆弱"。
```

同时新增两条防误用条目：**不得把 scene-edited 与 natural 当重复平均**、
**I2 的 `no_approach` 标签不得跨条件并列引用**。

### 一个必须留给 plan2 的口径债

`natural_v2` 只保存了 restart 视频（10 个）。
continuation 按 §2.1 被定义为 generation 的切片，因此没有单独渲染
（generation 阶段未落盘帧）。关键分支视频齐全，但**这个缺口我没修**——
补它需要重跑 10 次 generation，属于新的 GPU 消耗，
按 §12 的暂停规则我不自行启动，已写入 `artifacts_manifest.md` §10 诚实清单。

---

## 8. §5.7 完成：Plan 1 收尾，`plan2.md` 已起草

新文件：**`plan/plan2.md`**（执行者起草，等待你裁决，不构成自行进入 plan2）。

### 结构

```text
§0  出发点（Plan 1 已确认事实 + 当前成立/不成立的主张
     + 唯一未解混淆：Plan 1 的 EXO vs NAT 同时变了三件事）
§1  Q1 决定性因子 / Q2 强基线能否解决 / Q3 决策接口 / Q4 失败机制
§2  范围（做 7 项；不做 Memory、不微调 VLA、不训 ENA Head）
§3  execute_logs/plan2/ + results/plan2/ 目录规范
§4  安全规则（沿用 Plan 1，新增"在线量必须可离线复算""每 run 存视频"）
§5  Stage 0 冻结 + engagement 度量修正 + Mini-PAB-D（纯离线）
§6  Stage 1 ★ 2×3 因子实验（决定性）
§7  Stage 2 强基线（B1 re-prompt / B2 oracle router / B3 视觉抑制）
§8  Stage 3 最小 state-only gate（含训练可行性 gate F1–F3）
§9  Stage 4 false-stop / continuation 保持
§10 判读决策树   §11 暂停条件   §12 表格   §13 提交格式   §14 一句话目标
附  执行者 3 点提醒
```

### 三个我认为最关键的设计点

1. **把 Plan 1 的三重混淆变成 2×3 因子**（§6）：
   因子 A = 完成状态来源 `NAT-obj` / `EXO-obj`；
   因子 B = 机器人位姿来源 `same-traj` / `other-traj` / `official-init`。
   6 格里 **2 格复用 Plan 1 产物**（`natural_v2`、`pilot_full` B），
   **4 格是新的**。预测**跑之前写死**：H-pose / H-exo / H-both / H-neither。
   我的先验偏 H-pose，理由写在 §6.2（I2 根本没回头看已完成对象却依然失败）。

2. **`B1` re-prompt 必须做**（§7）：它是本项目当前最大的反驳风险 ——
   如果"把指令换成剩余子目标"就好了，整条 execution-necessity 叙事要重写。
   判读写死：B1 通过 → 转向 goal representation；B2 通过而 B1 失败 →
   gate 是正确靶子；B2 也失败 → 靶子错了，转向 re-anchoring。

3. **训练可行性必须先查**（§8.2）：我已现场确认**远端没有 I1/I2 的演示数据**
   （`libero_cm2/data/libero_cm2/` 只有 3 个**其他任务**的 hdf5，
   `libero_10` 目录为空）。所以默认路线是
   **冻结 OpenVLA-OFT 特征 + 轻量 probe**（每个状态一次前向，
   200–500 状态约 5–15 分钟 GPU），标签由 simulator predicate 自动给，
   **不微调 VLA 主体**。

### 顺手为 §6 备好的任务备选（纯 BDDL 解析，未跑仿真）

`libero_10 ∪ libero_goal` 中 goal 谓词 ≥2 的任务共 **9/20**：

```
3  KITCHEN_SCENE8_put_both_moka_pots_on_the_stove
     [turnon flat_stove_1, on moka_pot_1, on moka_pot_2]   ← 3 谓词，可做多子目标
2  KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it   （= I2）
2  LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket （= I1）
2  LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket
2  LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket
2  LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate
2  LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate
2  KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it
2  KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it
```

Plan 1 只有 2 个任务，这是最大的外推弱点；上面这些可组成
"双物体同容器" / "前置条件+放置" / "有序序列" 三族，用于 Stage 1 扩容
（需先过 plan1 §10.4 的能力门槛 ≥70%）。

---

## 9. 本轮结束状态

```text
Plan 1：✅ 收尾（总结 / 中间报告 / 产物清单 全部更新）
Plan 2：📝 已起草 plan/plan2.md，等你裁决
GPU  ：空闲
训练 ：未启动任何模型训练
```

**暂停，等待你的下一步指令。** 我不会自行开始 Plan 2 的任何 GPU 运行。
