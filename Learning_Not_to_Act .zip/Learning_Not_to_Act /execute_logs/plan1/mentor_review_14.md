# Mentor Review 14：Plan 1 收尾验收与 Plan 2 草案裁决

> 裁决：**Plan 1 的实验结果验收通过；Plan 2 方向正确，但当前草案需要 major revision，暂不批准启动 GPU 实验。**  
> 当前允许事项：修正文档、重写 `plan2.md`、执行只读核对。不得自行进入 Stage 1，也不得训练 probe。

## 1. Plan 1 收尾验收

我已直接抽查服务器上的：

```text
/HUBU-AI004/zp/ICML/results/plan1/intermediate/natural_v2/
```

`natural_offline_summary.json` 与回应中的汇总一致：

| task | attempted | eligible | continuation success | restart success | correct skip | reexecution |
|---|---:|---:|---:|---:|---:|---:|
| I1 | 5 | 4 | 4/4 | 4/4 | 4/4 | 0/4 |
| I2 | 5 | 4 | 4/4 | 4/4 | 4/4 | 0/4 |
| 合计 | 10 | 8 | 8/8 | 8/8 | 8/8 | 0/8 |

两个 ineligible seed 被保留且没有替换；I1 seed0 的 continuation failure、I2 seed2 的 baseline failure 也与记录一致。主脚本末尾因漏导入 `Counter` 而没有写总 JSON，属于工程错误，但 trace/state/video 已先落盘，离线脚本从原始 trace 重算出了结果，因此不影响这次科学结论。无需为了补 generation 视频重跑 Plan 1。

Plan 1 的最终结论应固定为：

> OpenVLA-OFT 在自然成功轨迹的中间状态上能够继续完成剩余子目标；失败集中在任务进度与机器人状态被反事实重组的场景。现有证据说明它对这种 task-progress intervention / state-distribution shift 很脆弱，但不支持“模型普遍不会跳过已完成子目标”。

### 1.1 收尾前必须修正的一处文字错误

下列表述不成立：

```text
“同一中间状态、同一指令、同一 checkpoint，只差状态是外部构造还是自然产生”
```

自然组与 scene-edited 组并不是同一个当前状态：机器人位姿、物体配置、相机画面以及它们的联合分布都不同。对于无历史的策略，如果当前输入真的逐位相同，“自然产生/外部产生”这一 provenance 本身不可能被模型观察到，也就不可能成为因果变量。

请修正以下位置及同义表述：

- `execute_logs/plan1/summary.md`；
- `execute_logs/plan1/04_intermediate_pilot.md`（若存在同义句）；
- `plan/plan2.md`。

`execute_logs/plan1/to_codex.md` 与 `mentor_review_13_response.md` 属于历史记录，保持原样；在本轮 response 中追加 erratum，明确旧措辞作废，不回写历史日志。

应改为：

```text
同一任务、同一指令、同一 checkpoint，在两类“subgoal-1 已满足、subgoal-2 未满足”
状态分布上出现相反结果；两类状态同时在 robot pose、task-object configuration
及其联合关系上不同，因此尚不能归因给单一因素。
```

## 2. Plan 2 草案中应保留的部分

以下方向是对的：

1. 先做干预因子分解，再决定是否做方法；
2. 把 re-prompt / oracle remaining-goal prompt 放在训练方法之前；
3. 单独评估 false stop 与正常 continuation；
4. 暂不引入 Memory，不微调 OpenVLA-OFT 主体；
5. 所有在线量可由 trace 离线复算，并保留失败样本；
6. Stage 1 与 Stage 2 结束后设置暂停点，由结果决定后续路线。

这说明研究没有偏离，但论文问题必须表述为：

```text
Can a VLA re-decide execution necessity from the current state when task progress
and robot phase are decoupled from the demonstration distribution?
```

“Learning Not to Act”仍可作为总标题；现阶段不能再把贡献预设成“VLA 不会停/不会跳过”。

## 3. Plan 2 的六个阻塞问题

### 3.1 `NAT/EXO source` 不是可识别的因果因子

当前 §6 把因子 A 写成“完成状态来源：NAT-obj / EXO-obj”。这只能表示**数据生成方式**，不是 state-only VLA 可观察的变量。真正能被干预和比较的是当前状态中的可观察分量。

请把 2×3 设计重写成：

```text
因子 O：task/environment configuration
  O_nat   = 自然 capture 的非机器人状态分量
  O_edit  = predicate-valid 的编辑状态分量

因子 R：robot phase/pose
  R_cap   = 本 seed 自然 capture 时的机器人状态
  R_donor = 另一成功轨迹在相同 predicate transition 附近的机器人状态
  R_init  = 官方初始机器人状态
```

在同一个 `(task, seed)` 上固定 O、只换 R，或固定 R、只换 O，才有可解释的 paired contrast。所有六格都应按**实际分量名**命名，禁止把 `O_edit/R_cap` 写成“same-traj”或“位姿匹配”，因为编辑状态没有一条产生它的自然轨迹。

必须增加：

- O 与 R 的精确 state-index 白名单；
- donor 选择规则在跑前写死；
- EEF 到 completed/remaining object、gripper、碰撞、predicate stability 等连续量，用来描述“congruence”，不能只靠来源标签宣布一致/不一致；
- 主分析用同 seed 的 paired contrasts：`R_cap vs R_init`、`O_nat vs O_edit` 及其 interaction；
- `R_donor` 用来区分“必须是逐位同源配对”还是“只要处于正确 task phase 即可”。

当前 §6.2 的 H-pose/H-exo/H-both/H-neither 精确成功格局也要删除或降级。n 很小，而且 `R_donor` 未必不一致，不能用预设的全成/全败模式硬分类。可以预注册**对比方向**，不能预注册未经测量的 congruence 标签。

### 3.2 2×3 不能声称“拆开了三个混淆”

当前设计最多分解：

1. robot phase/pose；
2. task/environment configuration；
3. 二者交互。

“旧位置参考”没有作为独立因子被操纵，因此 §0.3、§14 和相关文字不得声称已把它彻底拆开。旧位置锁定应作为 I1 的**机制诊断**：继续报告到 canonical/original location 的距离；若要做因果验证，另设一个小型 location-sweep，改变 completed object 的可行终点或 canonical 起点，并保持其他因素不变。它不应混进主 2×3 的命名。

### 3.3 B1 与 B2 在当前两任务上实际上等价

当前定义：

- B1：手工把 prompt 改成“只做剩余子目标”；
- B2：oracle predicate 选出第一个未满足子目标，再只下该指令。

I1/I2 在测试状态里都只剩一个子目标，所以两者第一次下给 VLA 的文本相同。由此不可能可靠地区分“re-prompt 通过、oracle 不同结果”，当前 §7.3 的决策树不成立。

请改成：

| baseline | 是否使用 predicate oracle | 正确定义 |
|---|---|---|
| B0 original | 否 | 原始完整指令 |
| B1 non-oracle structured prompt | 否 | 保留所有子目标，并加入“检查当前场景，只执行未完成目标；全部完成则停止”的通用指令/结构化列表 |
| B2 oracle remaining-goal prompt | 是 | 用 simulator predicate 删除已完成子目标，只把剩余目标交给 VLA；这是执行上界 |
| B2b closed-loop oracle router | 是 | 仅在有两个及以上 remaining goals 时有额外意义；predicate 翻转后重路由 |

正确判读应是：

```text
B2 失败              → 即使目标已给对仍无法执行，靶子是 re-anchoring / recovery，不是 gate。
B2 成功、B1 失败     → 缺口可能在无 oracle 的 completion estimation / routing。
B1 成功              → 通用 prompt scaffolding 已足够，先把它作为最小方法，不应急着训练 probe。
```

当前 B3 “遮掉已完成对象”不能直接证明旧位置锁定：旧位置往往是空的，遮掉对象还会制造黑块 OOD，并可能遮住容器。B3 只能作为可选诊断，且必须加 equal-area irrelevant/random mask control；不能与 B1/B2 同等级解释。

### 3.4 gate 的标签、接口和训练对象尚未闭合

草案在 `ADVANCE / EXECUTE / SKIP / STOP` 之间切换，但没有定义 gate 判完以后怎样真正驱动 VLA。建议不要直接训练三分类 ENA head，而是定义为：

```text
f(current deployable observation, one subgoal text) -> P(subgoal satisfied)

router:
  对每个子目标估计 satisfied / unsatisfied
  跳过 satisfied
  从合法的 unsatisfied 集合中选择一个并编译 remaining-goal prompt
  若全部 satisfied，则 STOP（不调用 policy）
```

这样“冻结特征 + 二分类 satisfaction probe + 确定性 router”才与“不训练 ENA Head”一致，也与 B2 的 oracle 上界一一对应。

必须写清：

- 推理输入只能是部署时可用的 RGB / proprio / language；不得把 simulator qpos、predicate truth 或 provenance 喂给 probe；
- subgoal list 来自固定 benchmark annotation / instruction decomposition，不能在推理时偷用 simulator predicate；
- 每个 subgoal 单独以文本条件化，才能支持可变数量子目标；
- router 在 action-chunk 边界重判；prompt 变化时清 action queue；控制器保存当前 prompt 不等于学习历史，但不得把过去观测作为模型输入；
- 先在 validation split 定阈值，test 上不得调阈值；
- rollout/seed 必须分组切分，禁止同一轨迹相邻帧分别落入 train/test；若要声称跨任务泛化，还必须有 held-out task/family。

Stage 1 的 200–500 帧若来自同两任务、同 seeds、同轨迹，只能证明 interpolation feasibility，不能作为方法泛化结果。下载 demonstrations 不是当前第一优先级；只有 Stage 2 表明 gate 是正确靶子后，才决定用自生成数据还是下载数据。

### 3.5 benchmark 的“正确决策”定义过窄

`first engaged subgoal == first unsatisfied subgoal` 会把合法行为误判为错。对于 conjunction（例如 “put both A and B ...”），多个未完成子目标可能都合法，并不天然要求按 BDDL 列表顺序执行。

改为：

```text
correct first target := first engaged target ∈ valid_unsatisfied_set
reexecution          := first/any engaged target ∈ satisfied_set
STOP correct         := valid_unsatisfied_set is empty
```

若任务确有顺序依赖，必须由语言语义或显式 dependency graph 定义 `valid_unsatisfied_set`，不能用 predicate 文件顺序代替。

另外要拆开两个概念：

- **gate false-stop**：仍有未满足目标时，router 错误输出 STOP / 把全部目标判为 satisfied；
- **policy non-progress**：router 给出了合法目标，但底层 VLA 没完成。

后者不能计入 gate false-stop，否则会把底层策略失败归咎于决策器。`Mini-PAB-D` 应分为离线 decision benchmark 与在线 routed-rollout benchmark；旧 trace 能复算原策略行为，不能替代新 gate 的在线 rollout。

`NORM` 中 `pairs_v2 A` 与 `capability` 可能是同一批状态/rollout，必须按唯一 state ID 去重，不能写成 `10 + 10` 后当 20 个独立样本。

### 3.6 规模、分母和 PASS 条件有算术/统计错误

当前 §6.4：

```text
2 tasks × 5 seeds × 6 cells = 60 policy restarts
```

不是 30。若每格都有 no-op，则是 60 policy + 60 no-op，再加 generation。Plan 1 可复用锚点是 `EXO-init` 10 条加 `NAT-congruent` 8 条 eligible，不是“12 条”；但新矩阵的 provenance/schema 若不同，旧数据只能作锚点，不能强行当成完整配对。

请预注册两套分母：

1. attempted：固定 5 seeds/task，不替换；
2. paired-eligible：同一 seed 的自然 capture 成功、六格构造与 no-op stability 均通过，才进入主 paired contrast。

不得拿不同 eligibility 的格子直接平均后归因。

`EXO SR ≥ 8/10` 的 pooled 阈值也会掩盖 I1/I2 异质性。至少同时要求并报告：

- 每个 task、每个关键 cell 的精确分子/分母；
- 相对 B0 的 paired improvement；
- 二项置信区间（描述性即可，不因 n 小夸大显著性）；
- normal-preservation 按 task 报告，不能只用总计掩盖某一任务退化。

如果最终方法声称“能 STOP”，`TERM` 不能只报不进 PASS。可以把它降为次级验收，但至少预注册 stop-rate（建议 ≥7/8）并同时报告 false-stop；否则 Plan 2 只能声称“能 skip/re-route”，不能声称“能 not act”。

## 4. 修订后的执行顺序

Plan 2 应收敛为以下决策链：

```text
P2.0  文档修正 + freeze + engagement metric + 去重后的 offline benchmark
  ↓ 导师检查
P2.1  可观察状态分量的 2×3 matched-intervention 构造
      先每任务 1 seed smoke，只验 state/provenance/no-op stability
  ↓ 导师检查
P2.2  固定 5 attempted seeds/task 的 full factorial
  ↓ 必须暂停，判断 robot phase、environment configuration 及 interaction
P2.3  B0/B1/B2 强基线；B3 仅作带 control 的可选诊断
  ↓ 必须暂停
P2.4  只有在“B2 成功、B1 失败”时，才做 satisfaction probe + router
P2.5  离线 decision + 在线 rollout + NORM/NAT/TERM preservation
```

若 B2 也失败，不得继续训练 gate；方法方向应改为 pose re-anchoring / recovery。若 B1 已成功，不得为了“必须有训练方法”而强行训练 probe，应先把 training-free prompt 方案做扎实。

## 5. DeepSeek 下一次回应必须交付

1. 修正 Plan 1 总结中的“同一状态/只差来源”错误措辞；
2. 提交修订后的 `plan/plan2.md`，逐项落实 §3.1–§3.6；
3. 在 response 中列出修改前后对应关系，不要只说“已接受”；
4. 给出修正后的 episode 数量和预计 GPU 时间；
5. 明确 P2.1 的 1-seed smoke 构造表、state-index 白名单与 paired-eligibility；
6. 在获得下一次批准前，继续保持 GPU 空闲，不运行 Plan 2 正式实验。

## 6. 当前进度判定

```text
Plan 1：实验与结论验收通过；只剩文字口径修正。
Plan 2：科学问题已找到，实验草案已成形，但因果设计和方法接口尚未闭合。
阶段位置：Plan 1 → Plan 2 的设计审查关口；尚未进入 Plan 2 执行。
```

这不是在否定课题。相反，natural 与 counterfactual 条件的反转让问题变得更有研究价值：现在要研究的不是一个容易被反例推翻的“VLA 总会多动”，而是一个更精确的问题——**当任务进度与动作阶段脱离训练分布时，模型能否仅依据当前状态重新判断哪些动作仍有必要。**
