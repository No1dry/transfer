# mentor_review_14 回应：Plan 1 文字口径修正 + Plan 2 草案 major revision

> 状态：**全部裁决已接受并执行**（文档修正 + 计划重写 + 只读核对）。
> **GPU 保持空闲；未启动 P2.1 及之后的任何运行；未训练任何 probe。**
> 修订稿：`plan/plan2.md`（v2，816 行）

---

## 0. 一句话

Plan 1 的**实验与数字**不动，只改**文字口径**；
Plan 2 的**科学问题不变**，但因果设计与方法接口按 §3.1–§3.6 **重写**：
因子从"数据生成方式"改成**可观察分量**，基线定义改成可区分，
gate 接口从三分类改成**二分类 satisfaction probe + 确定性 router**，
并把"正确决策"定义放宽、分母拆成两套、TERM 纳入次级验收。

---

## 1. §1.1 文字错误修正（已完成）

### 1.1 你指出的错误

```text
❌ "同一中间状态、同一指令、同一 checkpoint，只差状态是外部构造还是自然产生"
```

你指出它不成立，理由我完全接受：两组**当前状态并不相同**（robot pose、
物体配置、相机画面、联合分布都不同）；对无历史策略而言，
若当前输入逐位相同，provenance **根本不可观察**，不可能是因果变量。

### 1.2 已修改的位置

| 文件 | 位置 | 改法 |
|---|---|---|
| `execute_logs/plan1/summary.md` | §14.2 | 改为你的措辞，并加 **erratum 块**（标明初稿措辞作废、为什么不成立） |
| `execute_logs/plan1/summary.md` | §7 第 7 条 | 标题从"外部完成 + 位姿不匹配 → 崩溃"改为"两类中间状态分布上结果相反"，并写明**具体是 pose / configuration / 联合中的哪一项尚未识别** |
| `execute_logs/plan1/summary.md` | §8 | 新增第 10 条禁止结论："失败已归因于机器人位姿不匹配"（或"归因于外部完成"）**不得写** |
| `execute_logs/plan1/04_intermediate_pilot.md` | §0 | "exogenous completion + 位姿不匹配这个组合下的脆弱性" → "**B 这一类状态分布**上的脆弱性；两个因素尚未分开" |
| `execute_logs/plan1/04_intermediate_pilot.md` | §6 标题 | "替代解释被确认为主因" → "**失败与状态分布绑定，但因子未识别**" |
| `execute_logs/plan1/04_intermediate_pilot.md` | §6.4 后 | 加"读法限制"：两组"到旧位置的距离"**定义都不同**，是描述性对照 |
| `execute_logs/plan1/04_intermediate_pilot.md` | §6.6 | 判定收窄到"两类状态分布 → 相反结果"，并加判定边界块 |
| `plan/plan2.md` | §0.3 | 新增**术语纪律**小节，把错误措辞与正确措辞并列写死，禁止用 provenance 命名因子 |

### 1.3 历史文件按你的要求**不回写**

`execute_logs/plan1/to_codex.md` 与 `mentor_review_13_response.md` 保持原样。
旧措辞作废的声明**只在本文件**（以及 summary 的 erratum 块）中给出。

### 1.4 一处未改的同类文字（请你裁决）

`scripts/plan1_natural_intermediate.py` 的**文件头 docstring** 里有一句
"scene-edited B 的失败主要来自机器人姿态组合 OOD"。
它是**运行源码**，哈希已作为"运行时冻结"记录在 `artifacts_manifest.md` §11；
改它会让哈希失效、也无法再声称"跑的就是这份代码"。
因此我**没有动它**，在这里声明该 docstring 的因果措辞同样作废。
若你要求，我可以在不改原文件的前提下追加一份 `_note.md` 说明。

---

## 2. §3.1 因子重写（v1 → v2 对应）

### 2.1 改了什么

| 项目 | v1（错误） | v2（已改） |
|---|---|---|
| 因子 A | "完成状态来源：NAT-obj / EXO-obj" | **因子 O（task/environment configuration）**：`O_nat` / `O_edit` |
| 因子 B | "机器人位姿来源：same-traj / other-traj / official-init" | **因子 R（robot phase/pose）**：`R_cap` / `R_donor` / `R_init` |
| 格子命名 | `NAT-obj / same-traj` 等 | `O_nat/R_cap`、`O_nat/R_donor`、`O_nat/R_init`、`O_edit/R_cap`、`O_edit/R_donor`、`O_edit/R_init`（**只按分量名**） |
| 白名单 | 无（只有 `n_changed` + `unexpected=[]`） | **精确 state-index 白名单**（见 §3） |
| donor 规则 | 未定义 | **跑前写死**：`donor(s) = (s+1) mod 5`；失败则 `(s+2) mod 5`；再无则标 ineligible（不补跑、不换 seed） |
| congruence | 用"same-traj / 匹配"等**标签**宣布 | 用**连续量描述**：`d_eef_completed`、`d_eef_remaining`、`gripper_open_frac`、`contact_flags`、`noop_label_stability`、`‖R−R_cap‖₁`、`‖R−R_init‖₁`、`‖O−O_nat‖₁` |
| 主分析 | 六格各自 SR | **同 seed paired contrasts**：`C1 = O_nat/R_init vs O_nat/R_cap`（robot phase 效应）、`C2 = O_edit/R_cap vs O_nat/R_cap`（env config 效应）、`C3 = interaction`、`C4 = R_donor 落在哪一侧`（是否必须逐位同源） |

`C4` 的作用正是你要求的"区分**必须逐位同源配对**还是**只要处于正确 task phase**"：

```text
若 O_nat/R_donor ≈ O_nat/R_cap  ≫ O_nat/R_init  → 只要 phase 对
若 O_nat/R_donor ≈ O_nat/R_init                  → 需要逐位同源配对
```

### 2.2 预注册的"精确成功格局"已删除

v1 §6.2 的 H-pose / H-exo / H-both / H-neither **已删除**，替换为

```text
D1  robot phase 主导   D2  env config 主导   D3  interaction 主导
D4  两者都不影响（无差异 → 先查构造与度量）
```

理由与你一致：n 小，`R_donor` 未必真不一致，不能用预设的全成/全败模式硬分类。
**只预注册对比方向**。

我的先验（偏 D1/D3）**只在计划里标注为"仅供裁决参考、不构成结论"**，
并明确写了"不得影响判据"。

---

## 3. §3.2 "拆开三个混淆"的声称已删除 + state-index 白名单（已实测）

### 3.1 删除的声称

`plan2.md` §0.4 现在明确写：

```text
主 2×3 只分解：robot phase / env configuration / interaction
"旧位置参考"没有被作为独立因子操纵 → 不得声称已拆开三个混淆
```

**旧位置锁定降级为 I1 的机制诊断**（字段名沿用 `d_eef_completed_A_orig`），
**不进主因子命名**。若要做因果验证，另设**独立的小型 location-sweep**
（固定 `R` 与其余 O 分量，只改 completed object 的可行终点 / canonical 起点，
扫 3 个合法终点），且**不属于**主 2×3 —— 默认**暂不做**，是否执行由你定。

### 3.2 state-index 白名单（**本轮已只读实测**）

新增脚本 `scripts/plan2_state_index_map.py`（**不加载 policy、不跑 episode**），
产物 `results/plan2/state_index_map.json`。布局
`[time(1) | qpos(nq) | qvel(nv) | act(na)]`：

**I1**（nq=65, nv=57, total=123）

| 角色 | 关节 | flat qpos 下标 |
|---|---|---|
| R | `robot0_joint1..7` | `1..7` |
| R | `gripper0_finger_joint1/2` | `8, 9` |
| O（completed） | `alphabet_soup_1_joint0` | `10..16`（xyz 10–12, quat 13–16） |
| O（remaining） | `tomato_sauce_1_joint0` | `24..30` |
| O（container） | `basket_1_joint0` | `59..65` |
| O（非任务物体） | cream_cheese / ketchup / orange_juice / milk / butter | `17..23, 31..58` |

**I2**（nq=24, nv=22, total=47）

| 角色 | 关节 | flat qpos 下标 |
|---|---|---|
| R | `robot0_joint1..7` + 两指 | `1..9` |
| O（completed） | `flat_stove_1_button`（hinge, 1 维） | `24` |
| O（remaining） | `moka_pot_1_joint0` | `17..23` |
| O（非任务物体） | `chefmate_8_frypan_1_joint0` | `10..16` |
| O（container） | `flat_stove_1` **无自由关节**（固定 fixture） | — |

**预注册白名单**：

```text
R 可写 = {1..9}（两任务相同）
O 可写 = qpos 段除 {1..9} 外全部         I1: {10..65}   I2: {10..24}
主干预受控子集：
  I1: completed {10..16} ∪ remaining {24..30} ∪ container {59..65}
  I2: completed {24}     ∪ remaining {17..23}
未列出的下标在构造后必须逐位等于基准状态（unexpected_indices = []）
qvel 段同样登记与校验（脚本已输出 flat_qvel_indices）
```

P2.1 可以直接引用这张表，不需要再猜下标。

---

## 4. §3.3 基线重定义（B1≢B2）

| baseline | 用 oracle？ | v2 定义 |
|---|---|---|
| `B0` original | 否 | 原始**完整**指令 + 清 queue |
| `B1` non-oracle structured prompt | **否** | 保留**所有**子目标 + 通用指令"检查当前场景，只执行尚未完成的目标；全部完成则停止" + 结构化列表 |
| `B2` oracle remaining-goal prompt | 是 | 用 simulator predicate 删掉已完成子目标，只把**剩余目标**交给 VLA（执行上界） |
| `B2b` closed-loop oracle router | 是 | 每个 chunk 边界重判 + 重路由 + 重编译 prompt + 清 queue；**仅 ≥2 remaining 时才有额外意义** |
| `B3` completed-object suppression | 否 | **可选诊断**，必须同时跑 `B3-random`（等面积随机 mask）与 `B3-irrelevant`（等面积非任务物体 mask） |

判读按你的原文写死：

```text
B2 失败            → 靶子 = re-anchoring / recovery，不是 gate
B2 成功、B1 失败   → 缺口可能在无 oracle 的 completion estimation / routing → 才允许进 §7
B1 成功            → 先做 training-free prompt 方案，不应急着训练 probe
```

**B3 不得与 B1/B2 同等级解释**，已写进计划。

---

## 5. §3.4 gate 接口闭合

v2 §7.1 现在把接口固定成（不再在 ADVANCE / EXECUTE / SKIP / STOP 之间切换）：

```text
f(deployable observation o_t, one subgoal text s_k) -> p̂_k ∈ [0,1]

router（确定性，无学习参数）:
  S = { k : p̂_k < θ }
  if S == ∅:  STOP（不调用 policy）
  else:       k* = 预注册规则（|S|>1 时按 benchmark annotation 固定的
              demonstration-prior 顺序）
              编译成 remaining-goal prompt → policy.reset() → 交给 policy
  每个 action-chunk 边界重判；prompt 变化时清 action queue
```

并逐条落实你列的约束：

| 你的要求 | v2 落点 |
|---|---|
| 推理输入只能 RGB / proprio / language | §3.1 可观察性规则 + §7.1 约束 1 |
| 不得喂 simulator qpos / predicate / provenance | 同上；构造侧可用但**不得接进推理路径** |
| subgoal list 来自固定 annotation，不得偷用 predicate | §7.1 约束 4 |
| 每个子目标单独文本条件化（支持可变数量） | §7.1 约束 3 |
| chunk 边界重判；prompt 变化清 queue | §7.1 router 定义 |
| 保存当前 prompt ≠ 学习历史；不得把过去观测作为输入 | §7.1 约束 5 |
| validation 定阈值，test 不调 | §7.1 约束 6 |
| rollout/seed 分组切分，禁止相邻帧跨 split | §7.1 约束 7 |
| 跨任务泛化必须有 held-out task/family | §7.1 约束 8 + §7.4 |
| 同两任务同 seed 的帧只能声称 interpolation feasibility | §7.3 诚实边界（原文照录） |
| 下载 demos 不是第一优先级 | §7.3 末段：只有 P2.3 表明 gate 是正确靶子后才决定 |

**gate 接口与 B2 的 oracle 上界一一对应**：B2 = oracle `p̂`，gate = 学出来的 `p̂`。

---

## 6. §3.5 benchmark 定义放宽 + 两处 provenance 发现

### 6.1 决策定义已放宽

```text
correct first target := first engaged target ∈ valid_unsatisfied_set
reexecution          := first/any engaged target ∈ satisfied_set
STOP correct         := valid_unsatisfied_set is empty
```

`valid_unsatisfied_set` 规则：默认 **order-free**；
只有语言含显式顺序词或存在显式 dependency graph 才收缩；
**禁止**用 BDDL predicate 文件顺序代替语言语义。

两任务的预注册判定：I1 与 I2 都判 **order-free**
（I2 的 `on` 谓词本身不要求 `turnon` 先发生；demonstration-prior 顺序只作描述统计）。

**并且我验证了这个放宽不削弱 Plan 1 的结论**：
I1 的 B 条件失败是 `engaged target ∈ satisfied_set`（重做已完成对象），
I2 的 B 条件失败是**两个合法目标都没被 engagement** —— 在更宽松的定义下**依然是失败**。

### 6.2 gate false-stop 与 policy non-progress 已拆开

```text
gate false-stop     ：仍有未满足目标时 router 错误输出 STOP / 把全部目标判 satisfied
policy non-progress ：router 给了合法目标但底层 VLA 没完成  ← 不计入 gate false-stop
```

`Mini-PAB-D` 已拆成 **`/offline`（决策，可离线复算）** 与
**`/online`（routed rollout，闭环）** 两个 benchmark，明确写了
"旧 trace 能复算原策略行为，不能替代新 gate 的在线 rollout"。

### 6.3 去重（你的怀疑方向对，但结论比"重复"更严重）

我做了只读核对，结果如下 —— **`capability/` 既不是状态集合、起点也不对**：

1. **`capability/` 从来没有保存状态**：脚本只有 `save_video` 与 `json.dump`，
   **没有 `np.save`** → 它**无法**作为 `NORM` 的状态来源；
2. 它的 rollout 起点是 **"double wait"**：
   `LiberoArena.reset()` **内部已经做了 10 步官方 dummy**
   （本轮实测 `num_steps_wait_inside_reset = 10`），
   而 `plan1_stage4_capability.py` 在 reset 之后**又**跑了 10 步
   `arena.no_op_action()`（同一个官方 dummy action）→ 共 **20 步**，
   比官方语义晚 10 步；
3. 因此 `NORM` 的 n = **10**（只用 `pairs_v2 A`），
   **禁止**写成 `10 + 10 = 20`；`capability/` 只作能力门槛证据，
   并在文档中标注其起点与官方语义相差 10 步 dummy。

顺带核对：`plan1_stage4_pilot.py` 用 `set_state` 加载 A/B，
`plan1_natural_intermediate.py` reset 后直接进 policy —— **两者都没有 double wait**，
所以 `pilot_full` / `natural_v2` 的起点是正确的官方语义。

### 6.4 两套分母（预注册）

```text
denominator-1  attempted       固定 5 seeds/task，不替换
denominator-2  paired-eligible 同 seed：自然 capture 成功
                               ∧ 六格白名单 + predicate 全过
                               ∧ 每格 no-op 稳定窗口标签不变
```

只有 `paired-eligible` 的 seed 进入主 paired contrast；
**不得**拿不同 eligibility 的格子平均后归因。

---

## 7. §3.6 算术与统计修正（含修正后的数量与 GPU 时间）

### 7.1 你指出的算术错误

v1 写 `2 tasks × 5 seeds × 6 cells = 30`，**错了，应为 60**。已改：

```text
P2.2 full = 10 generations + 60 policy restarts + 60 no-op 对照
P2.1 smoke = 2 generations + 12 policy restarts + 12 no-op
```

### 7.2 Plan 1 可复用锚点的条数

v1 写"12 条"，**错**。正确是：

| 锚点 | 条数 | 来源 |
|---|---:|---|
| `O_edit/R_init` | **10** | `pilot_full` B（2 tasks × 5 seeds） |
| `O_nat/R_cap` | **8 eligible** | `natural_v2`（10 attempted，2 ineligible） |

且因 provenance / schema 不同，旧数据**只作锚点**，
**不得**并进新矩阵的 paired contrast。

### 7.3 修正后的 episode 数量总表

| 阶段 | generation | policy rollout | no-op 对照（150 步窗口） | 小计 |
|---|---:|---:|---:|---:|
| P2.0 | 0 | 0 | 0 | 离线 |
| P2.1 smoke | 2 | 12 | 12 | **26** |
| P2.2 full | 10 | 60 | 60 | **130** |
| P2.3 baselines（必做部分） | 0 | 30–60 | 0 | **30–60** |
| P2.3 保持性组 | 0 | 54 | 0 | **54** |
| P2.4 gate | 0 | 0 | 0 | 离线（≤500 帧前向） |
| P2.5 preservation / online | 0 | 48 | 0 | **48** |
| **合计** | **12** | **204–234** | **72** | **≈290–320 episodes** |

### 7.4 修正后的 GPU 时间估算

标定口径：**总 env step 数 × ≈0.5 s/step**（Plan 1 实测：
`natural_v2` 10 gen + 10 restarts = 28.7 min；`pilot_full` 20 policy + 20 no-op
= 105.8 min；`capability` 10 policy = 18.5 min；渲染 ~0.35 s/step，
policy 前向每 8 步一次）。

| 阶段 | 估算 |
|---|---|
| P2.1 smoke | **35–60 min** |
| P2.2 full | **3–4 h** |
| P2.3 baselines + 保持性 | **2–3 h** |
| P2.4 gate（特征抽取 + CPU probe） | **10–30 min** |
| P2.5 preservation / online | **1.5–2 h** |
| **合计** | **≈8–12 h GPU（±50%）** |

> **一个重要的成本决策**：no-op 对照统一用**固定 150 步稳定窗口**
> （不是整个官方预算）。60 条 × 520 步会多花约 4.3 h。
> 依据：Plan 1 的 no-op 对照在整段窗口内事件恒为 0、标签恒定，
> 150 步足以覆盖漂移检查。若你认为必须全窗口，请裁决。

### 7.5 逐任务报告与 TERM

- `EXO SR ≥ 8/10` 这种 pooled 阈值**已删除**，改为
  "**逐任务**的精确分子/分母 + 相对 B0 的 paired improvement + 二项 CI"；
- normal-preservation **逐任务**报，禁止用总计掩盖某一任务退化；
- `TERM` 从"可以不进 PASS"改为**次级验收**：
  若方法声称"能 STOP"，**预注册 `stop_rate ≥ 7/8`** 并同时报 false stop；
  否则 Plan 2 只能声称"能 skip / re-route"，**不能**声称"能 not act"。

新的 PASS 条件（v2 §8.3）：

```text
PASS =  (a) 失败格子相对 B0 有 paired improvement，且逐任务都改善
     AND (b) NORM-A 逐任务 SR ≥ 9/10
     AND (c) NAT/R_cap SR ≥ 7/8
     AND (d) gate false_stop_rate(NORM-A ∪ NAT/R_cap) ≤ 1/18
     AND (e) 若声称 STOP：TERM stop_rate ≥ 7/8
```

---

## 8. §4 执行顺序已按你的决策链重写

```text
§4  P2.0  文档修正 + freeze + engagement metric + 去重后的 offline benchmark
     ↓ 导师检查
§5  P2.1  可观察分量的 2×3 matched-intervention 构造（每任务 1 seed smoke，
          只验 state / provenance / no-op stability）
     ↓ 导师检查
§5  P2.2  固定 5 attempted seeds/task 的 full factorial
     ↓ **必须暂停**，判断 robot phase / env config / interaction
§6  P2.3  B0/B1/B2 强基线；B2b / B3（带 mask control）可选
     ↓ **必须暂停**
§7  P2.4  只有在 B2 成功、B1 失败时才做 satisfaction probe + router
§8  P2.5  offline decision + online rollout + NORM/NAT/TERM preservation
```

并把你写死的两条红线原样录入 §9 决策树与 §10 暂停条件：

- **B2 也失败 → 不得继续训练 gate**，方法方向改为 pose re-anchoring / recovery；
- **B1 已成功 → 不得为了"必须有训练方法"而强行训练 probe**，
  应先把 training-free prompt 方案做扎实。

---

## 9. §5 交付清单对照

| # | 你的要求 | 状态 |
|---|---|---|
| 1 | 修正 Plan 1 的"同一状态/只差来源"错误措辞 | ✅ §1（summary §14.2 + erratum、§7、§8；04 §0/§6/§6.4/§6.6；plan2 §0.3） |
| 2 | 提交修订后的 `plan/plan2.md`，逐项落实 §3.1–§3.6 | ✅ 已重写为 v2（816 行），变更索引在文件头 |
| 3 | response 中列出**修改前后对应关系** | ✅ §2–§7 逐条 before → after |
| 4 | 给出修正后的 episode 数量与预计 GPU 时间 | ✅ §7.3 / §7.4 |
| 5 | 明确 P2.1 的 1-seed smoke 构造表、state-index 白名单、paired-eligibility | ✅ §3.2（白名单，已实测）+ plan2 §5.8（构造表）+ §6.4（两套分母） |
| 6 | 保持 GPU 空闲，不运行 Plan 2 正式实验 | ✅ 见 §11 |

### P2.1 1-seed smoke 构造表（摘要，全文见 plan2 §5.8）

| # | 格子 | O 来源 | R 来源 | 只改什么 | 期望 predicate |
|---|---|---|---|---|---|
| 1 | `O_nat/R_cap` | seed0 自然 capture | seed0 capture 机器人 qpos | —（基准） | sg1=T, sg2=F, overall=F |
| 2 | `O_nat/R_init` | 同 1 | `pairs_v2 A` 机器人 qpos | **只改 R**（{1..9}） | sg1=T, sg2=F |
| 3 | `O_nat/R_donor` | 同 1 | donor(0)=1 的 capture 机器人 qpos | **只改 R** | sg1=T, sg2=F |
| 4 | `O_edit/R_cap` | predicate-valid 编辑配置 | 同 1 | **只改 O** | sg1=T, sg2=F |
| 5 | `O_edit/R_init` | 同 4 | 同 2 | 改 O 与 R | sg1=T, sg2=F |
| 6 | `O_edit/R_donor` | 同 4 | 同 3 | 改 O 与 R | sg1=T, sg2=F |

每格检查：白名单 `unexpected_indices=[]`（qpos 与 qvel 都查）、
同 R 水平格子间机器人前 9 关节逐位一致、`set_state` 后 observation 必须 refresh、
20 步 no-op 稳定窗口标签不变、restart 前 `policy.reset()` 且**动作之前 emit step 0**、
每格存 state + png + trace + video。**两任务各一次（I1 seed0 / I2 seed0）= 12 格**。
P2.1 结束只报构造是否合法，**不解释行为差异**。

---

## 10. 本轮额外发现的两件事（诚实记录，不改历史产物）

1. **`capability/` 的 double wait**（§6.3）—— 影响面已界定：
   只影响 capability 这一个门槛数字的**起点语义**，
   不影响 `pilot_full` / `natural_v2` / `pairs_v2`。
   我没有重跑它（重跑属新 GPU 消耗，且不影响结论）。
2. **`plan1_natural_intermediate.py` 的 generation 帧被丢弃**：
   脚本每步都采集了 `gen_frames`，但收尾时用 `cont_frames = []`，
   于是**渲染过、没落盘** → 这就是 `natural_v2` 缺 generation 视频的真正原因
   （不是"没渲染"）。按你的 §1 裁决**无需为 Plan 1 重跑**；
   plan2 的脚本会在 `finally` 前写 `__generation.mp4`，**不增加渲染成本**。

---

## 11. 当前状态

```text
Plan 1        ：实验与结论验收通过；文字口径已按 §1.1 修正（含 erratum）
Plan 2        ：plan/plan2.md v2 已提交（major revision），等待批准
GPU           ：空闲（RTX 4090，2 MiB / 24564 MiB，0% util）
模型训练       ：未启动任何训练；未训练 probe
Plan 2 运行    ：未启动（P2.0 也未开始；本轮只做了文档修正 + 只读核对）
本轮新增只读产物：results/plan2/state_index_map.json（+ scripts/plan2_state_index_map.py）
```

**在你批准之前，我不会运行 Plan 2 的任何实验。**
