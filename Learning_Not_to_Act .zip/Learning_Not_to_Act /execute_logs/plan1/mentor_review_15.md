# Mentor Review 15：Plan 2 v2 条件批准与 P2.0/P2.1 启动授权

> 裁决：**mentor_review_14 的六个 major blockers 已基本解决，Plan 2 v2 科学方向通过。**  
> 在完成本文件 §2 的文档勘误后，批准执行 **P2.0 + 缩小后的 P2.1 construction smoke**。  
> **P2.2 full factorial 尚未批准**；P2.1 结束后必须暂停汇报。

## 1. 本轮验收结果

### 1.1 已通过

1. Plan 1 的“同一状态/只差来源”错误已经在当前总结与报告中更正，历史日志保持不回写，处理正确；
2. 因子已从不可观察的 provenance 改为当前状态分量 `O × R`；
3. B1/B2 已重新定义，逻辑上可区分；
4. gate 已闭合为 `satisfaction probe + deterministic router`；
5. `valid_unsatisfied_set`、gate false-stop 与 policy non-progress 已分开；
6. 两套分母、逐任务报告和 TERM 条件已加入；
7. 我已抽查服务器上的 `results/plan2/state_index_map.json`：
   - I1：`nq=65, nv=57, R qpos={1..9}`；
   - I2：`nq=24, nv=22, R qpos={1..9}`；
   - completed/remaining/container 的 qpos/qvel 映射与计划所列一致。

冻结脚本头部那句旧因果表述无需修改；运行时文件哈希应保留。当前 summary 的 erratum 已足够。

### 1.2 状态说明

`scripts/plan2_state_index_map.py` 与远端 `results/plan2/state_index_map.json` 已经是
Plan 2 的准备性产物，因此状态不要再写“P2.0 完全未开始”。应写成：

```text
P2.0：准备性 state-index 核对已完成；正式 freeze/metric/benchmark 尚未执行。
```

把这两个文件登记到 Plan 2 的 manifest，并记录 hash。它们不算 GPU experiment。

## 2. 启动前必须完成的九项勘误

这些是 v2 的小修，不再要求提交 v3 等待批准；修完并在
`execute_logs/plan2/decisions.md` 逐项登记后，可直接进入 §3 的授权范围。

### 2.1 删除 B1/B2 的自相矛盾句

`plan2.md` §1 Q2 仍写“两者第一次文本相同”。那是 v1 的问题；v2 中 B1 保留全部子目标、B2 只保留 remaining，文本已经不同。删除该句，保留 §6.1 的新定义。

### 2.2 P2.1 不得使用 ineligible 的 I1 seed0

I1 seed0 在 Plan 1 中已经因 continuation 未在官方 520 步预算内成功而判为 ineligible，不应再作为自然成功轨迹的 smoke 基准。

P2.1 固定为：

```text
I1 base seed = 1，donor seed = 2
I2 base seed = 0，donor seed = 1
```

base 与 donor 都必须满足：

```text
捕获到 sg1=True, sg2=False 的稳定帧
AND 从该轨迹继续时在官方总预算 520 步内 overall success
```

这也是 P2.2 `paired-eligible` 与 donor eligibility 的统一定义。不得把“只捕获到 sg1”写成自然成功。

### 2.3 把 O/R 的组装规则写到逐分量可执行

每个 hybrid state 必须明确：

```text
O_nat  = natural capture 的全部非机器人 qpos + 非机器人 qvel
O_edit = 同 seed 的 pairs_v2 B 的全部非机器人 qpos + 非机器人 qvel
R_cap  = base natural capture 的全部机器人 qpos + 机器人 qvel
R_donor= donor natural capture 的全部机器人 qpos + 机器人 qvel
R_init = 同 seed 的 pairs_v2 A/B 的全部机器人 qpos + 机器人 qvel
time   = 六格统一置为同一个预注册值（建议 0.0），不作为因子
act    = 当前两任务 na=0；若未来任务 na>0，必须另行定义，不能漏掉
```

`O_edit/R_init` 应能逐位复现对应的 `pairs_v2 B`（除统一后的 time）；
`O_nat/R_cap` 应能逐位复现 natural capture（除统一后的 time）。

当前 §5.2 同时写“O 可写为全部非机器人下标”与“主干预只允许 task subset”，容易冲突。
改成：**组装白名单是全部 O；task subset 只是报告/机制诊断子集，不是禁止其他 O 分量随其来源变化。**

### 2.4 interaction 必须用 difference-in-differences

对任一指标 `Y`，主 2×2 部分定义为：

```text
ΔR(O_nat)  = Y(O_nat,R_init) - Y(O_nat,R_cap)
ΔR(O_edit) = Y(O_edit,R_init) - Y(O_edit,R_cap)
Interaction = ΔR(O_edit) - ΔR(O_nat)
```

二值 SR 同样按逐 seed paired outcome 报告，不要只写“双干预是否更差”。
把 C4 从 `provenance necessity` 改名为 `exact-pair dependence / phase transfer`；
provenance 不是模型可观察量，不得重新进入因果命名。

删除 D1/D2 中“显著”措辞；n 很小，只报告方向、精确计数与区间。
同时，robot phase 导致的失败不一定表现为 reexecution（I2 已证明可能是 non-progress），
所以 D1 必须同时看 `SR / reexecution / policy non-progress / steps_to_progress`。

### 2.5 统一 no-op 窗口和 smoke 规模

当前文档同时写了 20 步与 150 步。统一为：

```text
P2.1 construction smoke：每格 20 步 no-op，只验构造、碰撞与 predicate stability
P2.2 full factorial：每格 150 步 no-op，作为正式稳定性对照
```

P2.1 不需要跑 12 条 policy rollout。它的目标不是提前看六格结果，而是验证生成与组装管线。
批准的 P2.1 规模为：

```text
4 条 natural generation：I1 s1/s2 + I2 s0/s1（base + donor）
12 个 hybrid state 构造
12 条 × 20 步 no-op
2 条 policy harness sanity：每任务只跑 O_nat/R_cap 一条，验证 step0/queue/trace/video
```

两条 sanity **不得用于科学比较**。P2.1 结束只回答“构造是否可靠”。

### 2.6 P2.2 验收不能要求所有 seed 都通过

固定尝试 5 seeds/task，但允许某些 seed 因 generation、白名单、碰撞或稳定性失败而 ineligible。
验收应写成：所有 attempted case 都有状态或明确失败记录；主 paired contrast 只使用六格都合法的 paired-eligible seeds。不得为了满足“全部落盘、全部通过”而替换 seed。

### 2.7 在跑基线前写死“成功/失败”的数值定义

当前决策树仍使用未定义的“B1 成功/B2 成功”。改为：

```text
一个 (task, cell) 可进入强基线：paired-eligible n >= 4，且 B0 SR <= 0.5。

Bx 在该 (task, cell) 通过：
  successes >= ceil(0.75 * n)
  AND 相对 B0 至少多成功 2 个 paired seeds。
```

若 B1/B2 在不同任务或格子上结果混合，不得 pooled 后强行选 gate/re-anchoring；
新增 `mixed outcome → 暂停，由导师决定按 family 分流还是扩任务` 分支。

P2.5 的方法 PASS 同样要求每个目标 `(task, cell)` 达到 `ceil(0.75*n)`，
不能只有“比 B0 好一点”。

### 2.8 修正 preservation 阈值的分母

`NORM-A` 每个任务只有 5 条，因此“逐任务 SR ≥9/10”没有意义。改成：

```text
NORM-A：每任务 >=4/5，且 pooled >=9/10
NAT/R_cap：每任务 >=3/4，且 pooled >=7/8
gate false-stop：仍为 <=1/18
TERM：若声称 STOP，>=7/8
```

### 2.9 去掉重复 rollout 与数据泄漏歧义

- P2.2 的原始 policy rollout 就是 B0；P2.3 必须复用，不得在同状态上无意义重跑 B0；
- B2 的静态 remaining-goal prompt 只适用于当前“只剩一个目标”的失败格子；
  在 NORM 上若要完成全任务，必须使用 B2b closed-loop，不能把静态 B2 的单子目标结果当 overall SR；
- `gate 验 provenance` 改成 `dataset ingestion/validation guard 验 provenance`。
  satisfaction gate 的推理路径绝不能读取 provenance；
- 修正 P2.3/P2.5 的 episode 表，明确哪些是 B1 preservation、哪些是 B2b oracle upper bound、哪些是最终 gate rollout，避免当前的 54 + 48 重复/含义不清。

## 3. P2.0 执行授权

完成 §2 的文档勘误后，批准执行 P2.0：

1. 冻结 Plan 1 产物与 hashes；
2. 修 engagement metric；
3. 建立去重后的 Mini-PAB-D/offline；
4. 从既有 trace 离线复算并列出逐条 diff；
5. 增加单测并运行完整测试集。

engagement 修正时再加一个守卫：

```text
inside_at_step0 时，单纯“step0 已经闭爪且后续保持闭爪”不算 acted。
应使用 gripper close transition near target、目标位移、目标接触或该子目标专属进展。
task_joint_progress 必须属于正在判断的子目标，不能用无关关节变化代替。
```

P2.0 完成后可继续 P2.1，不必等待新的文字批准；但若离线重算改变 Plan 1 的核心计数，立即暂停。

## 4. P2.1 construction smoke 执行授权

P2.0 通过后，批准按 §2.2–§2.5 的固定配置执行 P2.1。

P2.1 必须交付：

- 4 条 generation 的 eligibility 与 capture step；
- 12 个 state 的完整 provenance、逐维 diff、O/R/time 分量哈希；
- `O_edit/R_init ↔ pairs_v2 B` 与 `O_nat/R_cap ↔ natural capture` 的逐维复现检查；
- 12 条 20-step no-op 的 predicate/contact/drift 结果；
- 两条 policy sanity 的 step0、首个 action、queue reset、trace 与 video；
- 所有失败、碰撞、predicate 翻转均保留，不得换 seed。

P2.1 结束后写：

```text
execute_logs/plan2/00_freeze.md
execute_logs/plan2/01_measure_fix.md
execute_logs/plan2/02_benchmark.md
execute_logs/plan2/03_factorial.md   # 只含 smoke，不含 full
execute_logs/plan2/artifacts_manifest.md
execute_logs/plan2/execution.log
```

然后**必须暂停**。不得启动 60 条 policy 的 P2.2 full factorial。

## 5. 当前阶段判定

```text
Plan 1：正式关闭。
Plan 2：设计通过，进入 P2.0 离线准备 + P2.1 construction smoke。
已授权 GPU 工作：仅 4 条 generation + 2 条 anchor sanity。
未授权：P2.2 full、强基线、probe、任何 VLA 微调。
```

这一次不再讨论是否“偏离 Learning Not to Act”。当前计划已经把问题落到一个可证伪的链条上：先识别状态重组中的失败因子，再用 oracle prompt 判断是决策问题还是执行问题，只有证据支持时才训练 gate。这正是下一步应走的路线。
