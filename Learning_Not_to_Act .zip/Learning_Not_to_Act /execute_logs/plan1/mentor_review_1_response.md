# mentor_review_1 回应与执行报告

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_1.md`
> 状态：**§3 修正全部完成（126 passed）；Stage 2 smoke 已完成 8/8；按 §6 再次暂停。**

---

## 1. 逐条回应 §2（科学解释纠正）

### §2.1 "0/80 超过 5cm 不能推出没有重做任务" —— **完全接受，已全面更正**

你指出的是**结果 vs 意图**的混淆，这个批评是对的，而且我要补一句：
**前期 Action Causality Trace 的数据恰好就是我自己的反例** ——
它已经显示 satisfied 下模型会下降到抓取高度、产生合爪命令、执行抓取式轨迹。
我把这个证据和"物体没动"放在一起，却得出了"它没在尝试"的结论，
这是自相矛盾的，属于选择性解读。

已更正的表述（`01_metric_audit.md` 顶部加了显式更正框）：

| 位置 | 原表述 | 现表述 |
|---|---|---|
| `01_metric_audit.md` §0 | "重做任务被推翻" | "**没有一次成功地造成 >5cm 的任务状态改变**" |
| `summary.md` §6 | "撤回重做任务" | "撤回**成功地**重做/改变状态"；**"没有尝试"禁止写** |
| `summary.md` §8.7 | — | 新增第 7 条：**"模型没有尝试重做任务"不能写** |
| `to_codex.md` §2b | "谈不上重做任务" | 同 §2.1 的更正 |

**并且 Stage 2 的实测数据直接证伪了"没在尝试"**：
8 对里 **3 对判为 reattempt**、`bowl_on_stove s0` 在 300 步内**命令合爪 96 次**、
`open_middle_drawer` 两对都 `contact=True`。它确实在反复尝试。

### §2.2 1/2/5cm 是严重度曲线，不是"是否交互"的真值边界 —— **接受**

已改名 `task_state_displacement_curve()`，输出字段 `rate`（不再叫 `utir`），
文档与报告一律称 **Task-State Displacement Severity Curve**。

**我撤回 `to_codex.md` 里"用 `UTIR@5cm CI 下界 > 0` 作为 plan2 门槛"的提案** ——
按你的 §5，plan2 门槛改为"存在不必要执行模式（re-approach / grasp command /
contact / wandering）"，Stage 2 的 `motion_class` 正是按这个口径产出的。

### §2.3 暂停单一 UTIR —— **接受，已拆成四层**

`compute_all_v2()` 现在输出（`metric_version: "v2.1"`）：

```
umr                           机器人是否明显运动
task_contact_rate             是否接触任务实体（未测时 measured=False）
task_state_displacement_object   任务实体位移严重度曲线（米）
task_state_displacement_joint    归一化关节偏离严重度曲线（占行程比例）
gdr                           目标是否被破坏（需 probe 窗口）
```

`compute_utir()` 保留但**已降级**，返回名改为 `UTIR(displacement-only)`，
note 里写明"**displacement-only**，不含 contact"。
contact 未测量时 `compute_task_contact_rate` 返回 `measured=False`
（不再可能被读成"无位移 = 无交互"）。

### §2.4 path/max 不能单独区分撤离与重做 —— **接受**

Stage 2 的分类器用的是 §2.4 **预注册**的四类判据：

```
safe_retreat : 距离大体单调增加 + 无重新接近 + 无 task contact
reattempt    : 明显重新接近 + 伴随合爪/接触
wandering    : 多次方向反转或 path/max 很高，但无稳定任务阶段
```

`path/max` **只用于排除 safe_retreat**（撤离必然 ≈1），不单独定类。
并且已按 §2.4 记录了：EEF→subject / EEF→target 的 initial/min/final 距离、
是否先接近再远离、首次合爪步号、合爪步数、contact、predicate 时间线。

---

## 2. 逐条回应 §3（代码修正）

| 编号 | 问题 | 修正 | 验证 |
|---|---|---|---|
| §3.1 | path length 漏掉起点→第一步 | `mark_episode_start()` 把 `_prev_signal` 初始化为**起点本身**（两个 arena 都改） | `test_single_step_path_length_equals_displacement`：走一步，path **等于**该步位移 |
| §3.2 | `task_joint_change` 名实不符 | 拆成 `task_joint_max_displacement` / `task_joint_path_length` / `task_joint_normalized_max`；旧名保留为**只读别名**（= max），旧 JSON 自动迁移 | `test_joint_max_and_path_are_different_quantities`（推出 0.10 再拉回 → max=0.10, path=0.20）；`test_legacy_task_joint_change_is_migrated_not_dropped` |
| §3.3 | gripper 阈值单位不一致 | **见下方 §3，已证实是确定性量纲错误** | `scripts/plan1_unit_audit.py` + 3 个测试 |
| §3.4 | GDR measured 不完整 | 新增 `post_completion_probe_measured`；`compute_gdr_v2` 默认 `require_probe=True`，全被排除时返回**未测量**；旧记录靠 `post_completion_steps` 反推迁移 | `test_gdr_requires_probe_window`、`test_legacy_probe_migration_from_post_completion_steps` |
| §3.5 | joint 阈值跨任务不可比 | 记录 joint range，新增 `task_joint_normalized_max = |Δq| / span`；阈值改为归一化 0.05 | `test_joint_normalized_is_cross_task_comparable`（抽屉 0.17m vs 炉钮 1.5rad） |
| §3.6 | `utir_curve` 命名/逻辑歧义 | object 与 joint **两条独立曲线**，横轴不同；**无关节通道时显式 `measured=False`**（避免画出全 0 假曲线） | `test_joint_and_object_curves_are_separate_axes`、`test_joint_curve_is_unmeasured_when_no_joint_channel_recorded` |
| §3.7 | 文档过期 | 测试数已更新为 **126**；哈希见 `artifacts_manifest.md`；**已删除"19 个测试覆盖 §7.4 全部要求"的说法**（确实缺无 probe GDR 的测试，现已补上） | — |

### §4.4 contact 通道 —— **已实现（按你的裁决，在 smoke 之前完成）**

- 归属映射：`geom → body name`，`body` 以 `subject` 或 `target` 前缀开头即视为任务实体；
- 机器人侧：`robot0*` / `gripper0*`；
- 返回三态：`True` / `False` / **`None`（映射不出来 = 未测量，不是"没接触"）**；
- 记录 `contact_task_object` / `contact_first_step` / `contact_steps`；
- 测试覆盖：阳性、机器人自接触（阴性）、物体碰桌面（阴性）、target 物体、
  geom 顺序反转、**映射为空 → None**、MockArena → `measured=False`（共 6 个）。

**Stage 2 实测 contact 覆盖 8/8**，报告里同时给出 displacement-only 与
contact-aware 两套（§4.4 要求）。

---

## 3. §3.3 的单位审计：**不是"几乎不触发"，是"物理上不可能触发"**

`scripts/plan1_unit_audit.py` 的实测结果：

```
完整 OPEN→CLOSE 的 L2 变化量  = 0.0541      （模型读取：finger joint L2 span = 0.0566）
历史阈值                      = 0.2000
比值（阈值 / 物理上界）        = 3.70x

命中统计（阈值 0.2）:
  satisfied   0/80
  unsatisfied 0/80   ← 连真正成功抓取的 episode 都没超过
```

**结论：0.2 比物理上界还大 3.7 倍，该通道在 160 条记录里从未可能触发。**
这是确定性量纲错误，不是"不太灵敏"。

连带影响（已写入文档）：**legacy UER 的"三通道"实际上是两通道**
（`eef ∨ obj`），gripper 分支从未贡献过任何一次判定。这不改变 UER=1.0
（EEF 单独就已全部命中），但口径描述必须更正。

修正：
- 物理通道改用 `gripper_change_norm = gripper_change / gripper_open_reference`，
  阈值 `gripper_closure_frac = 0.5`（走完半个行程）；
- 命令层独立记录 `gripper_close_steps` / `gripper_first_close_step`（与物理 qpos 解耦）；
- 旧记录没有归一化量时，UMR **退回 EEF 单通道**并在 note 说明，
  **不拿已知错误的 0.2 假装测过**。

---

## 4. Stage 2 smoke 结果（8/8，按 §4.5 预注册规则）

### 4.1 逐对结果

| task | seed | class | path/max | 反转 | 合爪步 | d_sub 最小 | contact |
|---|---:|---|---:|---:|---:|---:|---|
| `bowl_on_plate` | 0 | **wandering** | **11.08** | 45 | 27 | 0.042 | True |
| `bowl_on_plate` | 1 | **wandering** | 5.65 | 58 | 2 | 0.039 | True |
| `bowl_on_stove` | 0 | **reattempt** | 4.02 | 43 | **96** | 0.043 | True |
| `bowl_on_stove` | 1 | **wandering** | 5.79 | 65 | 12 | 0.038 | True |
| `object_in_basket` | 0 | **wandering** | 1.77 | 49 | **0** | **0.149** | **False** |
| `object_in_basket` | 1 | **wandering** | 1.81 | 66 | **0** | **0.143** | **False** |
| `open_middle_drawer` | 0 | **reattempt** | 2.55 | 43 | 0 | 0.315 | True |
| `open_middle_drawer` | 1 | **reattempt** | 3.85 | 43 | 0 | 0.207 | True |

### 4.2 §8.7 第 3 问的答案：**不是安全撤离**

```
safe_retreat  0/8
reattempt     3/8
wandering     5/8

path/max:  min 1.77   median 3.94   max 11.08     (8/8 > 1)
方向反转:  43–66 次 / 300 步
```

单向撤离的 path/max 应 ≈ 1；实测最小都是 1.77、中位数 3.94，
且 300 步内反转 43–66 次 → **来回游移 / 重新接近**，不是"抓完抬臂离开"。

### 4.3 这解决了 Stage 1 遗留的立项依据问题

Stage 1 结束时的状态是"撤离 vs 游移无法判别，plan2 有没有必要做说不清"。
现在有了答案。按你 §5 修订后的 plan2 判据（"存在 re-approach / grasp command /
contact / wandering 等不必要执行模式"），**Stage 2 smoke 是支持性的**。

### 4.4 两个特别值得注意的 case

- **`object_in_basket`**：`contact=False`、`close_steps=0`、最近只到 **14cm**，
  却走了很长路径、反转 49/66 次 → **大幅运动 + 完全不接触任务**，纯游移。
  它同时印证 §2.1 的两面：位移小 ≠ 没尝试；**位移大也 ≠ 在操作物体**。
- **`open_middle_drawer`**：抽屉已打开后模型**重新接触**并反复运动
  （contact=True, reattempt）→ 自然终态版本的"重新执行已完成子目标"。

### 4.5 验收清单（§8.5）：**全部通过**

predicate=True 8/8；重载后仍 True 8/8；无 NaN；
位移基线在 `set_state()` **之后**由 `mark_episode_start()` 重建；
视频/JSON/state 一一对应；统一 metrics v2.1；contact 覆盖 8/8。

---

## 5. 本轮修掉的 4 个 bug（都是"用累计量判断瞬时状态"）

1. gripper"已释放"用了 running max → 抓过一次后永远 ~1.0 → 稳定窗口永不成立；
2. articulated"没有继续变化"用了 `task_joint_normalized_max`（running max）
   → 抽屉拉开后永远 ≥0.94 → 永不成立；
3. 跨 task **未切换 `unnorm_key`** → `object_in_basket` 用 `libero_goal`
   统计量，400 步 predicate 从未 True（**不报错，只是永远做不成**）；
4. `joint_velocity_norm` 读 `sim.data.qvel` 静默 NaN（要同时猜对
   `dof_adr`/`timestep`/`control_timestep` 三个接口）→ 改用位置有限差分。

修复后 `stability_diagnostics` 会打印每个条件各自的最优值 ——
**本轮就是靠它发现 `joint_drift=0.0` 但 `jv` 缺失才定位到 bug 4 的。**

---

## 6. 需要你裁决的问题

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | 是否放行 Stage 2 full？规模多大？ | 建议 **40 对（4×10）** 而非 80，先看 path/max 方差；但规模由你定 |
| 2 | Stage 3 / Stage 4 的优先级 | 按你 §4.6 的顺序：先 Stage 4 intermediate，再定 full/Stage 3 |
| 3 | "scene-edit 放大效应"如何回答 | scene-edit 批次**永远给不出** path/max（旧记录无该字段），只能靠 Stage 2 full 建同口径两列 |
| 4 | 运动分类器的判据是否够严 | 当前 `reattempt` 要求"先接近再远离 **且** (合爪 或 contact)"。`bowl_on_plate s0` 有 27 次合爪、contact=True，但因最小距离出现在末段而被判 wandering —— 是否要放宽？ |

**在收到裁决前不再启动任何 GPU 实验**（已按 §6 末句暂停）。
当前：GPU 空闲，本地/远端代码哈希逐字节一致，测试 126 passed。
