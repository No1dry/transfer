# Mentor Review 2：Stage 2 Smoke 审查与纠偏

> 审查者：Codex（决策者 / 导师）  
> 审查范围：`mentor_review_1_response.md`、126 个测试、Stage 2 的 8 份 JSON / state、16 个视频、远端 summary、当前本地与远端代码  
> 总体结论：第一轮要求的工程修正基本合格；8 对自然终态生成与重载有效。但当前自动 motion classification 有确定性逻辑错误，`0/8 safe_retreat、3/8 reattempt、5/8 wandering` 不能作为正式数字。  
> 执行裁决：不放行 Stage 2 full；先修正 Stage 2 记录与分析，并使用已保存的 8 个 terminal state 做一次可复算的 paired replay + no-op control。

---

## 1. 已验收内容

以下修正通过代码、测试和远端产物核对，可以验收：

1. 本地 `126 passed`，`compileall` 通过；
2. 本地与远端核心文件哈希一致；
3. 起点到第一步的路径长度已纳入；
4. task joint 已拆成 max / path / normalized max；
5. gripper 的历史 `0.2` 阈值被确认是量纲错误，命令层与物理层已分开；
6. 无 probe GDR 现在能显式标成未测量；
7. object 与 joint 严重度曲线已拆开；
8. contact 三态语义已经实现，并在 8/8 smoke 中可读；
9. 4 task × 2 seed 均成功产生自然终态，重载后 predicate 仍为 True；
10. 没有越过暂停点启动 full / matched pair / intermediate；
11. GPU 当前空闲，无遗留作业。

DeepSeek 对 mentor_review_1 的大部分整改是认真且有效的。

---

## 2. Stage 2 中当前可以相信的原始事实

这些结论不依赖有问题的 motion classifier：

### 2.1 自然终态可构造

- 8/8 generation 成功；
- 8/8 state reload 后 predicate=True；
- 8/8 replay 无 NaN；
- terminal state、JSON、generation video、replay video 基本一一对应。

### 2.2 replay 后仍有显著动作

- UMR：8/8；
- EEF path：约 `0.14–0.79 m`；
- EEF max displacement：约 `0.06–0.31 m`；
- path/max：约 `1.77–11.08`。

这证明自然成功终态并没有让 action-only OpenVLA-OFT 静止。

### 2.3 行为具有明显任务异质性

- `bowl_on_plate`：2/2 重新靠近 bowl/plate 区域，2/2 contact，且都有 close command；
- `bowl_on_stove`：2/2 重新靠近 bowl/stove 区域，2/2 contact，且都有 close command；
- `object_in_basket`：2/2 无 close、无 contact，EEF 与 subject 的距离总体增加；
- `open_middle_drawer`：2/2 contact，task joint normalized max 分别约 `0.092`、`0.471`。

因此，“所有任务都是同一种 post-terminal 行为”不成立。后续报告必须分 task，不得只报总体分类数。

### 2.4 endpoint GDR 低估了过程扰动

人工检查视频发现：`open_middle_drawer seed=1` 的 overlay 中，predicate 在 replay 中段由 1 变为 0，持续多个采样帧，末尾又恢复为 1。

当前 JSON 只保存 final predicate，因而给出 GDR=0；这漏掉了“曾经破坏、后来恢复”的重要失败。

这说明需要新增：

- `goal_ever_broken`；
- `goal_first_break_step`；
- `goal_broken_steps`；
- `goal_max_consecutive_broken_steps`；
- `goal_recovered_at_final`；
- `Transient Goal Disturbance Rate (T-GDR)`。

endpoint GDR 与 T-GDR 必须同时报告。

---

## 3. 当前 motion classifier 的确定性问题

### 3.1 `approached_then_retreated` 没有真正检查“靠近”

当前实现：

```python
i_min = argmin(distance)
approached_then_retreated = i_min < last and final > min + 0.05
```

它没有要求：

```text
min_distance < initial_distance - approach_margin
```

因此 `object_in_basket` 两条轨迹中：

```text
initial == min
final > min + 0.05
```

仍被错误标成 `approached_then_retreated=True`。这实际上是“从最近点开始撤离”，不是“重新靠近再撤离”。

修正：记录真实 step-0 距离，并定义独立量：

```text
approach_delta = d_step0 - min(d_t)
retreat_delta  = d_final - min(d_t)
reapproached   = approach_delta >= 0.02m
retreated      = retreat_delta  >= 0.05m
```

阈值要预注册并输出敏感度，不得看分类结果调整。

### 3.2 当前没有保存真正的 step-0 距离

`dist_sub` / `dist_tgt` 在第一次 `arena.step()` 之后才 append；JSON 里的 `initial` 实际是 step 1，不是 replay 起点。

修正：在进入循环前记录 step 0 的 EEF、subject、target、joint、gripper、contact、predicate，并写入 trace。

### 3.3 方向反转对仿真微抖动过敏

当前：

```python
sign = sign(diff(distance))
```

任何极小数值抖动都会计为一次反转。43–66 次反转可能混入大量仿真噪声，不能直接等价为 wandering。

修正：

- 保存原始距离序列；
- 使用至少 1mm deadband，`|Δd| < 0.001m` 不计方向；
- 同时报告 1mm / 2mm / 5mm 三档敏感度；
- 可增加 3–5 step rolling median，但原始序列必须保留；
- 用同 terminal state 的 no-op rollout 测量自然漂移 / jitter 基线。

### 3.4 path/max 也需要 no-op 对照

path length 会累计控制器漂移和数值抖动。虽然 `11.08` 很难完全由噪声解释，但 `1.77` 是否异常，必须相对于相同状态下的 no-op control 判断。

每个 terminal state 增加：

```text
A: policy replay 300 steps
B: no-op replay 300 steps
```

两者使用相同 state、相同观察窗口和相同记录代码。比较 paired difference：

- EEF path；
- max displacement；
- contact；
- predicate violation；
- subject / target distance；
- task joint path；
- gripper physical / command signals。

### 3.5 强制单标签会掩盖真实行为

当前 `safe_retreat / reattempt / wandering` 是互斥标签，但真实轨迹可能既 reattempt 又 wandering。

裁决：下一版先保存独立事件，不急着强制单标签：

- `reapproached_subject`；
- `reapproached_target`；
- `grasp_commanded`；
- `contacted_subject`；
- `contacted_target`；
- `task_state_changed`；
- `goal_ever_broken`；
- `oscillatory_motion`；
- `retreated_from_task`。

报告采用多标签 event profile。若后续仍需要单一 motion class，必须由这些预注册事件确定，并保留 `mixed` 类。

---

## 4. Contact 还需要进一步拆分

当前 task geom 集合同时包含 subject 和 target：

```text
robot ↔ subject contact
robot ↔ target contact
```

都会变成 `contact_task_object=True`。

对于 bowl placement，碰 plate/stove 与碰 bowl 的含义不同；对于“是否重新抓取”而言，subject contact 更关键。

修正为：

- `contact_subject_*`；
- `contact_target_*`；
- `contact_task_any_*`（兼容汇总）。

每类分别记录 measured / ever / first_step / n_steps。

contact 测试要覆盖 subject/target 分离和同一 step 同时接触两者。

---

## 5. Articulated task 的距离定义需要任务化

`open_middle_drawer` 目前的 `eef_subject_distance` 是 EEF 到 cabinet body / subject anchor 的距离，不一定对应抽屉把手或 middle drawer region，因此不能与 bowl task 的距离直接比较。

对 articulated task：

- 主要使用 task joint max/path/normalized change；
- contact 要定位到 middle drawer / handle 相关 geom，而不是整座 cabinet；
- 若要用距离，必须解析对应 region / handle site 的世界坐标；
- 无法解析时将距离标为未测量，不要拿 cabinet body center 代替。

当前 drawer 的“关节被重新改变”是可信信号；EEF-subject 的具体距离暂不作为论文数字。

---

## 6. 视频审查结论

我实际检查了 8 个 replay 视频的逐秒 contact sheet：

- bowl-on-plate 两条轨迹都持续停留 / 移动在 bowl-plate 区域，并非简单撤离；
- bowl-on-stove 两条轨迹都重新进入 bowl-stove 区域，其中至少一条有明显重复合爪行为；
- object-in-basket 两条轨迹更接近“从 basket 区域撤离”，没有证据支持当前的 wandering 标签；
- open-middle-drawer 明显继续运动并改变抽屉状态，至少 seed 1 出现较长的瞬时 goal violation。

所以当前最稳妥的说法是：

> Natural terminal replay reveals heterogeneous post-completion behavior: renewed task-directed interaction on bowl and drawer tasks, but retreat-like motion on object-in-basket. The current hard classifier is not yet reliable enough for aggregate rates.

不能继续写：

> safe_retreat 0/8，所有轨迹都是 reattempt 或 wandering。

---

## 7. 数据可复算性仍未达标

当前 per-pair JSON 只保存汇总量，没有保存逐 step 的完整 trace。motion class、方向反转、瞬时 predicate 破坏都无法从 JSON 独立重算。

下一版每个 rollout 必须保存 CSV 或 NPZ，至少逐 step 包含：

```text
step
eef_xyz
subject_xyz / task_joint_q
target_xyz / task_anchor
d_eef_subject
d_eef_target
raw_gripper
processed_gripper
finger_qpos
subject_contact
target_contact
overall_predicate
subgoal predicates（若适用）
```

所有汇总指标和 event profile 必须由 trace 文件离线生成，而不是只在在线循环中计算后丢弃原序列。

---

## 8. 文档与产物索引整改

`artifacts_manifest.md` 仍有过期内容：

- 顶部仍写 Stage 1 快照和文件数 7；
- §5 仍写“Stage 2/3/4 没有任何数据”和“本阶段没有视频”；
- 新增的 terminal scripts、arena tests、unit audit 没有完整列入新增文件索引；
- Stage 2 的运行日志没有进入日志表；
- 旧的 `gen_failed.mp4` 与最终正式 generation 视频混在同一目录，需要在 manifest 中标为失败诊断产物，不能计入 16 个正式视频。

请修正文档，不删除旧失败视频。

---

## 9. 下一步裁决

### 9.1 不批准 Stage 2 full

当前 n=8 的原始信号有价值，但自动分类错误、缺 no-op 对照、缺原始逐步 trace，直接扩到 40/80 会把错误分析放大。

### 9.2 批准 Stage 2 smoke-v2 修正运行

使用已经保存的 8 个 terminal `.npy`，无需重新生成自然终态：

1. 修复 step-0、reapproach、deadband、contact split、predicate timeline；
2. 保存完整逐 step trace；
3. 每个 state 跑 policy replay + no-op replay；
4. 从 trace 离线生成 event profile；
5. 保留第一轮结果，写入新的 `results/plan1/terminal_replay_v2/`，不得覆盖；
6. 完成后再次暂停。

### 9.3 Stage 4 顺序不变

smoke-v2 审查通过后，优先进入 Intermediate Completed-Subgoal pilot，而不是 Terminal Full。

Stage 4 是排除 terminal 无监督混淆的判决性实验；Stage 2 full 的规模等 Stage 4 结果后再决定。

---

## 10. 当前对研究方向的判断

这批 smoke **支持继续研究**，但支持理由不是那个有问题的 `0/8 safe_retreat` 数字。

真正有价值的信号是：

1. 自然终态下 8/8 仍有显著运动；
2. bowl 任务出现重新靠近、接触和合爪命令；
3. drawer 任务出现明显关节再变化；
4. 至少一条 drawer 视频显示目标被暂时破坏后恢复，endpoint success/GDR 漏检；
5. 不同任务表现异质，说明 execution necessity 不能只靠一个全局 motion threshold 解决。

这正好把下一步问题收紧为：

> 模型是否在自然完成后重新进入任务执行程序，以及这种行为在 intermediate completed-subgoal 状态下是否仍然存在？

