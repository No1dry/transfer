# mentor_review_2 回应与 smoke-v2 执行报告

> # ⛔ INVALID DIAGNOSTIC RUN: stale observation after state restore
>
> 按 **mentor_review_3 §3.3**，本文件涉及的 **smoke-v2 数字全部作废**，
> 只能作为"复现该 bug"的诊断材料，**不得作为研究结论**。
>
> 原因：`set_state(..., settle_steps=0)` 当时**不刷新 observation**，
> 于是 policy 的**首个 action chunk 用的是上一段旧轨迹的图像与 proprio**，
> 整条闭环轨迹都不是对 terminal state 的响应。实测证据：
> policy step0 的 EEF 在 6/8 条上逐位相同（home 位姿）、
> step0→1 伪跳变 0.27–0.33 m（真实单步 median 0.0019 / max 0.0124 m）、
> no-op step0 与前一条 policy 末帧 **8/8 逐位相同**。
>
> 已修复（无步进 observation refresh，真实 LIBERO 集成测试全过），
> 修正后的结果是 **smoke-v3**（`results/plan1/terminal_replay_v3/`，
> 见 `mentor_review_3_response.md`）。


> 执行者：DeepSeek ｜ 回应对象：`mentor_review_2.md`
> 状态：**§3/§4/§7 修正全部完成（155 passed）；smoke-v2 已跑完 8 对 paired；
> 按 §9.2 第 6 条暂停，等待复审。**

---

## 1. 你指出的分类器错误 —— 确认成立，已修

§3.1 的确定性错误是真的。原实现：

```python
i_min = argmin(d); approached_then_retreated = i_min < last and final > min + 0.05
```

**没有检查"真的靠近过"**，于是 `initial == min`（从最近点一路离开）也被标成
`approached_then_retreated`。已按你的定义拆成两个独立量：

```text
approach_delta = d_step0 − min(d)      reapproached = approach_delta ≥ 0.02 m
retreat_delta  = d_final − min(d)      retreated    = retreat_delta  ≥ 0.05 m
```

阈值预注册在 `benchmark/event_profile.py`，有专门测试
`test_initial_equals_min_is_not_reapproach`（构造单调远离序列，
断言 `reapproached=False` 而 `retreated=True`）。

**结论：第一版的 `safe_retreat 0/8 / reattempt 3/8 / wandering 5/8` 作废。**
已在 `02_terminal_smoke.md` §C3、`artifacts_manifest.md` §10 明确标注，
原始文件保留未删。

---

## 2. 逐条落实 §2、§3、§4、§7

| review | 要求 | 实现 | 验证 |
|---|---|---|---|
| §3.1 | 拆 approach / retreat | `approach_metrics()` | `test_initial_equals_min_is_not_reapproach` 等 5 个 |
| §3.2 | 真正的 step-0 | trace **含 step 0**（进入循环前 emit） | trace CSV 第 1 行 `step=0` |
| §3.3 | 死区 + 三档敏感度 | `count_reversals(deadband)`；1/2/5mm | `test_reversals_ignore_sub_millimetre_jitter` 等 4 个 |
| §3.4 | no-op 对照 | 每 state 跑 policy + no-op，paired 差 | `plan1_analyze_v2.py` |
| §3.5 | 多标签，保留 mixed | 9 个事件 + `derive_single_label()` 保留 `mixed` | `test_event_profile_is_multilabel_not_forced_single` |
| §2.4 | T-GDR | `transient_goal_stats()`：ever_broken / first_break_step / broken_steps / max_consecutive / recovered_at_final | 5 个测试 |
| §4 | contact 拆 subject/target | `contact_{subject,target,any}_*`，各 4 字段 | 6 个测试（含同 step 同时接触） |
| §5 | articulated 距离 | `open_middle_drawer` 的 `d_eef_subject` 记为 **NA** | 见下表 `reappr=None` |
| §7 | 逐 step trace + 离线算出 | 22 列 CSV；`plan1_analyze_v2.py` 纯离线重算 | 该脚本不加载模型、不碰仿真 |

**测试：155 passed**（本地 = 远端），`compileall` 通过。

---

## 3. smoke-v2 结果（8 对 paired，全部由 trace 离线重算）

| task | s | label | reappr | grasp | c_sub | broken | osc | retreat | rev(1mm) | noop | noop_rev | path | **noop_path** |
|---|---:|:--|:--|:--|:--|:--|:--|:--|---:|:--|---:|---:|---:|
| bowl_on_plate | 0 | mixed | T | T | T | T | T | F | 21 | undet | 0 | 0.89 | 0.08 |
| bowl_on_plate | 1 | mixed | T | F | T | T | T | F | 53 | undet | 0 | 0.86 | 0.09 |
| bowl_on_stove | 0 | mixed | T | T | T | T | T | F | 46 | undet | 1 | 0.84 | 0.13 |
| bowl_on_stove | 1 | mixed | T | T | T | T | T | F | 34 | reattempt | 2 | 0.83 | 0.23 |
| object_in_basket | 0 | mixed | T | T | T | T | T | F | 10 | undet | 0 | 1.60 | 0.12 |
| object_in_basket | 1 | mixed | T | T | F | F | T | F | 11 | reattempt | 1 | 1.62 | 0.05 |
| open_middle_drawer | 0 | reattempt | **NA** | T | F | F | F | **NA** | 0 | undet | 0 | 1.23 | **1.04** |
| open_middle_drawer | 1 | reattempt | **NA** | T | T | F | F | **NA** | 0 | undet | 0 | 1.16 | **0.96** |

### 3.1 事件级 policy vs no-op（本轮最有说服力的表）

| 事件 | policy | no-op |
|---|---:|---:|
| `reapproached_subject` | **6/6** | 1/6 |
| `grasp_commanded` | **7/8** | **0/8** |
| `contacted_subject` | **6/8** | 1/8 |
| `task_state_changed` | **6/8** | **0/8** |
| `goal_ever_broken` | **5/8** | **0/8** |
| `oscillatory_motion` | 6/8 | 0/8 |
| `retreated_from_task` | **0/6** | 0/6 |

paired 差：`eef_path_length` median **+0.74 m**；`reversals` median **+15.5**。

### 3.2 T-GDR = 0.625 vs endpoint GDR ≈ 0 —— 你的 §2.4 判断被证实

| task | s | first break @ | broken steps | 最长连续 | 恢复 |
|---|---:|---:|---:|---:|:--|
| bowl_on_plate | 0 | 52 | 13 | 2 | T |
| bowl_on_plate | 1 | 120 | 5 | 4 | T |
| bowl_on_stove | 0 | 115 | 2 | 1 | T |
| bowl_on_stove | 1 | 102 | 2 | 1 | T |
| object_in_basket | 0 | 123 | **72** | **21** | T |

**T-GDR 5/8 = 0.625，no-op 0/8。**
endpoint GDR 会把它们全部记成 0 —— 这正是你预判的漏检。

---

## 4. 但本轮结果也**削弱**了两个先前说法（如实报告）

### 4.1 no-op 对照显示：部分"多余运动"只是从捕获点 settling

`noop_path` 在 `open_middle_drawer` 上是 **0.96 / 1.04 m**，
而 policy 是 1.16 / 1.23 m —— **paired 差只有 +0.19 / +0.12**。
`eef_max_displacement` 的 paired 差甚至有一例 **−0.02**（no-op 更大）。

**根因**：§4.5 预注册的捕获判据约束了**物体**速度与夹爪释放，
**没有约束机器人自身速度**，所以捕获点可能带残余动量，
no-op 时靠惯性/控制器 settle 就走了一大段。

我**没有**事后来改 §4.5 的判据（那是"看结果调参"），
而是把 no-op 基线如实报出来，并把"必须用 paired 差、不能用绝对值"
写进结论边界。**是否要在下一版捕获判据里加机器人速度约束，请你裁决。**

### 4.2 `open_middle_drawer` 的瞬时目标破坏**没有复现**

你从 v1 视频里看到的现象，在 v2 用**同一个保存的 state**重跑时消失了：

```
v1: joint max displacement = 0.0801 m  (normalized 0.471)
v2: joint max displacement = 0.0020 m  (normalized 0.0118)   ← 差 40 倍
v2: goal_ever_broken = False
```

结合已知的仿真非逐位可复现性，**单条轨迹的量级不可靠**。
所以：不能把"drawer 目标被瞬时破坏"当已确认结论；
`T-GDR = 0.625` 这个数字由 **5 条 bowl/object 轨迹**贡献，drawer 两对未贡献。

### 4.3 分类器在 no-op 上仍有假阳性

no-op 有 **2/8** 被判 `reattempt` → `reapproached_subject` 的 2cm 阈值
落在静置漂移范围内，**分类器偏松**。
因此本轮**不报 reattempt/wandering 的总体比例**，只报事件级对照（§3.1）。

### 4.4 5mm 死区下"游移"基本消失

| 死区 | 反转中位数 |
|---|---:|
| 1 mm | 16.0 |
| 2 mm | 8.0 |
| **5 mm** | **0.5** |

大部分"反转"是 5mm 以下抖动，`oscillatory_motion`（1mm 预注册）偏宽松，
**不能单独用来支持"游移"**。

---

## 5. 现在能说 / 不能说

**能说（有 no-op 对照支撑）**

1. 自然终态后 policy 的**任务指向行为显著多于静置基线**：
   `grasp_commanded` 7/8 vs 0/8、`task_state_changed` 6/8 vs 0/8、
   `goal_ever_broken` 5/8 vs 0/8、`reapproached_subject` 6/6 vs 1/6。
2. **"不停止"是策略行为，不是仿真漂移**（no-op 对应事件全 0）。
3. **目标扰动被 endpoint 指标严重低估**（T-GDR 0.625 vs endpoint ≈0）。
4. 行为**跨任务异质**（§2.3），不能用一个全局阈值概括。

**不能说**

1. ❌ `safe_retreat 0/8、全部 reattempt/wandering`（分类器错误 + no-op 假阳性）。
2. ❌ drawer 的瞬时目标破坏（未复现）。
3. ❌ 用 `eef_path_length` 绝对值说明"多余运动"（drawer 的路径主要是 settling）。
4. ❌ 用 1mm 反转数当"游移"证据（5mm 下中位数仅 0.5）。

---

## 6. 需要你裁决

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | 捕获判据是否加**机器人速度**约束（§4.1 根因） | 建议加，否则 no-op 基线不可比；但这是改预注册判据，**必须你批** |
| 2 | `reapproached` 的 2cm 阈值是否上调（no-op 有假阳性） | 建议先做 no-op 基线标定（用 no-op 的 approach_delta 分布定阈值），再定 |
| 3 | drawer 未复现如何处理 | 建议在论文里把 drawer 的"关节再变化"降级为**未定**，只用 bowl/object 的 5 条 |
| 4 | 是否进入 Stage 4 | 按你 §9.3：smoke-v2 通过后**优先 Stage 4**；我未自行启动 |

**在收到裁决前不再启动任何 GPU 实验。**
当前：GPU 空闲；测试 155 passed；本地/远端核心文件哈希逐字节一致。
