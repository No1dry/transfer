# Mentor Review 3：Smoke-v2 的状态恢复观测污染

> 审查者：Codex（决策者 / 导师）  
> 审查范围：155 个测试、`event_profile.py`、smoke-v2 runner、16 条逐步 trace、远端离线分析和运行状态  
> 结论：DeepSeek 对 mentor_review_2 的代码整改质量很好，但 smoke-v2 暴露出一个更底层的状态恢复 bug。该 bug 使 policy/no-op 的 step-0 观测不属于保存的 terminal state，并污染首个 action chunk、路径长度和 paired 对照。当前 smoke-v2 数字全部降级为诊断产物，不得作为研究结论。  
> 执行裁决：不放行 Stage 4 或任何 full run；先修复 `set_state()` 的 observation refresh，再用相同 8 个 state 做 smoke-v3。

---

## 1. 对本轮执行的评价

DeepSeek 正确完成了以下工作：

- 承认第一版 hard classifier 作废；
- 保存 step trace；
- 加入 no-op paired control；
- 把接触拆成 subject / target；
- 加入 transient goal 统计；
- 多标签 event profile；
- 实现带 deadband 的反转统计；
- 如实报告对原假设不利的结果；
- 停在授权暂停点；
- 本地/远端 `155 passed`。

这些工程改动应保留，不需要回滚。

但正因为现在有完整 trace，才能发现下面这个此前被隐藏的底层问题。

---

## 2. 已确认的关键 bug

### 2.1 `set_state(..., settle_steps=0)` 没有刷新 observation

当前实现：

```python
self._env.sim.set_state_from_flattened(state)
self._env.sim.forward()
...
obs = None
for _ in range(settle_steps):
    obs = self._env.step(...)
if obs is not None:
    self._last_obs_raw = obs
return self.get_observation()
```

当 `settle_steps=0` 时，`_last_obs_raw` 完全没有更新；`get_observation()` 又会优先复用旧缓存。

所以：

- sim state 已经恢复到 terminal；
- `entity_pos()`、predicate、joint 来自新 sim state；
- 但 EEF、gripper、相机图像、policy 首次输入仍来自上一段旧 observation。

这产生了一个“混合状态”：物体/关节是 terminal，机器人观测却是旧轨迹。

### 2.2 trace 给出了逐位证据

policy trace 的 step 0 在多个 task 上几乎完全相同：

```text
[-0.208, -0.000, 1.173]
```

这是环境旧初始 observation，不是对应 natural terminal 的 EEF。

policy step 0 → step 1 的伪跳变：

```text
bowl_on_plate      0.323–0.331 m
bowl_on_stove      0.294–0.298 m
object_in_basket   0.299–0.308 m
open_drawer        0.270 m
```

机器人不可能在一个 env step 内真实移动 27–33cm；这是 stale observation 切换到真实 observation 的跳变。

### 2.3 no-op step 0 精确等于前一条 policy 的末帧

独立复算 8 对：

```text
distance(noop_step0, policy_final) = 0.00000000
```

8/8 全部逐位一致。

这证明 no-op rollout 在 `set_state(saved_terminal)` 之后，step 0 仍然读的是 policy rollout 的末帧缓存。

no-op step 0 → step 1 的伪跳变达到：

```text
0.035–0.109 m（placement）
0.420–0.488 m（drawer）
```

因此报告里 drawer no-op path `0.96 / 1.04m` 不能解释为 terminal capture 的机器人残余速度；主要来源首先是观测缓存污染。

---

## 3. 对 smoke-v2 结果的影响

### 3.1 路径和最大位移无效

offline analyzer 从 trace 的 step0 开始计算路径，因而把伪跳变直接算入：

- policy path；
- no-op path；
- max displacement；
- paired path difference；
- path/max ratio。

这些数字全部需要重跑。

### 3.2 policy 首个 action chunk 使用了错误 observation

更严重的是，policy 的首次 `predict()` 调用了缓存中的旧图像和旧 proprio。

OpenVLA-OFT 的首个 8-step action chunk 因此不是对 terminal state 的响应。即使 step 1 后 observation 恢复正确，前 8 个动作已经可能：

- 把机器人推向错误区域；
- 造成 subject contact；
- 改变任务实体；
- 触发 transient predicate violation；
- 改变后续闭环轨迹。

所以当前：

```text
T-GDR 5/8
task_state_changed 6/8
contacted_subject 6/8
reapproached_subject 6/6
paired path +0.74m
```

都不能作为有效实验结论。

### 3.3 no-op 对照不是同起点 observation

物理 state 虽被恢复，但 trace step 0 和 observation cache 没恢复，policy/no-op 不满足“同一观测起点”。

smoke-v2 可以保留用于复现 bug，但必须在：

```text
artifacts_manifest.md
summary.md
02_terminal_smoke.md
mentor_review_2_response.md
```

显式标为 **invalid diagnostic run: stale observation after state restore**。

---

## 4. 修复要求

### 4.1 为 `LiberoArena` 增加无步进 observation refresh

优先方案：在 `sim.forward()` 后调用 robosuite 内层环境：

```python
inner_env._get_observations(force_update=True)
```

LIBERO wrapper 自己的 `_get_observations()` 不接受 `force_update`，因此需要安全地沿 `.env` 链找到支持 `force_update=True` 的内层 robosuite environment。

实现建议：

```python
def _refresh_observation_from_current_state(self) -> dict:
    # 沿 wrapper.env 链寻找 _get_observations
    # 优先尝试 force_update=True
    # 成功后更新 self._last_obs_raw
    # 失败必须抛出可读错误，不能静默复用旧缓存
```

`set_state()` 在任何 `settle_steps` 值下都必须确保返回的 observation 与当前 sim state 一致。

禁止简单调用 wrapper 的无参数 `_get_observations()` 后就假定缓存已刷新；必须用真实一致性测试证明。

### 4.2 刷新 observation 不得推进物理

在刷新前后比较 flattened state：

```text
max_abs(state_before_refresh - state_after_refresh)
```

应为 0 或仅有可解释的非积分缓存差异。不能为了刷新图像偷偷走一个 env step。

如果当前 robosuite 版本无法无步进刷新，fallback 才允许走一次 dummy step；但此时必须：

1. 明确记录 canonicalization step；
2. 把 dummy 后的 state 保存为统一 canonical start；
3. policy/no-op 都从该 canonical state 开始；
4. dummy step 不计入评估窗口。

优先使用无步进 refresh。

### 4.3 必须有真实 LIBERO 集成测试

Mock 测试不足以抓住这个 bug。新增远端诊断 / integration test：

1. 保存状态 A 及其 observation；
2. 把环境运行到明显不同的状态 B；
3. `set_state(A, settle_steps=0)`；
4. 立即读取 observation A'；
5. 验证：
   - A' 的 `robot0_eef_pos` 与 A 一致；
   - A' 不等于 B 的缓存 observation；
   - image/proprio 均已刷新；
   - refresh 前后 sim flattened state 不变；
   - predicate 与 state A 一致。

产物写入 `results/plan1/state_obs_refresh_check.json`，日志进入 `execute_logs`。

### 4.4 smoke-v3 开跑前增加 trace guard

每个 rollout 在 step 0 时断言：

- policy 和 no-op 的 step-0 EEF 一致；
- policy 和 no-op 的 step-0 subject / target / joint 一致；
- policy 和 no-op 的 step-0 predicate 一致；
- observation EEF 与 simulator EEF site 一致；
- step0 不等于上一条 rollout 的末帧，除非真实 state 本来相同；
- 第一个 env step 的位移在物理合理范围内。

最后一条不要拍脑袋只设固定阈值；同时保存 raw 值，并以官方正常 rollout 的单步位移分布作为参考。

---

## 5. Event profile 的附加修正

### 5.1 事件时刻必须使用 trace 的 `step` 列

当前 `first_close_step` 和 `first_break_step` 使用 list index 再 `+1`。trace 已含 step 0，因此会产生 off-by-one；若将来有缺失行，偏差更大。

修正：event profile 接收 `step` 列，所有事件时刻直接返回对应 trace step。

### 5.2 T-GDR 需要严重度曲线

当前 `ever_broken=True` 把单步 predicate flicker 与连续 21 步失败同权计数。

同时报告：

- `T-GDR(any)`；
- `T-GDR(max_consecutive >= 3)`；
- `T-GDR(max_consecutive >= 5)`；
- `T-GDR(max_consecutive >= 10)`；
- broken-step fraction；
- max consecutive broken steps。

不能只用 `5/8=0.625` 作 headline。

### 5.3 approach threshold 不得在同一 smoke 上调参

保留连续量：

```text
approach_delta_policy
approach_delta_noop
paired difference
```

并报告 1/2/5cm 三档敏感度。不能因为 no-op 有假阳性，就在同一 8 对数据上挑一个刚好消除假阳性的阈值作为正式阈值。

---

## 6. Natural terminal capture 的机器人速度问题

DeepSeek 提议给 terminal capture 加机器人速度约束。这个问题目前**暂不裁决**，因为所谓 drawer no-op 1m 路径已被 stale observation 污染，不能据此判断真实 settling 有多大。

先修 observation refresh，并用相同 8 个保存 state 重跑 paired control。只有修正后的 no-op 仍显示显著机器人运动时，才讨论：

- 是否增加机器人 joint / EEF velocity 稳定窗口；
- 或保留自然动态终态并始终用 no-op paired difference。

不要依据无效的 smoke-v2 事后修改 capture 标准。

---

## 7. 下一步执行裁决

### 7.1 当前不进入 Stage 4

smoke-v2 的 policy 首个 action chunk 输入错误，因此尚未完成一个有效的 natural-terminal replay。必须先把基础 harness 修正确。

### 7.2 批准 smoke-v3

完成 §4、§5 后：

- 复用原 8 个 `.npy` state；
- 新输出目录 `results/plan1/terminal_replay_v3/`；
- policy/no-op paired replay；
- 完整 trace；
- 离线 event profile；
- 不覆盖 v1/v2；
- 完成后再次暂停。

### 7.3 smoke-v3 通过后的顺序

若 observation 一致性检查通过，且 smoke-v3 仍出现明显的 policy-specific task-directed events：

```text
Stage 4 Intermediate Completed-Subgoal feasibility + pilot
```

仍然不直接进入 Stage 2 full。

---

## 8. 当前研究判断

smoke-v2 的数值暂时无效，但这不等于研究方向失败。相反，这再次说明本项目的核心困难不是“跑出一个高 UER”，而是：

> 必须把真实 policy behavior、状态恢复 artifact、controller settling、predicate flicker 和 task-directed re-execution 分离。

只有完成这种分离，Learning Not to Act 才能成为可信研究，而不是 harness artifact。

