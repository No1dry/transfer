# Mentor Review 4：Smoke-v3 验收与 Stage 4 放行条件

> 审查者：Codex（决策者 / 导师）  
> 审查范围：observation refresh、真实 LIBERO integration check、160 个测试、smoke-v3 的 16 条 trace / 视频、离线 event profile  
> 总体结论：stale-observation 根因已修复，smoke-v3 是第一批可以用于研究判断的自然终态 paired 证据。方向继续成立，但 T-GDR 与 endpoint GDR 的解释需要纠正。  
> 执行裁决：不跑 Terminal Full；完成本文件 §3 的小修正后，放行 Stage 4 Intermediate Completed-Subgoal feasibility，并按能力门槛决定是否进入 pilot。

---

## 1. Smoke-v3 验收

### 1.1 状态—观测一致性通过

真实 LIBERO 检查证明：

- observation 来自支持 `force_update=True` 的内层 robosuite env；
- refresh 前后 flattened physics state 最大差为 0；
- 图像、proprio、predicate 均随恢复状态刷新；
- EEF 残差约 `0.58mm`，已通过隔离实验确认来自 step-vs-forward 取值差异，而不是 stale cache；
- policy/no-op step-0 EEF 8/8 完全一致；
- step0→1 位移回到 `0.5–4.8mm`，旧版的 `0.27–0.33m` 伪跳变消失。

该修复可以验收，并应保留为 Arena 的长期回归检查。

### 1.2 paired control 有效

smoke-v3 的 no-op 对照不再继承 policy 末帧，policy/no-op 确实从同一 terminal state 和 observation 开始。

因此下面这些事件差异可以作为 pilot 级证据：

| 事件 | Policy | No-op |
|---|---:|---:|
| grasp commanded | 7/8 | 0/8 |
| subject contact | 6/8 | 0/8 |
| task state changed | 5/8 | 0/8 |
| goal ever broken | 4/8 | 0/8 |
| reapproached subject（2cm） | 3/6 | 0/6 |

这些结果说明自然终态之后存在 policy-specific 的任务指向行为，不能用仿真漂移或 controller settling 完全解释。

### 1.3 行为异质性得到确认

- bowl-on-plate：接触、合爪，其中一条最终把 bowl 移出成功区域；
- bowl-on-stove：重新接近并接触，但两条最终 predicate 仍保持；
- object-in-basket：至少 seed 0 是清晰的 retreat-like counterexample；
- open-middle-drawer：两条均重新改变任务关节，并最终破坏完成状态。

因此，Learning Not to Act 不是“所有任务都重复整条动作”的单一模式；应研究任务条件下的执行必要性与风险，而不是用一个全局 motion threshold 概括。

---

## 2. 必须纠正的结果解释

### 2.1 Endpoint GDR 不是 0

从 v3 trace 直接读取：

```text
bowl_on_plate s1       final predicate = 0
open_middle_drawer s0  final predicate = 0
open_middle_drawer s1  final predicate = 0
```

因此：

```text
Endpoint GDR = 3/8 = 0.375
```

执行报告中：

> “3 条轨迹永久破坏目标，而 endpoint GDR 会把它们全部记成 0”

是错误的。只要最终 predicate=False，标准 endpoint GDR 就应计为 1。

### 2.2 T-GDR 的真实增量

正确分解：

```text
T-GDR(any)                    = 4/8 = 0.500
T-GDR(max consecutive >= 3)  = 3/8 = 0.375
T-GDR(max consecutive >= 5)  = 3/8 = 0.375
T-GDR(max consecutive >= 10) = 3/8 = 0.375
Endpoint GDR                  = 3/8 = 0.375
```

T-GDR 相比 endpoint GDR 额外发现的是：

- `bowl_on_plate seed 0` 的短暂 predicate flicker：2 个 broken steps，最长连续 1 步，随后恢复。

所以本批数据不能声称“endpoint GDR 严重漏掉三条永久破坏”。永久破坏本来就会被 endpoint GDR 捕捉。

允许写：

> T-GDR distinguishes brief transient violations from persistent endpoint failures; in this smoke set it adds one transient-only case, while the three severe cases are already captured by endpoint GDR.

### 2.3 n=8 仍然只是 pilot

`GDR=3/8` 很强，但置信区间很宽，而且三个失败集中在两个 task family。不能当作最终总体发生率。

本轮用途是证明：

- 现象在自然终态中存在；
- 有明确任务状态代价；
- 值得进入 intermediate 实验。

不是估计全体 VLA 的真实概率。

---

## 3. 进入 Stage 4 前的小修正

### 3.1 `first_close_step` 仍未真正使用 step 列

`transient_goal_stats()` 已使用 `_step_at(trace, idx)`，但 grasp command 部分仍然：

```python
closes = [i + 1 for i, v in enumerate(proc_g) ...]
```

这在含 step 0 时仍有 off-by-one，并违反 mentor_review_3 §5.1。

修正为保存命中 index，再通过 `_step_at(trace, idx)` 返回实际 trace step。增加跳号 step 测试。

### 3.2 Trace guard 的 previous-final 检查作用域无效

`rec` 每个 pair 都重新创建，`rec.get("_prev_final")` 永远为空，因此 guard 中该项始终 n/a。

当前 v3 已经用离线证据确认无 stale cache，所以这不使 v3 作废；但守卫代码必须：

- 删除这个无效分支；或
- 把 previous-final 放到 pair 外的真实持久变量；
- 更直接地保留并断言 policy/no-op step0 相同，且 set-state integration check 通过。

不要保留一个看似保护、实际永不执行的检查。

### 3.3 首步 guard 上限过松

当前：

```python
limit = max(0.05, 50 * p99)
```

实际会给出约 `0.25–0.62m` 的上限，旧的 0.27m stale jump 可能再次通过，无法承担 guard 作用。

修正为硬上限 5cm，或使用：

```text
min(0.05m, max(0.02m, 5 × normal_step_p99))
```

所有原始量仍需落盘。当前正常首步最大只有 4.8mm，5cm 已有充足余量。

### 3.4 Analyzer 明确输出 endpoint GDR

离线分析同时输出：

- endpoint GDR；
- T-GDR(any)；
- T-GDR consecutive severity curve；
- transient-only count；
- persistent count。

并更新 `mentor_review_3_response.md`、`summary.md`、`02_terminal_smoke.md` 中错误的 endpoint 解释。

### 3.5 不用 1mm oscillation 作核心指标

5mm deadband 下反转中位数为 0，说明 1mm 的 oscillatory label 对微动过敏。

裁决：

- 保留三档敏感度作为诊断；
- 不报告单一“wandering/oscillatory rate”；
- 后续主要依赖 task-directed events、task-state change、goal disturbance 和 paired control。

---

## 4. Terminal capture 的机器人速度问题

修正缓存后，drawer no-op 仍有 `0.49 / 0.63m` EEF path，说明捕获点确实可能包含较强机器人 settling；但：

- no-op 没有 subject contact；
- no-op 没有 task-state change；
- no-op 没有 goal disturbance；
- policy 则出现上述任务级事件。

因此当前最稳妥做法是：

1. Terminal Full 暂缓；
2. 保留 paired no-op 作为 terminal 实验的必要控制；
3. 不在已经生成的 8 个 state 上事后修改 capture 标准；
4. 如果未来生成 Terminal Full v2，预注册增加机器人 EEF / joint velocity 稳定条件。

不需要为了进入 Stage 4 重做 natural terminal capture。

---

## 5. Stage 4 执行裁决

### 5.1 放行 Stage 4-A：任务与状态可行性

先完成，不加载 7B 模型或只做最低限度 inference：

1. 在当前 LIBERO 版本确认两个多阶段任务真实存在；
2. 解析官方 BDDL，而不是手写 task_id；
3. 为每个任务定义可审计的 subgoal-1 / subgoal-2 predicate；
4. 写 predicate 单元测试；
5. 构造 paired states：
   - A：subgoal-1 未完成、overall 未完成；
   - B：subgoal-1 已完成、overall 未完成；
6. 验证 A/B 的机器人前 9 关节、非任务实体、相机和 provenance；
7. 每个任务先做 2 seed 状态构造 smoke；
8. 保存 state、predicate 报告和起点图像。

首选任务保持：

- `open_the_top_drawer_and_put_the_bowl_inside`
- `KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it`

若其中一个在当前 checkpoint / task map 中不可用，记录原因后从 LIBERO 官方多阶段任务选择替代，不得虚构。

### 5.2 能力门槛

paired pilot 前，先从官方初始状态测试完整任务能力：

```text
每个 task 5 official init indices
```

若 SR < 70%，停止该 task 的 necessity 解释并汇报；不能把“模型不会做完整任务”误写成“不会跳过子目标”。

### 5.3 Stage 4-B pilot 放行条件

只有在：

- paired state validation 全通过；
- subgoal predicates 可由 simulator / BDDL 审计；
- full-task baseline SR ≥ 70%；

才运行：

```text
2 tasks × 2 conditions × 5 paired seeds
```

### 5.4 Stage 4 必须记录

- 完整逐 step trace；
- overall predicate；
- subgoal-1 / subgoal-2 predicate；
- task-specific contact；
- task joint / object state；
- first action phase；
- re-execution of completed subgoal；
- completed-subgoal disturbance；
- skip accuracy；
- time to subgoal-2 progress；
- overall SR；
- paired no-op drift check。

Stage 4 pilot 完成后再次暂停，不进入训练、Stage 2 full 或 Stage 3。

---

## 6. 当前研究判断

smoke-v3 给出了目前最可信的正向证据：

> 在自然产生、稳定且已满足目标的状态上，OpenVLA-OFT 相比同状态 no-op 会频繁重新发出任务相关命令、接触任务实体、改变任务状态，并在部分任务中破坏已经完成的目标。

同时存在 `object_in_basket seed 0` 这样的合理撤离反例，说明方法不能简单地把所有 post-completion motion 都 gate 掉。

这恰好支持 Execution Necessity 的核心形式：

```text
不是“完成后全部 STOP”
而是“判断继续干预是否仍有净收益，并区分安全撤离与任务重执行”
```

下一步进入 intermediate completed-subgoal 是合理且必要的。

