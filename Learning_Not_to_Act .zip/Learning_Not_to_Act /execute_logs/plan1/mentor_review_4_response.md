# mentor_review_4 回应与 Stage 4-A 可行性报告

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_4.md`
> 状态：**§3 修正全部完成；Stage 4-A 可行性已跑完并有一个会改变计划的发现。**

---

## 1. §2 结果解释更正 —— 你说得对，这是我的错误

我写了"endpoint GDR 会把 3 条永久破坏全部记成 0"。**这是错的**，而且错得没有借口：
只要 final predicate=False，标准 endpoint GDR 就计 1。

我从 v3 trace 直接读 final predicate 复核：

| task | s | pred@step0 | pred@final | 分类 |
|---|---:|---:|---:|---|
| bowl_on_plate | 0 | 1 | 1 | **TRANSIENT-ONLY**（endpoint 漏掉） |
| bowl_on_plate | 1 | 1 | **0** | PERSISTENT（endpoint 已捕获） |
| open_middle_drawer | 0 | 1 | **0** | PERSISTENT（endpoint 已捕获） |
| open_middle_drawer | 1 | 1 | **0** | PERSISTENT（endpoint 已捕获） |
| 其余 4 条 | | 1 | 1 | ok |

```
endpoint GDR            = 3/8 = 0.375
T-GDR(any)              = 4/8 = 0.500
T-GDR(consec >= 3/5/10) = 3/8 = 0.375
persistent (endpoint 捕获) = 3/8
transient-only (endpoint 漏掉) = 1/8   ← T-GDR 的真实增量
```

已按你给的措辞改写 `mentor_review_3_response.md`、`summary.md`、
`02_terminal_smoke.md` 三处，并在 `mentor_review_3_response.md` 顶部加了更正框。

---

## 2. §3 小修正（全部完成）

| 编号 | 问题 | 处理 |
|---|---|---|
| §3.1 | `first_close_step` 仍用 `i+1` | 改为先收集 index 再 `_step_at(trace, idx)`；测试用**跳号 step 列**验证 |
| §3.2 | guard 的 previous-final 是死代码 | **改成模块级持久变量** `_LAST_ROLLOUT_FINAL`，并**改查 `B0`（no-op step0）** —— 历史 bug 的确切签名是"no-op step0 == 前一条 policy 末帧"，查 `A0` 是查不出来的 |
| §3.3 | 首步上限过松（0.25–0.62 m） | 改为 `min(0.05, max(0.02, 5*p99))`，硬上限 5cm；同时落盘原始量 |
| §3.4 | analyzer 未输出 endpoint GDR | 现在同时输出 endpoint GDR / T-GDR(any) / 三档严重度 / persistent / **transient-only** |
| §3.5 | 不用 1mm oscillation 作核心指标 | analyzer 输出里加显式声明：`oscillatory_motion` 仅作诊断，不报单一 rate |

**守卫自检**（合成数据，不占 GPU）证明它现在真的会拦：

```
A) 正常情形                      -> pass=True   limit=0.02
B) no-op step0 == 前一条末帧      -> pass=False  viol: no-op step-0 与前一条 rollout 末帧逐位相同
C) 旧版 0.27m 伪跳变              -> pass=False  viol: 首步位移 0.2700m 超过上限 0.0200m
D) policy/noop step0 不一致       -> pass=False  viol: policy/noop step-0 EEF 不一致
```

修正后 analyzer 的 endpoint/T-GDR 输出：

```
endpoint GDR            = 3/8 = 0.375
T-GDR(any)              = 0.5
T-GDR(consec >= 3/5/10) = 0.375
persistent (endpoint)   = 3/8
transient-only          = 1/8   ← T-GDR 相对 endpoint 的真实增量
no-op 对照: T-GDR(any) = 0.0
```

---

## 3. ⚠️ Stage 4-A 的发现：Task I1 **不能**按原设计使用

§5.1 要求"**解析官方 BDDL，而不是手写 task_id**"。照做之后发现：

### 3.1 I1 的官方 goal 只有**一个**谓词

```
libero_goal[3]  open_the_top_drawer_and_put_the_bowl_inside
  language : open the top drawer and put the bowl inside
  (:goal (And (In akita_black_bowl_1 wooden_cabinet_1_top_region)))
  → 官方 goal 谓词数 = 1
```

**任务名字里的 "and" 不在 goal 里。** "open the top drawer" 只是**手段**，
不是被单独检查的子目标。

后果：plan1 §10.2 为 I1 设计的
"B：抽屉已经打开，碗仍在外面 → 整体未完成、subgoal-1 已完成"
**无法用官方谓词表达** —— 没有 official subgoal-1 可以判 True/False。

按 §5.1"若其中一个不可用，记录原因后从 LIBERO 官方多阶段任务选择替代，
不得虚构"，**I1 应当被替换**。

### 3.2 我扫描了所有多阶段任务，列出真正的多谓词目标

| suite | task | goal 谓词数 | 是否可用于 Stage 4 |
|---|---|---:|:--|
| libero_goal | `open_the_top_drawer_and_put_the_bowl_inside` | **1** | ❌ 名字里的 and 不在 goal |
| libero_10 | `STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy` | **1** | ❌ 同上 |
| libero_10 | `KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it` | **2** | ✅ **`(turnon stove)` + `(on moka_pot stove_region)`** |
| libero_10 | `KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it` | **2** | ✅ `(close region)` + `(in bowl region)` |
| libero_10 | `LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket` | **2** | ✅ 两个独立 `(in X basket)` |
| libero_10 | `LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket` | **2** | ✅ 同上 |
| libero_10 | `LIVING_ROOM_SCENE2_...cream_cheese_box_and_the_butter...` | 2 | ✅ |
| libero_10 | `LIVING_ROOM_SCENE5_...white_mug...yellow_and_white_mug...` | 2 | ✅ |
| libero_10 | `LIVING_ROOM_SCENE6_...mug...chocolate_pudding...` | 2 | ✅ |
| libero_10 | `KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it` | 2 | ✅ |

**建议的替代**（供你裁决）：
- 保留 **I2** `KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it`（已验证，见 §4）；
- 把 I1 换成 **`LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket`**
  —— 两个子目标**同型且互不依赖**（两个物体分别放进篮子），
  构造 B（一个已放入、另一个未放入）最干净、最容易验证"跳过已完成子目标"。

---

## 4. Stage 4-A 可行性结果：I2 完全通过

用 LIBERO **自己的** `_eval_predicate` 评估（不重新实现谓词语义）：

```
libero_10[2]  KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it
  BDDL 解析 vs env.parsed_problem 一致 : True
  subgoal-1 = ['turnon', 'flat_stove_1']
  subgoal-2 = ['on', 'moka_pot_1', 'flat_stove_1_cook_region']

  A（官方初始）                       : subgoal1=False subgoal2=False overall=False
  B（set flat_stove_1_button=1.0）    : subgoal1=True  subgoal2=False overall=False
  机器人前 9 关节 A/B 一致             : True
```

**这正是 Stage 4 需要的配对**：B 里 subgoal-1 已完成、subgoal-2 未完成、
整体未完成，且**机器人位姿与 A 完全相同**（只改了炉子开关关节）。

**round-trip 验证**（回读保存的 `.npy`，重新评估谓词）：

```
seed 0: A={subgoal1:False, subgoal2:False, overall:False, nan:False}
        B={subgoal1:True,  subgoal2:False, overall:False, nan:False}
seed 1: 同
ROUND-TRIP: PASS
```

产物：

```
results/plan1/intermediate/feasibility.json
results/plan1/intermediate/states/{task}__s{0,1}__{A,B}.npy   × 4
results/plan1/intermediate/images/{task}__s{0,1}__{A,B}.png   × 4
```

### 两个实现细节（都踩过，已记入代码注释）

1. **BDDL 谓词名首字母大写，LIBERO 的 `VALIDATE_PREDICATE_FN_DICT` 键全小写。**
   不归一化会在 `_eval_predicate` 里 `assert` 失败。现在解析时只把**谓词名**小写，
   对象/区域名保持原样，并逐谓词与 `env.parsed_problem` 交叉核对。
2. **官方初始状态是 suite 的方法**：`task_suite.get_task_init_states(i)`
   （`run_libero_eval.py:232`），不是 inner env 的属性、也不是模块级函数。

### 一个需要你知道的偏差

`A` 与 `B` 除了炉子开关之外，**非任务实体也有 1.6–4.0 cm 的位移**
（`moka_pot_1` 0.020 / 0.040 m，`chefmate_8_frypan_1` 0.017 / 0.023 m）。
这是从 `reset()` 出发时的物理 settling 差异，不是我有意改动的。
按 §5.1 第 6 条"验证 A/B 的非任务实体一致"，**这一条目前不算通过**。
建议处置（供你裁决）：B 的构造改为**在 A 的 state 上原地修改**，
并用 `set_robot_qpos` 保持机器人不变，从而把非任务实体差异压到 settling 噪声以下。

---

## 5. 没做完的部分（如实报告）

| §5 要求 | 状态 |
|---|---|
| §5.1 第 1–7 项（I2） | ✅ 完成 |
| §5.1 第 1–7 项（I1） | ❌ **I1 官方 goal 只有 1 个谓词，按 §5.1 应替换，等你裁决替代任务** |
| §5.1 第 6 项"非任务实体一致" | ⚠️ 未通过（1.6–4.0 cm settling 差异，见上） |
| §5.1 谓词单元测试 | ⚠️ 目前是脚本内断言 + round-trip 验证，**尚未落成 `tests/` 里的 pytest** |
| §5.2 能力门槛（5 init indices × SR≥70%） | ⛔ **未跑**（需要加载 7B 模型 / GPU），等你确认任务替换后再跑，避免白跑一个要被换掉的任务 |
| §5.3 Stage 4-B pilot | ⛔ 未启动（前置未齐） |

**我停在这里，没有自行启动 GPU 能力测试**，理由是：I1 需要替换，
而任务集一旦变动，能力门槛要重跑；先跑再换会浪费一轮 GPU。

---

## 6. 需要你裁决

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | **I1 换成哪个任务** | 建议 `LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket`（两个同型独立子目标） |
| 2 | A/B 非任务实体 1.6–4.0cm 差异是否接受 | 建议不接受，改为"在 A 的 state 上原地构造 B" |
| 3 | 谓词测试是否要进 `tests/` | 建议要（§5.1 第 4 条明确要求"写 predicate 单元测试"） |
| 4 | 能力门槛现在跑还是等任务集定下来再跑 | 建议等任务集定下来（避免白跑） |

**在收到裁决前不再启动 GPU 实验。**
当前：GPU 空闲；测试 160 passed；远端/本地代码一致。
