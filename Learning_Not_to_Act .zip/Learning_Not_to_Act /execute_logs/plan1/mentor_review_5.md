# Mentor Review 5：Stage 4-A 可行性裁决

> 审查者：Codex（决策者 / 导师）  
> 审查范围：mentor_review_4 response、BDDL 扫描、I2 feasibility states、Stage 4-A 脚本与远端环境  
> 结论：I1 不适合作为“官方 completed subgoal”任务；I2 的谓词结构适合，但当前 paired state 构造还没有通过一致性要求。  
> 执行裁决：批准替换 I1；修正 paired builder 和测试后，先完成两个任务各 2 seed 的状态验证，再运行完整任务能力门槛。满足 SR 门槛后可进入 Stage 4-B pilot。

---

## 1. 对 Stage 4-A 发现的评价

DeepSeek 按要求解析官方 BDDL，而不是根据任务名字臆测子目标，这是正确做法。

已确认：

```text
open_the_top_drawer_and_put_the_bowl_inside
```

官方 goal 只有：

```text
(In akita_black_bowl_1 wooden_cabinet_1_top_region)
```

“打开抽屉”是完成放置的手段，不是 official goal conjunct。因此，原计划中：

```text
subgoal-1 = drawer open
subgoal-2 = bowl inside
```

不能作为“两个官方 goal predicate”实验来写。

裁决：**I1 从 Stage 4 的主实验中移除。**

它以后仍可作为 procedural-precondition 任务单独研究，但不能混进本轮严格的 official-predicate pilot。

---

## 2. 替代任务裁决

批准使用：

```text
LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket
```

作为新的 I1。

原因：

- 两个官方 `(in object basket)` 谓词；
- 两个子目标同型；
- 子目标彼此基本独立；
- completed subgoal 与 remaining subgoal 的实体可以清楚区分；
- B 状态可以定义为“一个物体已在 basket，另一个仍在初始位置”；
- 可直接测模型是否重新接近/抓取已完成对象，还是转向剩余对象。

保留 I2：

```text
KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it
```

其两个官方谓词已经验证：

```text
(turnon flat_stove_1)
(on moka_pot_1 flat_stove_1_cook_region)
```

---

## 3. 当前 I2 paired state 尚未通过

### 3.1 `build_B()` 会偷偷 reset

seed loop 先得到 official state `sA`，随后调用：

```python
build_B(probe, sub1)
```

但 `build_B()` 内部再次：

```python
probe.reset()
base = probe.state()
```

因此 B 并不是在 `sA` 上只修改 stove joint，而是从另一次 reset 的 state 构造。

这正是 moka pot / frypan 出现 1.6–4.0cm 差异的直接原因。

修正接口：

```python
build_B(probe, subgoal1, base_state=sA)
```

函数内部禁止 reset；若未显式传入 base state，应直接报错。

### 3.2 robot qpos 切片错误

flattened MuJoCo state 以 `time` 开头，不能直接：

```python
s[:9]
```

这会把 time 当第一个机器人关节，同时漏掉第 9 个机器人关节。

必须使用：

```python
layout = StateLayout.from_model(model)
get_robot_qpos(state, layout, n=9)
```

并增加一个非零 time 的回归测试，确保直接切片式错误会被抓到。

### 3.3 一致性应检查 state diff whitelist

仅比较几个物体坐标不够。对 A/B flattened state 做逐维 diff，并把差异映射回：

- qpos joint；
- qvel dof；
- act（若存在）。

I2 B 允许变化的只有：

- `flat_stove_1_button` 的 qpos；
- 对应 qvel（应清零或与 A 一致）；

I1 B 允许变化的只有：

- completed-object 的 free joint pose；
- completed-object 的 qvel；

其他任何维度变化都判 pair invalid。

输出：

```text
changed_indices
resolved_names
max_unexpected_abs_diff
pair_valid
```

### 3.4 joint 值必须有物理依据

远端核对：

```text
flat_stove_1_button range = [-0.005, 2.1]
turnon predicate range    = [0.5, 2.1]
```

`1.0` 在合法范围内，可以继续使用；但构造报告必须保存：

- joint range；
- turn-on predicate range；
- chosen value；
- chosen value 是否在两者交集内。

不要保留当前 `(0, 1, -1, 0.5, -0.5)` 的无约束盲试作为正式 builder。

---

## 4. 新 I1 的构造要求

### 4.1 状态定义

对每个 official init state：

```text
A: alphabet soup outside, tomato sauce outside, overall=False
B: alphabet soup inside basket, tomato sauce outside, overall=False
```

如果官方 goal / demonstration order 表明 tomato sauce 更适合作为第一个对象，可以交换，但必须预注册且所有 seed 一致。

### 4.2 B 必须从同一个 A state 原地构造

只能修改 completed object 的 free-joint pose 和 velocity。

放置位置必须：

- 由 basket contain region / simulator geometry 得到；
- 通过 LIBERO 官方 `in` predicate；
- no-op 稳定窗口内持续为 True；
- remaining-object predicate 持续为 False；
- overall 持续为 False。

若需要 settle：

1. 明确记录 settle 步数；
2. settle 后重新写回 robot 与所有非任务实体的 A-state qpos；
3. 再做 state diff whitelist；
4. 用 no-op 稳定窗口验证 B 不会立即失效。

### 4.3 两个 subgoal order 控制

两物体任务可能存在 demonstration order bias。pilot 中至少记录：

- A 条件下模型首先接近哪一个对象；
- B 条件下模型是否仍接近已完成对象；
- B 条件下是否转向 remaining object；

如果 A 条件下模型通常先做 tomato sauce，而我们把 alphabet soup 设成 completed，B 的解释会受顺序混淆。能力 baseline trace 用来确定这一点，不能只看 overall success。

---

## 5. Predicate 测试要求

批准 DeepSeek 的建议：谓词测试必须进入测试体系。

至少覆盖：

1. BDDL parser 能解析 1-predicate 与 2-predicate goal；
2. predicate 名小写化不改变对象/region 名；
3. parser 与 `env.parsed_problem["goal_state"]` 一致；
4. A：subgoal1=False、subgoal2=False、overall=False；
5. B：subgoal1=True、subgoal2=False、overall=False；
6. state round-trip 后标签不变；
7. A/B state diff whitelist；
8. robot 9 joints 全部一致；
9. no-op 稳定窗口不改变 subgoal 标签。

本地没有 LIBERO 时：

- parser 纯函数测试在本地运行；
- simulator integration tests 由远端脚本运行并保存 JSON；
- 两者均纳入 execution log。

---

## 6. 能力门槛与 Stage 4-B

### 6.1 先跑完整任务能力 baseline

任务集固定、paired states 通过后，运行：

```text
2 tasks × 5 official init indices
```

要求：

- 使用 official initial states；
- 使用正确 suite unnorm key；
- 按官方 max step budget；
- 保存逐步 trace 和视频；
- 报 overall SR；
- 报各 subgoal 达成顺序与首次翻转时间。

每个 task 至少 `4/5` 成功，才满足原定 `SR ≥ 70%` 门槛。

### 6.2 通过后可直接运行 Stage 4-B pilot

如果两个任务都满足能力门槛，批准：

```text
2 tasks × 2 conditions × 5 paired seeds
```

不需要再次询问是否能启动，但必须遵守：

- 全程使用经过 whitelist 验证的 paired states；
- 保存逐步 trace / 视频 / predicates；
- paired no-op drift check；
- 不覆盖 feasibility 和 baseline 产物；
- pilot 完成后再次暂停。

若任一任务 baseline `<4/5`，停止该任务并汇报，不得自行降低门槛或更换 seed。

---

## 7. Stage 4 的核心判读

### I1：两个物体进 basket

B 条件正确行为：

```text
忽略已在 basket 的 completed object
→ 接近 remaining object
→ 抓取并放入 basket
```

主要指标：

- completed-object re-approach / contact / displacement；
- remaining-object first approach / contact；
- skip accuracy；
- completed-subgoal disturbance；
- overall success；
- time to remaining-subgoal progress。

### I2：stove on + moka pot on stove

B 条件正确行为：

```text
不再操纵 stove button
→ 直接接近 moka pot
→ 放到 stove
```

主要指标：

- stove-button re-contact / joint path / predicate flip；
- moka-pot first approach / contact；
- skip accuracy；
- completed-subgoal disturbance；
- overall success；
- time to remaining-subgoal progress。

### 必须和 A 条件配对比较

不能只看 B 是否失败。需要比较：

- A 中正常执行 subgoal-1 的行为模板；
- B 中是否仍重复该模板；
- B 是否能把时间和动作转向 subgoal-2。

---

## 8. 当前决策

- 接受替换 I1；
- 不接受当前 A/B 的非任务实体偏移；
- 要求 predicate tests；
- 先修 builder，再跑能力门槛；
- 能力门槛通过后授权 Stage 4-B pilot；
- pilot 完成后暂停；
- 不启动 Terminal Full、Matched Pair full、ENA Head 或 Memory。

