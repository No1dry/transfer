# mentor_review_5 回应与 Stage 4-A 完成报告

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_5.md`
> 状态：**§3/§4/§5 修正完成；两个任务的 paired states 全部通过；
> 能力门槛 5/5 + 5/5 PASS。Stage 4-B pilot 已获 §6.2 授权，但 pilot 脚本尚未写。**

---

## 1. §3 paired builder 修正（4 条全部落实）

| 编号 | 问题 | 处理 |
|---|---|---|
| §3.1 | `build_B()` 内部偷偷 reset | 改为 **`build_B(probe, sub, base_state=sA)`**，函数内不再 reset；B 从 A 原地构造 |
| §3.2 | robot qpos 用 `state[:9]` | 改用 `StateLayout.from_model(model)` + `get_robot_qpos(state, layout, n=9)` |
| §3.3 | 只比几个物体坐标 | 新增**逐维 diff 白名单**，把差异映射回 qpos joint / qvel dof 名字 |
| §3.4 | 关节值盲试 | 改为从 `jnt_range` 取值并记录 joint range / 所选值 / 是否在范围内 |

### 1.1 §3.2 的连带影响 —— 我先做了全库审计

`state[:9]` 会把 `time` 当成第一个关节。我担心这个错误在核心代码里也存在，
所以先 grep 了全仓：

```
benchmark/ 里 get_robot_qpos/set_robot_qpos 全部走 StateLayout —— 正确
scripts/diag_joints.py  用 ms.get_qpos(state, layout)[:9] —— 正确
scripts/plan1_stage4_feasibility.py:136  s[:9]  ← 只有我这里错
```

**结论：主实验（`results/m1/final/`）不受影响**，这个 bug 只存在于我上一轮的
Stage 4-A 脚本里。

### 1.2 修正后的配对验证（两个任务 × 2 seed 全部通过）

| task | seed | A | B | robot 一致 | 白名单 | no-op 稳定 | **pair_valid** |
|---|---:|---|---|:--:|:--:|:--:|:--:|
| I1 `both_in_basket` | 0 | F/F/False | **T/F/False** | ✅ | ✅ | ✅ | **True** |
| I1 | 1 | F/F/False | **T/F/False** | ✅ | ✅ | ✅ | **True** |
| I2 `stove_then_moka` | 0 | F/F/False | **T/F/False** | ✅ | ✅ | ✅ | **True** |
| I2 | 1 | F/F/False | **T/F/False** | ✅ | ✅ | ✅ | **True** |

**白名单细节**（§3.3 要求的四个字段）：

```
I1 seed 0/1: changed=3  unexpected=[]  max_unexpected_abs_diff=0.00e+00
             （只动了 alphabet_soup_1 的 free-joint 位置 xyz）
I2 seed 0/1: changed=1  unexpected=[]  max_unexpected_abs_diff=0.00e+00
             （只动了 flat_stove_1_button 一个 qpos 维）
```

**§3.4 的物理依据**：

```
I2: joint_name=flat_stove_1_button
    joint_range=[-0.005, 2.1]   chosen_value=2.1   chosen_in_range=True
```

（上一版盲试到的是 1.0；现在取的是 range 上界 2.1，两者都能让 `turnon` 为真，
但只有后者是从几何读出来的。盲试 `(0,1,-1,0.5,-0.5)` 已删除。）

> 上一版 1.6–4.0 cm 的非任务实体偏移**已消失** —— §3.1 的原地构造就是根因，你判断得准。

---

## 2. §4 新 I1 的构造

**批准的任务**：`LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket`

```
goal (2): [['in','alphabet_soup_1','basket_1_contain_region'],
           ['in','tomato_sauce_1','basket_1_contain_region']]
BDDL 解析 == env.parsed_problem : True
```

- **completed object = `alphabet_soup_1`**（§4.1 预注册，所有 seed 一致）；
- B 的构造：把 soup 放到 `basket_1_contain_region` site 上方 3cm，free-joint qvel 清零；
- 放置点由 **simulator 的 site 世界坐标**得到（不是写死的坐标）；
- no-op 稳定窗口（10 步）内 subgoal 标签不变 ✅（§4.2）。

### §4.3 顺序混淆 —— 能力 baseline 确认了我的选择是对的

§4.3 要求从能力 baseline 的 trace 判断模型自然先做哪个对象。
实测（5/5 条）：

```
ep0: sg1@168  sg2@291   order=sg1_then_sg2
ep1: sg1@143  sg2@257   order=sg1_then_sg2
ep2: sg1@128  sg2@247   order=sg1_then_sg2
ep3: sg1@149  sg2@269   order=sg1_then_sg2
ep4: sg1@142  sg2@253   order=sg1_then_sg2
```

**模型 5/5 都是先 soup 后 tomato**，与我把 soup 设为 completed 的选择一致
→ **不存在"我们选错了第一个对象"的顺序混淆**。

---

## 3. §5 Predicate 测试

按你的批准，谓词测试已进入测试体系。

**本地纯函数测试**（`tests/test_bddl_goal.py`，9 个，不需要 LIBERO/GPU）：

- 解析 1-predicate / 2-predicate goal（含 unary+binary 混合）；
- 缺 `:goal` 抛 `ValueError`；
- **谓词名小写化不改变对象/region 名**（专门构造 `BowlA` 这种含大写的对象名验证）；
- 输出形状符合 LIBERO 契约（`list[list[str]]`，每项 2 或 3 个 token）。

为此我把解析器从脚本里**抽成独立纯模块** `benchmark/bddl_goal.py`，
这样本地就能测（§5 末段的要求）。

**远端 simulator 集成验证**（`scripts/plan1_stage4_pairs.py`）：

- §5 第 3 条：parser == `env.parsed_problem["goal_state"]` → **True**
- §5 第 4 条：A = subgoal1 False / subgoal2 False / overall False → ✅
- §5 第 5 条：B = subgoal1 True / subgoal2 False / overall False → ✅
- §5 第 6 条：state round-trip 后标签不变 → 见 §6 的 round-trip 验证
- §5 第 7 条：A/B state diff whitelist → ✅（见 §1.2）
- §5 第 8 条：robot 9 joints 全部一致 → ✅
- §5 第 9 条：no-op 稳定窗口不改变 subgoal 标签 → ✅

**测试总数：169 passed**（本地与远端一致）。

---

## 4. §6.1 能力门槛：**两个任务都 PASS**

```
$ ./submit.sh p1cap ./run_diag.sh scripts/plan1_stage4_capability.py --n 5
```

| task | SR | 门槛 (>=4/5) | sg1 首次达成 | sg2 首次达成 | 顺序 |
|---|---:|---|:--|:--|:--|
| I1 `both_in_basket` | **5/5** | **PASS** | 128–168 | 247–291 | sg1→sg2 |
| I2 `stove_then_moka` | **5/5** | **PASS** | 79–91 | 217–251 | sg1→sg2 |

- 使用**官方初始状态**（`suite.get_task_init_states`）；
- **正确的 suite unnorm key**（`libero_10`，两个任务同 suite，已切）；
- **官方 max step budget**（`TASK_MAX_STEPS[LIBERO_10] = 520`，另加 10 步 wait）；
- 保存逐步 trace（`traces/{task}__ep{k}.csv`）与视频（`videos/`）；
- 报 overall SR 与**各 subgoal 首次翻转步号 / 达成顺序**（§4.3 需要）。

`all_gate_pass = True`

### 4.1 本轮我自己抓到的两个 bug（都在验收前修掉）

1. **谓词读错了 simulator。** 我最初另建了一个 `OffScreenRenderEnv` 来调
   `_eval_predicate`，但它从未 step 过，`object_states_dict` 是陈旧值，
   导致每条 episode 都报 `sg1@1 sg2@1`（两个子目标"第 1 步就达成"）。
   `success` 走的是 `arena.goal_satisfied()` 所以是对的，但 subgoal/order 全是误读。
   已改为读 `arena._env.env._eval_predicate`。**这也是上面 5/5 那组 trace 可信的前提。**
2. `arena` 在 `finally` 里可能未定义（创建失败时）→ 已加 `arena = None` 守卫。

---

## 5. §6.2 Stage 4-B pilot 的状态

§6.2 写明能力门槛通过后**无需再询问即可启动** pilot
（`2 tasks × 2 conditions × 5 paired seeds`）。门槛已通过，所以 pilot 在授权范围内。

**但我没有启动它**，原因是诚实的：**pilot 脚本还没写**。
我需要一个新脚本，把
"通过白名单验证的 paired states" × {A/B} × 5 seeds × 完整 trace
串起来，并计算 §7 要求的指标（re-approach / contact / skip accuracy /
completed-subgoal disturbance / time to remaining-subgoal progress）。

考虑到本轮我已经因为**未先 smoke 就上量**而产生了 4 次无效运行
（stale observation、contact 结构、unnorm key、谓词读错 env），
我不打算在预算末尾写一个未经验证的 20-episode 脚本直接开跑。
**下一步应当是：写 pilot 脚本 → 先跑 1 对 smoke 验证 → 再跑 20 个 episode。**

---

## 6. 待你确认

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | Stage 4-B pilot 脚本是否按"先 1 对 smoke、再全量"执行 | 建议是（本轮 4 次无效运行的教训） |
| 2 | I1 的 completed object 固定为 `alphabet_soup_1` 是否确认 | 能力 baseline 5/5 都是先 soup，建议确认 |
| 3 | pilot 的 no-op paired 对照是否也要跑 | 建议要（沿用 smoke-v3 的 paired 设计） |
| 4 | `pairs_v2` 与 `capability` 产物是否算正式产物 | 是，已落盘 `results/plan1/intermediate/` |

**未启动 Terminal Full、Matched Pair full、ENA Head、Memory**（§8 遵守）。
当前 GPU 空闲，测试 169 passed。

## 7. 产物

```
results/plan1/intermediate/
├── feasibility.json                      （上一轮，I1 不可用的证据）
├── pairs_v2/
│   ├── pairs.json                        ← 本轮：白名单 + 标签 + no-op 稳定性
│   ├── states/{task}__s{0,1}__{A,B}.npy  × 8
│   └── images/{task}__s{0,1}__{A,B}.png  × 8
└── capability/
    ├── capability.json                   ← 本轮：SR 5/5 + 5/5
    ├── traces/{task}__ep{0..4}.csv       × 10
    └── videos/{task}__ep{0..4}.mp4       × 10
```
