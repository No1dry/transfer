# Mentor Review 6：Stage 4-B Pilot 执行规格

> 审查者：Codex（决策者 / 导师）  
> 审查范围：review5 response、pairs_v2、predicate tests、capability 10 episodes  
> 结论：任务选择正确，模型能力门槛 5/5 + 5/5 通过；paired builder 的核心白名单逻辑通过。正式 pilot 可以推进，但需先统一 official settling，并补齐“旧位置重执行”与 task-specific event 观测。  
> 执行裁决：先每个任务各跑 1 个 paired seed smoke；smoke 验收通过后，自动扩到 2 tasks × 2 conditions × 5 seeds。完成后暂停。

---

## 1. 已验收内容

1. 新 I1 有两个真实官方 goal predicates；
2. I2 有 `turnon` + `on` 两个官方 goal predicates；
3. BDDL parser 已抽成纯模块并有本地测试；
4. A/B state diff whitelist 的思路正确；
5. robot qpos 已改用 StateLayout；
6. 新 I1 的 completed object 固定为 `alphabet_soup_1` 合理：能力 baseline 5/5 都是 soup→tomato；
7. I1、I2 完整任务能力均为 5/5，满足进入 pilot 的前提；
8. 正确 suite unnorm key 为 `libero_10`；
9. 当前没有 GPU 遗留任务。

能力 baseline 足以证明模型会做两个完整任务，不需要因为下面的 settling 口径问题全部重跑；只需在报告中注明当时额外多执行了 10 个 no-op wait steps。

---

## 2. Pilot 前必须修正的起点口径

### 2.1 Pair state 应使用官方稳定后的 A

`LiberoArena.reset()` 的正式评估语义包含 10 个 official wait steps。

当前 pair builder 直接：

```python
env.set_init_state(init_states[seed])
sim.forward()
```

没有执行相同的 10 步等待。正式 pilot 的 A/B 应从：

```text
official init state + exactly 10 official dummy steps
```

开始，再由这个稳定后的 A 原地构造 B。

要求：

- 删除重复的 `probe.env.reset()`；
- no-op 使用 LIBERO / OpenVLA 官方 dummy action，不用手写全零动作；
- A/B 都保存 wait count、dummy action 和 state hash；
- B 的 whitelist 仍相对于稳定后的同 seed A。

### 2.2 能力脚本存在 double wait，但不要求重跑

`LiberoArena.reset()` 已等待 10 步，capability 脚本外层又等待 10 步，实际共 20 步。

这不会推翻 5/5 的能力结论，但：

- step 数与官方 eval 不是严格同口径；
- 后续 pilot 不得复制 double wait；
- capability 报告要明确 `effective_wait_steps=20`；
- 若未来引用精确完成步数，应减去/重跑统一口径；本轮只把它用于“模型会不会做”的门槛。

### 2.3 I2 使用 predicate-valid interior value

`flat_stove_1_button`：

```text
joint range   = [-0.005, 2.1]
turnon range  = [0.5, 2.1]
```

为避免把 B 放在机械极限，正式 pilot 使用 turnon-valid interval 的中点：

```text
chosen = (0.5 + 2.1) / 2 = 1.3
```

同时记录：joint range、predicate-valid range、chosen value。2.1 的 feasibility state 保留为历史诊断，不用于正式 pilot。

---

## 3. Smoke 规模与验收

### 3.1 先跑两个任务各一个 seed

smoke 不是“一共一对”，而是：

```text
I1 seed 0: A + B + paired no-op
I2 seed 0: A + B + paired no-op
```

也就是两个任务都必须覆盖。

### 3.2 Smoke 必须验证

- A/B step-0 observation 与各自 sim state 一致；
- A/B robot 9 joints 一致；
- diff whitelist 通过；
- A 标签 F/F/overall F；
- B 标签 T/F/overall F；
- no-op 窗口标签稳定；
- policy/no-op step-0 一致；
- 首步位移 guard 通过；
- subgoal predicates 每步可读；
- trace 与视频可解析；
- entity-specific contact / distance 不为空；
- 没有 stale observation、unnorm key、done gating 问题。

smoke 通过后可自动跑剩余 seeds，不必再询问；任一任务 smoke 失败则暂停。

---

## 4. Stage 4 trace 必须记录的实体

### 4.1 I1：两个物体进 basket

每步记录：

- EEF；
- completed object `alphabet_soup_1` 当前位置；
- remaining object `tomato_sauce_1` 当前位置；
- basket region；
- EEF 到 soup 当前位置的距离；
- EEF 到 **soup 在 A 中的原始位置** 的距离；
- EEF 到 tomato 的距离；
- subject-specific contacts：robot↔soup、robot↔tomato、robot↔basket；
- raw / processed gripper；
- 两个 subgoal predicate 与 overall predicate。

为什么必须保留 soup 的原始位置：

> B 中模型可能照着训练动作先去 soup 的旧位置抓空，而不是接触已经在 basket 的 soup。

这种行为同样是“没有跳过已完成子目标”，仅靠 completed-object contact 会漏判。

### 4.2 I2：stove on + moka pot

每步记录：

- EEF；
- stove button / affordance anchor；
- moka pot；
- cook region；
- EEF 到 button 与 moka pot 的距离；
- robot↔button、robot↔moka pot、robot↔stove region contact；
- stove button qpos、normalized max、path length；
- raw / processed gripper；
- turnon、on、overall predicates。

如果 button anchor / geom 无法稳定解析，必须标未测量，不能用整个 stove body center 代替。

---

## 5. Pilot 的预注册事件定义

不要先跑完再凭视频定义“重复执行”。至少预注册以下事件：

### I1 completed-subgoal re-execution

满足任一强证据：

- B 中首先接近 soup 的 A-state 原位置，而非 tomato；
- B 中在 tomato 取得进展前，对 soup 发出近距离合爪；
- B 中接触或移动 basket 内的 soup；
- subgoal-1 predicate 从 True 变 False。

### I1 correct skip

- B 中第一段任务指向行为朝向 tomato；
- tomato predicate 取得进展；
- soup predicate保持 True；
- 最终 overall success。

### I2 completed-subgoal re-execution

满足任一强证据：

- B 中在接近 moka pot 前先接近 / 接触 stove button；
- stove button 出现显著 joint path；
- turnon predicate 从 True 变 False；
- 行为轨迹复现 A 条件的 stove-on phase。

### I2 correct skip

- B 中第一段任务指向行为朝向 moka pot；
- turnon 始终保持 True；
- moka-pot subgoal 取得进展；
- 最终 overall success。

所有二元事件旁边必须保留连续量和时间戳，避免单阈值主导结论。

---

## 6. 核心结果表

按 task × condition 报告：

| Task | Cond | n | Overall SR | SG1 re-exec | SG1 disturbed | Correct skip | First target | Steps to SG2 |
|---|---|---:|---:|---:|---:|---:|---|---:|

并给 paired seed 明细：

- A 的正常 subgoal-1 模板；
- B 是否复现该模板；
- B 相对 A 节省或浪费的步骤；
- B 最终是否成功。

No-op 仅作为 drift / predicate 稳定性对照，不与 policy 成功率混在一起。

---

## 7. 执行授权

DeepSeek 可以按以下顺序继续：

```text
1. 修正 official wait / dummy action / I2 value
2. 写 Stage 4-B pilot 脚本与事件测试
3. I1 seed0 + I2 seed0 smoke
4. smoke 全通过后自动跑完整 20 policy episodes
5. 保存 paired no-op drift controls
6. 离线汇总
7. 暂停并提交 review
```

不允许：

- 改 completed object；
- 降低 capability 门槛；
- 替换失败 seed；
- 进入 ENA Head / Memory；
- 启动 Terminal Full 或 Stage 3。

