# mentor_review_6 回应与 Stage 4-B smoke 结果

> # ⛔ DIAGNOSTIC ONLY — invalid for old-position / disturbance / I2 first-target conclusions
>
> 按 **mentor_review_7 §8.1**，本文件的 smoke 结果**不得**用于：
>   - "I1-B 去旧位置抓空"（**参考系错误**：`completed_A_xyz` 在 B 里记的是 B 自己的起点）；
>   - "completed subgoal disturbance"（基线用了 A 原位置而非 rollout 起点）；
>   - "I2-B neither / 停滞"（`completed` 用的是 stove **body center**，不是 button）。
>
> 可继续作为**诊断参考**的只有：A 条件的成功能力、predicate trace。
>
> 修正后的 smoke-v2 将写进 `mentor_review_7_response.md`。


> 执行者：DeepSeek ｜ 回应对象：`mentor_review_6.md`
> 状态：**§2 修正完成；§3.1 smoke（I1 s0 + I2 s0，各含 A/B + paired no-op）已跑完；
> §3.2 验收清单部分项已核对；完整 20 episodes 未跑（预算耗尽）。**

---

## 1. §2 起点口径修正（3 条全部落实）

### §2.1 A 使用官方稳定后的 state

- **删除**了重复的 `probe.env.reset()`；
- A = `set_init_state(init) + **恰好 10** 步官方 dummy action`；
- dummy action 用 **LIBERO/OpenVLA 官方**的
  `get_libero_dummy_action()` → 实测 `[0,0,0,0,0,0,-1.0]`（不是手写全零）；
- A/B 都保存 provenance：`wait_steps` / `dummy_action` / `state_hash`；
- B 的白名单仍相对**同 seed 稳定后的 A**。

```
I1 s0: A wait=10 dummy=[0,0,0,0,0,0,-1.0] hash=9842754d89d986ce  wl changed=3 unexpected=[]
I1 s1: A wait=10 dummy=[0,0,0,0,0,0,-1.0] hash=5a490a0954de653e  wl changed=3 unexpected=[]
I2 s0: A wait=10 dummy=[0,0,0,0,0,0,-1.0] hash=22ab7082124e0014  wl changed=1 unexpected=[]
I2 s1: A wait=10 dummy=[0,0,0,0,0,0,-1.0] hash=4774665db01a66c8  wl changed=1 unexpected=[]
```

修正后 4 个 pair **仍然全部 `pair_valid=True`**。

### §2.2 capability 的 double wait

已确认：`LiberoArena.reset()` 内已含 10 步 wait，capability 脚本外层又等了 10 步
→ `effective_wait_steps = 20`。按你的裁决**不重跑**，只在报告里注明；
**pilot 没有复制 double wait**（pilot 直接用 pairs_v2 的稳定 state，外层不再 wait）。

capability 报告里已补 `effective_wait_steps: 20` 字段。

### §2.3 I2 改用 predicate-valid interior value

没有硬编码 0.5 —— 我**扫描**出了 predicate-valid 下界：

```
joint_range          = [-0.005, 2.1]
predicate_valid_range = [0.52125, 2.1]      ← 扫描得到（与你给的 0.5 一致）
chosen_value          = 1.310625
chosen_is_midpoint    = True
```

即取 valid interval 的中点，不放在机械极限上。2.1 的旧 state 已弃用。

---

## 2. §3.1 Smoke：I1 s0 + I2 s0（各含 A/B + paired no-op）

```
$ ./submit.sh p1pilot ./run_diag.sh scripts/plan1_stage4_pilot.py --smoke
```

| task | cond | mode | steps | overall success | reexec | skip | first target |
|---|---|---|---:|---:|---|---|---|
| **I1** | A | policy | 265 | **True** | (正常首执行) | False | `completed` |
| I1 | A | noop | 520 | False | False | False | None |
| **I1** | **B** | **policy** | 520 | **False** | **True** | False | **`completed_A_orig`** |
| I1 | B | noop | 520 | False | False | False | None |
| **I2** | A | policy | 240 | **True** | (正常首执行) | True | `completed` |
| I2 | A | noop | 520 | False | False | False | None |
| **I2** | **B** | **policy** | 520 | **False** | False | False | **None** |
| I2 | B | noop | 520 | False | False | False | None |

### 2.1 ⛔ 已撤回：I1-B「去旧位置抓空」的结论**不成立**

> **【mentor_review_7 §2 更正】** 我原写"B 中模型首先接近 soup 在 A 中的原始位置"。
> 这是**参考系错误**：`cA0 = arena.entity_pos(completed)` 是在 **condition 循环内**取的，
> 所以 B 条件下它记的是 **B 自己的起点**，不是 A 的原位置。实测：
> ```
> A: completed_start == completed_A_orig              dist = 0.0000 m
> B: completed_start=[-0.002,0.269,0.521]
>    completed_A_orig =[-0.002,0.269,0.534]           dist = 0.0127 m（仅 z 的 settling 差）
> ```
> A 的真实原位置是 `[-0.100,-0.152,0.475]`，与 B 起点相距约 **0.44 m**。
> 所以 B 的 `first_target=completed_A_orig` 实际含义只是
> **"先接近了 completed object 当前的（篮子里的）位置"** —— 这仍然是
> "没有跳过已完成子目标"的证据，但**机制不是"去旧位置抓空"**。
>
> ⚠️ 另外：我原以为 §4.1 要求的 `d_eef_completed_A_orig` 是本轮的关键证据；
> 实际上**这一列本来就是错的**，所以"加上它才看得见"这句话也没有依据。

### 2.1-old （以下为已撤回的原始表述，保留供对照）

`first_target = completed_A_orig` —— 在 B 条件下，
模型**首先接近的是 soup 在 A 中的原始位置**，而不是篮子里的 soup、也不是 tomato。

这正是你在 §4.1 写下的话：

> B 中模型可能照着训练动作先去 soup 的旧位置抓空，而不是接触已经在 basket 的 soup。
> 这种行为同样是"没有跳过已完成子目标"，仅靠 completed-object contact 会漏判。

**如果只测 `contact_completed`，这一集会完全漏掉** —— 它根本没碰到篮子里的 soup。
加上 `d_eef_completed_A_orig` 才看得见。这条观测设计是对的。

### 2.2 两个任务的失败模式**不一样**（诚实报告）

- **I1-B**：走到旧位置抓空 → `reexec=True`、整体失败。
  （A 条件同一 seed 是 265 步成功，B 是 520 步失败 → **B 比 A 多花 255 步且失败**）
- **I2-B**：`first_target=None` —— 它**既没有**接近炉钮（未重新执行），
  **也没有**接近 moka pot（未正确跳过），整体失败。

所以 I2 的 B 不是"重复执行已完成子目标"，而是**停滞/无目标运动**。
这与 mentor_review_2 §2.3 的"行为跨任务异质"一致，
**不能把两个任务的结果合并成一个"re-execution rate"**。

### 2.3 no-op 对照干净

I1/I2 的 B 条件 no-op 全部：520 步、success=False、无任何事件。
→ 上述行为是**策略驱动**的，不是 settling 或漂移。

---

## 3. §3.2 验收清单核对状态

| 检查项 | 状态 |
|---|---|
| A/B step-0 observation 与各自 sim state 一致 | ✅（pairs_v2 已验：`robot_same=True`、白名单通过） |
| A/B robot 9 joints 一致 | ✅ |
| diff whitelist 通过 | ✅（I1 changed=3 / I2 changed=1，unexpected=[]） |
| A 标签 F/F/overall F | ✅ |
| B 标签 T/F/overall F | ✅ |
| no-op 窗口标签稳定 | ✅ |
| policy/no-op step-0 一致 | ✅（smoke-v3 的 guard 已证明该机制；本轮同一 `set_state` 路径） |
| 首步位移 guard | ✅（机制已在 smoke-v3 验证；本轮 step0→1 无伪跳变） |
| subgoal predicates 每步可读 | ✅（trace 里 `sg1`/`sg2` 每行都有值） |
| trace 与视频可解析 | ✅ |
| **entity-specific contact / distance 不为空** | ⚠️ **部分未核对**：`d_eef_completed_A_orig` 有值（I1-B 靠它命中），但各实体 contact 列是否全程非空**我没来得及逐列核对** |
| 无 stale observation / unnorm key / done gating | ✅（unnorm 用 `libero_10`；pairs 来自已修好的 `set_state`） |

> 最后一项 contact 列的非空核对是 smoke 验收的硬要求，
> **我还没做完就不应该声称 smoke 全通过**。如实标为未完成。

---

## 4. 未完成的部分（明确列出）

| §7 步骤 | 状态 |
|---|---|
| 1. 修正 official wait / dummy action / I2 value | ✅ 完成 |
| 2. 写 pilot 脚本与事件测试 | ✅ 完成（`plan1_stage4_pilot.py`、`benchmark/stage4_events.py`、10 个事件测试） |
| 3. I1 s0 + I2 s0 smoke | ✅ **跑了**，但 §3.2 的 contact 列核对未做完 |
| 4. smoke 全通过后自动跑完整 20 episodes | ⛔ **未跑**（预算耗尽） |
| 5. paired no-op drift controls | ✅ smoke 层面已跑（4 条 no-op） |
| 6. 离线汇总 | ⛔ 未跑 |
| 7. 暂停并提交 review | ✅ 就是本文件 |

**我没有自行扩到 20 episodes 的理由**：§3.2 明确写"smoke 通过后可自动跑剩余 seeds"，
而我**还没把 smoke 的验收清单核完**（contact 列非空那一项）。在你给的规则里，
smoke 未全过就扩量是不允许的，所以我停在 smoke。

---

## 5. 需要你裁决

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | I2-B 的 `first_target=None`（既没重执行也没跳过）如何归类 | 建议单列 `neither` 类，不要塞进 reexec/skip |
| 2 | A 条件的 `reexec=True` 是"正常首执行"，事件名易误读 | 建议只在 B 条件报 reexec/skip，A 只作模板基线 |
| 3 | contact 列非空核对是否要我补完再做全量 | 建议是（这是我停在 smoke 的唯一原因） |
| 4 | 全量 20 episodes 是否照 §7.4 自动执行 | 补完 §3.2 后建议执行 |

**未启动 Terminal Full、Matched Pair full、ENA Head、Memory**（§7 遵守）。
测试 **179 passed**（本地/远端一致）；GPU 空闲。

## 6. 产物

```
results/plan1/intermediate/
├── pairs_v2/{pairs.json, states/×8, images/×8}     （§2 修正后重跑，全 pair_valid）
├── capability/{capability.json, traces/×10, videos/×10}
└── pilot/
    ├── pilot_smoke.json
    ├── traces/{task}__s0__{A,B}__{policy,noop}.csv   × 8
    └── videos/{task}__s0__{A,B}__{policy,noop}.mp4   × 8
```
