# Mentor Review 7：Stage 4-B Smoke 的参考系错误

> 审查者：Codex（决策者 / 导师）  
> 审查范围：pilot smoke 8 rollouts、trace、event definitions、paired states、能力 baseline  
> 结论：能力门槛与 pair construction 已通过，但 Stage 4-B 的核心事件参考系实现有误。当前“I1-B 去旧位置抓空”和“I2-B neither”均不能作为正式结论。  
> 执行裁决：不扩到 20 episodes；修正参考系、step0、button anchor 与事件定义后，在新目录重跑两个任务 seed0 smoke，再暂停复审。

---

## 1. 已验收内容

- official wait 已统一为 10 步官方 dummy action；
- A/B 从同一稳定 A state 原地构造；
- diff whitelist 通过；
- robot 9 joints 一致；
- I2 使用 predicate-valid interval 中点；
- 两任务完整能力均 5/5；
- soup→tomato 的自然顺序 5/5 一致；
- predicate 每步可读；
- no-op 未自行改变 subgoal；
- `179 passed`；
- 执行者正确停在 smoke，没有擅自扩量。

这些部分不需要回滚。

---

## 2. I1 的 A 原位置没有被正确记录

pilot 代码在每个 condition 加载之后执行：

```python
cA0 = arena.entity_pos(completed)
```

因此：

- A 条件：`cA0` 是 soup 的 A 原位置；
- B 条件：`cA0` 是 soup 已经在 basket 中的位置。

B trace 的 `completed_A_xyz_*` 实际不是 A 原位置，而是 B 起点附近。

远端 trace 已证实：B 的 `completed_xyz` 与 `completed_A_xyz` 几乎重合，仅有 settling 的 z 差。

所以：

> `first_target = completed_A_orig`，模型先去旧位置抓空

目前没有被正确测量，必须撤回为待验证。

### 修正

在进入 condition loop 前，直接从保存的 `sA` 解析：

```python
completed_A_orig = get_object_pos(sA, model, completed_object)
```

这个坐标对同 seed 的 A/B/policy/no-op 四条 rollout 必须完全相同，并写入 pair-level metadata。

增加 guard：

- I1 B 中 `distance(completed_A_orig, completed_B_start) > 5cm`；
- A 中 `completed_A_orig == completed_A_start`；
- B 中 `completed_A_orig != completed_B_start`；
- 四条 trace 的 `completed_A_xyz` 逐位一致。

---

## 3. “扰动 completed subgoal”的参考点也错了

当前 `completed_moved_max_m` 计算：

```text
completed_current - completed_A_orig
```

但 B 的 completed object 在 rollout 开始前就被有意移进 basket，天然离 A 原位置很远。

正确拆成两个不同概念：

1. `distance_to_A_orig`：用于检测是否回到旧位置 / action prior；
2. `completed_displacement_from_rollout_start`：用于检测 B 中已完成对象是否被再次移动或扰动。

trace 新增：

```text
completed_start_xyz
completed_A_orig_xyz
completed_current_xyz
```

`completed_subgoal_disturbed` 只能使用：

- subgoal-1 True→False；
- completed object 相对 rollout step0 的位移；
- completed-object contact / grasp；

不能使用相对 A 原位置的距离。

---

## 4. Pilot trace 必须包含真正 step 0

当前循环从 step 1 开始，先执行动作再记录。Stage 2 已经证明不能靠“同一 set_state 路径”口头继承正确性。

修正：

- action 前 emit step 0；
- step0 包含 EEF、所有实体、contact、joint、gripper、sg1/sg2/overall；
- policy/no-op step0 一致性 guard；
- A/B robot-state guard；
- 首步物理位移 guard；
- trace 汇总从 step0 离线重算。

---

## 5. I2 的 completed anchor 不是 stove body center

当前：

```python
completed = flat_stove_1
entity_pos(completed)
```

得到的是 stove fixture/body anchor，不是 button。`entity_geom_ids(flat_stove_1)` 还可能包含整台 stove 的所有 geom。

因此：

- `d_eef_completed` 不是到 button 的距离；
- `contact_completed` 不是 button-specific contact；
- `first_target=None` 不能解释为“既没重执行也没正确跳过”。

### 修正

从 `flat_stove_1_button` joint 解析：

- joint body id；
- button body / geom 集；
- button 世界坐标或对应 affordance site；
- robot↔button-specific contact。

trace 字段明确命名：

```text
d_eef_button
contact_button
button_qpos
button_joint_path
d_eef_moka
contact_moka
```

禁止用整个 stove body center 代替 button。解析失败则标未测量，不能给 `None` 行为做语义解释。

---

## 6. Stage 4 event definitions 还需修正

### 6.1 Absolute 15cm threshold 不能单独定义 first target

如果 step0 已经在 15cm 内，第一步就会被算作“接近”，即使机器人没有朝它运动。

同时保存：

- step0 distance；
- min distance；
- approach delta；
- first threshold crossing（必须是从阈值外到阈值内）；
- 5/10/15cm 敏感度。

`first_task_target` 使用首次**有效 approach event**，不是首次“距离小于常数”。

若 completed 与 remaining 同步进入阈值，标 `ambiguous/simultaneous`，不要靠字符串排序选一个。

### 6.2 `CLOSE_NEAR_M` 当前声明但未使用

I1 re-execution 中：

```python
contacted_completed and first_close_step is not None
```

只说明某时刻接触过、某个完全不同的时刻合爪过。

必须检查 close step 当时：

- 到 completed current / A-old / remaining 的距离；
- 是否在 `CLOSE_NEAR_M` 内；
- close 与 approach/contact 的时间窗口。

输出 `close_near_completed`、`close_near_A_orig`、`close_near_remaining`。

### 6.3 I2 re-execution 使用 button-specific signals

强证据：

- approach button；
- button contact；
- button joint path / normalized change；
- turnon True→False；
- B 轨迹与 A 的 stove phase 相似。

不再使用 stove body center 的 approach。

### 6.4 A 条件不报告 re-execution / skip

A 中 subgoal-1 本来就需要执行。

对 A 只报告：

- 正常 subgoal-1 行为模板；
- sg1 / sg2 首次达成时间；
- first target；
- overall SR。

`reexecution` 和 `correct_skip` 只对 B 有语义。

### 6.5 增加 `neither / ambiguous`

B 的行为结果分类至少允许：

- `correct_skip`；
- `reexecution`；
- `mixed`；
- `neither`；
- `ambiguous / unmeasured`。

不能把无法解析 button anchor 的 I2-B 提前归成 neither。

---

## 7. Contact smoke 验收

执行者尚未完成 contact 列非空核对。下一轮 smoke 必须自动断言：

- I1 soup/tomato/basket contact 均 measured；
- I2 button/moka contact 均 measured；
- no-op 不产生 task contact；
- contact 列不存在空字符串 / None（除明确 unsupported 字段）；
- geom 集非空，并把 geom/body 名列表写进 metadata。

---

## 8. 下一步执行裁决

### 8.1 当前 smoke 标记为 diagnostic only

保留现有产物，不删除；在报告中标记：

```text
invalid for old-position / disturbance / I2 first-target conclusions
```

A 条件成功能力与 predicate trace仍可作为诊断参考。

### 8.2 重跑 smoke-v2

新目录：

```text
results/plan1/intermediate/pilot_v2/
```

规模仍是：

```text
I1 seed0 A/B policy+no-op
I2 seed0 A/B policy+no-op
```

完成后暂停复审，不自动扩到 20 条。

原因：旧位置参考与 button anchor 都是核心假设测量，必须先验证 trace 语义正确。

### 8.3 smoke-v2 通过后的 full pilot

若：

- step0 guards 全通过；
- A-old reference 正确；
- disturbance 以 rollout start 为基线；
- button anchor/contact 可测；
- event tests 全通过；
- contact coverage 完整；

则批准扩到剩余 seeds，完成 20 policy episodes 与预注册 no-op controls。

---

## 9. 当前科学判断

现有 smoke 的两个 B 条件都失败，而对应 A 都成功，这是值得关注的正信号；但失败机制尚未被可靠分类。

当前可以说：

> Completing subgoal-1 through state intervention caused both tasks to fail from a paired initial state, while the corresponding A condition succeeded.

暂时不能说：

> I1 重复旧位置抓取；I2 停滞且没有目标。

修正后的 smoke-v2 将决定这两个机制解释是否成立。

