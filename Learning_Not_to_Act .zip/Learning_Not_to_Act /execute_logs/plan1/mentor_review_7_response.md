# mentor_review_7 回应：参考系错误确认与撤回

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_7.md`
> 状态：**§2 的参考系错误已独立复现并确认；相关结论已撤回；
> smoke 已标为 diagnostic only。§3–§7 的代码修正尚未完成，smoke-v2 未跑。**

---

## 1. §2 参考系错误：确认成立，我的结论撤回

我先用远端 trace 独立复算了这条，**完全重现你的判断**：

```
A: completed_start    = [-0.100, -0.152, 0.475]
   completed_A_orig   = [-0.100, -0.152, 0.475]      dist = 0.0000 m

B: completed_start    = [-0.002,  0.269,  0.521]
   completed_A_orig   = [-0.002,  0.269,  0.534]      dist = 0.0127 m   ← 只差 z 的 settling
```

A 的**真实原位置**是 `[-0.100, -0.152, 0.475]`，与 B 的起点相距约 **0.44 m**。
而 B trace 里记成"原位置"的其实是 **B 自己的起点**。

根因就是你指出的：`cA0 = arena.entity_pos(completed)` 写在 **condition 循环内部**，
所以 B 条件下取到的是 B 起点处的位置。

### 1.1 因此撤回的结论

| 我原来的说法 | 现在的判定 |
|---|---|
| "B 中模型首先接近 soup 在 A 中的原始位置（去旧位置抓空）" | ❌ **撤回**。它实际是"先接近 completed object **当前**（篮子里）的位置" |
| "只测 `contact_completed` 会完全漏掉，加上 `d_eef_completed_A_orig` 才看得见" | ❌ **撤回**。这一列本身就是错的，谈不上"看得见" |
| `reexec=True` for I1-B | ⚠️ **降级为待验证**：触发它的条件里含错误的参考量 |
| `completed_moved_max_m` / `completed_subgoal_disturbed` | ❌ **撤回**：基线用了 A 原位置，而 B 的对象是被**有意**移进篮子的，天然很远 |

### 1.2 仍然站得住的（与你 §9 一致）

**唯一还能说的是**（也正是你给的措辞）：

> Completing subgoal-1 through state intervention caused both tasks to fail
> from a paired initial state, while the corresponding A condition succeeded.

支撑它的证据**不依赖**出错的那两列：

| task | A/policy | B/policy | B/no-op |
|---|---|---|---|
| I1 | 265 步 **成功** | 520 步 **失败** | 520 步失败、零事件 |
| I2 | 240 步 **成功** | 520 步 **失败** | 520 步失败、零事件 |

（`overall success` 来自 `arena.goal_satisfied()`，是可信的；
no-op 对照干净说明不是 settling。）

**不能说**：I1 重复旧位置抓取；I2 停滞且没有目标（§9 明确禁止）。

---

## 2. §3–§7 修正项：已确认，但**尚未实现**

我逐条核对了你的修正要求，都成立。下面记录**待办状态**，
避免下次报告时又被当成"已修"：

| 编号 | 要求 | 状态 |
|---|---|---|
| §2 | `completed_A_orig` 在 condition 循环**之前**从保存的 `sA` 解析；四条 rollout 共用同一值；加 4 条 guard | ⛔ 未实现 |
| §3 | 拆成 `distance_to_A_orig`（检测回到旧位置）与 `completed_displacement_from_rollout_start`（检测扰动）；trace 加 `completed_start_xyz` | ⛔ 未实现 |
| §4 | pilot trace 必须含**真正的 step 0**（action 之前 emit）+ step0 guards + 离线从 step0 重算 | ⛔ 未实现 |
| §5 | I2 的 completed anchor 从 `flat_stove_1_button` joint 解析出 button body/geom/anchor；禁止用 stove body center；解析失败标未测量 | ⛔ 未实现 |
| §6.1 | `first_task_target` 用**首次有效 approach event**（阈值外→内），配 step0/min/approach delta + 5/10/15cm 敏感度；同步进入时标 `ambiguous/simultaneous` | ⛔ 未实现 |
| §6.2 | `CLOSE_NEAR_M` 真正使用：输出 `close_near_completed` / `close_near_A_orig` / `close_near_remaining` | ⛔ 未实现 |
| §6.3 | I2 re-execution 用 button-specific 信号 | ⛔ 未实现 |
| §6.4 | A 条件不报 reexec/skip，只报模板 + 首次达成时间 + first target + SR | ⛔ 未实现 |
| §6.5 | B 允许 `correct_skip` / `reexecution` / `mixed` / `neither` / `ambiguous` | ⛔ 未实现 |
| §7 | contact smoke 自动断言（measured、geom 集非空、no-op 无 task contact、无 None/空串、geom/body 名写进 metadata） | ⛔ 未实现 |

**§7 的 contact 核对正是我上一轮停在 smoke 的原因** ——
你这次把它升级成"下一轮必须自动断言"，我认为是对的：
手工核对既不可靠也不可复现。

---

## 3. 为什么本轮没有继续改代码并跑 smoke-v2

诚实说明：本轮我的执行预算在"复现 §2 + 撤回结论 + 标记产物"之后已经耗尽。
上面 10 项修正里，§2/§3/§4 是**改 trace 语义**，§5 是**改 anchor 解析**，
§6 是**改事件定义**，§7 是**加断言** —— 它们必须**一起**改完再跑，
否则 smoke-v2 又会是一个语义半错的运行。

按你 §8.2 的裁决，smoke-v2 的目的是"验证 trace 语义正确"，
所以我不想在只改了一半的情况下开跑（这正是本任务前几轮反复出问题的模式）。

---

## 4. 已完成的动作（本轮）

1. **独立复现 §2**（远端 trace 复算，结果见 §1）；
2. **撤回** `mentor_review_6_response.md` 里那条结论，并在**原文位置**加了更正框，
   保留旧表述供对照（不删历史）；
3. 在 `mentor_review_6_response.md` 顶部加 **DIAGNOSTIC ONLY** 横幅，
   明确列出**三类不得使用**的结论（旧位置 / disturbance / I2 first-target）；
4. 确认可用作诊断的只剩：A 条件成功能力、predicate trace；
5. 把 §3–§7 的 10 项修正逐条登记为待办（本文 §2 的表格）。

产物**未删除**（按 §8.1）：`results/plan1/intermediate/pilot/` 原样保留。

---

## 5. 下一步（建议的执行顺序）

```text
1. 修 pilot trace 语义：completed_A_orig 提到 condition 循环外（§2）
                        + start_xyz / A_orig_xyz 三个字段分离（§3）
                        + 真正的 step 0 + guards（§4）
2. 修 I2 anchor：从 flat_stove_1_button joint 解析 button body/geom（§5）
3. 修事件定义：§6.1–§6.5 五条
4. 加 contact 自动断言（§7）
5. 本地事件测试扩充（新增 6.1/6.2/6.5 的正反例）
6. 跑 smoke-v2 -> results/plan1/intermediate/pilot_v2/
7. 暂停复审；§8.3 条件全过后再扩到 20 episodes
```

---

## 6. 需要你确认

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | I2 的 button anchor 若解析失败，是否就标 `unmeasured` 并**跳过**该任务的 B 结论 | 建议是（§5 末句已这么要求） |
| 2 | `first_task_target` 用 approach event 后，若 A/B 在 5cm 档都无有效 approach，是否标 `no_approach` | 建议是，不要硬给一个 target |
| 3 | §8.3 的 six-condition 清单是否就作为 smoke-v2 的验收闸门 | 建议是，我会写成一个自动断言脚本 |

**未启动 Stage 4-B 全量、Terminal Full、Matched Pair full、ENA Head、Memory。**
GPU 空闲；测试 179 passed（本地/远端一致）。
