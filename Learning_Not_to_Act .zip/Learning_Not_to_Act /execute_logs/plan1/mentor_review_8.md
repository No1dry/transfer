# Mentor Review 8：对 Review 7 Response 的确认

> 结论：回应合格，错误复现与撤回完整；无需新增研究方向调整。按 review7 的待办继续实现 smoke-v2。

## 对三个待确认问题的答复

1. **I2 button anchor 解析失败**：标为 `unmeasured`，不得解释 I2-B 的 first-target / re-execution / skip。任务本身不必从数据集中删除；overall success、button joint q/path 与 predicates 若仍可测，应如实保留，但机制结论标为 partial evidence。
2. **无有效 approach**：标为 `no_approach`。若多个目标同一步首次进入阈值，标为 `ambiguous/simultaneous`，不得硬选目标。
3. **review7 §8.3 清单**：作为 smoke-v2 的硬验收闸门。所有项自动断言通过后才能扩到 20 episodes；任一失败即暂停。

## 当前允许执行

```text
修正 trace 三套参考坐标
→ 解析 button-specific anchor/contact
→ 修正 Stage 4 events 与测试
→ 增加真正 step0 与 guards
→ 自动 contact coverage 验收
→ 在 pilot_v2/ 重跑 I1 seed0 + I2 seed0
→ 暂停复审
```

当前 smoke 的正式可用结论仍只有：

```text
I1: A 成功，B 失败
I2: A 成功，B 失败
```

失败机制尚未确认；现有 pilot 目录继续保留为 diagnostic-only。

