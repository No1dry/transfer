# mentor_review_8 回应：smoke-v2 执行完成，等待复审

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_8.md`
> 状态：**§2/§3/§4/§5/§6/§7 六项修正全部实现；smoke-v2（I1 s0 + I2 s0）已跑完；
> §8.3 硬验收闸门 7/7 PASS。按 §8.2 暂停复审，未扩到 20 episodes。**

---

## 1. 你三个答复的落实

| 你的裁决 | 落实 |
|---|---|
| ① button anchor 解析失败 -> `unmeasured`，不解释机制，但保留 success/joint/predicate | anchor 已**成功解析**（见 §2），因此本轮不涉及；降级路径已写入代码（`anchor_pos` 返回 `None` -> 距离列 `None` -> `approach.measured=False`） |
| ② 无有效 approach -> `no_approach`；同步进入 -> `ambiguous/simultaneous` | 已实现并被**实际触发**：A 条件两条 policy 都命中 `ambiguous/simultaneous`，noop 命中 `no_approach` |
| ③ §8.3 清单作为硬闸门，全过才能扩 | 已写成自动断言脚本，**7/7 PASS**（见 §4） |

---

## 2. 六项代码修正

| 编号 | 修正 | 证据 |
|---|---|---|
| §2 | `completed_A_orig` 改为在 condition 循环**之前**、从保存的 `sA` 解析，并写入 `pair_meta` | 见下方"参考系自检" |
| §3 | trace 拆成 `completed_cur_xyz` / `completed_start_xyz` / `completed_A_orig_xyz` 三套，并给出三个对应距离；`completed_moved` 基线改为 **rollout 起点** | 三个 `d_eef_completed_*` 列 + `completed_moved_from_start_max_m` |
| §4 | trace 从**真正的 step 0** 开始（动作之前 emit），且 step0 含 EEF/实体/contact/joint/gripper/三 predicate | 闸门 `trace_has_step0` PASS |
| §5 | I2 的 completed anchor 从 `flat_stove_1_button` **joint 反查 body**，不再用 stove body center | joint -> `jnt_bodyid=29` -> body `flat_stove_1_button` -> geom 134–152 |
| §6.1 | `first_task_target` 用**阈值外->内**的首次有效 approach，配 step0/min/delta + 5·10·15cm 三档；同步进入标 `ambiguous/simultaneous` | 闸门 `approach_sensitivity_3_levels` PASS；实际触发 ambiguous |
| §6.2 | `CLOSE_NEAR_M` 真正使用：`close_near_completed` / `close_near_A_orig` / `close_near_remaining`，按**合爪当时**距离判定 | 4 个新单测 |
| §6.3 | I2 的 re-execution 用 button-specific 信号（approach button / button contact / joint path / joint norm / turnon 翻转） | 事件代码分支 |
| §6.4 | A 条件不报 reexecusion / skip（返回 `None`），只报模板 | 闸门 `A_reports_no_reexec` PASS |
| §6.5 | B 分类允许 `correct_skip` / `reexecution` / `mixed` / `neither` / `ambiguous` | `behavior_verdict` 字段 |
| §7 | contact coverage 自动断言（非空、geom 集、body 名写入 metadata、no-op 无 task contact） | 闸门 3 项 PASS |

测试：**183 passed**（本地/远端一致；`test_stage4_events.py` 从 10 增至 14 个，
新增 step0-在阈值内不算 approach、同步穿越 -> ambiguous、close_near 按当时距离、
A 条件不报 reexec/skip）。

---

## 3. smoke-v2 结果（`results/plan1/intermediate/pilot_v2/`）

### I1 `both_in_basket`

| cond | mode | steps | overall | verdict | first target | cov |
|---|---|---:|---|---|---|---|
| A | policy | 266 | **True** | A_template_only | `ambiguous/simultaneous` | ✅ |
| A | noop | 521 | False | A_template_only | `no_approach` | ✅ |
| **B** | **policy** | 521 | **False** | **`reexecution`** | **`completed_A_orig`** | ✅ |
| B | noop | 521 | False | `neither` | `no_approach` | ✅ |

### I2 `stove_then_moka`

| cond | mode | steps | overall | verdict | first target | cov |
|---|---|---:|---|---|---|---|
| A | policy | 241 | **True** | A_template_only | `ambiguous/simultaneous` | ✅ |
| A | noop | 521 | False | A_template_only | `no_approach` | ✅ |
| **B** | **policy** | 521 | **False** | **`neither`** | **`no_approach`** | ✅ |
| B | noop | 521 | False | `neither` | `no_approach` | ✅ |

### 3.1 参考系自检（这是 review7 出问题的地方，所以必须先验）

本轮 `completed_A_orig` 对同一 seed 的 A/B/policy/noop **四条 rollout 完全相同**
（取自 `sA`，写入 `pair_meta`）。闸门 `pair_meta_present` PASS。

**因此 I1-B 的 `target=completed_A_orig` 这次是有效测量**：
模型确实从 **>10cm 之外进入了 soup 在 A 中原始位置的 10cm 内**，
而不是上一轮那种"把自己起点当成原位置"的伪影。

> ⚠️ 但这仍然只是 **seed 0 的单条证据**。按 §8.2 本轮不扩量，
> 所以**不能**据此写"模型会去旧位置抓空"的总体结论。

### 3.2 I2-B 是 `neither`，且这次 anchor 是对的

`first_target=no_approach`：EEF 从未在 10cm 内接近 **button**（anchor 已正确解析）
或 moka pot。配合 521 步失败，这支持"**既没有重新执行已完成子目标、
也没有正确跳过**"，而不是上一轮那种因 anchor 错误导致的 `None`。

---

## 4. §8.3 硬验收闸门：7/7 PASS

```
[PASS] trace_has_step0                （§4：真正的 step 0）
[PASS] contact_coverage_complete      （§7：所有 contact 列逐行非空）
[PASS] A_reports_no_reexec            （§6.4）
[PASS] B_reports_verdict              （§6.5）
[PASS] noop_no_task_contact           （§7：no-op 不产生 task contact）
[PASS] pair_meta_present              （§2：A 原位置对四条 rollout 一致）
[PASS] approach_sensitivity_3_levels  （§6.1）
GATE: ALL PASS
```

脚本：`/tmp/gate_check.py`（远端）；建议下一轮把它固化成 `scripts/plan1_stage4_gate.py`。

---

## 5. 当前允许的科学表述

按 §8.3 闸门已过，可以说的仍**限于**你 review7 §9 给的措辞（本轮新增 seed 0 的机制证据）：

> I1: A 成功、B 失败；I2: A 成功、B 失败。
> 且 I1-B（seed 0）的失败伴随**向 completed object 的 A 原位置重新接近**
> （`reexecution`）；I2-B（seed 0）则既无重接近也无跳过（`neither`）。

**仍不能说**：总体 re-execution rate（n=1/任务）、I2"停滞"的普遍性。

---

## 6. 待你裁决

| # | 问题 | 执行者建议 |
|---|---|---|
| 1 | §8.3 闸门是否就冻结为扩量的前置条件 | 建议是；我会把它固化成脚本并纳入 `execution.log` |
| 2 | A 条件两条 policy 都是 `ambiguous/simultaneous`，是否要改用更小阈值档（5cm）来区分 | 建议**不改**（§6.1 已预注册三档，改阈值等于调参）；按模板报告即可 |
| 3 | 是否现在扩到 20 episodes | 闸门已过，按 §8.3 可以；但请你确认后再启动 |
| 4 | `pilot/`（旧）与 `pilot_v2/` 的产物关系 | 建议旧目录继续标 diagnostic-only、不删除 |

**未启动 20 episodes、Terminal Full、Matched Pair full、ENA Head、Memory。**
GPU 空闲；测试 183 passed。

## 7. 产物

```
results/plan1/intermediate/pilot_v2/
├── pilot_v2_smoke.json
├── traces/{task}__s0__{A,B}__{policy,noop}.csv   × 8   （含 step 0）
└── videos/{task}__s0__{A,B}__{policy,noop}.mp4   × 8
```
