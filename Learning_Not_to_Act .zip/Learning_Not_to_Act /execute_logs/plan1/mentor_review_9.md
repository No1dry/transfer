# Mentor Review 9：Pilot-v2 Smoke 验收

> 审查者：Codex（决策者 / 导师）  
> 结论：I1 seed0 的“回到 completed object 旧位置抓空”机制证据已可信；I2 的 button contact 已按 joint body 解析，但 button distance/anchor 尚未接入 trace，因此 I2 的 `neither/no_approach` 仍无效。硬闸门存在“有值但语义错误也能通过”的缺口。  
> 执行裁决：I1 smoke 通过；只需修复 I2 anchor 与补强 gate，重跑 I2 seed0 smoke。通过后可扩完整 pilot。

---

## 1. I1 seed0 验收通过

修正后的 trace 给出：

```text
B step0 到 soup A 原位置      = 0.276m
B 最小到 soup A 原位置       = 0.021m
首次进入旧位置 10cm          = step 46
close-near-old-position       = 32 steps，首次 step 64
到 remaining tomato 的最小距离 = 0.158m
接触 basket 内 soup           = False
最终 overall                  = False
```

No-op 对照没有 approach、close 或 contact。

所以当前允许的精确表述是：

> In the paired B state for seed 0, the policy revisited the completed object's original A-state location and repeatedly issued close commands there, while failing to approach the remaining object closely enough or complete the task.

这是一条强机制 case，但仍只有一个 seed；不能写总体发生率。

---

## 2. I2 anchor 仍未接入

代码虽然实现了：

```python
anchor_pos(sim, model, ent)
```

但全文件没有调用它。

I2 trace 仍使用：

```python
arena.entity_pos("flat_stove_1")
```

作为 `completed_cur/start/A_orig`，得到的是 stove fixture/body anchor，而不是 button anchor。

contact geoms 已经通过 `flat_stove_1_button` joint body 解析，这部分是 button-specific；但 distance 不是。于是当前 I2：

```text
first_target=no_approach
behavior_verdict=neither
```

仍不能解释。

### 修正

对于 I2：

- `completed_cur_xyz` = `anchor_pos(sim, model, button_entity)`；
- `completed_start_xyz` = rollout step0 的 button anchor；
- `completed_A_orig_xyz` = A state 的 button anchor；
- `d_eef_completed_*` 全部基于 button anchor；
- anchor 为 None 时所有相关列为 None，verdict=`ambiguous/unmeasured`；
- metadata 保存 anchor source、body id、body name、geom ids。

增加集成断言：

```text
I2 distance anchor body == flat_stove_1_button
I2 contact geom bodies  == flat_stove_1_button
```

---

## 3. Gate 仍缺少语义检查

当前 gate 的 7 项只检查“列存在/非空”，因此 I2 距离列虽然语义错误仍能 PASS。

补充：

1. `anchor_provenance_valid`：I2 distance/contact 都来自 button joint body；
2. `policy_noop_step0_equal`：同 condition 的 policy/no-op step0 状态一致；
3. `first_step_guard`：首步位移小于硬上限；
4. `A_orig_shared_across_rollouts`：同 seed 四条 rollout 的 A-orig 完全一致；
5. `B_completed_start_differs_from_A_orig`：I1 B 中二者至少相差 5cm；
6. `completed_start_shared_policy_noop`：同 condition 两模式起点一致；
7. `event_recomputable_from_trace`：在线 JSON 与离线重算一致。

Gate 不能只验证 schema，还必须验证字段的 provenance。

---

## 4. 其他代码修正

### 4.1 `completed_moved_from_A_orig_max_m` 实现错误

当前实现实际上取：

```python
max(d_eef_completed_A_orig)
```

这是 EEF 到旧位置的最大距离，不是 completed object 相对 A 原位置的位移。

修正为基于：

```text
completed_cur_xyz - completed_A_orig_xyz
```

或者直接删除该字段，避免误用。扰动主指标继续使用相对 rollout start 的 object displacement。

### 4.2 Contact coverage 对不适用列应显式声明

I2 没有 container，`contact_container` 全是 None；当前 coverage 会自动跳过该列却仍写 `complete=True`。

改为 metadata 显式给出：

```text
required_columns
optional_columns
unsupported_columns
```

I1 要求 completed/remaining/container；I2 要求 button/remaining，不要求 container。

---

## 5. 下一步执行裁决

1. 保留 I1 pilot-v2 smoke 为有效单例；
2. 标记 I2 pilot-v2 distance/verdict 为 invalid；
3. 修 button anchor、gate provenance 与错误 quantity；
4. 新目录或新文件名重跑 **I2 seed0 A/B policy+no-op**；
5. 用增强 gate 验收 I1 旧 trace + I2 新 trace；
6. 全部通过后，可自动扩到剩余 seeds，完成完整 pilot；
7. 完整 pilot 后暂停。

无需再次重跑 I1 seed0。

---

## 6. 当前科学判断

- “A 成功、B 失败”在两个任务上仍成立；
- I1 已有一个可信的旧位置重执行 case；
- I2 的失败机制仍未知；
- 目前还不能报总体 re-execution / skip rate；
- 研究方向继续得到支持，完整 pilot 仍是下一道决策门槛。

