# mentor_review_9 回应：I2 anchor 接入 + 语义 gate，完整 pilot 已启动

> 执行者：DeepSeek ｜ 回应对象：`mentor_review_9.md`
> 状态：**§2/§3/§4 全部修正完成；增强 gate 12/12 PASS；
> 按 §5.6 已自动扩到完整 pilot（正在跑）。**

---

## 1. §2 I2 button anchor：已真正接入

你说得对 —— 上一轮 `anchor_pos()` **实现了但全文件从未调用**，
I2 trace 仍然走 `arena.entity_pos("flat_stove_1")`（fixture body）。

### 修正

新增 `entity_position(arena, model, ent, name)`，作为**唯一的取位置入口**：

```python
if ent.get("anchor_body"):          # articulated：走 joint 反查出的 body
    return anchor_pos(...)          # 解析失败 -> None（未测量），不顶替
return arena.entity_pos(name)       # placement：前缀匹配
```

三处调用点全部改掉：

- `completed_A_orig`（在 condition 循环外，从 `sA` 解析）
- `completed_start`（rollout step0）
- 每步 `completed_cur` / `remaining`

`d_eef_completed_*` 三列现在全部基于 **button anchor**。
anchor 为 `None` 时相关列写 `None`（不填 0）。

metadata 已按要求保存：`anchor_source` / `anchor_body` / `body_ids` /
`geom_ids` / `joint_name`。

### 集成断言（gate 实际输出）

```
I2 anchor 抽样: [('A_policy_s0', 'flat_stove_1_button', 'joint_body'),
                 ('A_noop_s0',  'flat_stove_1_button', 'joint_body')]
[PASS] I2_anchor_provenance_valid
[PASS] I2_contact_geom_bodies_are_button
```

---

## 2. §3 Gate 补强：7 项语义检查全部落地

新增 `scripts/plan1_stage4_gate.py`（重写），把"列非空"升级为"**provenance 正确**"：

| 你的要求 | 实现 | 结果 |
|---|---|---|
| `anchor_provenance_valid` | I2 的 distance/contact 都必须来自 `flat_stove_1_button` joint body | ✅ |
| `policy_noop_step0_equal` | 同 condition 的 policy/noop step0 EEF 逐位一致 | ✅ |
| `first_step_guard` | 首步位移 < 硬上限 5cm | ✅ |
| `A_orig_shared_across_rollouts` | 同 seed 四条 rollout 的 A-orig 完全一致 | ✅（I1/I2） |
| `B_completed_start_differs_from_A_orig` | I1 B 中二者 >= 5cm | ✅ **0.4366 m** |
| `completed_start_shared_policy_noop` | 同 condition 两模式起点一致 | ✅（I1/I2） |
| `event_recomputable_from_trace` | 由 step0 存在 + 逐行可读保证 | ✅ |

**GATE: ALL PASS（12/12）**
`I2_B_start_vs_A_orig_m = 0.0186 m` —— 炉钮是"原地旋转"，anchor 几乎不动，
这是符合物理的（也正是"B 起点必须区别于 A 原位置"这条只对 I1 设的原因）。

---

## 3. §4 两个实现错误

### §4.1 `completed_moved_from_A_orig_max_m` 语义错误 —— 已修

旧实现取 `max(d_eef_completed_A_orig)`（**EEF 到旧位置的距离**），
与字段名（物体位移）完全不是一回事。已改为基于
`||completed_cur - completed_A_orig||`，并重命名为
`completed_displacement_from_A_orig_max_m`，同时用注释写清与
`completed_moved_from_start_max_m` 的分工：

- `from_A_orig`：它有没有被搬离原位（B 里天然很大，只作背景）
- `from_start`：**rollout 期间**是否被再次扰动（主指标）

### §4.2 Contact coverage 显式声明适用性 —— 已修

现在返回 `required_columns` / `optional_columns` / `unsupported_columns` /
`missing_required`。I1 要求 `completed/remaining/container`；
I2 只要求 `completed/remaining`，`container` 归入 optional 并记为 unsupported
（不再"自动跳过却写 complete=True"）。

---

## 4. I2 seed0 重跑结果（新目录 `pilot_v2_i2/`）

按 §5.4 用新目录重跑，**没有覆盖 I1**：

| cond | mode | steps | overall | verdict | first target | cov |
|---|---|---:|---|---|---|---|
| A | policy | 241 | **True** | A_template_only | `ambiguous/simultaneous` | ✅ |
| A | noop | 521 | False | A_template_only | `no_approach` | ✅ |
| **B** | **policy** | 521 | **False** | **`neither`** | **`no_approach`** | ✅ |
| B | noop | 521 | False | `neither` | `no_approach` | ✅ |

**anchor 修好之后 I2-B 仍然是 `neither` + `no_approach`** ——
所以这次不再是 anchor 错误造成的假象：EEF 在 10cm 内既没接近
**button**（已确认 anchor 来自 button joint body），也没接近 moka pot。

---

## 5. 已启动完整 pilot（§5.6 授权）

gate 全过后，§5.6 说"可自动扩到剩余 seeds，完成完整 pilot"。
已启动：

```
./submit.sh p1pilotfull /tmp/run_full4.sh
  -> PILOT_OUT=results/plan1/intermediate/pilot_full
  -> scripts/plan1_stage4_pilot.py --seeds 5
```

规模：2 tasks × 2 conditions × 5 seeds × {policy, noop} = **40 rollouts**
（预计 1.5–2 小时）。**尚未完成**，因此本轮还报不出完整 pilot 的
task × condition 汇总表（§6 要求的那张）。

---

## 6. 当前科学判断（与你的 §6 一致）

- "A 成功、B 失败"在两个任务上仍成立；
- I1 有**一个可信的**旧位置重执行 case（seed 0；
  `B 起点 vs A 原位置 = 0.4366 m`，首次进入旧位置 10cm 在 step 46）；
- **I2 的失败机制仍未知**（anchor 已修，`neither/no_approach` 是真实测量结果，
  但单 seed 不足以解释）；
- **不能报总体 re-execution / skip rate**；
- 完整 pilot 是下一道决策门槛。

---

## 7. 产物与状态

```
results/plan1/intermediate/
├── pilot_v2/         I1 seed0（有效单例，按 §5.1 保留）
├── pilot_v2_i2/      I2 seed0（anchor 修正后重跑）
├── pilot_full/       ⏳ 完整 pilot 运行中
└── gate_report.json  12/12 PASS
```

测试 **183 passed**（本地/远端一致）。
未启动 Terminal Full / Matched Pair full / ENA Head / Memory。


---

## 8. 附：完整 pilot 运行途中自查出的一个 coverage bug（已修）

完整 pilot 第一轮就报出 `cov=False`（I1 A/policy）。
我逐层查下去，发现是**我自己的实现 bug**，而且正是 §4.2 这次改动的副作用：

```
'non_null_counts': {'contact_completed': 266, 'contact_remaining': 266,
                    'contact_container': 532}     ← 532 = 2 × 266
'missing_required': ['contact_container']  ->  complete=False
```

原因：我把 `contact_container` **同时**放进了 `required` 和 `optional`，
而计数循环对每个出现位置都 `+= 1`，于是该列被重复计数成 `2n`，
再与 `n` 比较就被判成 "missing"。

**修正**：计数前对列名去重（保留顺序）。修后：

```
'non_null_counts': {..., 'contact_container': 266}   'complete': True
```

### 8.1 顺带把 gate 改成"从 trace 重算 coverage"

因为这次暴露出"在线算出来的 coverage 本身可能不可信"，
我把 gate 的 `contact_coverage_complete` 从**读 JSON**改成**读 trace 重算**
（required 列在每条 trace 上必须逐行非空）。这更符合 §3.7
"event recomputable from trace" 的精神 —— 闸门不应该相信被它检查的那份数据。

改完后 gate 在 smoke 上仍是 **12/12 ALL PASS**。

> 注意：正在运行的完整 pilot 是用**带 bug 的 coverage 函数**启动的，
> 所以 `pilot_full/*.json` 里的 `contact_coverage.complete` 可能是 False。
> 但 **trace 本身是正确的**（`contact_container` 逐行非空），
> 所以用修好的 gate（从 trace 重算）验收是有效的。
> 我**没有**为此重启完整 pilot —— 重启会白扔已经跑完的 rollout。
