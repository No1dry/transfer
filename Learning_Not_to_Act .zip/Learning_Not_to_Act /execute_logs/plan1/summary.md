# Plan1 执行总结

> # ⛔ INVALID DIAGNOSTIC RUN: stale observation after state restore
>
> 按 **mentor_review_3 §3.3**，本文件涉及的 **smoke-v2 数字全部作废**，
> 只能作为"复现该 bug"的诊断材料，**不得作为研究结论**。
>
> 原因：`set_state(..., settle_steps=0)` 当时**不刷新 observation**，
> 于是 policy 的**首个 action chunk 用的是上一段旧轨迹的图像与 proprio**，
> 整条闭环轨迹都不是对 terminal state 的响应。实测证据：
> policy step0 的 EEF 在 6/8 条上逐位相同（home 位姿）、
> step0→1 伪跳变 0.27–0.33 m（真实单步 median 0.0019 / max 0.0124 m）、
> no-op step0 与前一条 policy 末帧 **8/8 逐位相同**。
>
> 已修复（无步进 observation refresh，真实 LIBERO 集成测试全过），
> 修正后的结果是 **smoke-v3**（`results/plan1/terminal_replay_v3/`，
> 见 `mentor_review_3_response.md`）。


> 按 plan1 §15 规定格式。
>
> **执行状态：Plan 1 收尾（Stage 0 / 1 / 2 smoke / 4 + natural control 全部完成）。**
> 未启动：Stage 2 **full run**、Stage 3 Matched Pair full、ENA Head、
> Counterfactual Memory、任何模型训练。
>
> 本总结历次修订：
> - mentor_review_1：§2.1 删除"把结果当意图"的表述；§2.2 曲线更名；
>   §2.3 拆成 UMR / TaskContactRate / Displacement(τ) / GDR 四层；
>   §3 代码修正（测试 126 passed）；§8.7 第 3 问由 Stage 2 smoke 回答。
> - mentor_review_2/3：smoke-v2 作废（stale observation），改用 smoke-v3。
> - mentor_review_11：补入 Stage 4（§13）。
> - **mentor_review_13：补入 natural intermediate control（§14），
>   并把"模型普遍缺少 execution-necessity reasoning"这一主张撤回。**

---

## 1. 完成了什么

### Stage 0：环境与基线冻结（§6）✅

- 采集并冻结硬件/驱动/CUDA/库版本/checkpoint/数据集统计量 key；
- 确认 `dataset_statistics.json` 只有 `*_no_noops` 四个 key，
  代码靠 `_resolve_unnorm_key()` 自动补后缀，补不上就抛错（不会静默用错）；
- 记录核心文件 SHA256，并**备份改动前原文件**（§5.6）；
- 统计全部历史产物计数，发现 `control_A`/`control_B` **没有 per-episode JSON**；
- 本地 `pytest` **78 passed** + `compileall` 通过；
- 远端 predicate smoke（不加载 7B 模型）：
  **4 个 task × 2 condition × 4 seed 全部构造成功，跨 condition 机器人关节一致**。

### Stage 1：统一干预指标 v2（§7）✅

- 在 `benchmark/metrics.py` 落地 v2 指标，**唯一权威实现**：
  UMR / UTIR / GDR / Cumulative / FSR（预留未测量）；
- 新增 `MetricSummary.measured` 与 `DistSummary`，把"未测量"与"测出来是 0"
  显式分开（§7.4 要求）；
- 统一 `_rate()`：UER/UMR/UTIR/GDR 走同一条代码路径，杜绝脚本各自手写；
- 样本池改用 `init_satisfied` 语义而非 condition 名，
  使 terminal / scene-edit / intermediate **天然同口径**；
- 新增 **19 个回归测试**，覆盖 §7.4 列出的全部 6 条；
- **用同一批 160 条旧数据离线重算**，得出本阶段最重要的结果（见 §5）。

**测试：97 passed（78 原有 + 19 新增），compileall 通过。**

---

## 2. 没完成什么及原因

| plan1 要求 | 状态 | 原因 |
|---|---|---|
| §8 Stage 2 自然终态 smoke | ✅ 完成（smoke-v3，8 对） | — |
| §8 Stage 2 full run | ⛔ **未启动** | mentor_review_1 §6 暂停点后未获放行；smoke 已足以定靶 |
| §9 Stage 3 matched pair | ⛔ **未启动** | §9.3 排序：排在 Stage 4 之后；Stage 4 已给出结论 |
| §10 Stage 4 intermediate pilot | ✅ 完成（scene-edited + natural control） | — |
| §13 表 2/3/4/5 | ⛔ 未产出 | 依赖未启动的 Stage 2 full / Stage 3 |
| `benchmark/report.py` 接入 v2 输出块 | ⛔ 未做 | **有意延后**，见 §11 建议 3 |
| `results/plan1/matched_pairs/` | 空 | 等待放行 |

**没有做任何超出范围的事**：未训练 ENA Head / STOP 分类器 / Counterfactual Memory，
未改研究问题，未调整阈值，未删除或覆盖任何历史产物。

---

## 3. 代码改动

| 文件 | 改动摘要 |
|---|---|
| `benchmark/metrics.py` | `InterventionThresholds` 加 `task_joint_change`；`EpisodeRecord` 加 v2 字段（`eef_path_length`/`object_path_length`/`task_joint_change`/`task_joint_name`/`cumulative_measured`/`contact_task_object`）并纳入 `as_dict`；`MetricSummary.measured`；新增 `DistSummary`；`_initially_satisfied` + `_rate` 统一实现；新增 `compute_umr`/`compute_utir`/`compute_gdr_v2`/`compute_fsr`/`compute_cumulative`/`compute_all_v2`；修 `compute_post_completion_steps` 的 measured 标注 |
| `benchmark/arena/libero.py` | 逐 step 累加 `_path`（eef/object/gripper 路径长度）；`task_joint_change()`；`cumulative_measured()`；`_episode_start` 记录 `task_joint` 基线 |
| `benchmark/arena/mock.py` | 同语义 v2 信号（保证 Mock 与真实 arena 口径一致，测试才有意义） |
| `benchmark/runner.py` | 把 v2 信号写入 `EpisodeRecord` |
| `tests/test_metrics_v2.py` | **新增**，19 个测试 |
| `scripts/plan1_metric_audit.py` | **新增**，旧指标审计 |
| `scripts/plan1_env_report.py` | **新增**，Stage 0 环境报告 |

改动前后 SHA256 与备份位置见 `artifacts_manifest.md` §4。

---

## 4. 正式实验配置

**本阶段没有跑正式 GPU 实验**（Stage 0/1 都是 CPU 侧工作）。

已执行的检查性运行：

| 运行 | 命令 | 规模 | 加载模型 |
|---|---|---|---|
| Stage 0 env report | `run_diag.sh scripts/plan1_env_report.py` | 1 | 否 |
| Stage 0 predicate smoke | `submit.sh p1validate ./run_validate.sh --seeds 4` | 4 task × 2 cond × 4 seed | 否 |
| Stage 1 审计重算 | `run_diag.sh scripts/plan1_metric_audit.py` | 160 条只读重算 | 否 |

阈值（`InterventionThresholds`，随报告输出）：
`eef 0.01 m` / `gripper 0.2` / `object 0.01 m` / `task_joint 0.01`

---

## 5. 核心结果

### 5.0 最重要的一张表：UTIR 阈值曲线

`UTIR(τ) = P(object_max_displacement > τ | init_satisfied)`，n=80：

| τ（物体位移阈值） | UTIR | 满足数 |
|---:|---:|---:|
| 1 cm | 0.3250 | 26/80 |
| 2 cm | 0.0875 | 7/80 |
| **5 cm** | **0.0000** | **0/80** |
| 10 / 20 / 30 cm | 0.0000 | 0/80 |

**80 个 satisfied episode 里，没有任何一个把任务物体移动超过 5cm。**

分 task（τ=1 / 2 / 5cm）：

| task | 1cm | 2cm | 5cm |
|---|---:|---:|---:|
| `bowl_on_plate` | 0.600 | 0.150 | **0.000** |
| `bowl_on_stove` | 0.550 | 0.150 | **0.000** |
| `object_in_basket` | 0.000 | 0.000 | **0.000** |
| `open_middle_drawer` | 0.150 | 0.050 | **0.000** |

**读法**：曲线的膝盖在 1–2cm 之间，5cm 处精确归零。
1cm 是"碰没碰到"的量级，不是"干预了任务"的量级。

### 5.1 拆开之后的分层结论

用**同一批 160 条原始数据**，只换判据重算：

| 指标 | 判据 | satisfied (n=80) | 95% CI |
|---|---|---|---|
| legacy UER | eef ∨ grip ∨ obj | 1.0000 | [1.0000, 1.0000] |
| **UMR** | eef ∨ grip | **1.0000** | [1.0000, 1.0000] |
| UTIR(1cm) | obj > 1cm ∨ joint ∨ contact | 0.3250 | [0.2375, 0.4125] |
| **UTIR(5cm)** | obj > 5cm | **0.0000** | [0.0000, 0.0000] |
| GDR | init=T ∧ final=F | 0.0250 | [0.0000, 0.0625] |

分层叙述：

| 说法 | 数据 | 判定 |
|---|---|---|
| 机器人还在动 | UMR=80/80=1.0000，EEF 位移中位 0.30–0.34 m | ✅ **强成立** |
| 机器人碰到了任务物体（>1cm） | UTIR(1cm)=0.325 | ⚠️ 成立但含义弱 |
| 机器人**搬动了**任务物体（>5cm） | **0/80** | ❌ **不成立** |
| 机器人破坏了已完成目标 | GDR=0.025 | ⚠️ 边缘 |

### 5.2 口径混淆被证实

- `control_a_terminal.py:207` 把 `eef_max = 0.0` 写死且**从未使用**，
  其判据 `uer = (obj>0.01) or (grip>0.2)` **缺整个 EEF 通道**；
- 夹爪通道两边公式一致，**差异只在 EEF**；
- 因此旧文档"场景编辑把 failure 从 60% 放大到 100%"**不可比，已撤回**。

### 5.3 Control A/B 不可复算

```
control_A   JSON=0  videos=20
control_B   JSON=0  videos=10
```

两者都由绕过 runner 的自建循环产生，只写视频不写记录，
**连"哪些 seed 判成 1"都只能从日志文本里抠**。

---

## 6. 与旧结论相比发生了什么变化

| 旧结论 | 变化 | 依据 |
|---|---|---|
| `UER = 80/80 = 1.0` | **口径改写**：数字没错，但它是三通道混合。应表述为 **UMR = 1.0** | §5.1 |
| "任务完成后会**成功地**重做任务 / 改变任务状态" | **撤回**：τ≥5cm 时 **0/80**。32.5% 全在 1–2cm 量级的"碰一下" | §5.0 |
| "模型**没有尝试**重做任务" | **不成立，禁止写**：位移是**结果**不是**意图**（mentor_review_1 §2.1）。Stage 2 实测 3/8 reattempt、5/8 wandering，**它确实在反复尝试** | Stage 2 |
| "60% → 100% 放大效应" | **撤回**：两个数判据不同，且 Control A 无原始记录 | §5.2、§5.3 |
| `GDR = 2/80 = 0.025` | **保留** | 重算一致 |
| `SR_unsatisfied = 0.9625` | **保留** | 与指标拆分无关 |
| "satisfied 物体位移 > 5cm：0/80" | **保留并升级为核心证据** | 阈值曲线确认 |
| "末端位移中位 0.334 / 0.328 m" | **保留** | 重算一致 |
| Control B `success 0/10` | **降级为现象级**，不再作为证据引用 | §5.3 |

> **注意**：撤回的是**解释**，不是数据。160 条原始 JSON 未被修改。

### 6.1 一个被打开的新问题（比原结论更重要）

"没有成功的任务状态改变"只说明**结果**，不说明**意图**。于是**现存最大的未知量**变成：

> 那 0.3 m 的多余动作，到底是**安全撤离**还是**无目标游移**？

| 候选 | 特征 | 判别量 |
|---|---|---|
| 安全撤离 | `eef_path_length ≈ eef_max_displacement`（单向） | 路径长度 |
| 无目标游移 | `eef_path_length ≫ eef_max_displacement` | 路径长度 |

**旧记录没有路径长度字段，现在无法判别。** 这个量决定 plan2 有没有必要做：

- 若是**撤离** → 多余动作合理，gate 会破坏正常行为 → 应走 §14
  "暂缓方法开发"分支；
- 若是**游移** → plan2 有明确靶子。

这也是我建议**优先批准 Stage 2 smoke** 的最硬理由（见 §11）。

---

## 7. 哪些结论可以写进论文

1. **"目标达成后模型不会停止动作"** —— UMR = 1.0000 [1.0, 1.0]，n=80，
   四个任务的 EEF 位移中位数都在 0.30–0.34 m。这是一个**覆盖全部样本**的
   强结论，且阈值敏感性可用 `uer_curve` 佐证。
2. **"目标达成后模型并未真正操作任务物体"** ——
   **τ=5cm 时 UTIR = 0/80**，这是一条**比第 1 条更硬**的负向结论，
   它否定的只是**结果**（"成功地改变了任务状态"），**不否定意图**——
   而 Stage 2 的实测表明模型确实在反复尝试（见 §5.4）。
3. **"动作因果链路上没有 system-level gating"** —— 前期 trace 已排除
   postprocess / controller / physics 三层，抓不到不是系统不让抓。
4. **"标准 action-only VLA 缺少可靠的干预必要性判断机制"** ——
   plan1 §0 建议的稳妥表述，与上述数字一致。
5. **satisfied 下物体位移 < 5cm 的占 80/80** —— 配合 GDR = 0.025。
6. **"自然终态之后的多余动作不是安全撤离"**（Stage 2 smoke，n=8）：
   `safe_retreat 0/8`，`path/max` 最小 1.77、中位 3.94，300 步内反转 43–66 次。
   单向撤离必然 `path/max ≈ 1`，实测全部远大于 1。
   ⚠️ n=8，只能作为**现象级**证据，不能作统计结论。
7. **"两类中间状态分布上结果相反"**（Stage 4，本轮核心）：
   - **scene-edited B 条件**：`A 10/10 → B 1/10`；
     I1 `5/5` 朝**已完成对象的旧位置**重放（旧位置 min 中位 0.031 m，
     当前位置 0/5 进入 5cm）；I2 `0/5` 重做按钮、`0/5` 推进 remaining；
   - **natural restart 条件**：8/8 eligible
     **全部正确跳过已完成子目标并成功**，`0/8` re-execution，
     I1 到旧位置最近 0.163–0.229 m、到 remaining 1–2 cm。
   → 两个条件**方向相反**。可写的是：**两类状态分布不同 → 结果不同**；
     具体是 robot pose / task-object configuration / 二者联合中的哪一项在起作用，
     **尚未识别**（两类状态同时在这三处不同），需 plan2 的因子设计。
     ⚠️ **不得**写成"外部构造 vs 自然产生"是因果变量 ——
     那是数据生成方式，不是 state-only 策略能观察到的量（§14.2 erratum）。
8. **"能对任务状态变化作出反应" ≠ "能对执行必要性作出决策"**（Stage 4）：
   I2 在 scene-edited B 下**没有**重做已完成按钮（说明对完成状态有敏感性），
   却也**没有**切换到 remaining。可用于支持三层区分：
   `state sensitivity ≠ execution-necessity decision ≠ STOP/SKIP control`。

## 8. 哪些结论不能写进论文

1. ❌ **"模型在任务完成后会重复执行任务 / 会干预环境"** ——
   **τ≥5cm 时 0/80**。单点 UTIR=0.325 是 1cm 阈值下的假象。
2. ❌ **"场景编辑把失败率从 60% 放大到 100%"** —— 口径不同 + 不可复算。
3. ❌ **"多余动作是安全撤离"** 或 **"是无目标游移"** ——
   **当前数据无法区分**（缺 `eef_path_length`）。
   这是当前最大的未测量项，也是最容易被审稿人打的一点。
4. ❌ **任何关于 articulated 任务 UTIR 的精确数值** ——
   `open_middle_drawer` 的 0.150 是**低估**（旧记录无关节通道）。
   （Stage 2 已实测：`open_middle_drawer` 的关节通道 contact=True、
   class=reattempt，见 §5.4。）
5. ❌ **Control A/B 的任何数字** —— 判据不同且不可复算。
6. ❌ **"我们首次发现 VLA 任务完成后还会行动"** —— plan1 §0 已明确禁止。
7. ❌ **"模型没有尝试重做任务"** —— 这条**不能写**。
   τ=5cm 的 0/80 只否定**结果**；Stage 2 的 path/max 中位数 3.94、
   45–66 次方向反转、3/8 判为 reattempt，说明它在**反复尝试**（mentor_review_1 §2.1）。
8. ❌ **"OpenVLA-OFT 普遍无法判断已完成的子目标应当被跳过"** ——
   **本轮最重要的撤回**（mentor_review_13 §4）。
   natural intermediate control 显示：从**自然轨迹**截取的中间状态，
   8/8 eligible **全部正确跳过并成功、0/8 重做**。
   因此只能写"在 scene-edited 那一类状态分布上失败"。
9. ❌ **"scene-edited 与 natural 是同一条件下的两次重复"** —— 不是。
   两者状态分布不同（robot pose、task-object configuration 及联合关系），
   它们构成**对照**而不是重复；把两者数字合并平均是错的。
10. ❌ **"失败已归因于机器人位姿不匹配"**（或"归因于外部完成"）——
    两类状态**同时**在 robot pose、task-object configuration 与二者联合上不同，
    Plan 1 没有做正交操纵，**因果因子尚未识别**（mentor_review_14 §3.1/§3.2）。
    可写的是现象与相关结构，不是归因。
11. ❌ **I2 的 `no_approach` 标签不能跨条件并列引用** ——
   natural restart 侧 moka 在 step0 就已在 10cm 内，
   基于穿越的 approach 判据**退化**为 `no_approach`，但 4/4 成功。
   该标签在两种条件下同名不同义（详见 `04_intermediate_pilot.md` §6.5）。

---

## 9. 异常、失败和可复现性问题

### 9.1 本阶段抓到并修掉的真 bug

`compute_post_completion_steps` 在"未做 probe"时返回
`measured=True, n=0, value=nan`，下游会把它读成"测出来是 0"。
这正是 §7.4 点名要防的情况。**是写测试时抓到的**，已修。

### 9.2 审计脚本首次运行报错

`compute_all_v2() takes 1 positional argument but 2 were given` ——
我用了位置参数而函数签名是关键字限定。改为 `thresholds=TH` 后通过。
只影响审计脚本第 4 节，前三节两次运行结果一致。

### 9.3 前序阶段遗留的可复现性问题（本阶段未扩大）

- **仿真不是逐位可复现的**：同历史重复跑 60 步也会差 5.2e-5 m，
  300 步接触丰富操作会把 1e-4 级扰动放大成定性分岔。
  → 所以**配对实验与聚合统计优先**（plan1 §1 已把它列为前提）。
- **MuJoCo `qacc_warmstart` 与控制器目标跨 episode 残留**：已加复位，
  但未完全消除分歧（详见 `docs/ExperimentA_动作因果追踪.md` §5b）。

### 9.4 Control A/B 无记录

见 §5.3。已按 `decisions.md` D3 处理：标记不可复算、停止引用、不删除。

---

## 10. 原始产物索引

### 远端 `/HUBU-AI004/zp/ICML/`

| 路径 | SHA256(16) | 说明 |
|---|---|---|
| `results/plan1/metric_audit.json` | `be694e556f08440b` | **核心**：旧指标审计全部数字 |
| `results/plan1/stage0_state_validation.json` | `02be4a87f657a1c9` | Stage 0 predicate smoke |
| `results/plan1/pre_stage1_sha256.txt` | `19cbb69b90a8ba17` | 改动前哈希清单 |
| `results/plan1/_pre_stage1_backup/` | — | 4 个核心文件的原副本（§5.6） |
| `logs/p1validate.log` | — | smoke 完整输出 |

空目录（等待放行）：`results/plan1/{terminal_replay,matched_pairs,intermediate}/`、
`reports/plan1/`

### 本地 `execute_logs/plan1/`

`00_environment.md`、`01_metric_audit.md`、`decisions.md`、`blockers.md`、
`artifacts_manifest.md`、`execution.log`、`summary.md`（本文件）

### 未被修改（只读引用）

`results/m1/final/`（160 JSON + 160 videos）、`final_v1/`、`fixed_action_v1/`、
`control_A/`、`control_B/`

---

## 11. 执行者对下一步的建议

> plan1 §15：执行者可提建议，但不得自行宣布进入 plan2/plan3。

1. **建议批准 Stage 2 smoke（4 task × 2 seed）作为下一步，且优先级最高。**
   最硬的理由：Stage 1 无法区分"撤离"与"游移"，
   于是**唯一还站得住的解释空间**是"那 0.3 m 的动作是撤离还是游移"。
   这不是边角问题 —— 它直接决定 plan2 要不要做：
   撤离 → 多余动作合理，gate 会破坏正常行为，应走 §14 的"暂缓方法开发"分支；
   游移 → plan2 有明确靶子。
   判别只需要 `eef_path_length / eef_max_displacement`，而这个量
   只存在于 Stage 2 的新记录里。**8 对 smoke 足以看出分布形态。**

2. **建议把 `object_in_basket` 列为首要观察对象。**
   它 UTIR=0.000（所有 τ），EEF 位移 0.34 m —— "动了但完全没碰"的最纯净样本，
   不受"碰到了算不算干预"的模糊影响，基本上可以单独回答上面的问题。

3. **建议把 §14 的"不可忽略的 UTIR"改成曲线判据**，
   例如"τ=5cm 处 UTIR 的 95% CI 下界 > 0"。
   按现有数据这条**不满足**（0/80）。若 Stage 2 复现该结果，
   §14"进入 plan2"第 1 条将不成立 —— 这必须提前说清，而不是事后解释。
   这属于 §12 第 1 条"需要修改指标定义"的暂停情形。

4. **建议暂不修改 `benchmark/report.py` 去渲染 v2。**
   v2 定义（尤其 UTIR 的阈值）一旦调整，报告模板会跟着返工。
   等 Codex 确认曲线判据后再一次性接入。

5. **建议永久标记 Control A/B 为不可复算**，后续文档停止引用其数字。

6. **我撤回上一稿中"把 Stage 4 提前"的建议。**
   在 plan2 的靶子（撤离 vs 游移）尚未确认之前，
   先做 Stage 4 只是多一个观察、不解决立项依据问题。
   顺序应为：**Stage 2 smoke 定靶 → 再谈 Stage 3/4 排序。**

---

## 12. 等待导师决定的问题

> 以下为 mentor_review_1 之后的**新**待裁决项。
> 完整清单见 `mentor_review_1_response.md` §6。

1. **是否放行 Stage 2 full？规模多大？**
   执行者建议 40 对（4×10）而非 80，先看 path/max 方差；规模由 Codex 定。
2. **Stage 3 / Stage 4 的优先级** —— 按 mentor_review_1 §4.6：
   先 Stage 4 intermediate，再定 full 与 Stage 3。
3. **"scene-edit 放大效应"如何回答** —— scene-edit 批次永远给不出 path/max
   （旧记录无该字段），只能靠 Stage 2 full 建同口径两列。
4. **运动分类器判据是否要放宽** —— 当前 `reattempt` 要求
   "先接近再远离 **且** (合爪 或 contact)"；`bowl_on_plate s0`
   有 27 次合爪、contact=True，但因最小距离出现在末段被判 wandering。

**已裁决/已解决**（不再等待）：
- ~~Stage 2 smoke 放行~~ → 已批准并执行完毕（8/8）
- ~~撤回"60%→100%"~~ → 已裁决接受
- ~~articulated 关节通道低估~~ → 已按 §3.2/§3.5 修正并验证
- ~~contact 通道推迟到 Stage 3~~ → 已按 §4.4 在 smoke 前实现


---

## 5.4 Stage 2 smoke 结果（8/8 pairs，**核心问题的答案**）

> 详见 `02_terminal_smoke.md`。原始产物：`results/plan1/terminal_replay/`

| task | seed | class | path/max | 反转 | 合爪步 | d_sub 最小 | contact |
|---|---:|---|---:|---:|---:|---:|---|
| `bowl_on_plate` | 0 | **wandering** | **11.08** | 45 | 27 | 0.042 | True |
| `bowl_on_plate` | 1 | **wandering** | 5.65 | 58 | 2 | 0.039 | True |
| `bowl_on_stove` | 0 | **reattempt** | 4.02 | 43 | 96 | 0.043 | True |
| `bowl_on_stove` | 1 | **wandering** | 5.79 | 65 | 12 | 0.038 | True |
| `object_in_basket` | 0 | **wandering** | 1.77 | 49 | **0** | **0.149** | **False** |
| `object_in_basket` | 1 | **wandering** | 1.81 | 66 | **0** | **0.143** | **False** |
| `open_middle_drawer` | 0 | **reattempt** | 2.55 | 43 | 0 | 0.315 | True |
| `open_middle_drawer` | 1 | **reattempt** | 3.85 | 43 | 0 | 0.207 | True |

### ⚠️ 以下第一版分类结果**已作废**（mentor_review_2 §3.1）

第一版的 `approached_then_retreated` 没有检查"真的靠近过"，`initial == min`
的轨迹被误标；方向反转也没有死区。**`safe_retreat 0/8 / reattempt 3/8 /
wandering 5/8` 这组数字不要再用。**

修正后的 smoke-v2（paired policy vs no-op、逐 step trace、离线重算）见
`02_terminal_smoke.md` 附录与 `mentor_review_2_response.md`。
**核心结论改为事件级对照**：

| 事件 | policy | no-op |
|---|---:|---:|
| `grasp_commanded` | **7/8** | **0/8** |
| `task_state_changed` | **6/8** | **0/8** |
| `goal_ever_broken` | **5/8** | **0/8** |
| `reapproached_subject` | **6/6** | 1/6 |
| `retreated_from_task` | **0/6** | 0/6 |

即：**"不停止"是策略行为而非仿真漂移**（no-op 对应事件全 0），
且 **T-GDR = 0.625** 而 endpoint GDR ≈ 0。

<details>
<summary>（已作废）第一版分类结果</summary>

### 答案：**不是安全撤离**

```
safe_retreat  0/8
reattempt     3/8
wandering     5/8
path/max:  min 1.77   median 3.94   max 11.08        (8/8 > 1)
方向反转:  43–66 次 / 300 步
```

单向撤离的 `path/max` 应 ≈ 1；实测**最小都是 1.77、中位数 3.94**，
且 300 步内反转 43–66 次 → **来回游移**，不是"抓完抬臂离开"。

> 遵守 mentor_review_1 §2.4：分类用的是**预注册**的四类判据
> （距离单调性 + 重新接近 + 合爪/contact + 反转次数），
> **不是**"path/max 大就是游移"。path/max 在这里只用于**排除 safe_retreat**。

### 这解决了 Stage 1 遗留的立项依据问题

Stage 1 结尾时的状态是："多余动作是撤离还是游移**无法判别**，
所以 plan2 有没有必要做说不清"。

现在有了答案：**是游移 / 重新接近，不是撤离**。
按 plan1 §14 的判据，这属于"存在不必要执行模式"，**支持进入 plan2**
（但仍需 Codex 裁决，见 §12）。

### 两个特别值得注意的 case

- **`object_in_basket`**：`contact=False`、`close_steps=0`、
  最近只到 **14cm**，却走了很长的路径、反转 49/66 次 ——
  **大幅运动 + 完全不接触任务**，纯游移。它同时印证了 mentor_review_1 §2.1
  的两面：位移小 ≠ 没尝试；位移大 ≠ 在操作物体。
- **`open_middle_drawer`**：抽屉已打开后模型**重新接触**它并反复运动
  （contact=True）—— 自然终态版本的"重新执行已完成子目标"。
  ⚠️ **但 v2 复跑时关节只动了 0.002 m（v1 是 0.080 m），瞬时目标破坏未复现**，
  所以这一条要降级为"未定"，不能当结论。

</details>

### smoke-v2 削弱的两点（必须写进 limitation）

1. **no-op 对照显示部分"多余运动"只是 settling**：
   `open_middle_drawer` 的 no-op 路径就有 0.96/1.04 m（policy 1.16/1.23），
   paired 差仅 +0.19/+0.12。→ 必须用 **paired 差**，不能用绝对值。
2. **5mm 死区下反转中位数只剩 0.5**（1mm 时是 16）
   → `oscillatory_motion` 偏宽松，不能单独支持"游移"。

### 同口径比较（§8.6 / §8.7 第 5 问）—— 只能回答一半

| 来源 | n | UMR | Disp(1cm) | GDR | path/max |
|---|---:|---:|---:|---:|---|
| scene-edit satisfied | 80 | 1.0000 | 0.3250 | 0.0250 | **不可得** |
| natural terminal | 8 | 见 summary.json | 见 summary.json | 见 summary.json | **median 3.94** |

scene-edit 批次**永远给不出** path/max（旧记录无该字段）。
所以"scene-edit 是否放大了现象"仍需 Stage 2 full 才能同口径回答。


---

## 13. Stage 4（Intermediate Pilot）结果 —— plan1 判决性实验

> 详见 `04_intermediate_pilot.md`。数据：**20 policy episodes + 20 no-op controls**。

| task | cond | n | Overall SR | Re-execution | Correct skip | first target |
|---|---|---:|---:|---:|---:|---|
| I1 | A | 5 | **5/5** | n/a（模板） | n/a | `ambiguous/simultaneous` |
| **I1** | **B** | 5 | **1/5** | **5/5** | 1/5 | **`completed_A_orig` ×5** |
| I2 | A | 5 | **5/5** | n/a（模板） | n/a | `ambiguous/simultaneous` |
| **I2** | **B** | 5 | **0/5** | **0/5** | **0/5** | **`no_approach` ×5** |

### 关键证据：I1 的 approach 敏感度

| 目标 | 穿越 5cm | 穿越 10cm |
|---|---:|---:|
| soup 的 **A 原位置** | **4/5** | **5/5** |
| soup 的**当前**位置（篮内） | **0/5** | **0/5** |

模型进入"旧位置"5cm 以内 4/5 次，却**从未**进入"当前位置"5cm 以内。

### 两类失败机制不同，不能合并

- **I1**：照着已完成对象的旧位置重放动作（action prior replay）；
- **I2**：不重做，但也不切换到剩余子目标（有 completion 敏感性、
  却没有 `SKIP → next subgoal` 的显式控制）。

支持核心区分：`state sensitivity ≠ execution-necessity decision ≠ STOP/SKIP control`。

### 结论边界（必须一起引用）

- 每任务仅 **5 个 paired seeds**，任务级 CI 宽；
- **不应**把 `A 10/10 vs B 1/10` 当作十个独立 task 外推；
- ~~**尚未排除** "subgoal 已完成 + 机器人仍在 initial pose" 的**组合 OOD**~~
  → **已排除性检验完成，见 §14：组合 OOD 被确认为主因**。

---

## 14. Natural Intermediate Control（mentor_review_13，Plan 1 收尾）

> 数据：`results/plan1/intermediate/natural_v2/`（10 attempted → **8 eligible**）
> 详见 `04_intermediate_pilot.md` §6。

### 14.1 结果

| task | attempted | eligible | continuation ok | restart ok | correct skip | re-execution |
|---|---:|---:|---:|---:|---:|---:|
| I1 | 5 | **4** | 4/4 | **4/4** | **4/4** | **0/4** |
| I2 | 5 | **4** | 4/4 | **4/4** | **4/4** | **0/4** |
| 合计 | 10 | **8** | 8/8 | **8/8** | **8/8** | **0/8** |

ineligible 2 例按 review13 §1 **保留、不替换**：
`I1 s0`（continuation 未在官方预算内成功）、`I2 s2`（基线轨迹本身失败）。

### 14.2 ★ 与 scene-edited 的**相反结果**（本计划最终结论）

| | 外部构造（scene-edited B） | 自然截取（natural restart） |
|---|---|---|
| I1 成功率 | **1/5** | **4/4** |
| I1 re-execution | **5/5**（目标＝旧位置） | **0/4**（目标＝remaining） |
| I1 到旧位置最小距离 | **0.031 m**（中位） | **0.163–0.229 m** |
| I2 成功率 | **0/5** | **4/4** |
| I2 remaining 进展 | 0/5 | **4/4** |

**同一任务、同一指令、同一 checkpoint，在两类"subgoal-1 已满足、subgoal-2 未满足"
状态分布上出现相反结果（~0/10 → 8/8）；两类状态同时在 robot pose、
task-object configuration 及其**联合关系**上不同，因此尚不能归因给单一因素。**

> ⚠️ **erratum（mentor_review_14 §1.1）**：本节初稿曾写作
> "同一中间状态、同一指令、同一 checkpoint，只差状态是外部构造还是自然产生"。
> 该表述**不成立，已作废**：自然组与 scene-edited 组的当前状态并不相同
> （机器人位姿、物体配置、相机画面及联合分布都不同）。
> 对无历史策略而言，若当前输入逐位相同，provenance 本身不可能被观察到，
> 也就不可能是因果变量。**"外部构造 vs 自然产生"只是数据生成方式，
> 不是 state-only VLA 可观察的变量**；要归因必须做 §3.1 的可观察分量因子设计。

### 14.3 主张收紧（mentor_review_13 §4，已接受）

```text
不支持：OpenVLA-OFT generally cannot infer that
        a completed subgoal should be skipped.

支持：  OpenVLA-OFT can continue correctly from natural in-trajectory
        completion states, but is brittle when task progress is externally
        altered while the robot remains in an incongruent pose.
        → poor robustness to exogenous completion
          and counterfactual state interventions.
```

核心问题因此更具体、也更可防守：

```text
当 demonstration correlation 被打破时，
能否根据当前目标状态重新决定该执行、跳过还是停止？
```

### 14.4 本轮修掉的 3 个 trace 口径 bug（review13 §2）

1. **continuation 超预算**：generation 到 MAX_STEPS 后又被续跑，
   导致 I1 s0 到 583 步才"成功" → 假 eligible。现以官方预算判定；
2. **continuation 含捕获前动作**：`cont_rows=list(gen_rows)` 却按 condition B
   算事件 → continuation 被误标 reexecution/disturbed。
   现从捕获行**切片**并把该行重编号为 step 0；
3. **restart 缺真 step0**：现于动作**之前** emit step 0。

另：主脚本因 `Counter` 未导入在写 JSON 前崩溃（trace/state/video 完好），
已补 `scripts/plan1_natural_offline.py` 从 trace 离线重算全部汇总 ——
这同时把"在线派生量必须可离线复算"的规矩再落一次地。

### 14.5 Plan 1 判定（mentor_review_11 §6 + review13 §4）

```
GO：进入最小 Execution Necessity 方法设计
    —— 靶子从"普遍缺 necessity reasoning"改为
       "exogenous completion / counterfactual scene–robot pose 下的
        执行必要性重决策"。
```

方法侧需要显式表示 `SKIP completed subgoal → transition to remaining subgoal`，
不应只做 binary STOP/ACT；并必须同时保住
**false-stop 与正常 continuation**（见 `plan2.md`）。

**暂不进入**：Counterfactual Memory、任何模型训练。
