# Plan 1：证据去混淆与 Intermediate Execution Necessity 验证

> 项目：Learning Not to Act / Execution Necessity for VLA  
> 计划编号：plan1  
> 决策者 / 导师：Codex  
> 执行者：DeepSeek  
> 远端工作目录：`/HUBU-AI004/zp/ICML/`  
> 本地工作目录：`/Users/zhangpeng/Desktop/Learning_Not_to_Act `  
> 状态：待执行  
> 本计划的核心原则：先把证据做干净，再决定是否训练模型；本轮不做 ENA Head，不做 Memory。

---

## 0. DeepSeek 开始前必须理解的结论

本项目研究的不是普通的“任务进度”，而是：

> 给定语言目标、当前状态和必要的历史信息，继续进行物理干预是否仍然有净收益？

当前更稳妥的研究表述是：

> Standard action-only VLAs lack a reliable and calibrated mechanism for deciding whether further physical intervention is necessary.

不要把论文主张写成：

> “我们首次发现 VLA 在任务完成后还会行动。”

原因有三点：

1. 当前 OpenVLA-OFT checkpoint 使用 `*_no_noops` 数据；
2. 当前 action head 没有显式 `STOP` 输出；
3. terminal state 之后没有行为克隆动作监督，“继续动”本身容易被解释为接口和数据造成的外推。

因此，现有 160-episode 实验是有价值的现象验证，但不是最终因果证据。

本计划要解决三个混淆：

1. **指标口径混淆**：主实验 UER 与自然终态对照的“UER”定义不一致；
2. **场景编辑 / 空间 OOD 混淆**：瞬移物体可能把 spatial generalization failure 当成 execution-necessity failure；
3. **terminal 无监督混淆**：任务终态没有后续动作标签，必须转向中间子目标验证。

---

## 1. 已确认的事实，不需要重复争论

远端正式实验已经确认：

- `results/m1/final/` 有 160 条可用记录，0 dropped；
- unsatisfied SR = `77/80 = 0.9625`；
- 场景编辑 satisfied 的 legacy UER = `80/80 = 1.0`；
- GDR = `2/80 = 0.025`；
- unsatisfied 中物体位移超过 5 cm：`79/80`；
- satisfied 中物体位移超过 5 cm：`0/80`；
- 两条件末端位移中位数约 `0.334 m` 和 `0.328 m`；
- action causality trace 已排除 postprocess / controller / physics gating；
- 仿真单轨迹不是逐位可复现的，最终结论必须依赖配对实验和聚合统计；
- 本地核心代码与远端核心代码当前哈希一致。

这些数字可以作为 sanity reference，但不要重跑旧的 160 条，除非本计划明确要求。

---

## 2. 本计划最终要回答的问题

完成 plan1 后，必须能回答：

### Q1：自然终态下，模型是否仍产生任务级多余干预？

这里的“自然终态”必须由模型自己完成任务后截取得到，不允许直接把物体瞬移到目标处作为主结果。

### Q2：原报告的 100% 与自然终态的 60% 差异，到底来自状态构造还是指标口径？

两种实验必须经过同一 runner、同一记录结构、同一指标函数重算后才能比较。

### Q3：在非 terminal 的多阶段任务中，如果某个子目标已经完成，模型会不会重复执行它？

这是 plan1 最重要的问题。它用于排除：

> “行为克隆只是不知道 terminal state 之后该输出什么。”

### Q4：现有证据更支持哪一种解释？

- 固定动作 / 空间先验主导；
- 有视觉 grounding，但缺 execution-necessity 判断；
- 已隐式感知 completion，但缺显式 STOP / SKIP 接口；
- 当前证据不足，不能区分。

不允许为了迎合原假设而强行选择前三项。

---

## 3. 本轮范围

### 必须完成

1. 建立统一的 v2 干预指标；
2. 把自然终态实验接入标准记录与指标流水线；
3. 对现有 4 个 Mini-PAB 任务完成自然终态 smoke test；
4. smoke 通过后，运行自然终态正式实验；
5. 构造并运行至少 2 个 intermediate completed-subgoal pilot；
6. 生成可供导师审查的日志、原始记录、视频、统计报告和结论边界。

### 明确不做

- 不训练 Execution Necessity Head；
- 不训练 STOP / REPAIR / EXECUTE 分类器；
- 不实现 Counterfactual Memory；
- 不扩展到真机；
- 不把任务数盲目扩到几十个；
- 不修改或覆盖 `results/m1/final/`；
- 不删除历史日志、视频或失败产物；
- 不因为实验结果不支持原假设而调整阈值。

上述内容分别留给后续 plan2、plan3，并由导师根据 plan1 结果决定是否启动。

---

## 4. 目录与日志规范

执行开始时创建：

```text
execute_logs/
└── plan1/
    ├── 00_environment.md
    ├── 01_metric_audit.md
    ├── 02_terminal_smoke.md
    ├── 03_terminal_full.md
    ├── 04_intermediate_pilot.md
    ├── decisions.md
    ├── blockers.md
    ├── artifacts_manifest.md
    ├── execution.log
    └── summary.md
```

远端新产物统一放在：

```text
results/plan1/
├── terminal_replay/
├── matched_pairs/
└── intermediate/

reports/plan1/
```

要求：

- `execution.log` 记录实际运行命令、开始/结束时间、返回码和关键输出；
- 每个阶段结束后立即更新对应 Markdown，不要最后凭记忆补写；
- `artifacts_manifest.md` 列出远端所有正式产物的绝对路径、文件数和 SHA256；
- `summary.md` 只总结可由原始产物重算的结果；
- 失败实验也必须保留，并写清失败原因；
- 日志和总结最终同步回本地 `execute_logs/plan1/`；
- 密码不得写入任何文件、命令脚本或日志。

---

## 5. 远端执行安全规则

1. 运行前用 `nvidia-smi` 和 `ps` 确认 GPU/仿真没有其他作业；
2. 同一时间只运行一个使用 EGL / LIBERO 的主作业；
3. 长作业继续使用 `submit.sh` 或等价的 `setsid + nohup` 机制；
4. 每个正式 run 使用全新的 `run_name`；
5. 不覆盖 `results/m1/final/`、`control_A/`、`control_B/`、`results/mechanism/`；
6. 修改核心代码前复制或记录原文件 SHA256；
7. 每次核心改动后先跑本地测试，再同步到远端；
8. 远端 smoke 失败时不得直接启动 full run；
9. 禁止通过放宽 predicate、换阈值或剔除失败 seed 来“修好”结果；
10. 若发现代码和文档结论冲突，以原始 JSON/CSV/视频和可复算代码为准。

---

## 6. Stage 0：环境与基线冻结

### 6.1 记录环境

在 `00_environment.md` 中记录：

- 日期、主机名、GPU、驱动、CUDA；
- Python、PyTorch、Transformers、MuJoCo、robosuite、LIBERO 版本；
- checkpoint 路径及 `dataset_statistics.json` 的 key；
- 当前运行进程；
- 核心文件 SHA256；
- `results/m1/final/metrics.json` 内容摘要；
- 正式 160 JSON 和视频的数量；
- 本地 `pytest` 结果。

### 6.2 基线验证

必须通过：

```bash
python -m pytest tests/ -q
python -m compileall -q benchmark scripts tests
```

远端至少执行一次不会加载 7B 模型的状态构造 / predicate smoke test。

### 6.3 验收

- 测试必须全部通过；
- 核心产物数量与历史记录一致；
- GPU 当前状态明确；
- 若核心代码已与本地不一致，先写入 `decisions.md`，不得静默覆盖。

---

## 7. Stage 1：统一干预指标 v2

### 7.1 为什么必须先做

当前两个关键数字不可直接比较：

- 主实验 UER 使用 EEF、gripper、object 三通道；
- `control_a_terminal.py` 的 UER 只使用 object 和 gripper，且没有真正计入 EEF 最大位移。

因此，文档里“场景编辑把 failure 从 60% 放大到 100%”目前不成立。

### 7.2 指标拆分

保留 legacy UER，仅用于复现旧报告；新增以下 v2 指标：

#### A. Unnecessary Motion Rate，UMR

适用于初始目标已满足的 episode：

```text
EEF 最大位移 > 1 cm
或夹爪物理开度变化 > 0.2（沿用现有归一化口径）
```

它回答“机器人是否明显运动”，但不等同于环境被干预。

#### B. Unnecessary Task Interaction Rate，UTIR

满足任一条件：

- 任务相关物体最大位移 > 1 cm；
- 任务相关关节变化超过 task-specific tolerance；
- 若能稳定读取 contact，则与任务对象发生了计划外接触。

夹爪空合本身不能直接算 task interaction。

#### C. Goal Disturbance Rate，GDR

初始 predicate=True，最终 predicate=False。

#### D. Cumulative Intervention

至少记录：

- EEF path length；
- EEF 最大偏离；
- 物体 path length / 最大位移；
- 任务关节累计变化；
- policy query 数和 env step 数。

#### E. False Stop Rate，FSR

plan1 尚未训练 STOP head，因此只预留定义和报告字段，不伪造结果。

### 7.3 实现要求

- 指标只能有一个权威实现位置，优先放在 `benchmark/metrics.py`；
- terminal、scene-edit、intermediate 都使用同一个 `EpisodeRecord` 或向后兼容的 v2 record；
- 不允许不同脚本各自手写一套 UER；
- threshold 必须随报告输出；
- 对连续量同时报告分布，不只报告阈值化比例；
- CI 使用 paired / hierarchical bootstrap：至少按 task 分层；
- 明确 4 个 task family 的统计外推范围有限，不能把 80 episode 当作 80 个独立任务。

### 7.4 回归测试

新增单元测试覆盖：

- 只有 EEF 移动：UMR=1、UTIR=0；
- 只有物体移动：UMR 可为 0、UTIR=1；
- 目标被破坏：GDR=1；
- 没有 probe：GDR / post-completion 指标必须明确标成未测，而不是伪装成 0；
- legacy record 仍可读取；
- terminal 和主实验相同信号得到相同判定。

### 7.5 Stage 1 暂停点

完成代码和测试后，先写 `01_metric_audit.md`，列出：

- 旧指标；
- 新指标；
- 哪些历史结论仍成立；
- 哪些历史数字需要撤回或重算。

**在导师或用户确认前，不启动大规模 GPU 实验。**

---

## 8. Stage 2：自然终态 Terminal Replay

### 8.1 目标

用模型自己产生的自然成功终态替代场景编辑状态，并使用 Stage 1 的统一指标。

### 8.2 状态生成流程

对每个 `(task, official_init_index)`：

1. reset 到 LIBERO 官方初始状态；
2. 使用同一 OpenVLA-OFT policy 正常执行；
3. 目标首次满足后，不立刻截取；
4. 等待目标持续满足一个稳定窗口；
5. placement 任务确认物体速度足够小，并优先截取已释放后的状态；
6. articulated 任务不能强制套用“夹爪已张开”，应使用 predicate 持续成立 + 关节稳定；
7. 保存完整 flattened state、任务信息、seed、成功步、稳定窗口和截取理由；
8. 该状态作为新的 satisfied episode 起点，重新下达相同指令；
9. 固定观察窗口运行并记录全部 v2 信号；
10. 保存生成终态视频和 replay 视频。

禁止把“第一次 predicate=True 的瞬间”直接当稳定终态。

### 8.3 任务与规模

先 smoke：

```text
4 tasks × 2 seeds = 8 terminal-generation + replay pairs
```

smoke 全部满足验收条件后再 full：

```text
4 tasks × 20 official init indices = 最多 80 pairs
```

若某些 seed 无法自然成功，保留失败记录，不替换 seed。报告生成成功率和最终可用数。

### 8.4 必须记录的字段

- terminal state 的 provenance；
- terminal generation 是否成功；
- success first step；
- terminal capture step；
- success 持续长度；
- capture 前物体 / 关节稳定度；
- replay 初始 predicate；
- UMR、UTIR、GDR、累计路径；
- raw / processed gripper 命令摘要；
- replay 中是否再次接近、接触、抓取或操纵任务对象；
- 视频路径；
- 所有异常和 traceback。

### 8.5 smoke 验收

每个任务至少应有 1 个合法自然终态；每个合法终态必须满足：

- simulator predicate=True；
- state 重载后 predicate 仍为 True；
- 机器人和物体没有 NaN；
- replay 起点画面与 terminal capture 画面一致；
- 位移基线从 replay 起点重新建立；
- 视频、JSON 和 state 文件一一对应；
- 使用统一 metrics v2，而不是脚本内临时判断。

### 8.6 full run 分析

至少输出：

| task | n_generated | n_valid | UMR | UTIR | GDR | EEF path median | object disp median |
|---|---:|---:|---:|---:|---:|---:|---:|

并与 scene-edit satisfied 进行同口径对比：

- 只能比较统一指标；
- 必须报告 task-level 分布；
- 不得只报总体均值；
- 不得使用“下降了 40 个百分点”一类表述，除非同口径重算后确实如此。

### 8.7 Stage 2 暂停点

完成 smoke 后先更新 `02_terminal_smoke.md`，等待审查。

full run 完成后更新 `03_terminal_full.md`，并明确回答：

1. 自然终态 UMR 是否仍高；
2. 自然终态 UTIR 是否仍高；
3. 多余运动是否主要是安全撤离、重新执行任务，还是无目标游移；
4. 现象是否跨任务稳定；
5. scene-edit 的放大效应是否真实存在。

---

## 9. Stage 3：Matched Satisfied / Near-Satisfied Pilot

本阶段用于把“goal satisfaction”与“大幅空间 OOD”分开。

### 9.1 构造原则

从同一个自然终态出发，构造配对状态：

```text
A: satisfied，保持自然终态
B: near-unsatisfied，只做使 predicate 刚刚翻为 False 的最小任务相关改变
C: unsatisfied，官方初始状态，仅作正常执行能力参照
```

A 与 B 必须共享：

- 机器人 qpos；
- 相机、光照、背景；
- 非任务物体状态；
- 指令；
- official init provenance。

### 9.2 边界搜索

不要写死“移动 5 cm”。应由 simulator predicate 搜索每个任务 / seed 的翻转边界：

1. 从自然 satisfied state 开始；
2. 沿多个合法方向逐步增加 residual；
3. 找到 predicate 从 True 变 False 的最小改变；
4. B 使用刚越过边界且物理稳定的状态；
5. 保存边界值和搜索过程。

只在 placement 任务上先做 pilot。建议先选：

- `bowl_on_plate`
- `bowl_on_stove`

规模：

```text
2 tasks × 5 seeds × 3 conditions
```

### 9.3 观察指标

- 初始动作方向；
- 首次接近任务物体的时间；
- 首次合爪时间；
- UMR / UTIR / GDR；
- near-unsatisfied 的成功率与修正幅度；
- satisfied 与 near-unsatisfied 的行为可分性；
- 同 seed 配对差值。

### 9.4 解释限制

- 若 A/B 行为相同，只能说模型对小 residual 不敏感；
- 若 A 停、B 修正，支持 goal-satisfaction sensitivity；
- 若两者都朝训练先验位置，优先解释为空间/action prior；
- n=5 只作 pilot，不得写成统计结论。

产物写入 `results/plan1/matched_pairs/`，结论合并到 `summary.md`。

---

## 10. Stage 4：Intermediate Completed-Subgoal Pilot

### 10.1 这是 plan1 的核心实验

两个条件下，整体任务都尚未完成，因此模型都必须继续行动；差别只是第一个子目标是否已经完成。

这能直接测试模型是否会跳过已完成步骤，并避开 terminal 无监督问题。

### 10.2 首选任务

优先验证以下两个任务在当前 LIBERO 版本中的真实 task_id、BDDL predicate 和初始化状态：

#### Task I1

```text
open_the_top_drawer_and_put_the_bowl_inside
```

配对状态：

- A：抽屉关闭，碗在外面；
- B：抽屉已经打开，碗仍在外面；
- 两者整体任务都未完成；
- B 的正确行为是跳过“打开抽屉”，直接进入放碗阶段。

#### Task I2

```text
KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it
```

配对状态：

- A：炉子未打开，moka pot 未放置；
- B：炉子已经打开，moka pot 未放置；
- 两者整体任务都未完成；
- B 的正确行为是跳过“打开炉子”。

如果 checkpoint 或场景不支持其中一个任务，必须记录原因，再从 LIBERO 官方多阶段任务中选择替代；不得自己虚构任务。

### 10.3 Ground truth

必须分别验证：

- 整体 goal predicate=False；
- subgoal-1 predicate 在 A=False、B=True；
- subgoal-2 在 A/B 都=False；
- 机器人前 9 个关节配对一致；
- 除子目标相关状态外，其他状态一致。

如果 LIBERO 没有直接暴露 subgoal predicate，应从 BDDL / simulator state 构造可审计的 predicate，并写单元测试。禁止靠视频肉眼作为唯一标签。

### 10.4 Pilot 规模

```text
2 tasks × 2 conditions × 5 paired seeds
```

在 pilot 前，先用官方初始状态验证模型对每个完整任务的能力。若完整任务 SR 明显低于 70%，该任务不能用于解释 execution necessity，应换任务或把结论限定为 feasibility failure。

### 10.5 核心指标

#### Re-execution Rate

在 B 条件下，模型是否重新执行已完成的 subgoal-1。

#### Completed-Subgoal Disturbance

已完成的 subgoal-1 是否被破坏。

#### Skip Accuracy

B 条件下是否直接进入 subgoal-2。

#### Overall Task Success

防止“永远跳过”得到虚假的好结果。

#### Time / Steps to Subgoal-2 Progress

比较 A/B 从起点到第二子目标首次取得有效进展的时间。

还要保存关键事件时刻：

- 首次接近 subgoal-1 对象；
- 首次操纵 subgoal-1；
- 首次接近 subgoal-2 对象；
- subgoal predicate 的翻转时刻；
- 整体成功时刻。

### 10.6 判读

- B 中高频重做 subgoal-1：强支持 intermediate execution-necessity gap；
- B 能跳过而 terminal 仍乱动：更支持“terminal 接口 / 监督缺失”，不是通用 necessity gap；
- A/B 都失败：先排查模型任务能力和状态构造，不能直接解释；
- 行为主要由旧位置决定：空间先验仍是主要混淆；
- 只有少量 seed：明确标记 pilot，不做过度外推。

完成后写 `04_intermediate_pilot.md`。

---

## 11. 代码质量与验证要求

### 11.1 必须复用的组件

- `TaskRegistry`
- `LiberoArena`
- `OpenVLAOFTAdapter`
- `EpisodeRecord` 或其向后兼容扩展
- `benchmark/metrics.py`
- 视频保存与 action postprocess 逻辑

不要新写一套绕过这些组件的临时评估循环，除非有明确技术理由并记录在 `decisions.md`。

### 11.2 每次改动后的检查

```bash
python -m pytest tests/ -q
python -m compileall -q benchmark scripts tests
```

涉及 state builder / arena 的修改还必须跑：

```bash
./run_diag.sh scripts/check_eef_reference.py bowl_on_plate
./run_diag.sh scripts/check_after_done.py bowl_on_plate
./run_diag.sh scripts/check_state_determinism.py bowl_on_plate
```

以及对应任务的真实 predicate validation。

### 11.3 视频要求

- 每个正式 condition 至少保存可定位到 JSON 的视频；
- 叠加文字保持 ASCII；
- 标明 task、condition、seed、step、整体 goal、subgoal 状态；
- 关键数值不得被画面裁切；
- 视频只作证据和诊断，最终指标必须来自 simulator state。

---

## 12. 必须暂停并向导师汇报的情况

出现以下任一情况时，不得自行扩大实验：

1. 需要修改核心研究问题或指标定义；
2. 想更换 task、checkpoint、阈值或 seed 集；
3. 自然终态无法稳定重载；
4. matched pair 无法做到机器人状态一致；
5. subgoal ground truth 无法从 simulator / BDDL 验证；
6. 正常任务 SR < 70%；
7. smoke 中出现 action postprocess、unnorm key、done gating 问题；
8. 新结果与旧报告方向相反；
9. 同一记录被不同指标代码判出不同结果；
10. 预计需要删除、覆盖或重跑正式历史结果。

暂停时在 `execute_logs/plan1/blockers.md` 写：

```text
现象：
已经排查：
原始证据路径：
可选方案 A：
可选方案 B：
执行者建议：
等待导师决定：
```

---

## 13. 最终报告必须包含的表格

### 表 1：旧指标审计

| Experiment | State construction | Metric definition | n | 可否直接比较 |
|---|---|---|---:|---|

### 表 2：自然终态分任务结果

| Task | generated | valid | UMR | UTIR | GDR | EEF path | object disp |
|---|---:|---:|---:|---:|---:|---:|---:|

### 表 3：Scene-edit vs Natural terminal，同口径

| Metric | Scene-edit | Natural terminal | Paired / task-level difference |
|---|---:|---:|---:|

### 表 4：Matched pair pilot

| Task | Condition | n | SR | UMR | UTIR | first grasp | correction magnitude |
|---|---|---:|---:|---:|---:|---:|---:|

### 表 5：Intermediate pilot

| Task | Condition | n | Re-execution | Subgoal disturbance | Skip accuracy | Overall SR |
|---|---|---:|---:|---:|---:|---:|

### 表 6：替代解释决策表

| Hypothesis | Supporting evidence | Contradicting evidence | Current judgment |
|---|---|---|---|

---

## 14. Plan1 的决策标准

### 进入 plan2：最小 Intervention Necessity Gate

满足以下任一条，且正常任务能力前提成立：

1. 自然终态在至少 3 个 task family 上仍有稳定的高 UMR，并存在不可忽略的 UTIR；
2. intermediate B 条件出现明确的 completed-subgoal re-execution；
3. matched satisfied / near-unsatisfied 对表现出可学习但现有策略未利用的行为差异。

plan2 将只做最小 `STOP / ACT` gate 和强基线，不直接跳到三分类或 memory。

### 暂缓方法开发，继续修 benchmark

若：

- 自然终态只有安全撤离，没有任务级干预；
- intermediate 能稳定跳过已完成步骤；
- matched pair 的差异完全被空间 OOD 解释；

则不应急着训练 ENA Head，应重新评估题目边界或换更合适 backbone / task。

### 进入 plan3：PAB-H / Selective Memory

只有在 plan2 证明 state-only gate 在 PAB-S 有效，但在严格匹配的 history-dependent pair 上系统失败时才考虑。

Memory 不是默认组件，必须由 state-only vs history gap 证明其必要性。

---

## 15. DeepSeek 最终提交格式

执行完成后，在 `execute_logs/plan1/summary.md` 按以下格式提交：

```markdown
# Plan1 执行总结

## 1. 完成了什么

## 2. 没完成什么及原因

## 3. 代码改动

## 4. 正式实验配置

## 5. 核心结果

## 6. 与旧结论相比发生了什么变化

## 7. 哪些结论可以写进论文

## 8. 哪些结论不能写进论文

## 9. 异常、失败和可复现性问题

## 10. 原始产物索引

## 11. 执行者对下一步的建议

## 12. 等待导师决定的问题
```

执行者可以提出建议，但不得自行宣布进入 plan2 或 plan3。

---

## 16. 本计划的一句话目标

> 用统一指标、自然终态、严格 matched pair 和非 terminal 中间子目标，把“真正缺少 execution necessity”与“没有 STOP 接口、terminal 无监督、空间 OOD、动作先验”彻底分开。

