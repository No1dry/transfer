# Plan 1 最终科学总结：从 “VLA 会不会停止” 到 “VLA 能否重新判断动作是否必要”

> 项目：Learning Not to Act / Execution Necessity for VLA  
> 状态：**Plan 1 已正式完结**  
> 用途：项目阶段总结、论文 Introduction/Problem Formulation 的事实底稿  
> 注意：本文只总结已经被实验支持的内容；不把 Plan 2 的假设写成既成结论。

---

## 1. 一句话结论

Plan 1 没有支持最初那个宽泛主张——“现有 VLA 普遍不知道何时不该行动”；
它支持了一个更具体、也更有研究价值的结论：

> OpenVLA-OFT 能从自然成功轨迹的中间状态继续完成剩余目标，但当任务进度与
> 机器人动作阶段被反事实重组、偏离 demonstration distribution 时，行为会显著崩溃。
> 因此，真正值得研究的不是单纯的 STOP，而是 VLA 能否依据当前状态重新判断
> `EXECUTE / SKIP / STOP`——也就是 execution necessity。

这使 “Learning Not to Act” 从一个容易被反例推翻的现象描述，变成一个可以被严格
因果实验检验的问题：**在目标已经部分或全部满足时，哪些动作仍然有必要？**

---

## 2. 最初问题与 Plan 1 的研究转折

最初直觉是：任务已经满足时，策略本应不再行动；而现有 VLA 可能仍会输出动作。
这个直觉包含三个不同问题：

1. **STOP**：整体任务已经完成，是否应停止调用策略？
2. **SKIP**：多阶段任务中某个子目标已经完成，是否应跳过它？
3. **ADVANCE/EXECUTE**：仍有未完成目标时，是否能转向正确目标并继续执行？

Plan 1 的关键价值，是把这三件事逐步拆开。实验最终表明：

- “任务完成后仍输出动作”确实存在，但不能仅凭动作非零就断言它造成任务破坏；
- “模型一般不会跳过已完成子目标”不成立，因为自然中间状态上 8/8 都能正确继续；
- 真正稳定出现的失败，是**任务进度与 robot phase/pose 的联合关系被打破**以后，
  模型不能可靠地重新决定下一步。

---

## 3. Plan 1 完成了什么

### 3.1 建立了可复算的评估基础

Plan 1 不只跑 rollout，也修正并固定了后续研究必须依赖的实验基础：

- action post-processing 与 unnormalization key；
- environment done gating；
- local/world 坐标与 EEF 参考点；
- gripper 阈值单位；
- `set_state` 后 stale observation；
- controller goal 与 MuJoCo solver warm-start；
- contact/object mapping；
- BDDL predicate 与子目标语义；
- step-0、trace slicing、official-budget eligibility；
- policy/no-op 配对、原始 trace、state、video 与离线重算。

这些修正的意义不是工程上的“打补丁”，而是防止把 observation 污染、坐标错误、
预算不一致或 trace 口径错误误写成 VLA 的认知缺陷。

### 3.2 分四层回答了最初问题

| 层次 | 条件 | 结果 | 科学含义 |
|---|---|---|---|
| 历史 satisfied 批次 | 外部构造终态，80 episodes | 任务物体位移在 5cm 阈值下为 **0/80** | 单靠旧批次不能证明“VLA 会破坏已完成任务”；且 checkpoint 使用 `no_noops` 数据，不能据此主张 novelty |
| 自然终态 replay | 从策略自然成功状态继续询问，8 pairs | **8/8 继续运动**；7/8 抓取，6/8 接触任务对象，5/8 状态变化，4/8 曾破坏 goal；`safe_retreat=0/8` | 任务成功并不意味着策略内部自动进入“无需再行动”状态；但 n=8，只能作为现象证据 |
| scene-edited 中间状态 | sg1=True、sg2=False，robot 保持初始阶段 | 正常任务 10/10；编辑条件仅 **1/10** 成功 | 当任务进度与 robot phase 被反事实重组时，行为严重退化 |
| natural intermediate control | 自然成功轨迹中捕获 sg1=True、sg2=False 后 restart | 10 attempted、8 eligible；**8/8 成功、8/8 正确跳过、0/8 重做** | 模型并非一般性地不会 skip；失败与 counterfactual state distribution 绑定 |

---

## 4. 最关键的实验结果

### 4.1 自然终态：成功之后仍有任务相关动作

在 8 个自然成功终态上，环境不立即终止，而是继续向同一策略请求动作：

```text
仍有明显运动                         8/8
出现 grasp-like 行为                  7/8
与任务对象发生 contact                6/8
任务状态发生可测变化                   5/8
曾经使 goal predicate 变为 False       4/8
最终仍处于 goal-broken                 3/8
被判为安全撤离                         0/8
```

这个结果说明：至少对当前 OpenVLA-OFT checkpoint，任务成功以后继续查询策略，
不会自然得到一个可靠的“停止接口”。但是这里必须区分：

- **动作非零**不等于**有害动作**；
- “曾经破坏”与“终点仍破坏”不同；
- 这只是 8 个自然终态、一个 checkpoint，不能外推成所有 VLA 的普遍规律。

### 4.2 Scene-edited 中间状态：两个任务都崩溃，但机制不同

两个多阶段任务都先验证了完整任务能力：I1 5/5、I2 5/5。
随后只让第一个子目标满足、第二个子目标保持未满足，并从重组后的状态执行原指令。

#### I1：双物体放入篮子

```text
正常初始状态                 5/5 success
scene-edited 状态            1/5 success
重新接近已完成 soup 的旧位置   5/5
到旧位置最小距离中位数         0.031 m
进入 soup 当前位置 5cm         0/5
```

I1 的失败具有明确空间结构：策略不是随机游走，而是在空的 canonical/original
location 附近重放与已完成对象有关的动作。

#### I2：打开炉子并放置 moka pot

```text
正常初始状态                 5/5 success
scene-edited 状态            0/5 success
重新操作已完成 button         0/5
推进 remaining moka subgoal  0/5
出现有效闭爪                 0/5
```

I2 不是“重做第一个子目标”，而是没有可靠地切换到仍未完成的目标。
因此同一种整体失败率背后至少有两种行为机制：旧位置重放与 transition failure。

### 4.3 Natural intermediate：强主张被反例推翻

为了检验 scene-edited 失败是否代表一般性的 skip 缺陷，Plan 1 从自然成功轨迹中
截取相同语义标签的状态：`sg1=True, sg2=False`，然后清空 action queue 并 restart。

```text
I1：5 attempted，4 eligible，4/4 restart success，4/4 correct skip
I2：5 attempted，4 eligible，4/4 restart success，4/4 correct skip
总计：8/8 success，8/8 correct skip，0/8 reexecution
```

这组结果直接否定了：

> “OpenVLA-OFT 普遍无法判断已经完成的子目标应被跳过。”

但它没有否定整个课题。相反，它揭示了更精确的 gap：模型能够沿自然轨迹的联合分布
继续执行，却不能保证在任务进度与机器人阶段被重新组合时仍作出相同的 necessity decision。

---

## 5. Plan 1 最终支持与不支持的主张

### 5.1 可以写进论文

1. 当前 checkpoint 没有显式 STOP head；继续查询时会继续产生动作。
2. 在 8 个自然终态 replay 中，8/8 有明显运动，且多例出现任务相关接触或 goal disturbance。
3. 两个具备正常任务能力的多阶段任务，在 scene-edited 中间状态上从 10/10 降至 1/10。
4. I1 的失败表现为对已完成对象 canonical/original location 的定量空间锁定。
5. I2 的失败表现为既不重做已完成目标、也不推进 remaining goal 的 transition failure。
6. 自然中间状态 control 上 8/8 正确跳过并成功，说明 scene-edited 结果不是一般性 skip failure。
7. 当前证据支持研究 **counterfactual task-progress/robot-phase recombination 下的 execution necessity**。

### 5.2 不能写进论文

1. “所有 VLA 在任务完成后都会采取有害动作。”
2. “OpenVLA-OFT 普遍不会跳过已完成子目标。”
3. “失败已经被证明由 exogenous completion 本身造成。”
4. “失败已经被证明只由 robot pose mismatch 造成。”
5. “自然组与编辑组是同一状态，只差产生方式。”
6. “Memory 是必要解决方案。”
7. “state-only gate 已经有效。”
8. 把不同 task、不同 eligibility 或不同失败机制简单合并成大样本统计显著性。

---

## 6. 对论文 Introduction 最有价值的叙事

### 6.1 问题不应从“停止按钮”开始

论文不应只说“机器人任务做完后还在动”。这个表述太容易被以下反驳：

- benchmark 在 success 后本来就结束，策略从未被要求停止；
- 非零动作可能只是安全撤离；
- 模型训练数据可能根本没有 no-op/STOP supervision；
- 外部瞬移终态可能是明显 OOD。

更强的切入方式是：

> 现有 VLA 主要回答“给定指令，下一步做什么”，但实际部署还需要回答一个先验问题：
> **当前是否仍有必要行动，以及原指令中的哪些部分仍需执行？**

这把问题从动作生成提升为动作生成之前的 **execution-necessity decision**。

### 6.2 为什么这个问题重要

现实中的任务进度并不总由当前机器人自己按训练轨迹产生：

- 人可能提前完成部分步骤；
- 另一台机器人可能改变场景；
- 任务可能在等待期间已经满足；
- 机器人可能从恢复状态、交接状态或异常中间状态接管。

在这些情况下，盲目执行完整指令可能导致重复抓取、扰动已经完成的布置、浪费动作，
甚至破坏安全约束。一个可靠的具身智能体不仅要有 action competence，还要有
**action restraint**：执行未完成目标、跳过已满足目标、在全部满足时停止。

### 6.3 Plan 1 给 Introduction 的核心 empirical hook

可以用下面这组反差作为 Introduction 的中心：

```text
自然中间状态：8/8 正确继续，0/8 重做
反事实重组状态：完整任务能力 10/10，但编辑状态仅 1/10 成功
```

这个反差比“模型一直动”更强，因为它排除了“模型根本不会做任务”，也推翻了
“模型一般不会 skip”的简单解释。它指向的是 demonstration correlation：
策略可能把任务进度、视觉状态与机器人所处动作阶段作为联合模式学习；当这些因素被
解耦时，模型缺少一个显式、可校准的机制来重新判断 execution necessity。

### 6.4 Introduction 的逻辑链

建议用五段结构：

1. **能力背景**：VLA 已经能够根据视觉与语言生成复杂机器人动作 `[CITE]`。
2. **被忽略的问题**：任务成功通常只评价“能否完成”，较少评价“当前是否还应行动、
   哪些指令成分已经无需执行” `[CITE]`。
3. **现实需求**：在人机协作、任务交接和环境外部变化中，task progress 与 robot phase
   会脱离 demonstrations 中的相关性；错误行动可能重复或破坏已完成工作。
4. **经验发现**：OpenVLA-OFT 在自然中间状态上 8/8 正确继续，但在两个正常能力均为
   5/5 的任务上，counterfactual recombination 使成功率降到 1/10，并呈现旧位置重放和
   transition failure 两种机制。
5. **研究问题**：提出 execution necessity：模型应从当前状态判断每个子目标是
   `EXECUTE`、`SKIP` 还是整体 `STOP`，同时避免 false stop。

这里第 1、2 段需要在写论文时补正式文献；第 4 段是本项目自己的证据，不能用文献替代。

---

## 7. 可直接改写成 Introduction 的中文初稿

近年来，Vision-Language-Action 模型在语言条件下的机器人操作能力取得了显著进展，
能够将视觉观测和自然语言指令直接映射为连续控制动作 `[CITE]`。然而，现有研究主要
关注机器人能否完成给定任务，较少讨论一个更基础的问题：在当前场景中，机器人是否
仍然有必要行动？当一条复合指令中的部分目标已经满足时，可靠的智能体不仅需要知道
如何执行剩余步骤，还必须知道何时跳过已经完成的步骤，以及何时完全停止。

这一能力在开放环境中尤其重要。任务进度并不总是由当前机器人沿训练轨迹产生：人类、
其他机器人或环境变化都可能提前完成部分目标，机器人也可能从交接、恢复或异常状态中
重新接管任务。在这些情况下，无条件重放完整指令可能造成重复操作、扰动已完成的场景、
增加执行成本，甚至引入安全风险。我们将这种在动作生成之前判断“哪些动作仍有必要”
的能力称为 **execution necessity reasoning**。

我们的初步实验表明，execution necessity 并不能简单归结为“模型不会跳过已完成目标”。
在 OpenVLA-OFT 和 LIBERO 上，当中间状态来自模型自己的自然成功轨迹时，8 个有效样本
全部正确跳过已完成子目标并完成剩余任务；然而，当我们保持相同任务目标、重新组合
已完成的任务进度与不同 robot phase 时，两个在正常条件下均达到 5/5 成功的多阶段任务，
总体成功率降至 1/10。进一步的行为分析显示，一类失败会回到已完成对象的 canonical
旧位置重放动作，另一类失败则既不重复旧目标，也无法切换到剩余目标。

这些结果说明，当前策略能够在 demonstrations 所覆盖的自然状态联合分布上继续执行，
却不一定能在 task progress 与 robot phase 解耦时重新判断行动必要性。因此，VLA 的可靠性
不仅取决于动作生成能力，也取决于能否从当前状态区分应该执行、应该跳过和应该停止。
这构成了 “Learning Not to Act” 的核心问题。

---

## 8. 推荐的英文定位句

可以作为 abstract/introduction 的核心句，但 Plan 2 完成前不要写成最终贡献：

> We study execution necessity in vision-language-action models: the ability to
> decide, from the current state, which parts of an instruction still require
> execution, which should be skipped, and when no further action is needed.

Plan 1 当前最稳妥的 empirical claim 是：

> OpenVLA-OFT continued reliably from naturally occurring intermediate states,
> yet failed under counterfactual recombinations of task progress and robot phase,
> despite strong performance from standard initial states.

---

## 9. Plan 1 的局限

- 只有一个 OpenVLA-OFT checkpoint；
- 决定性的 intermediate 结果只有两个任务族；
- 每任务正式 paired seeds 较少；
- natural 与 edited 条件的 robot/environment 分量尚未正交拆开；
- terminal replay 只有 8 个有效状态；
- 当前没有训练或验证任何 necessity gate；
- 尚不能声称跨模型、跨 benchmark 或真机泛化。

这些不是需要隐藏的缺陷，而是 Plan 2 的实验设计来源。

---

## 10. Plan 2 为什么是自然下一步

Plan 1 已经把问题从“有没有现象”推进到“失败与哪类状态分布有关”，但还不能回答：

- 决定因素是 robot phase、environment configuration，还是二者 interaction？
- 如果直接告诉模型 remaining goal，它能否执行成功？
- 缺口是 goal representation、completion estimation，还是 pose recovery？
- state-only gate 能否修复失败，同时不在正常任务上产生 false stop？

因此 Plan 2 的顺序必须是：

```text
matched intervention 因子分解
→ non-oracle prompt 与 oracle remaining-goal 强基线
→ 只有在证据支持时才训练 satisfaction probe + router
→ 同时评估 recovery 与 false stop
```

这条路线保留 “Learning Not to Act” 的核心思想，同时允许实验否定某一种方法解释，
避免为了维持最初故事而强行训练一个并不对症的 gate。

---

## 11. 证据索引

- Plan 1 正式计划：`plan/plan1.md`
- 完整技术总结：`execute_logs/plan1/summary.md`
- Intermediate 实验报告：`execute_logs/plan1/04_intermediate_pilot.md`
- Natural control 审查：`execute_logs/plan1/mentor_review_13.md`
- Plan 1 收尾与 Plan 2 设计裁决：`execute_logs/plan1/mentor_review_14.md`
- Plan 2 启动裁决：`execute_logs/plan1/mentor_review_15.md`
- Plan 2 Codex 定稿：`plan/plan2.md`

Plan 1 至此关闭。后续若 Plan 2 改变因果解释，应更新论文叙事，但不回写或删除
Plan 1 的原始日志与结果。
