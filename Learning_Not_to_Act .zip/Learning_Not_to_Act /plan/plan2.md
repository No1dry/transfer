# Plan 2（Codex 定稿版 v3）：Counterfactual 状态重组下的执行必要性重判

> 项目：Learning Not to Act / Execution Necessity for VLA
> 计划编号：plan2（v3；DeepSeek 起草 v1/v2，Codex 按 mentor_review_14/15 最终定稿）
> 决策者 / 导师：Codex
> 执行者：DeepSeek
> 远端工作目录：`/HUBU-AI004/zp/ICML/`
> 本地工作目录：`/Users/zhangpeng/Desktop/Learning_Not_to_Act `
> 状态：**正式计划；已批准 P2.0 与 P2.1 construction smoke**
>
> 当前授权边界：可执行 P2.0，以及 P2.1 中固定的 4 条 generation、12 个状态构造、
> 12 条 20-step no-op 和 2 条 anchor sanity。**不得**启动 P2.2 full、强基线或 probe。
>
> v1 → v2 变更索引（review14 条目 → 本文件章节）：
> - §3.1 → **§5.1–§5.6**：因子改为可观察分量 + state-index 白名单 + donor 规则 + paired contrast
> - §3.2 → **§0.4 / §5.10**：删除"已拆开三个混淆"的声称；旧位置锁定降为机制诊断
> - §3.3 → **§6.1–§6.4**：B0/B1/B2/B2b 重定义；B3 加 mask control 后降级
> - §3.4 → **§7.1–§7.3**：gate 接口 = 二分类 satisfaction probe + 确定性 router
> - §3.5 → **§4.3–§4.5**：valid_unsatisfied_set、gate false-stop 与 policy non-progress
>   分离、offline/online benchmark 分离、state 去重
> - §3.6 → **§4.5 / §5.7 / §8.3**：两套分母、逐任务报数、TERM stop-rate
>
> v2 → v3（Codex 定稿）：修正 smoke seed、O/R/time 组装、difference-in-differences、
> 20/150-step no-op 口径、基线成功阈值、逐任务 preservation 阈值与重复 rollout 预算。

---

## 0. 出发点

### 0.1 Plan 1 已确认的事实（不再重复争论）

| 事实 | 数据 |
|---|---|
| 自然终态后模型仍持续动作，且不是安全撤离 | Stage 2 smoke：8/8 仍动，`safe_retreat 0/8`，`path/max` 中位 3.94 |
| 历史 satisfied 批次物体位移 τ≥5cm | **0/80** |
| 自然轨迹中间状态 | `natural_v2`：8 eligible，**8/8 正确跳过 + 成功，0/8 重做** |
| scene-edited 中间状态 | `pilot_full` B：I1 **1/5**（5/5 朝旧位置重放）、I2 **0/5** |
| I1 的旧位置指向是可测的 | 到旧位置 min 中位 **0.031 m**；当前位置 0/5 进入 5cm |
| I2 不是"重做"而是"不切换" | 0/5 重做 button、0/5 推进 moka、0/5 合爪 |

### 0.2 主张边界（mentor_review_13 §4 + mentor_review_14 §2）

```text
不支持：OpenVLA-OFT generally cannot infer that a completed subgoal should be skipped.
支持  ：两类"subgoal-1 已满足、subgoal-2 未满足"的状态分布上结果相反；
        失败与 scene-edited 那一类状态分布绑定。
```

论文问题必须表述为：

```text
Can a VLA re-decide execution necessity from the current state when task progress
and robot phase are decoupled from the demonstration distribution?
```

"Learning Not to Act" 仍可作总标题，但**现阶段不得**把贡献预设成"VLA 不会停 / 不会跳过"。

### 0.3 术语纪律（mentor_review_14 §1.1，本计划强制）

```text
❌ "同一中间状态、只差状态是外部构造还是自然产生"
   —— 不成立。两组当前状态并不相同；对无历史策略而言 provenance 不可观察，
      不可能是因果变量。
✅ "同一任务、同一指令、同一 checkpoint，在两类状态分布上出现相反结果；
    两类状态同时在 robot pose、task-object configuration 及其联合关系上不同，
    因此尚不能归因给单一因素。"
```

**本计划中所有因子必须用当前状态的可观察分量命名**，
不得用"自然产生 / 外部构造"这类 provenance 词命名因子。

### 0.4 Plan 1 没有识别出的东西（本计划要识别的）

Plan 1 的 EXO 与 NAT 两类状态同时变了三件事：

1. **robot phase / pose**；
2. **task/environment configuration**；
3. **二者的联合关系（interaction）**。

Plan 1 **没有正交操纵**，所以因果因子未识别。
本计划最多能分解这三项；**"旧位置参考"没有被作为独立因子操纵**
（见 §5.10），因此**不得**声称把三个混淆都拆开了。

---

## 1. 要回答的问题

### Q1（因子）

> 在**固定 task/environment configuration**、只换 **robot phase**，
> 或**固定 robot phase**、只换 **task/environment configuration** 时，
> 行为如何变化？二者是否有 interaction？

### Q2（强基线能否解决）

> 通用 prompt scaffolding（B1）或 oracle remaining-goal prompt（B2）
> 能否解决？B1 保留全部子目标且不使用 predicate；B2 使用 predicate oracle
> 只保留 remaining goal，二者必须在完全相同的状态上配对比较。

### Q3（决策接口）

> 一个 **state-only** 的 satisfaction probe + 确定性 router
> 能否在修好失败格子的同时**不引入 false stop**？

### Q4（机制）

> I1 的"旧位置指向"是不是一个可独立验证的机制？（作为诊断，见 §5.10）

---

## 2. 范围

### 必须完成

1. 修正 Plan 1 遗留的文字口径与 **engagement 度量缺陷**；
2. 建立**去重**后的 offline decision benchmark 与 online routed-rollout benchmark；
3. 运行**可观察分量**的 2×3 matched intervention（含 P2.1 1-seed smoke）；
4. 运行强基线 `B0/B1/B2`（`B2b`、`B3` 按条件）；
5. 仅在 **B2 成功、B1 失败** 时才实现 satisfaction probe + router；
6. 完成 offline decision + online rollout + preservation 三层评估；
7. 产出日志、原始记录、**视频**、统计报告与结论边界。

### 明确不做

- 不引入 Memory（任何跨 episode 历史）；
- 不微调 / 不重训 OpenVLA-OFT 主体；
- 不把三分类 ENA head 作为 Plan 2 交付物；
- 不扩展到真机；不修改 `results/plan1/`、`results/m1/`；
- 不删除历史日志、视频或失败产物；
- 不因结果不支持假设而调整阈值、seed 集或判据。

---

## 3. 目录、可观察性规则、安全规则

```text
execute_logs/plan2/
├── 00_freeze.md            冻结 + 文字口径修正记录
├── 01_measure_fix.md       engagement 度量修正 + 回归测试
├── 02_benchmark.md         Mini-PAB-D/offline + /online 定义与去重
├── 03_factorial.md         P2.1 smoke + P2.2 full
├── 04_baselines.md         B0/B1/B2/B2b/B3
├── 05_gate.md              probe + router（仅当触发）
├── 06_preservation.md      false-stop / continuation / TERM
├── decisions.md  blockers.md  artifacts_manifest.md  execution.log  summary.md
```

远端：`results/plan2/{freeze,measure_fix,benchmark,factorial,baselines,gate,preservation}/`
（**禁止写入 `results/plan1/`**；每个 rollout 默认存 trace + video）。

### 3.1 可观察性规则（贯穿全计划）

推理侧**只允许**使用部署时可得的输入：

```text
允许：与 policy 相同的 observation（agentview RGB、wrist RGB、proprio 8 维）+ 语言
禁止：simulator 的自由物体 qpos、predicate 真值、provenance 字段、
      超出 proprio 的关节角、任何未来信息
```

**构造侧**（离线造状态、造标签）可以用 simulator —— 但必须写清哪一步用了，
并且**不得把这些量接进推理路径**。只有 dataset ingestion / validation guard
可以验证 provenance；satisfaction gate 的推理路径不得读取 provenance。

### 3.2 安全规则（沿用 Plan 1 §5，加两条）

1. 运行前 `nvidia-smi` + `ps` 确认无他人作业；
2. 同一时间只跑一个 EGL / LIBERO 主作业；长作业 `setsid + nohup`；run_name 全新；
3. 改核心代码前记录 SHA256；先本地 `pytest` 再同步远端；
4. smoke 失败不得直接启动 full；
5. **新增**：任何在线派生量必须能从 trace 离线复算；
6. **新增**：每个 rollout 默认存视频；若某分支不渲染，必须在
   `artifacts_manifest.md` 写明缺哪个分支、为什么。

---

## 4. P2.0：冻结、度量修正、去重后的 benchmark（离线，不占 GPU）

### 4.1 冻结

记录 `results/plan1/` 全部哈希与计数（收尾实测：**411** 文件 / 38 MB，
`intermediate/` **283**）。**只读**。

准备性 state-index 核对已完成；将 `scripts/plan2_state_index_map.py` 与远端
`results/plan2/state_index_map.json` 登记进 Plan 2 manifest 并记录 hash。

### 4.2 engagement 度量修正

Plan 1 的 `approach_*` 基于**穿越**（outside→inside）。目标在 step 0 已在区内时
判据退化为 `no_approach`（I2 natural restart：step0 = 0.068–0.089 m，
4/4 成功却被标 `no_approach`）。

```text
engaged(object, τ) :=
    crossing_step(τ) is not None
 or (inside_at_step0(τ) and (gripper_close_transition_near(object)
                             or target_contact_onset
                             or object_max_displacement > 0.01 m
                             or subgoal_specific_joint_progress > tolerance))
engagement_mode ∈ {crossing, already_inside_then_acted, none}
```

若 step 0 已经闭爪、后续只是保持闭爪，不算 `acted`；关节进展必须属于当前
被判断的子目标，不能用无关 task joint 的变化替代。policy/no-op 的 matched diff
作为额外守卫，防止把被动物理漂移误判为 engagement。

要求：对 Plan 1 的 60 条 trace（`pilot_full` 40 + `natural_v2` 20）离线重算，
**逐条列出改变的标签**；I2 natural 作为回归用例；主判据仍是 10cm 档，
5/10/15cm 三档同时报。

### 4.3 `valid_unsatisfied_set`：放宽"正确决策"的定义（§3.5）

```text
correct first target := first engaged target ∈ valid_unsatisfied_set
reexecution          := first/any engaged target ∈ satisfied_set
STOP correct         := valid_unsatisfied_set is empty
```

`valid_unsatisfied_set` 的确定规则（**必须在跑之前按任务写死并留档**）：

- 默认：所有未满足子目标都合法（**order-free conjunction**）；
- 只有当**语言本身**含显式顺序（如 "… before …" / "… then …" /
  "… after …"）或存在显式 dependency graph 时，才收缩该集合；
- **禁止**用 BDDL predicate 的文件顺序代替语言语义。

对本计划两任务的预注册判定：

| task | goal | 语言是否含显式顺序 | `valid_unsatisfied_set` |
|---|---|---|---|
| I1 | `in(soup, basket) ∧ in(tomato, basket)` | 否（"put both A and B"） | 两个子目标**都合法**（order-free） |
| I2 | `turnon(stove) ∧ on(moka, stove_region)` | 否（"turn on the stove and put the moka pot on it"，"and" 非顺序词） | 两个子目标**都合法**（order-free） |

由 `on` 谓词本身不要求 `turnon` 先发生，因此 I2 按 **order-free** 处理；
demonstration-prior 的先后只作为**描述性统计**报告，不作为正确性判据。

> **为什么这个放宽不削弱 Plan 1 的结论**：I1 的 B 条件失败是
> `engaged target ∈ satisfied_set`（重做已完成对象），
> I2 的 B 条件失败是**两个合法目标都没被 engagement**。
> 两者在更宽松的定义下**依然**是失败。

### 4.4 两个 benchmark，不能混用（§3.5）

```text
Mini-PAB-D/offline  decision benchmark
  输入：Plan 1 已有 trace + 状态
  测的：原策略在既有 rollout 上的决策正确性（可离线复算）
  不能：替代新 gate 的在线表现

Mini-PAB-D/online   routed-rollout benchmark
  输入：新跑的 rollout（gate + router + policy 闭环）
  测的：决策正确性 + 整体 SR + false stop + 保持性
```

`Mini-PAB-D/offline` 的家族（**去重后**）：

| family | 状态来源 | n（唯一状态） | 正确决策 |
|---|---|---:|---|
| `NORM` | `pairs_v2/states/*__A.npy` | **10**（2 task × 5 seed） | ADVANCE 全程 |
| `EXO` | `pilot_full` B 状态 | 10 | 跳过 satisfied，ADVANCE remaining |
| `NAT` | `natural_v2` 捕获状态 | 10（含 2 例 ineligible） | 同上 |
| `TERM` | `terminal_replay_v3` | 8 | STOP |

### 4.5 去重与两处 provenance 发现（§3.5，已只读核对）

**(a) `capability/` 不是状态集合，且与 `pairs_v2 A` 不是同一批状态。**

- `capability/` 只写 `capability.json` + traces + videos，**没有 `np.save` 状态**，
  因此它**不能**作为 `NORM` 的状态来源；
- 它的 rollout 起点也不同于 `pairs_v2 A`：
  `LiberoArena.reset()` **内部已经做了 10 步官方 dummy**
  （`num_steps_wait_inside_reset = 10`，本轮只读核对确认），
  而 `plan1_stage4_capability.py` 在 reset 之后**又**跑了 10 步
  `arena.no_op_action()`（= 同一个官方 dummy action）→ **共 20 步**。
  即 capability 是一个"double wait"起点（比官方语义晚 10 步）。
- 因此：`NORM` 的 n = **10**（只用 `pairs_v2 A`），
  **禁止**写成 `10 + 10 = 20`；`capability/` 只作为能力门槛证据、
  并在文档中标注其起点与官方语义相差 10 步 dummy。
- `plan1_stage4_pilot.py` 与 `plan1_natural_intermediate.py` **没有**这个问题
  （前者用 `set_state` 加载 A/B，后者 reset 后直接进 policy），已核对。

**(b) 两套分母，预注册**（§3.6）：

```text
denominator-1  attempted      固定 5 seeds/task，不替换失败 seed
denominator-2  paired-eligible  同一 seed 满足：
                 (i) 捕获到 sg1=True、sg2=False 的稳定帧，且该自然轨迹
                     在官方总预算 520 步内 overall success；
                 (ii) 六格构造全部通过白名单与 predicate 检查；
                 (iii) 每格 no-op 稳定窗口标签不变
               只有 paired-eligible 的 seed 进入主 paired contrast
```

`R_donor` 的来源轨迹也必须满足同一 official-budget success 条件。

**不得**把不同 eligibility 的格子直接平均后归因。

### 4.6 P2.0 验收

`Mini-PAB-D/offline` 不跑仿真即可从 `results/plan1/` trace 复现 Plan 1 的全部结论
（数值一致，或有明确 diff 说明）。修正后的 engagement 标签改变必须逐条列出。

---

## 5. P2.1 / P2.2：可观察分量的 2×3 matched intervention

### 5.1 因子定义（§3.1）

```text
因子 O：task/environment configuration（非机器人状态分量）
   O_nat  = 自然 capture 的非机器人状态分量
   O_edit = predicate-valid 的编辑状态分量

因子 R：robot phase/pose（机器人状态分量）
   R_cap   = 本 seed 自然 capture 时的机器人状态
   R_donor = 另一条成功轨迹在**相同 predicate transition 附近**的机器人状态
   R_init  = 官方初始机器人状态（官方 init + 10 步 dummy 之后）
```

逐分量组装规则（不可省略）：

```text
O_nat   = natural capture 的全部非机器人 qpos + 非机器人 qvel
O_edit  = 同 seed 的 pairs_v2 B 的全部非机器人 qpos + 非机器人 qvel
R_cap   = base natural capture 的全部机器人 qpos + 机器人 qvel
R_donor = donor natural capture 的全部机器人 qpos + 机器人 qvel
R_init  = 同 seed 的 pairs_v2 A/B 的全部机器人 qpos + 机器人 qvel
time    = 六格统一设为 0.0，不作为实验因子
act     = 当前两任务 na=0；未来若 na>0，必须先定义归属并暂停审核
```

构造后必须满足：`O_edit/R_init` 除统一后的 time 外逐位复现 `pairs_v2 B`；
`O_nat/R_cap` 除统一后的 time 外逐位复现 natural capture。

六个格子**只能按分量名命名**：

| # | 格子 | 含义 | 与 Plan 1 的关系 |
|---|---|---|---|
| 1 | `O_nat/R_cap` | 全部同源 | `natural_v2`（**锚点**） |
| 2 | `O_nat/R_init` | 物体配置自然、机器人回到初始 | 新 |
| 3 | `O_nat/R_donor` | 物体配置自然、机器人用 donor 状态 | 新 |
| 4 | `O_edit/R_cap` | 物体配置被编辑、机器人用本 seed capture 状态 | 新 |
| 5 | `O_edit/R_init` | 全部不同源 | `pilot_full` B（**锚点**） |
| 6 | `O_edit/R_donor` | 物体配置被编辑、机器人用 donor 状态 | 新 |

**措辞禁令**：不得把 `O_edit/R_cap` 写成 "same-traj" 或 "位姿匹配" ——
`O_edit` 没有一条产生它的自然轨迹；`R_cap` 只是"本 seed 捕获时刻的机器人状态"
这一**分量标签**，不是一致性结论。

### 5.2 state-index 白名单（已实测，只读核对）

flattened state 布局：`[time(1) | qpos(nq) | qvel(nv) | act(na)]`。
只读脚本 `scripts/plan2_state_index_map.py` 输出 `results/plan2/state_index_map.json`。

**I1** `LIVING_ROOM_SCENE2_...basket`（nq=65, nv=57, total=123）：

| 角色 | 关节 | flat qpos 下标 |
|---|---|---|
| **R** | `robot0_joint1..7` | `1..7` |
| **R** | `gripper0_finger_joint1/2` | `8, 9` |
| O（completed） | `alphabet_soup_1_joint0` | `10..16`（xyz 10–12, quat 13–16） |
| O（remaining） | `tomato_sauce_1_joint0` | `24..30` |
| O（container） | `basket_1_joint0` | `59..65` |
| O（非任务物体） | cream_cheese / ketchup / orange_juice / milk / butter | `17..23, 31..58` |

**I2** `KITCHEN_SCENE3_...moka_pot_on_it`（nq=24, nv=22, total=47）：

| 角色 | 关节 | flat qpos 下标 |
|---|---|---|
| **R** | `robot0_joint1..7` | `1..7` |
| **R** | `gripper0_finger_joint1/2` | `8, 9` |
| O（completed） | `flat_stove_1_button`（hinge, 1 维） | `24` |
| O（remaining） | `moka_pot_1_joint0` | `17..23` |
| O（非任务物体） | `chefmate_8_frypan_1_joint0` | `10..16` |
| O（container） | `flat_stove_1` **无自由关节**（固定 fixture） | — |

**预注册白名单**：

```text
R 可写集合 = {1..9}                     （两任务相同：robot0_joint1..7 + 两指）
O 可写集合 = qpos 段中除 {1..9} 之外的全部下标
             I1: {10..65}   I2: {10..24}
任务相关报告子集（用于机制诊断，不是额外的写入禁令）：
  I1: completed {10..16} ∪ remaining {24..30} ∪ container {59..65}
  I2: completed {24}     ∪ remaining {17..23}
未列出的下标在构造后必须逐位等于基准状态（`unexpected_indices = []`）
```

O 的组装允许全部非机器人分量随 `O_nat/O_edit` 来源变化；不得只复制任务相关子集
而留下来源混杂。qvel 段同理：R 的 dof 下标与 O 的 dof 下标分别登记
（脚本已输出 `flat_qvel_indices`）。
构造后必须同时校验 **qpos 与 qvel** 的"未列出即不变"。

### 5.3 donor 选择规则（**跑之前写死**）

```text
donor(s) = (s + 1) mod 5
若 donor 未在官方 520 步预算内 overall success / 无合法 capture 帧 /
predicate 不成立 → (s + 2) mod 5
若仍无 → 该 seed 的 R_donor 两格标记 ineligible（不替换 seed，不补跑）
donor 的机器人状态定义：donor rollout 中 subgoal-1 首次满足且稳定窗口通过的那一帧
seed → donor 映射表在构造后立即落盘，禁止事后调整
```

### 5.4 congruence 用**连续量描述**，不用标签宣布（§3.1）

每格在 step 0 记录（全部可由 trace 离线复算）：

```text
d_eef_completed       EEF 到 completed 实体位置的距离
d_eef_remaining       EEF 到 remaining 实体位置的距离
gripper_open_frac     夹爪开度（归一化）
contact_flags         与 completed / remaining / container 的接触标志
noop_label_stability  P2.1 用 20 步、P2.2 用 150 步；窗口内 predicate 是否恒定
||R - R_cap||_1       与 R_cap 的关节空间距离（数值，不是标签）
||R - R_init||_1      与 R_init 的关节空间距离
||O - O_nat||_1       与 O_nat 的物体配置距离
```

**禁止**把 `R_donor` 或 `R_init` 直接宣布为"不一致/不匹配" ——
要报告上面的数，让读者看到距离有多远。

### 5.5 主分析 = 同 seed paired contrast（§3.1）

在 **paired-eligible** 的 seed 上，按下列对比给出逐 seed 差值与汇总：

```text
C1  robot phase 效应    : O_nat/R_init   vs O_nat/R_cap
C2  env config 效应     : O_edit/R_cap   vs O_nat/R_cap
C3  interaction（对任一指标 Y）:
      ΔR(O_nat)  = Y(O_nat,R_init) - Y(O_nat,R_cap)
      ΔR(O_edit) = Y(O_edit,R_init) - Y(O_edit,R_cap)
      Interaction = ΔR(O_edit) - ΔR(O_nat)
      二值 SR 同样报告逐 seed paired outcome
C4  exact-pair dependence / phase transfer:
                          O_nat/R_donor 落在哪一侧 ——
                          若 ≈ O_nat/R_cap  ≫ O_nat/R_init  → 只要"处于正确 task phase"
                          若 ≈ O_nat/R_init                        → 需要"逐位同源配对"
```

主指标：`SR`、`reexecution_rate`、`first_engaged_subgoal 的合法/非法归属`、
`steps_to_first_progress`、`d_eef_*`。

### 5.6 预注册的是**对比方向**，不是全成/全败模式（§3.1）

```text
D1  若 robot phase 是主导：C1 使 SR 方向性下降，或 reexecution / policy non-progress /
                           steps_to_progress 明显恶化；
                           C2 影响小；O_edit/R_cap 接近 O_nat/R_cap
D2  若 env config 是主导：C2 使 SR 方向性下降；C1 影响小；
                           O_nat/R_init 接近 O_nat/R_cap
D3  若 interaction 主导 ：单因子移动都不足以复现，
                           O_edit/R_init 明显差于两种单因子移动
D4  若两者都不影响      ：六格无差异 → 失败来自别的东西（先查构造与度量）
```

**不再预注册** v1 中的 H-pose / H-exo / H-both / H-neither 精确成功格局 ——
n 小，且 `R_donor` 未必真的不一致，不能用预设的全成/全败模式硬分类。
这里的“影响/恶化”只按精确计数、paired direction 与描述性区间报告，
不使用“统计显著”措辞。
**执行者先验（仅供裁决参考）**：偏 D1 或 D3，理由是 I2 在 B 下
**根本没有回头看已完成对象**（0/5 重做）却依然 0/5 推进 remaining。
该先验**不构成结论**，也不得影响判据。

### 5.7 规模与分母（§3.6）

```text
P2.1 smoke : 4 generations（I1 s1/s2，I2 s0/s1；base + donor）
             + 12 hybrid-state constructions
             + 12 no-op（20 步构造稳定窗口）
             + 2 policy anchor sanity（每任务仅 O_nat/R_cap 一条）
P2.2 full  : 2 tasks × 5 seeds × 6 cells = 60 policy restarts
             + 60 no-op（150 步正式稳定窗口）
             + 10 generations（取 O_nat / R_cap / R_donor）
```

- 分母-1 `attempted` = 5 seeds/task（不替换）；
- 分母-2 `paired-eligible` = 六格 + no-op 全通过的 seed 子集；
- 两套分母都要逐任务、逐格子报**精确分子/分母**；
- **Plan 1 可复用锚点**：`O_edit/R_init` **10 条**（`pilot_full` B）与
  `O_nat/R_cap` **8 条 eligible**（`natural_v2`），
  **不是 12 条**；且因 provenance/schema 不同，
  旧数据**只作锚点**，**不得**并进新矩阵的 paired contrast。

**GPU 时间估算**（口径 = **总 env step 数 × ≈0.5 s/step**，
由 Plan 1 实测标定：`natural_v2` = 10 generations + 10 restarts = 28.7 min；
`pilot_full` = 20 policy + 20 no-op = 105.8 min；
`capability` = 10 policy = 18.5 min。渲染 ~0.35 s/step，
policy 前向每 8 步一次，故 policy rollout 单步略贵于 no-op）：

| 阶段 | 规模 | 估算 |
|---|---|---|
| P2.1 smoke | 4 gen + 2 anchor policy + 12 no-op(20 步) | **20–45 min** |
| P2.2 full | 10 gen + 60 policy + 60 no-op(150 步) | **3–4 h** |
| P2.3 baselines | 20–40 个 B1/B2 target rollouts；B0 复用 P2.2；另做所需 preservation | **1.5–3 h** |
| P2.4 gate | ≤500 帧特征抽取 + CPU probe | **10–30 min** |
| P2.5 gate online / preservation | 约 36–46 policy（不含可选新任务） | **1–2 h** |
| **合计** | | **约 6–10 h GPU（±50%，后续阶段按暂停点重估）** |

> P2.1 的 20-step no-op 只用于 construction smoke；P2.2 的正式 no-op 统一用
> 150 步（不是整个官方预算）。150 步的依据是 Plan 1 的 no-op 对照在整段
> 窗口内事件恒为 0、标签恒定；若 20-step smoke 出现漂移，禁止进入 P2.2。

### 5.8 P2.1 1-seed smoke 构造表（**只验构造，不做科学判读**）

| # | 格子 | O 的来源 | R 的来源 | 期望 predicate | 主要检查 |
|---|---|---|---|---|---|
| 1 | `O_nat/R_cap` | I1 s1 / I2 s0 自然 capture | 同一 base capture 的 R qpos+qvel | sg1=T, sg2=F, overall=F | 与 natural capture 逐位复现（time 除外） |
| 2 | `O_nat/R_init` | 同上 | 同 seed `pairs_v2 A` 的 R qpos+qvel | sg1=T, sg2=F | 只换 R source：`unexpected_indices=[]` |
| 3 | `O_nat/R_donor` | 同上 | I1 s2 / I2 s1 capture 的 R qpos+qvel | sg1=T, sg2=F | 只换 R source；记录 `‖R−R_cap‖` |
| 4 | `O_edit/R_cap` | 同 seed `pairs_v2 B` 的全部 O qpos+qvel | base capture 的 R qpos+qvel | sg1=T, sg2=F | 只换 O source；记录 `‖O−O_nat‖` |
| 5 | `O_edit/R_init` | 同上 | 同 seed `pairs_v2 A` 的 R qpos+qvel | sg1=T, sg2=F | 逐位复现 `pairs_v2 B`（time 除外） |
| 6 | `O_edit/R_donor` | 同上 | I1 s2 / I2 s1 capture 的 R qpos+qvel | sg1=T, sg2=F | 只换 R source |

每个格子额外检查：

```text
- 逐维 diff 白名单：unexpected_indices = []（qpos 与 qvel 都查）
- 机器人前 9 关节在"同 R 水平"的格子之间逐位一致
- set_state 后 observation 必须 refresh（Plan 1 stale-observation 守卫）
- time 六格统一为 0.0；qpos/qvel 的 O/R 分量哈希与来源一致
- no-op 构造稳定窗口（20 步）内 sg1/sg2/overall 标签不变
- restart 前 policy.reset()；并在动作之前 emit step 0
- 每格存 state.npy + png + no-op trace/video；只对两条 `O_nat/R_cap` anchor
  运行 policy sanity 并保存 trace/video
```

base 固定为 **I1 seed1、I2 seed0**；donor 固定为 **I1 seed2、I2 seed1**。
四条 generation 都必须在官方预算内 overall success，否则保留失败并暂停。
两任务各构造 6 格，共 12 格；两条 policy sanity 不作科学比较。
P2.1 结束后**停下汇报**，只报构造是否合法，不解释行为差异。

### 5.9 P2.2 验收

- 固定尝试六格 × 2 task × 5 seed；每个 case 都有合法状态或明确失败记录；
- 不替换失败 seed；主分析只纳入六格、predicate 与正式 no-op 均通过的
  paired-eligible seed；
- 逐任务、逐格子两套分母齐全；no-op 对照干净；
- 因子标签**能从 provenance 离线复算**（dataset validation guard 验 provenance，
  satisfaction gate 不读取 provenance）；
- 每格有 policy 与 no-op 的 trace + video。

### 5.10 "旧位置锁定"是机制诊断，不是主因子（§3.2）

```text
主 2×3 只分解：robot phase / env configuration / interaction
旧位置参考没有被作为独立因子操纵 → 不得声称已拆开
```

因此：

- I1 的"到 canonical/original location 的距离"作为**机制诊断量**继续报告
  （字段名沿用 `d_eef_completed_A_orig`），但**不进主因子命名**；
- 若要做**因果验证**，另设一个**独立的小型 location-sweep**：
  在固定 `R` 与其余 O 分量的前提下，只改变 completed object 的
  可行终点 / canonical 起点（例如扫 3 个合法终点），
  看旧位置指向是否随之移动。该 sweep **不属于**主 2×3，
  是否执行由 Codex 决定（默认：暂不做）。

---

## 6. P2.3：强基线（training-free）

### 6.1 定义（§3.3，修正 v1 的 B1≡B2 问题）

v1 的 B1 与 B2 在 I1/I2 的测试状态上**第一次下给 VLA 的文本相同**
（都只剩一个子目标），因此不可能区分。现在改为：

| baseline | 用 predicate oracle？ | 定义 |
|---|---|---|
| `B0` original | 否 | 原始**完整**指令，清 action queue（Plan 1 参考行为） |
| `B1` non-oracle structured prompt | **否** | 保留**所有**子目标；加入通用指令："检查当前场景，只执行尚未完成的目标；若全部完成则停止"，并以结构化列表逐条列出子目标 |
| `B2` oracle remaining-goal prompt | **是** | 用 simulator predicate 删除已完成子目标，只把**剩余目标**交给 VLA（执行上界） |
| `B2b` closed-loop oracle router | **是** | 在每个 action-chunk 边界重判：predicate 翻转后重新路由并重编译 prompt；清 queue。**仅在 ≥2 个 remaining goals 时才有额外意义** |
| `B3` completed-object suppression（**可选诊断**） | 否 | 用分割 mask 把已完成物体像素置零/inpaint 后喂 policy |

`B1` 与 `B2` 的差别是**结构化的通用指令 vs 真正删掉已完成目标**；
在只剩一个子目标的状态上，B1 的文本仍然包含全部子目标列表，因此与 B2 不同。

### 6.2 `B3` 的强制对照（§3.3）

v1 的 B3 不能直接证明旧位置锁定：旧位置往往是**空的**，遮掉对象还会制造黑块 OOD，
并可能遮住容器。因此 B3 只能作可选诊断，且必须同时跑：

```text
B3-random   等面积随机 mask（位置随机）
B3-irrelevant 等面积、遮一个非任务物体
```

只有 `B3-completed` 明显优于两个对照，才能说"旧位置锁定"机制被支持。
**B3 不得与 B1/B2 同等级解释。**

### 6.3 判读（写死）

数值定义先于判读：

```text
一个 (task, cell) 进入强基线：paired-eligible n ≥ 4，且 B0 SR ≤ 0.5。

Bx 在该 (task, cell) 通过：
  successes ≥ ceil(0.75 × n)
  AND 相对 B0 至少多成功 2 个 paired seeds。
```

```text
B2 失败            → 即使目标已给对仍无法执行 → 靶子是 re-anchoring / recovery，不是 gate
B2 成功、B1 失败   → 缺口可能在无 oracle 的 completion estimation / routing
                     → 才允许进入 §7 的 satisfaction probe + router
B1 成功            → 通用 prompt scaffolding 已足够
                     → 先把 training-free prompt 方案做扎实，不应急着训练 probe
不同 task/cell 结果混合 → 不做 pooled 强判；暂停，由导师决定按 family 分流或扩任务
```

### 6.4 规模

```text
必做：P2.2 中确定为"失败"的格子（预计 1–2 个）
      × 对应 task × paired-eligible seeds × {B1, B2}
      B0 直接复用 P2.2 的同状态原始 policy rollout，不重复运行
可选：B2b（≥2 remaining 的任务上）、B3 + 两个 mask 对照
守卫：所有基线跑在**与 FACTORIAL 完全相同的状态**上（paired）；
      B1 通过 target 后再跑 `NORM`、`NAT/R_cap` preservation
```

静态 B2 只用于“当前恰好剩一个目标”的 target state。在 NORM 上若要测 overall SR，
必须使用 B2b closed-loop；不得把静态 B2 完成第一个子目标当作完整任务成功。

预计新跑 target baseline **20–40 条**（B1/B2；取决于失败格子数），
另加实际被选中方法的 preservation；每个暂停点重新核算，不把同一 rollout 重复计费。

---

## 7. P2.4：最小 gate —— satisfaction probe + 确定性 router（**条件触发**）

> **触发条件**：只有 §6.3 判定为 **B2 成功、B1 失败** 时才执行本节。
> 若 B2 也失败，靶子改为 re-anchoring；若 B1 成功，先做 training-free 方案。

### 7.1 接口（§3.4，必须闭合）

不再训练三分类 ENA head，而是：

```text
f(deployable observation o_t, one subgoal text s_k) -> p̂_k ∈ [0, 1]

router（确定性，无学习参数）:
  S = { k : p̂_k < θ }
  if S == ∅:            STOP（**不调用 policy**）
  else:                 k* = 预注册的选择规则（若 |S| > 1，按 demonstration-prior
                        顺序；该顺序在 benchmark annotation 中固定）
                        把 s_k* 编译成 remaining-goal prompt
                        policy.reset()（清 action queue）→ 交给 policy
  在每个 action-chunk 边界重新判定；prompt 变化时清 action queue
```

设计约束（不可协商）：

1. **state-only**：推理输入只能是与 policy 相同的 deployable observation +
   子目标文本；**禁止** simulator qpos / predicate 真值 / provenance；
2. **不微调 VLA 主体**：只在**冻结特征**上加轻量模块（线性 / 2 层 MLP）；
3. **每个子目标单独以文本条件化**，以支持可变数量子目标；
4. `subgoal list` 来自**固定 benchmark annotation / 指令分解**，
   推理时**不得**偷用 simulator predicate；
5. 控制器保存"当前 prompt"不等于学习历史；**不得**把过去观测作为模型输入；
6. **阈值只在 validation split 上定，test 上不得调阈值**；
7. **rollout / seed 必须分组切分**：同一轨迹的相邻帧**禁止**分别落入 train/test；
8. 若要声称**跨任务泛化**，必须有 **held-out task/family**。

### 7.2 必须区分的两个概念（§3.5）

```text
gate false-stop     ：仍有未满足目标时，router 错误输出 STOP / 把全部目标判为 satisfied
policy non-progress ：router 给出了合法目标，但底层 VLA 没完成
```

**后者不得计入 gate false-stop**，否则会把底层策略失败归咎于决策器。

### 7.3 训练数据与可行性 gate

**已知事实（本轮只读核对）**：远端**没有** I1/I2 的 LIBERO-10 演示数据 ——
`/HUBU-AI004/zp/libero_cm2/data/libero_cm2/` 只有 3 个**其他任务**的 hdf5，
`libero_10/` 为空。因此"用官方 demonstrations 训练 probe"当前不可行。

P2.4 开始前依次确认（写入 `blockers.md`）：

```text
F1 远端是否已有 libero_10 / libero_goal 演示数据？   （当前：否）
F2 能否下载？（网络 + 磁盘 + 时间）                  （待测）
F3 若 F1/F2 不通：接受"用我们自己的 rollout 状态 + predicate 标签"吗？
```

**默认路线（不依赖外部数据）**：冻结 OpenVLA-OFT 特征 + 轻量二分类 probe。
标签由 simulator predicate 自动生成（构造侧允许，推理侧禁止）。
状态来源：P2.2 的六格状态 + `NORM` 初始状态 + rollout 中间帧（每 k 步一帧）。
预算：200–500 帧 × 1 次前向 ≈ **10–30 min GPU**，probe 训练在 CPU。

**诚实边界（§3.4）**：若训练帧全部来自同两任务、同 seeds、同轨迹，
结果只能声称 **interpolation feasibility**，**不能**作为方法泛化结论。
主 PASS 必须在**held-out seeds**上给出；held-out task/family 作为加分项
（可用 §7.4 的备选任务补足）。
是否下载 demonstrations **不是当前第一优先级** ——
只有 P2.3 表明 gate 是正确靶子后才决定。

### 7.4 备选任务（用于 held-out family，需先过能力门槛）

`libero_10 ∪ libero_goal` 中 goal 谓词 ≥2 的任务共 **9/20**（纯 BDDL 解析）：

```
3 谓词  KITCHEN_SCENE8_put_both_moka_pots_on_the_stove
2 谓词  KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it        (= I2)
2 谓词  LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket (= I1)
2 谓词  LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket
2 谓词  LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket
2 谓词  LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate
2 谓词  LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate
2 谓词  KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it
2 谓词  KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it
```

可用家族："双物体同容器" / "前置条件+放置" / "有序序列"。
**必须先过能力门槛（官方初始状态 SR ≥ 70%）** 才能进入任何分析。

---

## 8. P2.5：评估（offline + online + preservation）

### 8.1 三层评估

```text
L1 offline decision  ：在 Mini-PAB-D/offline 上算决策正确性（可离线复算）
L2 online routed     ：Mini-PAB-D/online —— gate + router + policy 闭环
L3 preservation      ：见 §8.2
```

`L1` 必须报混淆矩阵（含 false stop / false act），`L2` 必须报 SR 与
`policy non-progress`（与 gate false-stop 分开）。

### 8.2 保持性测试组

| 组 | 状态 | 正确行为 | n | 要求 |
|---|---|---|---:|---|
| `NORM-A` | 官方初始（`pairs_v2 A`） | ADVANCE 全程 | 10 | 每任务 ≥4/5，且 pooled ≥9/10 |
| `NAT/R_cap` | `natural_v2` eligible | ADVANCE remaining | 8 | 每任务 ≥3/4，且 pooled ≥7/8 |
| `NORM-new` | 新增任务官方初始 | ADVANCE 全程 | ≥2×5 | 能力门槛 ≥70% 后才用 |
| `TERM` | `terminal_replay_v3` | STOP | 8 | **次级验收**：若方法声称"能 STOP"，预注册 `stop_rate ≥ 7/8`，并同时报 false stop |

附加指标（防止"靠变慢/靠少动"换正确率）：
`steps_to_first_progress`、`eef_path_length` 相对 `B0` 的变化、
`d_eef_completed_A_orig`（旧位置指向强度）。

### 8.3 PASS 条件（pre-registered，逐任务 + pooled + CI）

```text
PASS =  (a) 每个目标 (task,cell) 的 successes ≥ ceil(0.75 × n)，
             且相对 B0 至少多成功 2 个 paired seeds
     AND (b) NORM-A 每任务 ≥ 4/5，且 pooled ≥ 9/10
     AND (c) NAT/R_cap 每任务 ≥ 3/4，且 pooled ≥ 7/8
     AND (d) gate false_stop_rate(NORM-A ∪ NAT/R_cap) ≤ 1/18
     AND (e) 若声称 STOP：TERM stop_rate ≥ 7/8
```

必须同时报告（不因 n 小夸大显著性）：

```text
- 每个 task、每个关键 cell 的精确分子/分母
- 相对 B0 的 paired improvement（逐 seed）
- 二项置信区间（描述性）
- normal-preservation 逐任务报，禁止只用总计掩盖某一任务退化
```

任一条不满足即为 **NOT PASS**；不得通过调阈值、换 seed 或改判据挽救。

---

## 9. 判读与决策树

```text
P2.1 smoke 合法？ ──否──> 修构造；不得进入 P2.2
        │是
P2.2 因子 ──> D1 robot phase / D2 env config / D3 interaction / D4 无差异
        │        （D4 → 暂停，先查构造与度量）
        ↓ （必须暂停汇报）
P2.3 基线 ──> B2 失败        → 靶子 = re-anchoring / recovery（不是 gate）
        │      B2 成功、B1 失败 → 进入 P2.4（gate 是正确靶子）
        │      B1 成功        → 先做 training-free prompt 方案
        │      task/cell 混合  → 暂停；按 family 分流或扩任务，不 pooled 强判
        ↓ （必须暂停汇报）
P2.4 gate（仅条件触发）→ P2.5 三层评估
        ↓
PASS → 讨论是否进入 plan3（history-dependent pair）
NOT PASS → 写清失败模式；不得靠调阈值挽救；是否进 plan3 由 Codex 裁决
```

---

## 10. 必须暂停并汇报的情况

1. 需要修改决策标签、`valid_unsatisfied_set` 规则、10cm 主判据或 eligibility 规则；
2. 需要更换 task / checkpoint / seed 集 / donor 规则；
3. P2.1 构造不合法，或 P2.2 出现 D4（无差异）且排查不清；
4. gate 提高了失败格子的 SR 但**降低了** `NORM-A` / `NAT` 的 SR
   —— false-stop 权衡必须由 Codex 决定；
5. F1/F2 都不通且自生成训练数据超出商定预算；
6. 想引入任何形式的历史 / Memory；
7. 新结果与 Plan 1 方向相反；
8. 预计需要删除、覆盖或重跑正式历史结果；
9. 想用 training-free 方案之外的训练方法（如微调 VLA、三分类 head）。

暂停时按 Plan 1 §12 模板写 `execute_logs/plan2/blockers.md`。

---

## 11. 最终报告必须包含的表格

### 表 1：2×3 因子（逐任务、逐格子，两套分母）

| task | cell | O 来源 | R 来源 | n_attempted | n_paired_elig | SR | reexec | first engaged（合法/非法） | d_eef_completed | d_eef_remaining |
|---|---|---|---|---:|---:|---:|---:|---|---:|---:|

### 表 2：paired contrast

| task | contrast | n_pairs | ΔSR | Δreexec | Δsteps_to_progress | 方向是否与 D1–D4 一致 |
|---|---|---:|---:|---:|---:|---|

### 表 3：强基线

| cell | policy | n | SR | steps_to_progress | 旧位置锁定 min-dist | 判定 |
|---|---|---:|---:|---:|---:|---|

### 表 4：gate 决策混淆矩阵（L1 offline）

| family | n | EXECUTE 正确 | SKIP 正确 | STOP 正确 | gate false stop | false act |
|---|---:|---:|---:|---:|---:|---:|

### 表 5：保持性（L3）

| 组 | task | n | B0 SR | gate SR | Δsteps | Δpath | false_stop_rate |
|---|---|---:|---:|---:|---:|---:|---:|

### 表 6：替代解释决策表（承接 Plan 1 表 6）

| Hypothesis | Supporting | Contradicting | Judgment |
|---|---|---|---|

---

## 12. 提交格式

同 Plan 1 §15，写入 `execute_logs/plan2/summary.md`（12 节，标题不变）。
执行者可提建议，但**不得自行宣布进入 plan3**。

---

## 13. 一句话目标

> 用**可观察分量**的正交操纵（robot phase × environment configuration）
> 把 Plan 1 留下的因果混淆拆开，再用**强基线**判定缺口在目标表示、
> 执行还是不匹配状态下的完成度估计，最后（且仅在前一步支持时才）
> 交付一个 state-only、能 SKIP、**且不产生 false stop** 的最小 gate。

---

## 14. 当前执行授权

```text
已批准：P2.0 全部离线工作；P2.1 的 4 generations、12 state constructions、
        12 × 20-step no-op、2 anchor policy sanity。
必须暂停：P2.1 交付完成后。
未批准：P2.2 full、P2.3 强基线、P2.4 probe、任何 VLA 微调或 Memory。
```

若 P2.0 的离线重算改变 Plan 1 核心计数，或 P2.1 任一固定 seed / state 构造失败，
立即记录并暂停，不得替换 seed。

---

## 附：执行备注

1. **§5.2 的白名单已实测完成**（`scripts/plan2_state_index_map.py`，
   产物 `results/plan2/state_index_map.json`），P2.1 可直接引用，不需要再猜下标。
2. **两处 provenance 发现**（§4.5）：
   `capability/` 没有保存状态、且是 **double wait**（reset 内 10 步 + 循环内 10 步）
   起点 —— 因此它**不能**并入 `NORM`；`pairs_v2 A` 与 `pilot_full`/`natural_v2`
   的起点是正确的官方语义（已核对）。
3. **预算**：当前估算全计划约 **6–10 h GPU**（±50%），每个暂停点按真实
   env steps 重新估算，后续未授权阶段不得提前运行。
   若需缩，建议顺序是
   砍 `B2b`/`B3` → 砍 `NORM-new` → 砍 `R_donor` 两格 → 砍 P2.1 到单任务；
   **`C1`/`C2` 两个对比（即 `O_nat/R_init` 与 `O_edit/R_cap`）不可砍**，
   否则 §5 的因子分解不成立。
4. **v1 的两处工程发现（诚实记录，不改历史产物）**：
   - `plan1_natural_intermediate.py` 每步都采集了 `gen_frames`（generation 帧），
     但结束时被 `cont_frames = []` 覆盖，**从未落盘** —— generation 视频的缺失
     不是"没渲染"，而是"渲染了没写"；下次同类脚本应在 `finally` 前
     `save_video(gen_frames, ...__generation.mp4)`（**不增加渲染成本**）。
     按 review14 §1 无需为 Plan 1 重跑。
   - `plan1_stage4_capability.py` 的 double wait（§4.5）：建议后续脚本统一改为
     "reset 后直接进 policy"，并把 `num_steps_wait` 归属写进 provenance。
