#!/bin/bash
# 串联执行：等 official3 跑完 -> 启动 Mini-PAB 全量 160 episodes。
#
# 为什么要串联：今天实测两个进程同时用 EGL 离屏渲染会互相拖慢到"看起来像卡死"
# （GPU 利用率 0%，两个作业都停在原地）。而本机的 EGL 走的是 Mesa llvmpipe
# 软件光栅化，本来就慢，再争抢就没法看了。
#
# 用法: ./run_chain.sh [Mini-PAB 附加参数]
set -uo pipefail

ROOT=/HUBU-AI004/zp/ICML
cd "$ROOT"

PREV_PID_FILE="$ROOT/logs/official3.pid"
MAX_WAIT_S=5400   # 最多等 90 分钟，防止前一个作业卡死导致永不启动

echo "[chain] 等待 official3 结束（最多 ${MAX_WAIT_S}s）..." >&2
waited=0
while [ -f "$PREV_PID_FILE" ]; do
    prev=$(cat "$PREV_PID_FILE" 2>/dev/null || echo "")
    if [ -z "$prev" ] || ! kill -0 "$prev" 2>/dev/null; then
        echo "[chain] official3 已结束（等待 ${waited}s）" >&2
        break
    fi
    if [ "$waited" -ge "$MAX_WAIT_S" ]; then
        echo "[chain] 等待超时，直接开始 Mini-PAB" >&2
        break
    fi
    sleep 30
    waited=$((waited + 30))
done

echo "[chain] 启动 Mini-PAB 全量运行" >&2
exec "$ROOT/run_full.sh" "$@"
