#!/bin/bash
# 串联：等 unsatisfied 段跑完 -> 续做剩余的 satisfied 段（同一 run 目录，自动跳过已完成）
set -uo pipefail
ROOT=/HUBU-AI004/zp/ICML
cd "$ROOT"

PREV_PID_FILE="$ROOT/logs/minipab_unsat.pid"
MAX_WAIT_S=10800   # 最多等 3 小时

echo "[chain2] 等待 unsatisfied 段结束（最多 ${MAX_WAIT_S}s）..."
waited=0
while [ -f "$PREV_PID_FILE" ]; do
    prev=$(cat "$PREV_PID_FILE" 2>/dev/null || echo "")
    if [ -z "$prev" ] || ! kill -0 "$prev" 2>/dev/null; then
        echo "[chain2] unsatisfied 段已结束（等待 ${waited}s）"
        break
    fi
    if [ "$waited" -ge "$MAX_WAIT_S" ]; then
        echo "[chain2] 等待超时，直接开始 satisfied 段"
        break
    fi
    sleep 30
    waited=$((waited + 30))
done

echo "[chain2] 启动 satisfied 段（跳过已完成的 episode）"
exec "$ROOT/run_full.sh" --run_name final
