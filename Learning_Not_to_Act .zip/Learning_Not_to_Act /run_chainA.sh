#!/bin/bash
# 等对照 B 跑完 -> 自动跑对照 A（终态 satisfied）
set -uo pipefail
ROOT=/HUBU-AI004/zp/ICML
cd "$ROOT"
PREV="$ROOT/logs/ctrlBv3.pid"
echo "[chainA] 等待对照 B 结束..."
waited=0
while [ -f "$PREV" ]; do
    p=$(cat "$PREV" 2>/dev/null || echo "")
    if [ -z "$p" ] || ! kill -0 "$p" 2>/dev/null; then echo "[chainA] 对照 B 已结束（${waited}s）"; break; fi
    if [ "$waited" -ge 3600 ]; then echo "[chainA] 超时，直接开始"; break; fi
    sleep 30; waited=$((waited+30))
done
echo "[chainA] 启动对照 A（终态 satisfied）"
exec "$ROOT/run_diag.sh" scripts/control_a_terminal.py bowl_on_stove 10
