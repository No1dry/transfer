#!/bin/bash
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML
exec "$PY" -u "$@"
