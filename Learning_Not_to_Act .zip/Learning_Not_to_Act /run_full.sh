#!/bin/bash
# Mini-PAB 完整流程：160 episodes + 视频 + 报告
#
# 配置说明：
#   * 7B 模型 bf16 正常加载，不做 8bit/4bit 量化（保持与原论文可比）
#   * num_open_loop_steps=8，与官方 LIBERO eval 一致
#   * max_policy_queries=40 -> 最多 320 env steps，贴合官方 libero_goal 的 300 步上限
#   * 探针按 condition 分开：
#       satisfied   = 300 步。任务在起点就已完成，我们要看"它到底会不会去抓"。
#                     实测量到夹爪开始命令闭合平均要 ~100-112 步，
#                     完整抓取（合爪->抬起）还要再加几十步，所以给 300 步。
#       unsatisfied = 60 步。任务本来就要做，跑到成功即可，
#                     之后只需够判断 GDR。
#     robosuite 在成功瞬间会置 done=True 并拒绝后续 step，
#     所以 arena 侧显式打开 set_allow_after_done(True)。
#   * save_video 录全部 condition：satisfied 看"多余动作"，unsatisfied 作对照
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML

exec "$PY" -u scripts/run_mini_pab.py \
  --openvla_oft_root "$OPENVLA_OFT_ROOT" \
  --checkpoint "$CKPT" \
  --unnorm_key libero_goal \
  --policy openvla \
  --probe_steps 60 \
  --probe_steps_satisfied 300 \
  --num_open_loop_steps 8 \
  --max_policy_queries 40 \
  --save_video \
  --video_fps 20 \
  "$@"
