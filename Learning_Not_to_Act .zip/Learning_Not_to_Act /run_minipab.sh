#!/bin/bash
# Mini-PAB 160 episode 主流程（GPU）
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML
exec "$PY" -u scripts/run_mini_pab.py \
  --openvla_oft_root "$OPENVLA_OFT_ROOT" \
  --checkpoint "$CKPT" \
  --unnorm_key "${UNNORM_KEY:-libero_goal}" \
  "$@"
