#!/bin/bash
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd $OPENVLA_OFT_ROOT
exec "$PY" -u experiments/robot/libero/run_libero_eval.py \
  --pretrained_checkpoint "$CKPT" \
  --task_suite_name libero_goal \
  --num_trials_per_task 4 \
  --use_l1_regression True --use_proprio True \
  --num_images_in_input 2 --center_crop True \
  --num_open_loop_steps 8 --lora_rank 32
