#!/bin/bash
# 带构造追踪的 Mini-PAB 运行（用于定位卡点）
set -uo pipefail
export MINIPAB_TRACE=1
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML
exec "$PY" -u scripts/run_mini_pab.py \
  --openvla_oft_root "$OPENVLA_OFT_ROOT" \
  --checkpoint "$CKPT" \
  --unnorm_key libero_goal \
  --policy openvla \
  --probe_steps 15 \
  --save_video \
  --run_name trace_run \
  "$@"
