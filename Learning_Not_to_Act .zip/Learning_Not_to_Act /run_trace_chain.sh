#!/bin/bash
# Experiment A 链式执行：
#   1) 等 satisfied trace 跑完（已在跑的 traceA.pid）
#   2) 跑 unsatisfied trace（成功抓取对照）—— 模型只加载一次的对照条件
#   3) 对两个条件做统合分析（下降行为 + 对准先验/实际）
#
# 用法: ./submit.sh traceChain ./run_trace_chain.sh bowl_on_plate 6
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML

TASK=${1:-bowl_on_plate}
N=${2:-6}

echo "[chain] task=$TASK n=$N  start=$(date '+%F %T')"

if [ -f logs/traceA.pid ]; then
    P=$(cat logs/traceA.pid)
    echo "[chain] waiting for satisfied trace pid=$P ..."
    while kill -0 "$P" 2>/dev/null; do sleep 20; done
    echo "[chain] satisfied trace finished at $(date '+%F %T')"
fi

echo "[chain] === start unsatisfied trace ==="
"$PY" -u scripts/trace_action_pipeline.py "$TASK" "$N" unsatisfied
echo "[chain] === unsatisfied trace done at $(date '+%F %T') ==="

echo "[chain] === combined analysis ==="
"$PY" -u scripts/analyze_trace_vs_prior.py "$TASK" --dump
echo "[chain] === ALL DONE at $(date '+%F %T') ==="
