#!/bin/bash
# 状态构造校验（CPU 即可，不需要 GPU）
set -uo pipefail
source /HUBU-AI004/zp/ICML/env.sh
cd /HUBU-AI004/zp/ICML
exec "$PY" -u scripts/validate_states.py --openvla_oft_root "$OPENVLA_OFT_ROOT" "$@"
