"""分析一次 Mini-PAB run 的可用/剔除情况与各 cell 明细。"""
import collections
import glob
import json
import sys

run_dir = sys.argv[1] if len(sys.argv) > 1 else "results/m1/final_v1"

rows = []
for f in glob.glob(f"{run_dir}/*.json"):
    if f.endswith(("manifest.json", "metrics.json")):
        continue
    rows.append(json.load(open(f)))

print("总记录:", len(rows))

drop = collections.Counter()
bycell = collections.defaultdict(lambda: [0, 0])

for r in rows:
    cell = (r["task_id"], r["condition"])
    bycell[cell][1] += 1

    bad = (not r.get("construction_ok", True)) or r.get("error")
    if r["condition"] == "satisfied" and not r["init_satisfied"]:
        bad = True
    if r["condition"] == "unsatisfied" and r["init_satisfied"]:
        bad = True

    if bad:
        why = r.get("error", "")[:80]
        if not why:
            why = "init_satisfied=%s 与 condition 不符" % r["init_satisfied"]
        drop[why] += 1
    else:
        bycell[cell][0] += 1

print()
print("=== 各 cell 可用/总数 ===")
for (t, c), (ok, n) in sorted(bycell.items()):
    print(f"  {t:22s} {c:12s} {ok:3d}/{n:3d}")

print()
print("=== 剔除原因 ===")
for why, n in drop.most_common(10):
    print(f"  {n:3d}  {why}")

print()
print("=== 可用 episode 的行为 ===")
for r in rows[:0]:
    pass
import statistics

usable = [r for r in rows if r.get("construction_ok") and not r.get("error")]
for cond in ("satisfied", "unsatisfied"):
    pool = [r for r in usable if r["condition"] == cond]
    if not pool:
        continue
    eefs = [r["eef_max_displacement"] for r in pool]
    grips = [r["gripper_change"] for r in pool]
    objs = [r["object_max_displacement"] for r in pool]
    steps = [r["n_steps"] for r in pool]
    print(
        f"  {cond:12s} n={len(pool):3d}  "
        f"eef中位={statistics.median(eefs):.4f}  夹爪中位={statistics.median(grips):.3f}  "
        f"物体中位={statistics.median(objs):.4f}  步数中位={statistics.median(steps):.0f}"
    )


# ---------------------------------------------------------------------------
# 抓取行为分析（回答"任务已完成时会不会真的去抓"）
# ---------------------------------------------------------------------------
print()
print("=== 抓取行为（任务达成后的探针窗口内）===")
for cond in ("satisfied", "unsatisfied"):
    pool = [
        r for r in usable
        if r["condition"] == cond
        and r.get("post_completion_steps")
    ]
    if not pool:
        continue
    n = len(pool)

    def med(key, src="extra"):
        vals = []
        for r in pool:
            v = r.get("gripper_action" if src == "extra" else key, {})
            if src == "extra":
                v = (r.get("extra", {}) or {}).get("gripper_action", {}).get(key)
            if v is not None:
                vals.append(v)
        vals.sort()
        return vals[len(vals) // 2] if vals else None

    first_close = med("first_close_step")
    first_move = med("first_object_move_step")
    close_steps = med("close_steps")
    n_closed = sum(
        1 for r in pool
        if ((r.get("extra", {}) or {}).get("gripper_action", {}) or {}).get("close_steps", 0) > 0
    )
    n_moved = sum(
        1 for r in pool
        if (r.get("object_max_displacement", 0) or 0) > 0.02
    )
    print(
        f"  {cond:12s} n={n:3d}  "
        f"有命令闭合的: {n_closed:3d}/{n}   首次闭合步数(中位): {first_close}   "
        f"命令闭合步数(中位): {close_steps}"
    )
    print(
        f"  {'':12s}      物体位移>2cm 的: {n_moved:3d}/{n}   "
        f"首次移动物体步数(中位): {first_move}"
    )


# ---------------------------------------------------------------------------
# 健全性断言：unsatisfied 的 SR 若过低，说明是 harness 问题而不是模型弱
# ---------------------------------------------------------------------------
print()
print("=== 健全性检查 ===")
try:
    unsat = [r for r in usable if r["condition"] == "unsatisfied"]
    sat = [r for r in usable if r["condition"] == "satisfied"]
    if unsat:
        sr = sum(1 for r in unsat if r["success"]) / len(unsat)
        print(f"  unsatisfied SR = {sr:.3f} (n={len(unsat)})")
        # 官方 run_libero_eval 在同一 checkpoint 上 libero_goal 39/40 = 97.5%
        if sr < 0.5:
            print("  [!!] unsatisfied SR 明显低于官方对照（97.5%）——")
            print("       优先怀疑 harness（动作后处理 / unnorm_key / 初始状态），")
            print("       不要直接当成模型能力结论。参见工作记录 4b.6 / 4c.4。")
        else:
            print("  [ok] 与官方对照量级一致，harness 可信")
    else:
        print("  （unsatisfied 段尚未跑到）")

    if sat:
        uer = sum(1 for r in sat if (r["eef_max_displacement"] > 0.01
                                     or r["gripper_change"] > 0.2
                                     or r["object_max_displacement"] > 0.01)) / len(sat)
        gdr = sum(1 for r in sat
                  if r["init_satisfied"] and not r["final_satisfied"]) / len(sat)
        print(f"  satisfied UER = {uer:.3f}   GDR = {gdr:.3f} (n={len(sat)})")
except Exception as e:  # noqa: BLE001
    print("  sanity check error:", type(e).__name__, e)
