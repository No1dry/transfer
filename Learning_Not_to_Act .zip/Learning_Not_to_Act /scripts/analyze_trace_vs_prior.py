"""Experiment A 后处理：把 trace CSV 里 eef 的轨迹对齐到 (a) 实际碗位置 (b) 官方初始(先验)碗位置。

回答两个问题：
  Q1（satisfied 专属）模型合爪时，手是朝着"碗实际在的地方"还是"碗训练时在的地方"？
     -> 若两者都够不着，说明它执行的是与视觉无关的陈旧动作程序。
  Q2（两条件对照）satisfied 与 unsatisfied 的下降行为差在哪？
     -> unsatisfied 是"成功抓取"的参考；若 satisfied 的 eef_z 从不下降到碗口高度，
        则 UER=100% 的本质是"悬停空合爪"，而不是"真的在尝试抓取"。

只用 MuJoCo/LIBERO（不加载 7B 模型），可与 trace 并行跑。

用法:
  ./run_diag.sh scripts/analyze_trace_vs_prior.py bowl_on_plate [--dump]
"""
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.tasks import load_registry

TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"
DUMP = "--dump" in sys.argv
TRACE = Path("/HUBU-AI004/zp/ICML/results/mechanism/action_trace")
CONDS = ["satisfied", "unsatisfied"]

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)

# ---------- 官方初始状态下的碗位置 = 先验 ----------
arena.reset()
prior = np.asarray(arena.entity_pos(spec.subject), dtype=float)
print(f"[prior] 官方初始状态 subject={spec.subject} pos = {prior}")


def load(cond):
    """读某条件的全部 trace CSV，返回 [(seed, rows, eef, rawG), ...]"""
    out = []
    for c in sorted(TRACE.glob(f"{TASK}__{cond}__s*.csv")):
        seed = int(c.stem.split("s")[-1])
        with c.open() as f:
            rows = list(csv.DictReader(f))
        eef = np.array([[float(r["eef_x"]), float(r["eef_y"]), float(r["eef_z"])] for r in rows])
        rawg = np.array([float(r["raw_gripper"]) for r in rows])
        out.append((seed, rows, eef, rawg))
    return out


# 用 satisfied 第一个 CSV 的碗位置作为"实际位置"
sat0 = load("satisfied")
if not sat0:
    print("[warn] 没有 satisfied trace CSV")
    sys.exit(0)
actual = np.array([float(sat0[0][1][0][k]) for k in ("obj_x", "obj_y", "obj_z")])
gap = np.linalg.norm(prior[:2] - actual[:2])
print(f"[actual] satisfied 场景碗位置 = {actual}")
print(f"[gap] 先验-实际 xy 间距 = {gap:.4f} m")

stats = {}  # cond -> list of dict

for cond in CONDS:
    data = load(cond)
    if not data:
        continue
    print("\n" + "=" * 104)
    print(f"### 条件 = {cond}   n={len(data)}")
    print("=" * 104)
    hdr = (f"{'seed':>4} {'minD_3d':>8} {'minDxy':>8} {'minDxy_prior':>12} {'who':>7} "
           f"{'z_min':>7} {'bowl_z':>7} {'above':>7} {'close#':>7} {'1stClose':>8}")
    print(hdr)
    print("-" * 104)

    for seed, rows, eef, rawg in data:
        d3d = np.array([float(r["eef_obj_dist"]) for r in rows])
        obj = np.array([[float(r["obj_x"]), float(r["obj_y"]), float(r["obj_z"])] for r in rows])
        dxy = np.linalg.norm(eef[:, :2] - obj[:, :2], axis=1)
        dxy_prior = np.linalg.norm(eef[:, :2] - prior[None, :2], axis=1)
        zmin = float(eef[:, 2].min())
        bz = float(obj[0, 2])
        close = np.flatnonzero(rawg < 0.5)

        if cond == "satisfied":
            ma, mp = float(dxy.min()), float(dxy_prior.min())
            who = "prior" if mp < ma - 0.01 else ("actual" if ma < mp - 0.01 else "tie")
        else:
            mp, who = float("nan"), "-"   # 先验=实际，无区分意义

        print(f"{seed:>4} {d3d.min():>8.4f} {dxy.min():>8.4f} {mp:>12.4f} {who:>7} "
              f"{zmin:>7.4f} {bz:>7.4f} {zmin-bz:>+7.4f} {len(close):>7} "
              f"{(close[0]+1) if len(close) else -1:>8}")

        stats.setdefault(cond, []).append(
            dict(seed=seed, d3d=float(d3d.min()), dxy=float(dxy.min()), dxy_prior=mp,
                 zmin=zmin, bowl_z=bz, above=zmin - bz, n_close=len(close),
                 n_steps=len(rows))
        )
        if DUMP:
            print(f"      -- seed {seed} 轨迹采样:")
            for i in range(0, len(rows), 30):
                print(f"         {i+1:4d}  x={eef[i,0]:7.4f} y={eef[i,1]:7.4f} z={eef[i,2]:6.4f}  "
                      f"rawG={rawg[i]:.0f}  d_act={d3d[i]:.4f}")
            print(f"         LAST x={eef[-1,0]:7.4f} y={eef[-1,1]:7.4f} z={eef[-1,2]:6.4f}")

# ---------- 跨条件对照 ----------
print("\n" + "=" * 104)
print("### 跨条件对照（决定性的下降行为）")
print("=" * 104)
if "satisfied" in stats and "unsatisfied" in stats:
    print(f"{'指标':<34} {'satisfied':>16} {'unsatisfied':>16}")
    print("-" * 104)
    rows_cmp = [
        ("n episodes", lambda s: len(s), "{:d}"),
        ("eef_z 最低点高于碗 (m)", lambda s: np.median([x["above"] for x in s]), "{:+.4f}"),
        ("eef_z 最低点 (m)", lambda s: np.median([x["zmin"] for x in s]), "{:.4f}"),
        ("xy 最近距离 (m)", lambda s: np.median([x["dxy"] for x in s]), "{:.4f}"),
        ("3D 最近距离 (m)", lambda s: np.median([x["d3d"] for x in s]), "{:.4f}"),
        ("原始想合步数", lambda s: np.median([x["n_close"] for x in s]), "{:.1f}"),
    ]
    A, B = stats["satisfied"], stats["unsatisfied"]
    for name, fn, fmt in rows_cmp:
        print(f"{name:<34} {fmt.format(fn(A)):>16} {fmt.format(fn(B)):>16}")

    sat_above = np.array([x["above"] for x in A])
    uns_above = np.array([x["above"] for x in B])
    print(f"\n[判读] satisfied 的 eef 最低点高出碗顶中位数 {np.median(sat_above):+.4f} m；"
          f"unsatisfied（成功）为 {np.median(uns_above):+.4f} m")
    if np.median(sat_above) > np.median(uns_above) + 0.02:
        print("       -> satisfied 显著没有下降到抓取高度：UER=100% 的本质是"
              "『悬停在碗上方空合爪』，而非完整的抓取尝试。")
    else:
        print("       -> 两个条件的下降高度接近：satisfied 确实做出了完整的抓取动作。")

    if "satisfied" in stats:
        n_prior = sum(1 for x in A if x["dxy_prior"] < x["dxy"] - 0.01)
        n_act = sum(1 for x in A if x["dxy"] < x["dxy_prior"] - 0.01)
        print(f"[判读] satisfied 下 xy 最近点：更靠近先验 {n_prior}/{len(A)}，"
              f"更靠近实际 {n_act}/{len(A)}，并列 {len(A)-n_prior-n_act}/{len(A)}")
else:
    missing = [c for c in CONDS if c not in stats]
    print(f"[提示] 缺少条件 {missing} 的 trace，无法做跨条件对照。")

arena.close()
