"""LIBERO 环境速度基准（用于估算 160 episode 的耗时）。"""
import time

import numpy as np
from libero.libero import benchmark

from experiments.robot.libero.libero_utils import get_libero_dummy_action, get_libero_env

t0 = time.time()
print(f"[bench] import: {time.time() - t0:.1f}s", flush=True)

b = benchmark.get_benchmark_dict()
ts = b["libero_goal"]()
t = ts.get_task(8)

t0 = time.time()
env, desc = get_libero_env(t, "openvla", resolution=256)
print(f"[bench] env create: {time.time() - t0:.1f}s", flush=True)

init = np.asarray(ts.get_task_init_states(8))[0]
t0 = time.time()
env.reset()
obs = env.set_init_state(init)
print(f"[bench] reset+set_init: {time.time() - t0:.1f}s", flush=True)

t0 = time.time()
for _ in range(10):
    obs, r, d, i = env.step(get_libero_dummy_action("openvla"))
dt = time.time() - t0
print(f"[bench] 10 dummy steps: {dt:.1f}s -> {dt / 10 * 1000:.0f} ms/step", flush=True)

t0 = time.time()
for _ in range(100):
    env.check_success()
print(f"[bench] check_success x100: {time.time() - t0:.3f}s", flush=True)

t0 = time.time()
s = env.sim.get_state().flatten()
print(f"[bench] get_state: {time.time() - t0:.4f}s len={len(s)}", flush=True)

# 状态写回 + forward 的成本（状态构造的关键路径）
import mujoco

state = np.asarray(s, dtype=np.float64)
t0 = time.time()
for _ in range(100):
    env.sim.set_state_from_flattened(state)
    env.sim.forward()
print(f"[bench] set_state+forward x100: {time.time() - t0:.3f}s", flush=True)

env.close()
print("[bench] done", flush=True)
