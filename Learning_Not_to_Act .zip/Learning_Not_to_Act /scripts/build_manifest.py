#!/usr/bin/env python
"""Step 4 入口：生成并冻结 160-episode 评估清单。

不依赖 LIBERO / GPU，任何机器都能跑。

用法
----
    python scripts/build_manifest.py --model openvla_oft
    python scripts/build_manifest.py --model openvla_oft --out results/m1/manifest.json

产物
----
``results/m1/manifest_<model>.json``，含 160 条 episode 身份与 content hash。
冻结之后不要再改 —— 它是"两次实验跑的是同一套初始状态"这一承诺的载体（§65.4）。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from benchmark.manifest import build_manifest  # noqa: E402
from benchmark.tasks import episode_budget, load_registry  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", default="openvla_oft", help="被评估模型名，用于结果文件命名")
    p.add_argument("--config", type=Path, default=None, help="Mini-PAB 配置（默认 configs/mini_pab.yaml）")
    p.add_argument("--out", type=Path, default=None, help="输出路径")
    p.add_argument("--seeds", type=int, default=None, help="覆盖 seeds 数量（仅用于调试）")
    args = p.parse_args(argv)

    registry = load_registry(args.config)
    budget = episode_budget(registry)
    seeds = list(range(args.seeds)) if args.seeds else None
    manifest = build_manifest(registry, model_name=args.model, seeds=seeds)

    out = args.out or (REPO_ROOT / "results" / "m1" / f"manifest_{args.model}.json")
    manifest.write(out)

    print("Mini-PAB manifest")
    print(f"  benchmark      : {manifest.benchmark_version}")
    print(f"  model          : {manifest.model_name}")
    print(f"  tasks          : {budget['n_tasks']}")
    print(f"  conditions     : {manifest.conditions}")
    print(f"  seeds/task/cond: {len(manifest.seeds)}")
    print(f"  episodes       : {len(manifest)}")
    print(f"  content hash   : {manifest.content_hash[:16]}")
    print()
    print("  每个 (task, condition) 的 episode 数：")
    for k, v in manifest.counts().items():
        print(f"    {k:40s} {v}")
    print()
    print(f"[ok] 已写入 {out}")

    if len(manifest) != budget["total_episodes"]:
        print(
            f"[warn] episode 数 {len(manifest)} 与配置预算 {budget['total_episodes']} 不一致"
            "（如果用了 --seeds 覆盖则属预期）"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
