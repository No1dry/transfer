"""回归测试：episode 终止后能不能继续 step（探针模式）。

背景：主实验要测"任务已达成之后模型还动不动"，就必须在 robosuite 判定
``done`` 之后继续 step。但 robosuite 会拒绝：

    ValueError: executing action in terminated episode

`LiberoArena.set_allow_after_done(True)` 本意是清掉这个标志，但原来只清了
``self._env.done``（LIBERO 的 wrapper，通常没有 done 属性），而真正被检查的是
**内层** robosuite env（``self._env.env``）——所以那个修复是**空操作**，
unsatisfied seed 2 跑到成功之后仍然炸了。

这个脚本不加载模型，用"目标已达成"的 satisfied 状态跑若干步无意义动作，
验证：(1) done 到底挂在哪一层；(2) 修复后能否连续 step 而不抛异常。

用法: ./run_diag.sh scripts/check_after_done.py [task]
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"
N_STEPS = 40

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
builder = StateBuilder(settle_steps=15)

# ---- 1. done 标志到底挂在哪一层 ----
arena.reset()
print("[链] 逐层找 done 属性：")
obj, depth = arena._env, 0
while obj is not None and depth < 4:
    print(f"   [{depth}] {type(obj).__module__}.{type(obj).__name__}"
          f"   done={getattr(obj, 'done', '<无此属性>')!r}")
    obj = getattr(obj, "env", None)
    depth += 1

# ---- 2. 构造 satisfied 状态，跑过 done ----
r = builder.build_state(arena, spec, "satisfied", 0)
if not r.ok:
    print(f"[FAIL] satisfied 状态构造失败: {r.failure_reason}")
    sys.exit(1)
arena.set_state(r.state, settle_steps=0)
arena.mark_episode_start()
arena.set_allow_after_done(True)
print(f"\n[satisfied] goal_satisfied()={arena.goal_satisfied()}")

dummy = arena.no_op_action()
n_done_seen = 0
try:
    for i in range(1, N_STEPS + 1):
        res = arena.step(dummy)
        if res.done:
            n_done_seen += 1
        if i <= 3 or i == N_STEPS:
            print(f"   step {i:3d}: done={res.done}  "
                  f"cleared={arena._clear_done_flags()}  ok")
except ValueError as e:
    print(f"\n[FAIL] 第 {i} 步抛出: {e}")
    print("       -> 探针模式失效，done 没有被清掉")
    arena.close()
    sys.exit(1)

print(f"\n[PASS] 连续 {N_STEPS} 步无异常；期间 step 返回 done=True 的次数 = {n_done_seen}")

# ---- 3. 强制复现崩溃路径 ----
# 上面那 40 步 cleared 一直是空的：LIBERO 返回的 done=True 并没有写到 robosuite
# 内部的 self.done 上，所以没真正走到崩溃分支。而 trace 在 unsatisfied seed 2
# 上确实炸了，说明内层 done 会被置 True。这里直接手动把它置 True，
# 复现当时的状态 —— 旧代码（只清 wrapper）必然抛异常，新代码应当安然通过。
inner = getattr(arena._env, "env", None)
print(f"\n[强制复现] 手动设 {type(inner).__name__}.done = True，再 step 一次")
inner.done = True
try:
    cleared = arena._clear_done_flags()
    res = arena.step(dummy)
    print(f"   cleared={cleared}  step 返回 done={res.done}")
    if not cleared:
        print("   [WARN] 没有清到任何 done 标志 —— 清理逻辑可能没覆盖这一层")
        sys.exit(1)
    print("   [PASS] 内层 done 被清掉，仿真继续 —— 这就是之前炸掉的那条路径")
except ValueError as e:
    print(f"   [FAIL] 仍然抛出: {e}")
    arena.close()
    sys.exit(1)

print("\n[结论] 旧逻辑只清 wrapper（无 done 属性）= 空操作；"
      "新逻辑沿 .env 链逐层清，崩溃路径已被堵住")
arena.close()
