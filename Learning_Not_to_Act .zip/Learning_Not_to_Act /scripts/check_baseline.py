"""核对 mark_episode_start 建立的 eef 基线是否与真实仿真状态一致。

怀疑点：_finalize 会把机器人关节强制写回官方值，但 set_state(settle_steps=0)
不会刷新 _last_obs_raw，于是 mark_episode_start 可能用一个"陈旧的 obs"
建立位移基线 —— 位移基线偏了会直接影响 UER（阈值只有 1~10mm）。
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
arena = LiberoArena(
    task_suite_name="libero_goal", task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1", target="plate_1", residual_kind="placement",
)
builder = StateBuilder(settle_steps=15)

for cond in ("satisfied", "unsatisfied"):
    for seed in (0, 1):
        r = builder.build_state(arena, spec := reg["bowl_on_plate"], cond, seed)
        if not r.ok:
            print(cond, seed, "build failed"); continue
        arena.set_state(r.state, settle_steps=0)
        arena.mark_episode_start()

        base_eef = np.asarray(arena._episode_start["eef"], dtype=float)
        base_grip = np.asarray(arena._episode_start["gripper"], dtype=float)

        # 真实状态：从 sim 直接读
        sim = arena._env.sim
        real_eef = np.asarray(sim.data.get_body_xpos("robot0_right_hand"), dtype=float)
        # 用 qpos 里的机器人关节算"官方 vs 当前"的差异
        from benchmark.states import mujoco_state as ms
        layout = ms.StateLayout.from_model(arena.model)
        q_now = ms.get_robot_qpos(arena.get_state(), layout)
        q_off = arena.official_robot_qpos()
        dq = float(np.abs(q_now - q_off).max())

        print(f"[{cond:12s} seed={seed}] 基线eef={np.round(base_eef,4)} "
              f"| 关节与官方最大差={dq:.2e} rad | 基线夹爪={np.round(base_grip,4)}")
arena.close()
