import glob
import imageio.v2 as iio

fs = sorted(glob.glob("results/m1/control_B/videos/*.mp4"))
print("videos:", len(fs))
for f in fs[:1]:
    r = iio.get_reader(f)
    n = r.count_frames()
    print(" ", f.split("/")[-1])
    print("  frames:", n, "fps:", r.get_meta_data().get("fps"))
    for p in (0, 44, 120, min(n - 1, 300)):
        if p < n:
            iio.imwrite(f"/tmp/cb_f{p:03d}.png", r.get_data(p))
            print(f"  saved frame {p}")
    r.close()
