"""校验 eef 参考点：robot0_right_hand(body) vs obs['robot0_eef_pos'](官方 eef site)。

背景（重要）：trace 脚本一开始用 `sim.data.get_body_xpos("robot0_right_hand")`
当作 eef，算出"satisfied 下机械臂悬在碗上方 10cm 从不下降"。
但 unsatisfied（**成功抓取**）的轨迹算出来也是"高出碗 11-13cm"——
成功的 episode 不可能够不着碗，所以这个参考点几乎肯定是错的
（`robot0_right_hand` 是手腕 body，指尖还要往前伸 ~10cm）。

这个脚本不加载模型，直接对比两个参考点和碗位置，把差距量出来。

用法: ./run_diag.sh scripts/check_eef_reference.py [task]
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.tasks import load_registry

TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)

arena.reset()
env = arena._env
sim = env.sim

print(f"[task] {TASK}  suite={spec.suite}  subject={spec.subject}")
print(f"[obs] robot0_eef_pos (官方 eef)      = {np.asarray(arena._last_obs_raw.get('robot0_eef_pos'))}")

for name in ("robot0_right_hand", "robot0_left_hand", "gripper0_right_hand", "gripper0_grip_site"):
    try:
        if name.endswith("_site"):
            idx = sim.model.site_name2id(name)
            p = sim.data.site_xpos[idx]
        else:
            p = sim.data.get_body_xpos(name)
        print(f"[sim] {name:<22} = {np.asarray(p)}")
    except Exception as e:  # noqa: BLE001
        print(f"[sim] {name:<22} 不可用: {e}")

bowl = np.asarray(arena.entity_pos(spec.subject), dtype=float)
print(f"\n[bowl] {spec.subject} = {bowl}")

eef_official = np.asarray(arena._last_obs_raw["robot0_eef_pos"], dtype=float)
hand = sim.data.get_body_xpos("robot0_right_hand")
print(f"\n[对比] |eef_official - bowl| = {np.linalg.norm(eef_official - bowl):.4f} m")
print(f"[对比] |right_hand   - bowl| = {np.linalg.norm(hand - bowl):.4f} m")
print(f"[对比] |eef_official - right_hand| = {np.linalg.norm(eef_official - hand):.4f} m")
print(f"[z] eef_official_z={eef_official[2]:.4f}  right_hand_z={hand[2]:.4f}  bowl_z={bowl[2]:.4f}")

# 所有 site 名字里含 grip / eef 的
names = list(getattr(sim.model, "site_names", None) or [])
hits = [n for n in names if any(k in n.lower() for k in ("grip", "eef", "hand"))]
print(f"\n[site 候选] {hits}")
for n in hits:
    try:
        print(f"   {n:<24} = {sim.data.site_xpos[sim.model.site_name2id(n)]}")
    except Exception:  # noqa: BLE001
        pass

arena.close()
