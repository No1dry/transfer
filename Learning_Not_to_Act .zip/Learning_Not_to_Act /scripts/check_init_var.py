"""核实关键假设：LIBERO 官方初始状态里，物体位置到底有多大变化？

我的解释是"模型把碗的位置背下来了"。但这只有在**训练时碗的位置变化很小**时
才成立 —— 否则模型不可能靠背位置达到 96.8% 成功率。

这个脚本直接量官方 50 个 init state 里物体位置的分布。
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))

for tid in ("bowl_on_stove", "bowl_on_plate"):
    spec = reg[tid]
    arena = LiberoArena(
        task_suite_name=spec.suite,
        task_id=spec.task_id,
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        subject=spec.subject,
        target=spec.target,
        residual_kind=spec.residual_kind,
    )
    model = arena.model
    init_states = np.asarray(arena._init_states)
    print(f"\n=== {tid} ({spec.subject}) ===")
    print(f"  官方 init state 数量: {init_states.shape[0]}")

    poss = []
    for i in range(init_states.shape[0]):
        st = init_states[i]
        try:
            p = ms.get_object_pos(st, model, spec.subject)
            poss.append(p)
        except Exception as e:  # noqa: BLE001
            print("   ", i, "err", e)
            break
    poss = np.asarray(poss)
    if len(poss) == 0:
        arena.close()
        continue

    print(f"  位置范围 (xyz):")
    for ax, name in enumerate("xyz"):
        print(f"    {name}: min={poss[:,ax].min():+.4f}  max={poss[:,ax].max():+.4f}  "
              f"span={poss[:,ax].max()-poss[:,ax].min():.4f}  std={poss[:,ax].std():.4f}")
    print(f"  水平方向(xy)标准差 = {poss[:,:2].std(axis=0)}")
    print(f"  水平方向最大两两距离 = "
          f"{max(np.linalg.norm(a[:2]-b[:2]) for a in poss for b in poss):.4f} m")
    print(f"  到质心的平均水平距离 = "
          f"{np.linalg.norm(poss[:,:2]-poss[:,:2].mean(axis=0), axis=1).mean():.4f} m")

    # 目标位置（炉子/盘子）是固定的吗？
    try:
        tp = np.asarray([ms.get_object_pos(s, model, spec.target) for s in init_states[:5]])
        print(f"  目标 {spec.target} 前 5 个 init state 位置: {np.round(tp,4).tolist()}")
    except Exception:
        pass
    arena.close()

print("\n判读：如果水平方向标准差只有几厘米，说明模型**可以**靠'记住位置'达到高成功率；")
print("      如果变化达十几厘米以上，那'背位置'的解释就不充分。")
