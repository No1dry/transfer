"""不加载模型、不占 GPU，只验证视频叠加文字在 256x256 画面里放得下。

背景：服务器上只有 DejaVu/Liberation 字体，没有中文字体 —— 叠加中文会变成
豆腐块 ▯▯▯。所以在花 30 分钟 GPU 时间重跑之前，先用这个脚本把版面确认好。

用法:
    ./run_diag.sh scripts/check_overlay_layout.py [out.png]
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from PIL import Image, ImageDraw, ImageFont

W = H = 256
FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
]

# 与 trace_action_pipeline.py 中实际会画的内容一致（最坏情况：数字都最长）
CASES = [
    ("satisfied", [
        "SAT  s0  step 300/300",
        "d_bowl 0.128m  xy 0.062m",
        "eef_z 1.007  bowl 0.906  dz +0.100",
        "intent CLOSE  fingers 0.0400",
    ], "SATISFIED AT START - still acting?"),
    ("unsatisfied", [
        "UNSAT  s0  step 300/300",
        "d_bowl 0.012m  xy 0.009m",
        "eef_z 0.941  bowl 0.906  dz +0.035",
        "intent OPEN   fingers 0.0388",
    ], "GOAL REACHED at 300 - still acting?"),
]


def pick_font(size):
    for p in FONT_PATHS:
        try:
            return ImageFont.truetype(p, size), p
        except Exception:  # noqa: BLE001
            continue
    return ImageFont.load_default(), "<default>"


def render(font, size, case, out):
    cond, lines, banner = case
    img = Image.new("RGB", (W, H), (60, 60, 70))
    dr = ImageDraw.Draw(img)
    lh = size + 4
    pad = 4
    box_h = lh * len(lines) + pad
    dr.rectangle([0, 0, W, box_h], fill=(0, 0, 0))
    widths = []
    for i, t in enumerate(lines):
        dr.text((pad, pad + i * lh), t, fill=(255, 255, 255), font=font)
        bbox = dr.textbbox((0, 0), t, font=font)
        widths.append(bbox[2] - bbox[0])
    dr.rectangle([0, box_h, W, box_h + lh + 4], fill=(170, 0, 0))
    dr.text((pad, box_h + 3), banner, fill=(255, 255, 255), font=font)
    bw = dr.textbbox((0, 0), banner, font=font)[2]
    img.save(out)
    return widths, bw, box_h + lh + 4


def main():
    out_dir = Path("/tmp/overlay_check")
    out_dir.mkdir(parents=True, exist_ok=True)
    ok_all = True
    for size in (15, 13, 12, 11, 10, 9, 8):
        font, path = pick_font(size)
        print(f"\n=== font={Path(path).name} size={size} ===")
        for cond, lines, banner in CASES:
            out = out_dir / f"overlay_{cond}_{size}.png"
            widths, bw, total_h = render(font, size, (cond, lines, banner), out)
            mx = max(widths + [bw])
            fits = mx <= W - 2
            ok_all &= fits
            flag = "OK " if fits else "OVERFLOW"
            print(f"  [{flag}] {cond:<12} max_text_w={mx:>3}px (limit {W-2})  "
                  f"box_h={total_h}px  -> {out.name}")
            for t, w in zip(lines, widths):
                mark = "  <-- too wide" if w > W - 2 else ""
                print(f"        {w:>3}px  {t}{mark}")
            print(f"        {bw:>3}px  [BANNER] {banner}")
    print(f"\n[verdict] {'版面 OK，可以重跑' if ok_all else '仍有溢出，需要再缩短文案'}")
    print(f"[png] {out_dir}")


if __name__ == "__main__":
    main()
