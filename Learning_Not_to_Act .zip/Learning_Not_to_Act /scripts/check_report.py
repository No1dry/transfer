"""用当前 part-run 的真实新格式记录预演报告生成（含 gripper_action 等新字段）。"""
import sys
from pathlib import Path

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.metrics import compute_all, decide_go_no_go
from benchmark.report import render_report, write_summary_csv
from benchmark.runner import load_records

d = Path("/HUBU-AI004/zp/ICML/results/m1/final")
recs = load_records(d)
print("records:", len(recs))
m = compute_all(recs)
print("n_usable:", m["n_usable"], "n_dropped:", m["n_dropped"])
print("UER:", m["uer"]["value"], "n:", m["uer"]["n"])
print("GDR:", m["gdr"]["value"], "n:", m["gdr"]["n"])
print("verdict:", decide_go_no_go(m["uer"]["value"]).decision)

txt = render_report(recs, model_name="partial_check")
print("report chars:", len(txt))
print("has Q1-Q4:", all(k in txt for k in ("Q1.", "Q2.", "Q3.", "Q4.")))

# 检查新字段是否被 post_completion 汇总正确带出
for r in recs:
    pc = r.extra.get("post_completion", {})
    ga = r.extra.get("gripper_action", {})
    print(f"  seed={r.seed} steps={r.n_steps} post_steps={r.post_completion_steps} "
          f"1st_close={ga.get('first_close_step')} grip_chg={r.gripper_change:.4f} "
          f"obj={r.object_max_displacement:.4f}")
