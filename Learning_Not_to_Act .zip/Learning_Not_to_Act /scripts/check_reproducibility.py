"""验证：同一 (condition, seed) 在**不同运行历史**下是否给出相同轨迹。

背景：`unsatisfied seed 0` 曾出现两种结果——"先跑 3 个 satisfied 再跑"得到
``raw想合=93``，"直接跑"得到 ``raw想合=75``。状态构造本身是确定的
（``check_state_determinism.py`` 证明碗位差 < 1e-9），所以差异来自
MuJoCo 约束求解器的 ``qacc_warmstart`` 残留：``set_state_from_flattened``
不会清它，于是"前面跑过什么"会影响后面的仿真。

本脚本不加载模型，用**固定的确定性动作序列**（no-op + 小幅正弦）代替策略，
对比两种历史下同一状态的轨迹是否一致：

  A) 直接 set_state -> 跑 N 步
  B) 先跑若干步别的状态，再 set_state -> 跑同样的 N 步

修复后 A 与 B 应当完全一致（或只差浮点噪声）。

用法: ./run_diag.sh scripts/check_reproducibility.py [task]
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"
N_STEPS = 60

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
builder = StateBuilder(settle_steps=15)


def actions(n):
    """确定性动作序列：小幅正弦，足够搅动接触/约束求解器。"""
    t = np.arange(n, dtype=np.float64)
    return [
        [
            0.03 * np.sin(0.3 * i),
            0.03 * np.cos(0.2 * i),
            -0.02,
            0.01 * np.sin(0.1 * i),
            0.01 * np.cos(0.15 * i),
            0.01 * np.sin(0.25 * i),
            -1.0 if i % 7 else 1.0,
        ]
        for i in t
    ]


def rollout(cond, seed, n):
    r = builder.build_state(arena, spec, cond, seed)
    assert r.ok, f"构造失败: {cond} {seed}"
    arena.set_state(r.state, settle_steps=0)
    arena.mark_episode_start()
    arena.set_allow_after_done(True)
    trace = []
    for a in actions(n):
        arena.step(a)
        trace.append(np.asarray(arena._last_obs_raw["robot0_eef_pos"], dtype=float).copy())
    return np.array(trace)


# ---- A) 干净历史：直接跑目标 episode ----
A = rollout("unsatisfied", 0, N_STEPS)

# ---- B) 先跑 3 个别的 episode 弄脏求解器状态，再跑同一个 ----
for s in range(3):
    rollout("satisfied", s, 40)
B = rollout("unsatisfied", 0, N_STEPS)

# ---- C) 再跑一次（同一历史下重复，检查自身确定性）----
C = rollout("unsatisfied", 0, N_STEPS)

dAB = float(np.abs(A - B).max())
dAC = float(np.abs(A - C).max())
print("\n" + "=" * 74)
print(f"A（干净历史）       末点 eef = {A[-1]}")
print(f"B（先跑过别的）     末点 eef = {B[-1]}")
print(f"|A-B| 最大逐点差 = {dAB:.3e} m")
print(f"|A-C| 最大逐点差 = {dAC:.3e} m   （同历史重复，用于区分噪声与真实分歧）")
print("=" * 74)

THRESH = 1e-6
if dAB < THRESH:
    print("[结论] 不同运行历史下轨迹一致 —— warm-start 复位生效，可复现性 OK")
else:
    print("[结论] ⚠️ 不同运行历史下轨迹不同 —— 仍有非确定性来源")
    print(f"       分歧量级 {dAB:.3e} m，远大于同历史重复的噪声 {dAC:.3e} m")
    print("       需要继续查（可能是 solver 迭代残留、接触缓存等）")

arena.close()
