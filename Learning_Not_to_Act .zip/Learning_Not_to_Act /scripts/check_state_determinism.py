"""检查状态构造是否**依赖进程历史**（可复现性 bug）。

发现的疑点：`unsatisfied seed 0` 在两次运行里给出不同轨迹
（raw想合 93 vs 75）。同一个 seed、同一个模型、同一个 eef 参考，
所以要么是 done 清理改变了动力学，要么是**构造出来的状态本身不同**。

如果是后者，那"seed"就不能唯一确定实验条件——换运行顺序/换机器重跑
可能得到不同结果，属于比 trace 本身更严重的问题。

这个脚本不加载模型：
  1. 新 arena，构造 unsatisfied seed 0，记录碗位
  2. 构造 3 个 satisfied（模拟"先跑 satisfied 再跑 unsatisfied"的顺序）
  3. 再构造一次 unsatisfied seed 0，记录碗位
  4. 比较 —— 不一致就说明构造依赖历史

用法: ./run_diag.sh scripts/check_state_determinism.py [task]
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"
SEED = 0

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
builder = StateBuilder(settle_steps=15)


def probe(cond, seed):
    """构造状态并返回碗位 / residual / ok。"""
    r = builder.build_state(arena, spec, cond, seed)
    if not r.ok:
        return None, None, False
    arena.set_state(r.state, settle_steps=0)
    try:
        pos = np.asarray(arena.entity_pos(spec.subject), dtype=float)
    except Exception:  # noqa: BLE001
        pos = np.full(3, np.nan)
    res = float(arena.residual())
    return pos, res, True


print("=" * 78)
print("A) 全新 arena，第一个就构造 unsatisfied seed 0")
a_pos, a_res, a_ok = probe("unsatisfied", SEED)
print(f"   碗位 = {a_pos}   residual = {a_res}   ok={a_ok}")

print("\nB) 构造 3 个 satisfied（模拟另一种运行顺序）")
for s in range(3):
    p, rr, ok = probe("satisfied", s)
    print(f"   satisfied seed={s}  碗位 = {p}   residual = {rr}   ok={ok}")

print("\nC) 再构造一次 unsatisfied seed 0")
c_pos, c_res, c_ok = probe("unsatisfied", SEED)
print(f"   碗位 = {c_pos}   residual = {c_res}   ok={c_ok}")

print("\n" + "=" * 78)
if a_pos is None or c_pos is None:
    print("[结果] 构造失败，无法比较")
    sys.exit(2)
d = float(np.linalg.norm(a_pos - c_pos))
print(f"[比较] |A_pos - C_pos| = {d:.6f} m")
print(f"[比较] |A_res - C_res| = {abs(a_res - c_res):.6f}")
if d < 1e-6:  # 1 微米以内算浮点噪声；真正要担心的是 mm 级差异
    print("[结论] 状态构造**与顺序无关**（确定性 OK）")
    print("       -> 那 unsatisfied seed 0 两次轨迹不同，应该来自 done 清理的副作用")
else:
    print("[结论] ⚠️ 状态构造**依赖进程历史** —— 同一 seed 在不同顺序下状态不同")
    print("       这是可复现性 bug：seed 不能唯一确定实验条件。")
    print("       需要让 builder 的缓存（_offset_cache / _reset_cache）不跨 episode 影响结果。")

arena.close()
