import glob
import imageio.v2 as iio

fs = sorted(glob.glob("results/m1/final/videos/*.mp4"))
print("files:", len(fs))
for f in fs[:3]:
    r = iio.get_reader(f)
    md = r.get_meta_data()
    n = r.count_frames()
    fr = r.get_data(0)
    name = f.split("/")[-1][:50]
    print(f"  {name:52s} frames={n:4d} fps={md.get('fps')} size={fr.shape}")
    r.close()
# 帧数分布
allf = []
for f in fs:
    try:
        r = iio.get_reader(f); allf.append(r.count_frames()); r.close()
    except Exception:
        allf.append(-1)
print("frame counts:", allf)
