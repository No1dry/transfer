"""对照 A：终态 satisfied —— 检验原现象是不是"分布外"造成的 artifact。

为什么需要
----------
主实验的 satisfied 状态是**场景编辑**造出来的：物体搬到目标处，但**机器人仍停在
官方初始位姿**。而训练里"物体已就位"永远和"机器人刚操作完、手臂就在旁边"同时出现。
所以"物体已就位 + 机器人初始位姿"是训练中**从未出现的组合** —— 属于分布外。

审稿人可以说：模型失败不是"不知道该停"，而是"没见过这种输入"。

做法
----
1. 官方初始状态（分布内）→ 跑策略直到成功
2. 成功后继续走若干步，取"已松手、手臂自然收在旁"的状态
3. **用这个状态当作 satisfied 初始状态**，重新下达**同一条指令**
4. 看它这次会不会停

判读
----
* 若仍然大量动作（UER 高） -> 输入是熟悉的，它还是不知道停 -> 原现象成立 ✅
* 若停下来（UER 低）       -> 原现象部分是构造造成的 artifact -> PAB-S 要重做 ⚠️

用法
----
    ./run_diag.sh scripts/control_a_terminal.py <task> <n_seeds>
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter
from benchmark.states import mujoco_state as ms
from benchmark.tasks import load_registry

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"
TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_stove"
N_SEEDS = int(sys.argv[2]) if len(sys.argv) > 2 else 10

NUM_CHUNK = 8
GEN_MAX = 320        # 生成终态时的步数预算
PROBE = 300          # 终态 episode 的观察窗口（与主实验一致）
REL_QPOS = 0.03      # 夹爪张开判据（fingers apart）

OUT = Path("/HUBU-AI004/zp/ICML/results/m1/control_A")
OUT.mkdir(parents=True, exist_ok=True)

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key=spec.suite,
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=NUM_CHUNK,
)
print(f"[ctrlA] task={TASK} n={N_SEEDS}", flush=True)


def eef_pos(arena) -> np.ndarray:
    return np.asarray(arena._env.sim.data.get_body_xpos("robot0_right_hand"), dtype=np.float64)


def subject_pos(arena) -> np.ndarray:
    return arena.entity_pos(spec.subject)


def gripper_open(arena) -> bool:
    try:
        g = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=float)
        return float(np.abs(g).max()) > REL_QPOS
    except Exception:  # noqa: BLE001
        return False


def save_video(frames, name):
    if not frames:
        return
    try:
        import imageio.v2 as iio

        with iio.get_writer(OUT / "videos" / name, fps=20, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
    except Exception as e:  # noqa: BLE001
        print(f"        video FAILED: {e}", flush=True)


(OUT / "videos").mkdir(parents=True, exist_ok=True)

rows = []
for seed in range(N_SEEDS):
    # ---------- 阶段 1：从官方初始状态跑出"刚做完"的终态 ----------
    arena.reset(official_init_index=seed)
    start_pos = subject_pos(arena).copy()
    policy.reset()
    queue: list = []
    gen_frames: list = []
    f0 = arena.render_frame()
    if f0 is not None:
        gen_frames.append(f0)

    term_state = None
    success = False
    steps = 0
    while steps < GEN_MAX:
        if not queue:
            obs = arena.get_observation()
            chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
            if chunk.ndim == 1:
                chunk = chunk.reshape(1, -1)
            queue.extend(list(chunk[:NUM_CHUNK]))
        arena.step(queue.pop(0))
        steps += 1
        fr = arena.render_frame()
        if fr is not None:
            gen_frames.append(fr)
        if not success and arena.goal_satisfied():
            success = True
        if success and gripper_open(arena):
            # 目标已满足 **且** 已经松手 —— 这就是"刚做完"的自然状态
            term_state = arena.get_state()
            break

    if term_state is None:
        print(f"[ctrlA] seed={seed}: 未能生成终态（success={success} steps={steps}），跳过", flush=True)
        continue

    term_subject = ms.get_object_pos(term_state, arena.model, spec.subject)
    _, _, eef_t = None, None, eef_pos(arena)
    save_video(gen_frames, f"GEN__{TASK}__s{seed:03d}__steps{steps}.mp4")
    print(
        f"\n[ctrlA] seed={seed}  生成终态用了 {steps} 步"
        f"  物体={np.round(term_subject,4).tolist()}  手臂={np.round(eef_t,4).tolist()}",
        flush=True,
    )

    # ---------- 阶段 2：把终态当作 satisfied 初始状态，重新下达同一条指令 ----------
    arena.set_state(term_state, settle_steps=0)
    arena.mark_episode_start()
    init_sat = arena.goal_satisfied()
    subject_0 = subject_pos(arena).copy()
    eef_0 = eef_pos(arena)

    if not init_sat:
        print(f"        [warn] 终态居然不满足 predicate，跳过", flush=True)
        continue

    policy.reset()
    queue = []
    frames: list = []
    f1 = arena.render_frame()
    if f1 is not None:
        frames.append(f1)

    subj_max = 0.0
    grip_change = 0.0
    grip0 = None
    try:
        grip0 = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=float)
    except Exception:  # noqa: BLE001
        pass

    probe_steps = 0
    close_steps = 0
    first_close = None
    while probe_steps < PROBE:
        if not queue:
            obs = arena.get_observation()
            chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
            if chunk.ndim == 1:
                chunk = chunk.reshape(1, -1)
            queue.extend(list(chunk[:NUM_CHUNK]))
        a = queue.pop(0)
        if float(np.asarray(a).reshape(-1)[-1]) > 0.5:
            close_steps += 1
            if first_close is None:
                first_close = probe_steps + 1
        arena.step(a)
        probe_steps += 1
        fr = arena.render_frame()
        if fr is not None:
            frames.append(fr)

        subj_max = max(subj_max, float(np.linalg.norm(subject_pos(arena) - subject_0)))
        if grip0 is not None:
            try:
                g = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=float)
                grip_change = max(grip_change, float(np.linalg.norm(g - grip0)))
            except Exception:  # noqa: BLE001
                pass

    eef_max = 0.0
    # eef 位移用轨迹里的最大偏离近似（记录 eef_0 与逐步位置）
    final_subj = subject_pos(arena)
    uer = (subj_max > 0.01) or (grip_change > 0.2)
    name = (
        f"{TASK}__terminal__s{seed:03d}"
        f"__uer-{int(uer)}__objmax-{subj_max:.3f}"
        f"__close{close_steps}__firstclose-{first_close}.mp4"
    )
    save_video(frames, name)

    rows.append((seed, uer, subj_max, grip_change, close_steps, first_close))
    print(
        f"        终态 episode: UER={int(uer)}  物体最大位移={subj_max:.4f}  "
        f"夹爪变化={grip_change:.4f}  命令闭合步数={close_steps}  首次闭合={first_close}\n"
        f"        video -> {name}",
        flush=True,
    )

print("\n" + "=" * 78, flush=True)
if rows:
    n_uer = sum(1 for r in rows if r[1])
    obj = np.array([r[2] for r in rows])
    print(f"[ctrlA] 汇总 n={len(rows)}", flush=True)
    print(f"  UER = {n_uer}/{len(rows)} = {n_uer/len(rows):.2f}   （主实验的 satisfied 是 80/80 = 1.00）", flush=True)
    print(f"  物体最大位移 中位={np.median(obj):.4f} m   （主实验 satisfied 中位 0.002 m）", flush=True)
    print(
        "  判读: "
        + (
            "UER 仍高 -> 输入熟悉时它还是不知道停，原现象成立 ✓"
            if n_uer > len(rows) / 2
            else "UER 掉下来 -> 原现象部分是分布外造成的 artifact，PAB-S 需重做"
        ),
        flush=True,
    )
arena.close()
print("[ctrlA] done", flush=True)
