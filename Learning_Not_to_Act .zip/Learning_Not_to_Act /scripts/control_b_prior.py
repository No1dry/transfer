"""对照 B：物体移位但任务未完成 —— 检验"先验驱动"机制。

设计
----
官方初始状态（任务未完成），把碗**瞬移到桌面上一个新位置**（远离它训练时
一直在的地方）。任务仍然 unsatisfied，所以"该不该停"这个因素被排除 ——
只看它**往哪伸手**。

判读
----
* 伸向**先验位置**（训练时碗一直在的地方） -> "先验驱动"坐实
* 伸向**实际位置**（我们新放的地方）       -> 模型能做视觉定位，机制解释要修正

用法
----
    ./run_diag.sh scripts/control_b_prior.py <task> <n_seeds> <shift_m>
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter
from benchmark.states import mujoco_state as ms
from benchmark.tasks import load_registry

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"
TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_stove"
N_SEEDS = int(sys.argv[2]) if len(sys.argv) > 2 else 10
SHIFT = float(sys.argv[3]) if len(sys.argv) > 3 else 0.22

NUM_CHUNK = 8
MAX_STEPS = 320
EARLY = 100   # 只看前 100 步的"早期伸手"

VIDEO_DIR = Path("/HUBU-AI004/zp/ICML/results/m1/control_B/videos")
VIDEO_DIR.mkdir(parents=True, exist_ok=True)

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key=spec.suite,
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=NUM_CHUNK,
)
print(f"[ctrlB] task={TASK} n={N_SEEDS} shift={SHIFT}m", flush=True)


def eef_pos(arena) -> np.ndarray:
    return np.asarray(
        arena._env.sim.data.get_body_xpos("robot0_right_hand"), dtype=np.float64
    )


def try_place(arena, seed: int, prior: np.ndarray, shift: float):
    """把碗移到离先验位置 shift 米处，返回 (state, new_pos) 或 None。

    依次尝试多个方向，取第一个"能稳稳放在桌上且不满足 predicate"的。
    """
    table_z = float(prior[2])
    for ang_deg in (90, 135, 45, 180, 0, -90, -135, -45):
        ang = np.deg2rad(ang_deg)
        new_xy = prior[:2] + shift * np.array([np.cos(ang), np.sin(ang)])
        tgt = [float(new_xy[0]), float(new_xy[1]), table_z]

        st = ms.set_object_pos(arena.get_state(), arena.model, spec.subject, tgt)
        st = ms.clear_all_velocities(st, ms.StateLayout.from_model(arena.model))
        arena.set_state(st, settle_steps=25)
        pos = arena.entity_pos(spec.subject)

        slid = float(np.linalg.norm(pos[:2] - new_xy))
        if slid > 0.05:            # 没放稳（滑走/掉下）
            continue
        if arena.goal_satisfied():  # 意外满足了目标
            continue
        return arena.get_state(), pos.copy(), ang_deg, slid
    return None


results = []
for seed in range(N_SEEDS):
    # 1) 官方初始状态 —— 记录"先验位置"
    arena.reset(official_init_index=seed)
    prior = arena.entity_pos(spec.subject).copy()

    # 2) 把碗挪到一个新位置
    placed = try_place(arena, seed, prior, SHIFT)
    if placed is None:
        print(f"[ctrlB] seed={seed}: 找不到合适的放置位置，跳过", flush=True)
        continue
    st, actual, ang, slid = placed
    arena.set_state(st, settle_steps=0)
    arena.mark_episode_start()

    shift_vec = actual[:2] - prior[:2]
    print(
        f"\n[ctrlB] seed={seed}  先验={np.round(prior,4).tolist()}  "
        f"新位置={np.round(actual,4).tolist()}  "
        f"实际位移={np.linalg.norm(shift_vec):.4f}m (方向{ang}°)  滑移={slid:.4f}  "
        f"satisfied={arena.goal_satisfied()}",
        flush=True,
    )

    # 3) 跑策略，记录 eef 与到两个位置的最近距离
    policy.reset()
    queue: list = []
    eef_start = eef_pos(arena)
    frames: list = []
    _f0 = arena.render_frame()
    if _f0 is not None:
        frames.append(_f0)
    min_prior = min_actual = 1e9
    early_min_prior = early_min_actual = 1e9
    step_prior = step_actual = -1
    first_reach_dir = None
    eef_at_first_close = None
    step_first_close = -1
    steps = 0
    success = False

    while steps < MAX_STEPS:
        if not queue:
            obs = arena.get_observation()
            chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
            if chunk.ndim == 1:
                chunk = chunk.reshape(1, -1)
            queue.extend(list(chunk[:NUM_CHUNK]))
        a = queue.pop(0)
        # 在 step 之前判断这条动作是否是"命令闭合"（约定 +1 = 合）
        if eef_at_first_close is None and float(np.asarray(a).reshape(-1)[-1]) > 0.5:
            eef_at_first_close = eef_pos(arena).copy()
            step_first_close = steps + 1

        res = arena.step(a)
        steps += 1
        fr = arena.render_frame()
        if fr is not None:
            frames.append(fr)

        e = eef_pos(arena)
        dp = float(np.linalg.norm(e - prior))
        da = float(np.linalg.norm(e - actual))
        if dp < min_prior:
            min_prior, step_prior = dp, steps
        if da < min_actual:
            min_actual, step_actual = da, steps
        if steps <= EARLY:
            if dp < early_min_prior:
                early_min_prior = dp
            if da < early_min_actual:
                early_min_actual = da
            if first_reach_dir is None and np.linalg.norm(e - eef_start) > 0.05:
                first_reach_dir = e - eef_start
        if res.done:
            success = True
            break

    # 初始伸手方向 vs 两个目标方向
    cos_prior = cos_actual = float("nan")
    if first_reach_dir is not None:
        v = first_reach_dir
        for name, tgt in (("prior", prior), ("actual", actual)):
            w = tgt - eef_start
            c = float(np.dot(v, w) / (np.linalg.norm(v) * np.linalg.norm(w) + 1e-12))
            if name == "prior":
                cos_prior = c
            else:
                cos_actual = c

    # "它认为碗在哪"：首次命令闭合时的 eef 到两个位置的距离
    if eef_at_first_close is not None:
        fc_prior = float(np.linalg.norm(eef_at_first_close - prior))
        fc_actual = float(np.linalg.norm(eef_at_first_close - actual))
    else:
        fc_prior = fc_actual = float("nan")

    verdict = "先验" if early_min_prior < early_min_actual else "实际"
    results.append((seed, early_min_prior, early_min_actual, min_prior, min_actual,
                    cos_prior, cos_actual, success, fc_prior, fc_actual, step_first_close))

    print(
        f"        早期({EARLY}步内)最近: 先验={early_min_prior:.4f}  实际={early_min_actual:.4f}  -> 更近【{verdict}】\n"
        f"        全程序最近:          先验={min_prior:.4f}(第{step_prior}步)  "
        f"实际={min_actual:.4f}(第{step_actual}步)\n"
        f"        首次命令闭合(第{step_first_close}步) 时 eef 距: 先验={fc_prior:.4f}  实际={fc_actual:.4f}"
        f"  -> 它认为碗在【{'先验' if fc_prior < fc_actual else '实际'}】\n"
        f"        success={success} steps={steps}",
        flush=True,
    )

    # 录像：文件名编码关键判读结果，便于按现象挑片子
    if frames:
        believes = "prior" if fc_prior < fc_actual else "actual"
        earlyv = "prior" if early_min_prior < early_min_actual else "actual"
        name = (
            f"{TASK}__shift{int(SHIFT*100)}cm__s{seed:03d}"
            f"__believes-{believes}__early-{earlyv}"
            f"__dprior{fc_prior:.2f}__dactual{fc_actual:.2f}"
            f"__success{int(success)}.mp4"
        )
        try:
            import imageio.v2 as iio

            with iio.get_writer(VIDEO_DIR / name, fps=20, macro_block_size=1) as w:
                for _f in frames:
                    w.append_data(_f)
            print(f"        video -> {name}", flush=True)
        except Exception as _e:  # noqa: BLE001
            print(f"        video FAILED: {type(_e).__name__}: {_e}", flush=True)

print("\n" + "=" * 78, flush=True)
if results:
    ep = np.array([r[1] for r in results])
    ea = np.array([r[2] for r in results])
    fp = np.array([r[8] for r in results], dtype=float)
    fa = np.array([r[9] for r in results], dtype=float)
    n_prior = int((ep < ea).sum())
    ok = ~np.isnan(fp)
    n_fc_prior = int((fp[ok] < fa[ok]).sum()) if ok.any() else 0
    print(f"[ctrlB] 汇总 n={len(results)}", flush=True)
    print(f"  早期(100步)更靠近【先验】: {n_prior}/{len(results)}", flush=True)
    print(f"  首次闭合时更靠近【先验】: {n_fc_prior}/{int(ok.sum())}  <- 最直接的指标", flush=True)
    print(f"  早期最近距离  先验 mean={ep.mean():.4f}  实际 mean={ea.mean():.4f}", flush=True)
    if ok.any():
        print(f"  首次闭合距离  先验 mean={np.nanmean(fp):.4f}  实际 mean={np.nanmean(fa):.4f}", flush=True)
    print(f"  任务成功率: {sum(1 for r in results if r[7])}/{len(results)}  <- 正常 unsatisfied 是 ~96%", flush=True)
arena.close()
print("[ctrlB] done", flush=True)
