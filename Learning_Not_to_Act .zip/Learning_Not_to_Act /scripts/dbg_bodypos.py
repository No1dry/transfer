import sys
import numpy as np
sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms

arena = LiberoArena(task_suite_name="libero_goal", task_id=1,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1", target="flat_stove_1_main", residual_kind="placement")
arena.reset(official_init_index=0)
arena.set_state(arena.get_state(), settle_steps=10)

tgt = "flat_stove_1_main"
try:
    bid = ms.find_body_id(arena.model, tgt)
    print("find_body_id ->", bid, flush=True)
    nm = ms.body_name(arena.model, bid)
    print("body_name    ->", repr(nm), flush=True)
    sim = arena._env.sim
    print("has get_body_xpos:", hasattr(sim.data, "get_body_xpos"), flush=True)
    try:
        v = sim.data.get_body_xpos(nm)
        print("get_body_xpos(name) ->", np.round(np.asarray(v), 4).tolist(), flush=True)
    except Exception as e:
        print("get_body_xpos(name) RAISED:", type(e).__name__, e, flush=True)
    try:
        print("body_name2id  ->", sim.model.body_name2id(nm), flush=True)
    except Exception as e:
        print("body_name2id RAISED:", type(e).__name__, e, flush=True)
    print("entity_pos   ->", np.round(arena.entity_pos(tgt), 4).tolist(), flush=True)
    print("_body_pos    ->", np.round(arena._body_pos(tgt), 4).tolist(), flush=True)
    # 再列出所有含 stove 的 body 名
    names = [n for n in ms.all_body_names(arena.model) if "stove" in n]
    print("stove bodies :", names, flush=True)
    for n in names:
        try:
            print("   ", n, np.round(np.asarray(sim.data.get_body_xpos(n)), 4).tolist(), flush=True)
        except Exception as e:
            print("   ", n, "ERR", e, flush=True)
except Exception as e:
    import traceback; traceback.print_exc()
arena.close()
