"""找出"fixture 世界坐标"的正确读法。

背景：benchmark 需要知道 stove / plate 等目标的世界位置，才能把 subject 放上去。
实测 robosuite 的 data.xpos 对 fixture 返回 [0,0,0]（不是世界坐标），
导致 bowl_on_stove 的 satisfied 构造把碗放到了桌子原点。

本脚本对比几种读法，找出正确的那个。
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=1,  # put_the_bowl_on_the_stove
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="flat_stove_1_main",
    residual_kind="placement",
)
arena.reset(official_init_index=0)
arena.set_state(arena.get_state(), settle_steps=15)

sim = arena._env.sim
raw_model = arena.model
raw_data = arena._data

names = ["akita_black_bowl_1_main", "flat_stove_1_main", "flat_stove_1_burner",
         "table", "wooden_cabinet_1_main", "plate_1_main"]

print("=== 各种读法对比 ===")
for nm in names:
    row = {"name": nm}
    # 1) robosuite sim.data.get_body_xpos
    try:
        row["sim.data.get_body_xpos"] = np.round(sim.data.get_body_xpos(nm), 4).tolist()
    except Exception as e:
        row["sim.data.get_body_xpos"] = f"ERR {type(e).__name__}"
    # 2) robosuite sim.data.body_xpos 索引
    try:
        idx = sim.model.body_name2id(nm)
        row["sim.data.body_xpos[i]"] = np.round(sim.data.body_xpos[idx], 4).tolist()
    except Exception as e:
        row["sim.data.body_xpos[i]"] = f"ERR {type(e).__name__}"
    # 3) 原始 mujoco data.xpos
    try:
        from benchmark.states import mujoco_state as ms

        idx = ms.find_body_id(raw_model, nm)
        row["raw data.xpos[i]"] = np.round(np.asarray(raw_data.xpos)[idx], 4).tolist()
    except Exception as e:
        row["raw data.xpos[i]"] = f"ERR {type(e).__name__}"
    # 4) 原始 mujoco 的 body 全局位姿（用 mj_forward 后读 xpos）
    print(f"  {nm}")
    for k, v in row.items():
        if k != "name":
            print(f"      {k:26s} = {v}")

print()
print("=== 结论判断 ===")
print("  若 sim.data.get_body_xpos 给出非零且合理的值，就用它作为 fixture 世界坐标。")

arena.close()
