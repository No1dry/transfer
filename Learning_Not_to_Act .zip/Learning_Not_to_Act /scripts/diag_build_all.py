"""修复 _body_pos 之后，直接测 builder 在各 task 上的 satisfied 构造成功率。"""
import sys
from pathlib import Path

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
builder = StateBuilder(settle_steps=15)

N = 6

for spec in reg:
    arena = LiberoArena(
        task_suite_name=spec.suite,
        task_id=spec.task_id,
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        subject=spec.subject,
        target=spec.target,
        joint_name=(spec.edit or {}).get("joint_name"),
        residual_kind=spec.residual_kind,
    )

    # 顺带报告目标锚点（验证 _body_pos 修好没有）
    try:
        anchor = arena._target_anchor(arena, spec, spec.target) if spec.target else None
        if anchor is not None:
            import numpy as np

            print(f"[{spec.id}] target anchor = {np.round(anchor, 4).tolist()}", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[{spec.id}] anchor err: {type(e).__name__}: {e}", flush=True)

    for cond in ("satisfied", "unsatisfied"):
        ok = 0
        for seed in range(N):
            r = builder.build_state(arena, spec, cond, seed)
            if r.ok:
                ok += 1
        print(f"[{spec.id}] {cond:12s} {ok}/{N}", flush=True)
    arena.close()

print("done", flush=True)
