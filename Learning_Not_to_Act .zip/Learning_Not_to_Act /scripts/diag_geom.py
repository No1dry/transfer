"""诊断 2：打印真实几何/坐标，找出正确的"放到盘子上"的 z。"""
import sys

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="plate_1",
    residual_kind="placement",
)
model, data = arena.model, arena._data

arena.reset(official_init_index=0)
arena.set_state(arena.get_state(), settle_steps=20)

st = arena.get_state()
bowl = ms.get_object_pos(st, model, "akita_black_bowl_1")
plate = ms.get_object_pos(st, model, "plate_1")
print(f"settled: bowl={np.round(bowl,4)}  plate={np.round(plate,4)}  satisfied={arena.goal_satisfied()}")

# 每个 body 的 geom 世界坐标
from benchmark.states.mujoco_state import _id2name

for name in ("table", "akita_black_bowl_1_main", "plate_1_main"):
    try:
        bid = ms.find_body_id(model, name)
    except KeyError as e:
        print(f"  {name}: {e}")
        continue
    print(f"--- body {name} (id={bid}) xpos={np.round(data.xpos[bid],4)}")
    for g in range(model.ngeom):
        if ms.geom_bodyid(model, g) != bid:
            continue
        gname = _id2name(model, 'geom', g)
        print(
            f"    geom[{g:3d}] {str(gname):34s} type={ms.geom_type(model, g)} "
            f"xpos={np.round(data.geom_xpos[g],4)} rbound={ms.geom_rbound(model, g):.4f}"
        )

# 地面/桌面高度猜测：把碗往下放，看它停在哪
print("--- 让碗自由落到桌面，测出真实静止 z ---")
saved = arena.get_state()
try:
    st2 = ms.set_object_pos(saved, model, "akita_black_bowl_1", [plate[0], plate[1], plate[2] + 0.05])
    st2 = ms.clear_all_velocities(st2, ms.StateLayout.from_model(model))
    arena.set_state(st2, settle_steps=60)
    rest = ms.get_object_pos(arena.get_state(), model, "akita_black_bowl_1")
    print(f"  bowl 从 plate_z+0.05 落下后静止于 z={rest[2]:.4f}  xy={np.round(rest[:2],4)}")
    print(f"  -> 碗底 = z - half_height；若碗半高={0.5*(ms.geom_vertical_extent(model,data,ms.find_body_id(model,'akita_black_bowl_1'))[1]-ms.geom_vertical_extent(model,data,ms.find_body_id(model,'akita_black_bowl_1'))[0]):.4f}")
    print(f"  satisfied={arena.goal_satisfied()} residual={arena.residual():.4f}")
finally:
    arena.set_state(saved, settle_steps=0)

# 关键对比：直接读 predicate 会用什么
print("--- 直接调用 env.check_success() 前的状态 ---")
print("  arena.goal_satisfied():", arena.goal_satisfied())

arena.close()
