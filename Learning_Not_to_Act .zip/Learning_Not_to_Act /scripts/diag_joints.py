"""诊断 3：为什么两种 condition 的机器人关节不一致。"""
import sys

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms
from benchmark.states.builder import StateBuilder, verify_robot_joints_unchanged
from benchmark.tasks import load_registry

from pathlib import Path
reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]
builder = StateBuilder(settle_steps=15)

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)

layout = ms.StateLayout.from_model(arena.model)
print("nq =", layout.nq, "nv =", layout.nv)

names = [j.name for j in ms.iter_joints(arena.model)][:9]
print("前 9 个关节:", names)

for seed in (0, 1):
    sat = builder.build_state(arena, spec, "satisfied", seed)
    unsat = builder.build_state(arena, spec, "unsatisfied", seed)
    print(f"--- seed {seed}: sat.ok={sat.ok} unsat.ok={unsat.ok}")
    if not (sat.ok and unsat.ok):
        continue
    qa = ms.get_qpos(sat.state, layout)[:9]
    qb = ms.get_qpos(unsat.state, layout)[:9]
    diff = np.abs(qa - qb)
    print("  satisfied   robot qpos:", np.round(qa, 6))
    print("  unsatisfied robot qpos:", np.round(qb, 6))
    print("  max |diff| =", float(diff.max()))
    print("  per-joint diff:", np.round(diff, 6))
    print("  verify_robot_joints_unchanged ->", verify_robot_joints_unchanged(sat.state, unsat.state, arena.model))

    # 也看看自由物体的速度：清速度是否覆盖了所有 dof
    qvel_sat = sat.state[layout.qvel_slice]
    qvel_unsat = unsat.state[layout.qvel_slice]
    print("  qvel max |sat| =", float(np.abs(qvel_sat).max()), " |unsat| =", float(np.abs(qvel_unsat).max()))

arena.close()
