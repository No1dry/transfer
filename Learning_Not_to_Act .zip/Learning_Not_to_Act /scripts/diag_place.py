"""诊断 bowl_on_plate 的 satisfied 构造为何失败（直接打印真实几何量）。"""
import numpy as np
from libero.libero import benchmark

import sys

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms

b = benchmark.get_benchmark_dict()
ts = b["libero_goal"]()

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="plate_1",
    residual_kind="placement",
)

model, data = arena.model, arena._data

print("=" * 70)
for idx in (0, 1):
    print(f"--- official init index {idx} ---")
    arena.reset(official_init_index=idx)
    st = arena.get_state()
    bowl = ms.get_object_pos(st, model, "akita_black_bowl_1")
    plate = ms.get_object_pos(st, model, "plate_1")
    print(f"  after reset: bowl={np.round(bowl,4)} plate={np.round(plate,4)} satisfied={arena.goal_satisfied()}")

    # settle
    arena.set_state(st, settle_steps=15)
    st2 = arena.get_state()
    bowl2 = ms.get_object_pos(st2, model, "akita_black_bowl_1")
    plate2 = ms.get_object_pos(st2, model, "plate_1")
    print(f"  after settle: bowl={np.round(bowl2,4)} plate={np.round(plate2,4)} satisfied={arena.goal_satisfied()}")

    # 几何测量
    sb = ms.find_body_id(model, "akita_black_bowl_1")
    pb = ms.find_body_id(model, "plate_1")
    print(f"  body ids: bowl={sb} plate={pb}")
    b_min, b_max, b_c = ms.geom_vertical_extent(model, data, sb)
    p_min, p_max, p_c = ms.geom_vertical_extent(model, data, pb)
    print(f"  bowl  z extent: [{b_min:.4f}, {b_max:.4f}] half={0.5*(b_max-b_min):.4f}")
    print(f"  plate z extent: [{p_min:.4f}, {p_max:.4f}] half={0.5*(p_max-p_min):.4f}")
    z, top = ms.suggest_resting_z(model, data, "akita_black_bowl_1", "plate_1", clearance=0.002)
    print(f"  suggest_resting_z -> z={z:.4f} (target_top={top:.4f})")

    # 尝试放置
    new = ms.set_object_pos(st2, model, "akita_black_bowl_1", [plate2[0], plate2[1], z])
    new = ms.clear_all_velocities(new, ms.StateLayout.from_model(model))
    arena.set_state(new, settle_steps=15)
    st3 = arena.get_state()
    bowl3 = ms.get_object_pos(st3, model, "akita_black_bowl_1")
    print(f"  after place+settle: bowl={np.round(bowl3,4)} satisfied={arena.goal_satisfied()} residual={arena.residual():.4f}")
    print(f"  bowl displacement during settle: {np.linalg.norm(bowl3 - np.array([plate2[0], plate2[1], z])):.4f}")

    # 直接读 predicate 内部
    try:
        print("  check_success():", arena._env.check_success())
    except Exception as e:
        print("  check_success err:", e)

arena.close()
