"""诊断 bowl_on_stove 的 satisfied 构造：暴力搜索能否让 predicate 成立。

目的：区分两种可能
  (a) predicate 根本没法通过"放置碗"来满足（我对目标的理解错了）
  (b) 只是我搜索的 z / xy 范围不够
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_stove"]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)
model = arena.model

arena.reset(official_init_index=0)
base = arena.get_state()
arena.set_state(base, settle_steps=15)
base = arena.get_state()

subject = spec.subject
s0 = ms.get_object_pos(base, model, subject)
print(f"subject 初始位置: {np.round(s0, 4)}")
print(f"目标 body      : {spec.target}")
try:
    tid = ms.find_body_id(model, spec.target)
    print(f"target body id : {tid}")
except Exception as e:
    print("target find err:", e)

# 目标锚点（与 builder 一致）
try:
    tgt = ms.get_object_pos(arena.get_state(), model, spec.target)
except KeyError:
    tgt = None
if tgt is None:
    data = arena._data
    tid = ms.find_body_id(model, spec.target)
    tgt = np.asarray(data.xpos[tid], dtype=float)
print(f"目标锚点       : {np.round(tgt, 4)}")

print()
print("=== 暴力搜索: 以目标 xy 为中心，扫 z 与 xy 偏移 ===")
found = []
for dz in (0.0, 0.02, 0.05, 0.08, 0.12, 0.16, 0.20, 0.25, 0.30):
    for dx in (0.0, -0.05, 0.05, -0.10, 0.10):
        for dy in (0.0, -0.05, 0.05):
            pos = [float(tgt[0] + dx), float(tgt[1] + dy), float(s0[2] + dz)]
            st = ms.set_object_pos(base, model, subject, pos)
            st = ms.clear_all_velocities(st, ms.StateLayout.from_model(model))
            arena.set_state(st, settle_steps=6)
            ok = bool(arena.goal_satisfied())
            if ok:
                fin = ms.get_object_pos(arena.get_state(), model, subject)
                found.append((dz, dx, dy, np.round(fin, 4).tolist()))
                print(f"  OK  dz={dz:.2f} dx={dx:+.2f} dy={dy:+.2f} -> settled {np.round(fin,4)}")

print()
print(f"命中 {len(found)} 个组合")
if not found:
    print("=> 放置方式无法满足 predicate，说明该 task 的成功条件不是简单的'碗放在炉子上'")
    print("   或者目标 body 选错了。需要检查 BDDL 的 goal 与 flat_stove 的 region 结构。")

arena.close()
