"""抽取两种行为模式的代表帧：
   seed 5: first_close=46  （较早尝试抓取）
   seed 3: first_close=None（300 步从不闭合）
"""
import glob
import imageio.v2 as iio

for seed, picks in ((5, [0, 46, 120, 300]), (3, [0, 150, 300])):
    fs = glob.glob(f"results/m1/final/videos/*bowl_on_plate__satisfied__s{seed:03d}*.mp4")
    if not fs:
        print("missing seed", seed); continue
    r = iio.get_reader(fs[0])
    n = r.count_frames()
    for p in picks:
        if p >= n:
            continue
        fr = r.get_data(p)
        iio.imwrite(f"/tmp/s{seed}_f{p:03d}.png", fr)
        print(f"seed{seed} frame {p:3d} -> /tmp/s{seed}_f{p:03d}.png shape={fr.shape} mean={int(fr.mean())}")
    r.close()
