"""从 satisfied episode 视频里抽取关键帧，用于人工核对画面内容。"""
import glob
import imageio.v2 as iio
import numpy as np

fs = sorted(glob.glob("results/m1/final/videos/*bowl_on_plate__satisfied__s000*.mp4"))
assert fs, "video not found"
f = fs[0]
r = iio.get_reader(f)
n = r.count_frames()
# 关键帧：起点 / 首次闭合(112) / 闭合中 / 末尾
picks = [0, 60, 112, 160, 220, 300]
picks = [p for p in picks if p < n]
out = []
for p in picks:
    fr = r.get_data(p)
    iio.imwrite(f"/tmp/frame_{p:03d}.png", fr)
    out.append((p, fr.shape, int(fr.mean())))
r.close()
print("video:", f.split("/")[-1], "frames:", n)
for p, shp, mean in out:
    print(f"  saved frame_{p:03d}.png  shape={shp} mean={mean}")
