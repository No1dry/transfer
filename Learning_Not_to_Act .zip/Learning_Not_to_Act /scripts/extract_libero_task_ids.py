"""从 LIBERO 官方 `libero_suite_task_map.py` 提取权威 task_id。

为什么需要这个脚本
------------------
`task_suite.get_task(task_id)` 的 task_id 是 **task 在该 suite 列表中的下标**。
手写 task_id 极易出错（并且 LIBERO 各版本的任务顺序可能变动），所以这里
不手写，而是解析 LIBERO 官方源码，生成一份可追溯的 JSON。

来源
----
https://github.com/Lifelong-Robot-Learning/LIBERO
  libero/libero/benchmark/libero_suite_task_map.py
仓库快照已存于 data/libero_suite_task_map.source.py（含 commit 信息见下）。

用法
----
    python scripts/extract_libero_task_ids.py
    # 或指定本地 LIBERO 安装路径（GPU 机器上更可靠）
    python scripts/extract_libero_task_ids.py --libero_root /path/to/LIBERO

后者会优先从已安装的 LIBERO 包中读取，保证与实际运行环境一致。
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]

# LIBERO 官方仓库中该文件的相对路径（仓库根 -> 文件）
LIBERO_REL_PATH = Path("libero/libero/benchmark/libero_suite_task_map.py")

# 本项目 Fast 版本绑定的上游 commit。若为空字符串，表示使用快照文件。
LIBERO_SNAPSHOT_COMMIT = ""  # 由 --libero_commit 覆盖


def _parse_task_map(src: str) -> dict[str, list[str]]:
    """从 `libero_task_map = {...}` 源码中解析出 suite -> [task_name] 映射。

    使用 ast.literal_eval 而非 eval，确保不会执行任意代码。
    """
    match = re.search(r"libero_task_map\s*=\s*(\{.*?\n\})", src, re.DOTALL)
    if match is None:
        raise ValueError(
            "在源码中找不到 `libero_task_map = { ... }`。"
            "请确认这是 LIBERO 的 libero_suite_task_map.py。"
        )
    task_map = ast.literal_eval(match.group(1))
    if not isinstance(task_map, dict):
        raise ValueError(f"libero_task_map 应为 dict，实际为 {type(task_map)}")
    for suite, tasks in task_map.items():
        if not isinstance(tasks, list) or not all(isinstance(t, str) for t in tasks):
            raise ValueError(f"suite `{suite}` 的值应为 list[str]")
    return task_map


def _find_source_file(libero_root: Path | None) -> tuple[Path, str]:
    """定位 task map 源文件，返回 (路径, 来源标记)。"""
    if libero_root is not None:
        candidate = libero_root / LIBERO_REL_PATH
        if candidate.is_file():
            return candidate, f"installed_libero:{libero_root}"
        # 也允许直接指向包目录
        candidate = libero_root / "benchmark" / "libero_suite_task_map.py"
        if candidate.is_file():
            return candidate, f"installed_libero:{libero_root}"
        raise FileNotFoundError(
            f"在 {libero_root} 下找不到 {LIBERO_REL_PATH}。"
            "请传入 LIBERO 仓库根目录（含 libero/ 子目录）。"
        )

    snapshot = REPO_ROOT / "data" / "libero_suite_task_map.source.py"
    if not snapshot.is_file():
        raise FileNotFoundError(
            f"找不到快照文件 {snapshot}。请用 --libero_root 指向本地 LIBERO 安装。"
        )
    return snapshot, "bundled_snapshot"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--libero_root",
        type=Path,
        default=None,
        help="LIBERO 仓库根目录。省略则使用 data/ 下的快照文件。",
    )
    parser.add_argument(
        "--libero_commit",
        type=str,
        default=LIBERO_SNAPSHOT_COMMIT,
        help="可选：记录上游 commit，便于追溯。",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=REPO_ROOT / "data" / "libero_task_ids.json",
        help="输出 JSON 路径。",
    )
    args = parser.parse_args(argv)

    src_path, source_kind = _find_source_file(args.libero_root)
    raw = src_path.read_text(encoding="utf-8")
    task_map = _parse_task_map(raw)

    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_kind": source_kind,
        "source_file": str(src_path),
        "source_sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
        "libero_commit": args.libero_commit or None,
        "note": (
            "task_id 即 task 在该 suite 列表中的下标，与 task_suite.get_task(task_id) 一致。"
            "请勿手写 task_id。"
        ),
        "suites": {
            suite: {str(i): name for i, name in enumerate(tasks)}
            for suite, tasks in task_map.items()
        },
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"[ok] source      : {source_kind} -> {src_path}")
    print(f"[ok] sha256      : {payload['source_sha256'][:16]}...")
    print(f"[ok] wrote       : {args.out}")
    for suite, tasks in task_map.items():
        print(f"     {suite:16s} n={len(tasks)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
