"""抽取 object_in_basket 的 unsatisfied 视频关键帧，确认画面合理。"""
import glob
import imageio.v2 as iio

fs = sorted(glob.glob("results/m1/final/videos/*object_in_basket__unsatisfied__s000*.mp4"))
if not fs:
    print("no video yet for object_in_basket s000")
    fs = sorted(glob.glob("results/m1/final/videos/*object_in_basket*.mp4"))
    print("available:", [f.split("/")[-1] for f in fs])
else:
    r = iio.get_reader(fs[0])
    n = r.count_frames()
    print("video:", fs[0].split("/")[-1], "frames:", n)
    for p in (0, 49, 120, 190):
        if p >= n:
            continue
        fr = r.get_data(p)
        iio.imwrite(f"/tmp/ob_f{p:03d}.png", fr)
        print(f"  frame {p:3d} saved mean={int(fr.mean())}")
    r.close()
