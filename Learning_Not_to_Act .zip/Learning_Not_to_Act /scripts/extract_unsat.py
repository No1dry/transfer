"""抽取 unsatisfied episode 的关键帧，确认"任务真的被完成了"。"""
import glob
import imageio.v2 as iio

fs = sorted(glob.glob("results/m1/final/videos/*bowl_on_plate__unsatisfied__s000*.mp4"))
assert fs, "not found"
r = iio.get_reader(fs[0])
n = r.count_frames()
print("video:", fs[0].split("/")[-1], "frames:", n)
for p in (0, 36, 49, 90, 135, 195):
    if p >= n:
        continue
    fr = r.get_data(p)
    iio.imwrite(f"/tmp/u_f{p:03d}.png", fr)
    print(f"  frame {p:3d} saved mean={int(fr.mean())}")
r.close()
