"""从 trace 视频里抽若干帧存成 PNG，用于快速目视检查叠加信息是否正确。

用法:
    ./run_diag.sh scripts/grab_video_frames.py <video> <out_dir> [n_frames]
"""
import sys
from pathlib import Path

import imageio.v2 as imageio
import numpy as np

vid = Path(sys.argv[1])
out = Path(sys.argv[2] if len(sys.argv) > 2 else "/tmp/frames")
n = int(sys.argv[3]) if len(sys.argv) > 3 else 3
out.mkdir(parents=True, exist_ok=True)

r = imageio.get_reader(str(vid))
meta = r.get_meta_data()
try:
    nframes = r.count_frames()
except Exception:  # noqa: BLE001
    nframes = int(meta.get("duration", 0) * meta.get("fps", 20))
print(f"[frames] {vid.name}  nframes={nframes}  fps={meta.get('fps')}  size={meta.get('size')}")

idxs = [int(nframes * (i + 1) / (n + 1)) for i in range(n)]
for k, i in enumerate(idxs):
    try:
        fr = r.get_data(i)
    except Exception as e:  # noqa: BLE001
        print(f"  frame {i} failed: {e}")
        continue
    p = out / f"{vid.stem}__f{i:04d}.png"
    imageio.imwrite(p, np.asarray(fr))
    print(f"  wrote {p}")
r.close()
