"""隔离测试：用**官方初始状态**跑我的 adapter，判断流水线是否真的能成功。

与 Mini-PAB 的区别只有一个：初始状态来自 LIBERO 官方 init state，
而不是我们构造的 12cm 圆。这样可以区分两种失败：
  (a) 我的 adapter / harness 有问题  -> 官方初始状态也做不成
  (b) 只是 12cm 起始位置更难          -> 官方初始状态能做成
"""
import sys
import time

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="plate_1",
    residual_kind="placement",
)

policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key="libero_goal",
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=8,
)
print("[iso] model loaded", flush=True)

NUM_ACTIONS_CHUNK = 8
MAX_QUERIES = 40

for idx in range(4):
    t0 = time.time()
    arena.reset(official_init_index=idx)
    print(
        f"[iso] init idx={idx}: satisfied={arena.goal_satisfied()} "
        f"residual={arena.residual():.4f}",
        flush=True,
    )

    policy.reset()
    queue: list[np.ndarray] = []
    steps = 0
    success = False
    while steps < MAX_QUERIES * NUM_ACTIONS_CHUNK:
        if not queue:
            obs = arena.get_observation()
            chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
            if chunk.ndim == 1:
                chunk = chunk.reshape(1, -1)
            queue.extend(list(chunk[:NUM_ACTIONS_CHUNK]))
        a = queue.pop(0)
        res = arena.step(a)
        steps += 1
        if res.done:
            success = True
            break

    print(
        f"[iso] idx={idx}: SUCCESS={success} steps={steps} "
        f"final_sat={arena.goal_satisfied()} residual={arena.residual():.4f} "
        f"({time.time() - t0:.0f}s)",
        flush=True,
    )

arena.close()
print("[iso] done", flush=True)
