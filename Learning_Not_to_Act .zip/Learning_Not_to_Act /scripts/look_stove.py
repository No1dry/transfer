"""看 bowl_on_stove satisfied 的实际画面 + 打印碗/炉子的真实位置。"""
import glob
import sys

import imageio.v2 as iio
import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

fs = sorted(glob.glob("results/m1/final/videos/*bowl_on_stove__satisfied__s000*.mp4"))
assert fs, "no video"
r = iio.get_reader(fs[0])
n = r.count_frames()
print("video:", fs[0].split("/")[-1], "frames:", n, flush=True)
for p in (0, 45, 120, 300):
    if p < n:
        iio.imwrite(f"/tmp/st_f{p:03d}.png", r.get_data(p))
        print(f"  saved frame {p}", flush=True)
r.close()

# 打印 satisfied 状态下各物体的真实位置
from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry
from pathlib import Path

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_stove"]
arena = LiberoArena(task_suite_name=spec.suite, task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject, target=spec.target, residual_kind=spec.residual_kind)
b = StateBuilder(settle_steps=15)

arena.reset(official_init_index=0)
prior = arena.entity_pos(spec.subject).copy()
r_ = b.build_state(arena, spec, "satisfied", 0)
arena.set_state(r_.state, settle_steps=0)
actual = arena.entity_pos(spec.subject).copy()

sim = arena._env.sim
for nm in ("flat_stove_1_main", "flat_stove_1_burner", "flat_stove_1_burner_plate"):
    try:
        print(f"  {nm:28s} = {np.round(sim.data.get_body_xpos(nm),4).tolist()}", flush=True)
    except Exception as e:
        print(f"  {nm}: {e}", flush=True)
print(f"  bowl 先验位置(官方初始)     = {np.round(prior,4).tolist()}", flush=True)
print(f"  bowl 实际位置(satisfied)    = {np.round(actual,4).tolist()}", flush=True)
print(f"  bowl 到 burner 水平距离     = {np.linalg.norm(actual[:2]-np.array(sim.data.get_body_xpos('flat_stove_1_burner')[:2])):.4f} m", flush=True)
print(f"  goal_satisfied              = {arena.goal_satisfied()}", flush=True)
arena.close()
