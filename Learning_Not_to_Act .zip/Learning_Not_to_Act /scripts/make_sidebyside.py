"""把两个 trace 视频并排拼成一个对照视频（左 satisfied / 右 unsatisfied）。

为什么需要：单独看一个视频只能说"它在动"；把"目标已达成"和"需要真正执行"
两种状态放在同一屏、同一步数上，才能一眼看出差别 ——
左边悬在碗上方 10cm 空合爪，右边降下去把碗抓起来。

用法:
    ./run_diag.sh scripts/make_sidebyside.py <left.mp4> <right.mp4> <out.mp4> \
        [--labels SAT,UNSAT] [--fps 20]
"""
import sys
from pathlib import Path

import imageio.v2 as imageio
import numpy as np


def parse_flag(name, default):
    if name in sys.argv:
        return sys.argv[sys.argv.index(name) + 1]
    return default


def put_label(img, text, color=(170, 0, 0), size=13):
    """在画面顶部画一条标题栏（ASCII，服务器无中文字体）。"""
    from PIL import Image, ImageDraw, ImageFont

    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    ]
    font = None
    for p in paths:
        try:
            font = ImageFont.truetype(p, size)
            break
        except Exception:  # noqa: BLE001
            continue
    im = Image.fromarray(img).convert("RGB")
    dr = ImageDraw.Draw(im)
    W = im.size[0]
    h = size + 8
    dr.rectangle([0, 0, W, h], fill=color)
    dr.text((4, 4), text, fill=(255, 255, 255), font=font)
    return np.asarray(im)


def main():
    left, right, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    labels = parse_flag("--labels", "SAT,UNSAT").split(",")
    fps = int(parse_flag("--fps", "20"))

    # 注意：不要用 list(reader) —— imageio 的 ffmpeg reader 在 EOF 之后仍会
    # 继续产出帧，list() 会一路吃到 MemoryError（即使机器有 700G 内存也一样）。
    # 用 count_frames() + get_data(i) 显式按下标取，与 grab_video_frames.py 一致。
    rl, rr = imageio.get_reader(str(left)), imageio.get_reader(str(right))
    nl, nr = rl.count_frames(), rr.count_frames()
    n = min(nl, nr)
    print(f"[stack] {left.name} ({nl}f)  +  {right.name} ({nr}f)  -> use {n}f")

    from PIL import Image

    f0l, f0r = rl.get_data(0), rr.get_data(0)
    w = min(f0l.shape[1], f0r.shape[1])
    if w % 2:
        w -= 1

    def fit(a):
        im = Image.fromarray(a)
        if im.size[0] != w:
            h = int(round(im.size[1] * w / im.size[0]))
            im = im.resize((w, h), Image.BILINEAR)
        return np.asarray(im.convert("RGB"))

    out.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    try:
        with imageio.get_writer(out, fps=fps, macro_block_size=1) as wtr:
            for i in range(n):
                a = put_label(fit(rl.get_data(i)), labels[0], (170, 0, 0))
                b = put_label(
                    fit(rr.get_data(i)),
                    labels[1] if len(labels) > 1 else "",
                    (0, 90, 170),
                )
                h = min(a.shape[0], b.shape[0])
                wtr.append_data(np.concatenate([a[:h], b[:h]], axis=1))
                n_written += 1
        print(f"[stack] wrote {out}  ({n_written} frames)")
    except Exception as e:  # noqa: BLE001
        print(f"[stack] mp4 failed: {type(e).__name__}: {e}")
    finally:
        rl.close()
        rr.close()


if __name__ == "__main__":
    main()
