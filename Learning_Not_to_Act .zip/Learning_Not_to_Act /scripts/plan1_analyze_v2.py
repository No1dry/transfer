"""从 trace 文件**离线**重算 smoke-v2 的全部汇总（mentor_review_2 §7）。

这个脚本只读 `results/plan1/terminal_replay_v2/traces/*.csv`，
不加载模型、不碰仿真。它的存在本身就是 §7 要求的证明：
**所有汇总指标与 event profile 都能从逐 step trace 独立重算**，
而不是只在在线循环里算完就丢掉原序列。

同时给出 policy vs no-op 的 **paired 对照**（§3.4）：
path 长度、反转次数、contact、目标破坏、任务状态改变。

用法: ./run_diag.sh scripts/plan1_analyze_v2.py
"""
from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.event_profile import (  # noqa: E402
    DEFAULT_EVENT_THRESHOLDS,
    compute_event_profile,
    derive_single_label,
)

ROOT = Path("/HUBU-AI004/zp/ICML")
# 默认分析 v3；用 --dir 可指向 v2（对比用）。
import argparse as _ap
_ap_ = _ap.ArgumentParser()
_ap_.add_argument("--dir", default="terminal_replay_v3")
_ARGS, _ = _ap_.parse_known_args()
V2 = ROOT / "results/plan1" / _ARGS.dir
TRACES = V2 / "traces"
OUT = V2 / "offline_analysis.json"

EVENT_KEYS = [
    "reapproached_subject", "reapproached_target", "grasp_commanded",
    "contacted_subject", "contacted_target", "task_state_changed",
    "goal_ever_broken", "oscillatory_motion", "retreated_from_task",
]


def read_trace(path: Path) -> dict[str, list]:
    cols: dict[str, list] = defaultdict(list)
    with path.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            for k, v in row.items():
                if v in ("", "None", None):
                    cols[k].append(None)
                elif k in ("step", "overall_predicate"):
                    cols[k].append(int(float(v)))
                elif k in ("subject_contact", "target_contact"):
                    cols[k].append(v.lower() == "true")
                elif k == "mode":
                    cols[k].append(v)
                else:
                    try:
                        cols[k].append(float(v))
                    except (TypeError, ValueError):
                        cols[k].append(None)
    return dict(cols)


def path_length(xs, ys, zs) -> float:
    """从 trace 的 xyz 序列直接算路径长度（不依赖 arena 的在线累计量）。"""
    pts = [(x, y, z) for x, y, z in zip(xs, ys, zs)
           if None not in (x, y, z)]
    if len(pts) < 2:
        return float("nan")
    a = np.asarray(pts, dtype=np.float64)
    return float(np.linalg.norm(np.diff(a, axis=0), axis=1).sum())


def main() -> int:
    files = sorted(TRACES.glob("*__policy.csv"))
    if not files:
        print(f"[FAIL] {TRACES} 下没有 policy trace")
        return 1

    rows = []
    for pf in files:
        stem = pf.name[: -len("__policy.csv")]
        nf = TRACES / f"{stem}__noop.csv"
        P = read_trace(pf)
        N = read_trace(nf) if nf.exists() else None

        profP = compute_event_profile(P)
        profP["single_label"] = derive_single_label(profP)
        profN = None
        if N is not None:
            profN = compute_event_profile(N)
            profN["single_label"] = derive_single_label(profN)

        def plen(T):
            return path_length(T.get("eef_x", []), T.get("eef_y", []), T.get("eef_z", []))

        def maxdisp(T):
            pts = [(x, y, z) for x, y, z in zip(T.get("eef_x", []), T.get("eef_y", []),
                                                T.get("eef_z", [])) if None not in (x, y, z)]
            if len(pts) < 2:
                return float("nan")
            a = np.asarray(pts, dtype=np.float64)
            return float(np.linalg.norm(a - a[0], axis=1).max())

        task_id, seed_s = stem.rsplit("__s", 1)
        rows.append({
            "task_id": task_id, "seed": int(seed_s), "stem": stem,
            "policy": profP, "noop": profN,
            "policy_path": plen(P), "noop_path": (plen(N) if N else float("nan")),
            "policy_maxdisp": maxdisp(P),
            "noop_maxdisp": (maxdisp(N) if N else float("nan")),
        })

    # ---------------- 逐对明细 ----------------
    print("=" * 118)
    print("policy vs no-op 逐对对照（全部由 trace 离线重算）")
    print("=" * 118)
    hdr = (f"{'task':<20}{'s':>3} | {'label':<12}{'reappr':>7}{'grasp':>6}"
           f"{'c_sub':>6}{'broken':>7}{'osc':>5}{'retreat':>8}{'rev':>5}"
           f" | {'noop':<10}{'noop_rev':>9}{'path':>8}{'noop_path':>10}")
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        e, q = r["policy"]["events"], r["policy"]["quantities"]
        ne = (r["noop"] or {}).get("events", {})
        nq = (r["noop"] or {}).get("quantities", {})
        print(f"{r['task_id']:<20}{r['seed']:>3} | "
              f"{r['policy']['single_label']:<12}"
              f"{str(e['reapproached_subject']):>7}{str(e['grasp_commanded']):>6}"
              f"{str(e['contacted_subject']):>6}{str(e['goal_ever_broken']):>7}"
              f"{str(e['oscillatory_motion']):>5}{str(e['retreated_from_task']):>8}"
              f"{str(q.get('reversals_main')):>5} | "
              f"{(r['noop'] or {}).get('single_label', 'NA'):<10}"
              f"{str(nq.get('reversals_main')):>9}"
              f"{r['policy_path']:>8.2f}{r['noop_path']:>10.2f}")

    # ---------------- 汇总 ----------------
    print("\n" + "=" * 118)
    print("汇总")
    print("=" * 118)
    labels = Counter(r["policy"]["single_label"] for r in rows)
    print(f"policy 单标签分布: {dict(labels)}")
    nlabels = Counter((r["noop"] or {}).get("single_label") for r in rows if r["noop"])
    print(f"no-op  单标签分布: {dict(nlabels)}")

    print("\n事件命中率（policy）:")
    print("   [mentor_review_4 §3.5] oscillatory_motion 仅作**诊断**："
          "5mm 死区下反转中位数为 0，\n"
          "   1mm 判据对微动过敏，因此**不报告单一 wandering/oscillatory rate**；"
          "\n   主结论依赖 task-directed events / task-state change / "
          "goal disturbance / paired control。")
    ev_count = {}
    for k in EVENT_KEYS:
        vals = [r["policy"]["events"].get(k) for r in rows]
        meas = [v for v in vals if v is not None]
        hit = sum(1 for v in meas if v)
        ev_count[k] = {"n_measured": len(meas), "n_hit": hit,
                       "rate": (hit / len(meas)) if meas else None}
        print(f"   {k:<24} {hit}/{len(meas)}"
              + ("" if meas else "   (未测量)"))

    print("\n事件命中率（no-op 对照）:")
    for k in EVENT_KEYS:
        vals = [(r["noop"] or {}).get("events", {}).get(k) for r in rows if r["noop"]]
        meas = [v for v in vals if v is not None]
        hit = sum(1 for v in meas if v)
        print(f"   {k:<24} {hit}/{len(meas)}")

    # ---------------- paired 差 ----------------
    print("\n" + "=" * 118)
    print("paired 差（policy − no-op）")
    print("=" * 118)
    dp = [r["policy_path"] - r["noop_path"] for r in rows
          if not np.isnan(r["noop_path"])]
    dm = [r["policy_maxdisp"] - r["noop_maxdisp"] for r in rows
          if not np.isnan(r["noop_maxdisp"])]
    dr = [(r["policy"]["quantities"].get("reversals_main") or 0)
          - ((r["noop"] or {}).get("quantities", {}).get("reversals_main") or 0)
          for r in rows if r["noop"]]
    for name, arr in (("eef_path_length", dp), ("eef_max_displacement", dm),
                      ("reversals(1mm)", dr)):
        if arr:
            a = np.asarray(arr, dtype=np.float64)
            print(f"   {name:<22} median={np.median(a):+.4f}  "
                  f"min={a.min():+.4f}  max={a.max():+.4f}  n={a.size}")

    print("\n反转死区敏感度（policy，§3.3 要求三档同时报）:")
    for band in ("1mm", "2mm", "5mm"):
        vals = [r["policy"]["quantities"]["reversals"].get(band) for r in rows]
        vals = [v for v in vals if v is not None]
        if vals:
            print(f"   {band:<5} median={np.median(vals):.1f}  "
                  f"range=[{min(vals)}, {max(vals)}]")

    # ---------------- transient goal（§2.4）----------------
    print("\n" + "=" * 118)
    print("Transient Goal Disturbance（endpoint GDR 会漏掉的那些）")
    print("=" * 118)
    tgdr = 0
    for r in rows:
        t = r["policy"]["quantities"]["transient_goal"]
        if t.get("ever_broken"):
            tgdr += 1
            print(f"   {r['task_id']:<20} s{r['seed']}  first_break@{t['first_break_step']}  "
                  f"broken_steps={t['broken_steps']}  "
                  f"max_consec={t['max_consecutive_broken_steps']}  "
                  f"recovered={t['recovered_at_final']}")
    from benchmark.event_profile import t_gdr_severity

    # ---- mentor_review_4 §3.4：endpoint GDR 与 T-GDR 必须**同时**明确输出 ----
    def final_pred(T):
        vals = [v for v in T.get("overall_predicate", []) if v is not None]
        return vals[-1] if vals else None

    def init_pred(T):
        vals = [v for v in T.get("overall_predicate", []) if v is not None]
        return vals[0] if vals else None

    endpoint_hits = persistent = transient_only = 0
    print("\n   Endpoint GDR vs T-GDR（§3.4：不能只报 T-GDR）:")
    print(f"     {'task':<20}{'s':>3} {'pred0':>6}{'predF':>6}  "
          f"{'ever_broken':>11}{'max_consec':>11}  分类")
    for r in rows:
        T = read_trace(TRACES / f"{r['stem']}__policy.csv")
        p0, pf = init_pred(T), final_pred(T)
        t = r["policy"]["quantities"]["transient_goal"]
        ep = bool(p0 == 1 and pf == 0)
        endpoint_hits += ep
        if ep:
            persistent += 1
            kind = "PERSISTENT (endpoint 已捕获)"
        elif t.get("ever_broken"):
            transient_only += 1
            kind = "TRANSIENT-ONLY (endpoint 漏掉)"
        else:
            kind = "ok"
        print(f"     {r['task_id']:<20}{r['seed']:>3} {str(p0):>6}{str(pf):>6}  "
              f"{str(t.get('ever_broken')):>11}"
              f"{str(t.get('max_consecutive_broken_steps')):>11}  {kind}")
    n = len(rows)
    print(f"\n     endpoint GDR            = {endpoint_hits}/{n} = {endpoint_hits/n:.3f}")
    sev = t_gdr_severity([r["policy"] for r in rows])
    print(f"     T-GDR(any)              = {sev.get('t_gdr_any')}")
    for k in (3, 5, 10):
        print(f"     T-GDR(consec >= {k:<2})     = {sev.get(f't_gdr_consec_ge_{k}')}")
    print(f"     persistent (endpoint)   = {persistent}/{n}")
    print(f"     transient-only          = {transient_only}/{n}   ← T-GDR 相对 endpoint 的**真实增量**")
    print(f"     broken_step_fraction mean = {sev.get('broken_step_fraction_mean')}"
          f"  max = {sev.get('broken_step_fraction_max')}")

    sev_noop = t_gdr_severity([r["noop"] for r in rows if r["noop"]])
    print(f"\n   no-op 对照: T-GDR(any) = {sev_noop.get('t_gdr_any')},"
          f" consec>=3 = {sev_noop.get('t_gdr_consec_ge_3')}")

    # §5.3 approach 连续量 + 三档敏感度（不做同批调参）
    print(f"\n   approach_delta 连续量（§5.3）:")
    for r in rows:
        a = r["policy"]["quantities"].get("approach_sensitivity_subject", {})
        n = (r["noop"] or {}).get("quantities", {}).get("approach_sensitivity_subject", {})
        if not a.get("measured"):
            print(f"     {r['task_id']:<20} s{r['seed']}  policy=NA(articulated)")
            continue
        print(f"     {r['task_id']:<20} s{r['seed']}  policy_delta={a['approach_delta']:+.4f}"
              f"  noop_delta={n.get('approach_delta') if n.get('measured') else 'NA'}"
              f"  levels={a['levels']}")

    OUT.write_text(json.dumps({
        "schema_version": "plan1-terminal-v2-offline",
        "n_pairs": len(rows),
        "event_rates_policy": ev_count,
        "label_counts_policy": dict(labels),
        "label_counts_noop": {str(k): v for k, v in nlabels.items()},
        "endpoint_gdr": (endpoint_hits / len(rows)) if rows else None,
        "t_gdr_any": sev.get("t_gdr_any") if 'sev' in dir() else None,
        "t_gdr_severity": sev if 'sev' in dir() else None,
        "persistent_count": persistent if 'persistent' in dir() else None,
        "transient_only_count": transient_only if 'transient_only' in dir() else None,
        "thresholds": DEFAULT_EVENT_THRESHOLDS.as_dict(),
        "records": [{"task_id": r["task_id"], "seed": r["seed"],
                     "policy": r["policy"], "noop": r["noop"]} for r in rows],
    }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[out] {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
