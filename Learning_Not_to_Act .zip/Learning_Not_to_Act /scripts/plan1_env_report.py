"""Stage 0：环境与基线冻结报告（plan1 §6.1）。

一次性收集：
  - 版本信息（Python / torch / transformers / mujoco / robosuite / LIBERO / numpy）
  - checkpoint 与 dataset_statistics.json 的 key
  - 核心文件 SHA256
  - results/m1/final/metrics.json 摘要
  - 正式 160 JSON / 视频数量
  - 统一 unnorm key 与 action 约定自检

用法:
    ./run_diag.sh scripts/plan1_env_report.py            # 纯 CPU，不加载模型
    ./run_diag.sh scripts/plan1_env_report.py --hash     # 附加核心文件 SHA256
"""
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/HUBU-AI004/zp/ICML")
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"
FINAL = ROOT / "results/m1/final"

WANT_HASH = "--hash" in sys.argv

# 核心文件：任何改动都会影响实验结论，必须留指纹
CORE_FILES = [
    "benchmark/arena/libero.py",
    "benchmark/arena/protocol.py",
    "benchmark/arena/mock.py",
    "benchmark/metrics.py",
    "benchmark/runner.py",
    "benchmark/policy/base.py",
    "benchmark/states/builder.py",
    "benchmark/states/mujoco_state.py",
    "benchmark/manifest.py",
    "benchmark/report.py",
    "benchmark/tasks/registry.py",
    "scripts/run_mini_pab.py",
    "configs/mini_pab.yaml",
]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sh(cmd: str) -> str:
    try:
        return subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=60
        ).stdout.strip()
    except Exception as e:  # noqa: BLE001
        return f"<{type(e).__name__}: {e}>"


print("=" * 78)
print("Stage 0 环境冻结报告")
print("=" * 78)
print(f"采集时间 (UTC) : {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
print(f"主机名         : {platform.node()}")
print(f"平台           : {platform.platform()}")
print(f"CPU 核数       : {sh('nproc')}")

print("\n--- GPU ---")
print(sh("nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used "
         "--format=csv,noheader"))
print("CUDA: " + (sh("nvidia-smi | grep -o 'CUDA Version: [0-9.]*'") or "<未报告>"))

print("\n--- 当前运行进程（应为空，确认 GPU 没被占用）---")
print(sh("ps -eo pid,etime,cmd | grep -E 'run_mini|trace_action|run_libero' "
         "| grep -v grep") or "<无>")

print("\n--- 版本 ---")
print(f"Python       : {sys.version.split()[0]}")
for mod in ("torch", "transformers", "numpy", "mujoco", "robosuite", "imageio", "PIL"):
    try:
        m = __import__(mod)
        print(f"{mod:<13}: {getattr(m, '__version__', '<无 __version__>')}")
    except Exception as e:  # noqa: BLE001
        print(f"{mod:<13}: <导入失败 {type(e).__name__}>")

# LIBERO 版本（无 __version__，用 git 或路径代替）
for cand in (ROOT / "LIBERO", Path("/HUBU-AI004/lgm/openvla-oft/LIBERO")):
    if cand.exists():
        rev = sh(f"cd {cand} && git rev-parse --short HEAD 2>/dev/null")
        print(f"LIBERO       : {cand}  git={rev or '<非 git>'}")
        break

print("\n--- checkpoint ---")
print(f"路径: {CKPT}")
print(f"存在: {CKPT.exists()}")
if CKPT.exists():
    for f in sorted(CKPT.iterdir()):
        if f.is_file():
            sz = f.stat().st_size
            print(f"   {f.name:<46} {sz/1e6:>10.1f} MB")

ds = CKPT / "dataset_statistics.json"
print(f"\ndataset_statistics.json: {ds}")
if ds.exists():
    try:
        stats = json.loads(ds.read_text())
        print(f"  存在的 unnorm key ({len(stats)} 个):")
        for k in stats:
            arr = stats[k]
            n = len(arr.get("action", {}).get("q01", [])) if isinstance(arr, dict) else "?"
            print(f"    - {k}   (action dim={n})")
    except Exception as e:  # noqa: BLE001
        print(f"  解析失败: {type(e).__name__}: {e}")
else:
    print("  <不存在>")

print("\n--- 正式实验产物计数 ---")
if FINAL.exists():
    js = sorted(FINAL.glob("*.json"))
    vids = sorted((FINAL / "videos").glob("*.mp4")) if (FINAL / "videos").exists() else []
    print(f"{FINAL}   JSON={len(js)}   videos={len(vids)}")
    mj = FINAL / "metrics.json"
    if mj.exists():
        m = json.loads(mj.read_text())
        print("\nmetrics.json 顶层 key:")
        for k in m:
            v = m[k]
            if isinstance(v, (int, float, str, bool)) or v is None:
                print(f"   {k} = {v}")
            elif isinstance(v, dict):
                print(f"   {k} = <dict, {len(v)} keys>")
            elif isinstance(v, list):
                print(f"   {k} = <list, {len(v)} items>")
        # 关键结论字段
        print("\n关键字段摘录:")
        for k in ("uer", "uer_ci", "gdr", "sr_satisfied", "sr_unsatisfied",
                  "n_episodes", "n_dropped", "verdict", "decision"):
            if k in m:
                print(f"   {k} = {m[k]}")
else:
    print(f"{FINAL} <不存在>")

print("\n--- baseline 目录 ---")
for d in ("final_v1", "fixed_action_v1", "control_A", "control_B", "smoke_video_default"):
    p = ROOT / "results/m1" / d
    if p.exists():
        n = len(list(p.glob("*.json")))
        v = len(list((p / "videos").glob("*.mp4"))) if (p / "videos").exists() else 0
        print(f"   {d:<22} JSON={n:<4} videos={v}")
    else:
        print(f"   {d:<22} <不存在>")

if WANT_HASH:
    print("\n--- 核心文件 SHA256 ---")
    for rel in CORE_FILES:
        p = ROOT / rel
        print(f"   {sha256(p) if p.exists() else '<缺失>':<64}  {rel}")

print("\n[env-report] done")
