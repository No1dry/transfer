"""plan1 Stage 1：旧指标审计（§7.5）。

回答一个问题：**把历史记录用统一口径重算之后，哪些结论还站得住？**

做三件事：
  1. 用 `results/m1/final/` 的 160 条原始 JSON，同时算 legacy UER 与 v2 的
     UMR / UTIR / GDR —— 同一批数据、同一套信号，只有判据不同。
     这样"100% 里有多少只是'动了'、多少才是'真的干预了任务'"第一次可量化。
  2. 分 task 报告，避免被总体均值掩盖（§7.3 要求）。
  3. 检查 control_A / control_B 是否有可复算的原始记录。

用法:
    ./run_diag.sh scripts/plan1_metric_audit.py [--out results/plan1/metric_audit.json]
"""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.metrics import (  # noqa: E402
    DEFAULT_DISPLACEMENT_SWEEP,
    DEFAULT_JOINT_SWEEP,
    DEFAULT_THRESHOLDS,
    EpisodeRecord,
    compute_all_v2,
    compute_gdr,
    compute_task_contact_rate,
    compute_uer,
    compute_umr,
    compute_utir,
    task_state_displacement_curve,
)
from benchmark.runner import load_records  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
FINAL = ROOT / "results/m1/final"
OUT = ROOT / "results/plan1/metric_audit.json"

TH = DEFAULT_THRESHOLDS


def main() -> int:
    if not FINAL.exists():
        print(f"[FAIL] {FINAL} 不存在")
        return 1
    recs = load_records(FINAL)
    print(f"[load] {FINAL} -> {len(recs)} 条记录")

    has_cum = sum(1 for r in recs if getattr(r, "cumulative_measured", False))
    print(f"[load] 其中带 v2 累计量的: {has_cum} 条"
          f"  ({'无' if has_cum == 0 else ''}"
          f"{'—— 这批记录早于 v2，路径长度不可得，只能算阈值型指标' if has_cum == 0 else ''})")

    report: dict = {"source": str(FINAL), "n_records": len(recs),
                    "n_with_cumulative": has_cum,
                    "thresholds": TH.as_dict()}

    # ---------------- 1. 同数据、不同判据 ----------------
    print("\n" + "=" * 78)
    print("1) 同数据重算：legacy UER vs v2 UMR / UTIR / GDR")
    print("=" * 78)

    rows = []
    for cond in ("satisfied", "unsatisfied"):
        sub = [r for r in recs if r.condition == cond]
        if not sub:
            continue
        uer = compute_uer(sub, TH)
        umr = compute_umr(sub, TH)
        utir = compute_utir(sub, TH)
        tcr = compute_task_contact_rate(sub)
        gdr = compute_gdr(sub)
        print(f"\ncondition = {cond}   n={len(sub)}")
        print(f"   legacy UER (eef|grip|obj) : {uer.fmt()}")
        print(f"   v2 UMR     (eef|grip)     : {umr.fmt()}")
        print(f"   分层: UMR={umr.value:.4f}  TaskContactRate={tcr.fmt()}  "
              f"displacement-only={utir.value:.4f}")
        print(f"   displacement-only(继承名 UTIR): {utir.fmt()}")
        print(f"   GDR        (init=T,fin=F) : {gdr.fmt()}")
        rows.append({
            "condition": cond, "n": len(sub),
            "legacy_uer": uer.value, "umr": umr.value,
            "utir": utir.value, "gdr": gdr.value,
            "umr_ci": [umr.ci_low, umr.ci_high],
            "utir_ci": [utir.ci_low, utir.ci_high],
        })
    report["by_condition"] = rows

    # ---------------- 2. 分 task ----------------
    print("\n" + "=" * 78)
    print("2) 分 task（§7.3：不得只报总体均值）")
    print("=" * 78)
    print(f"{'task':<22} {'cond':<12} {'n':>3} {'legacyUER':>10} {'UMR':>7} {'UTIR':>7} "
          f"{'GDR':>6} {'eef中位':>8} {'obj中位':>8}")
    print("-" * 78)
    per_task = []
    tasks = sorted({r.task_id for r in recs})
    for tid in tasks:
        for cond in ("satisfied", "unsatisfied"):
            sub = [r for r in recs if r.task_id == tid and r.condition == cond]
            if not sub:
                continue
            uer = compute_uer(sub, TH)
            umr = compute_umr(sub, TH)
            utir = compute_utir(sub, TH)
            gdr = compute_gdr(sub)
            eef_med = float(np.median([r.eef_max_displacement for r in sub]))
            obj_med = float(np.median([r.object_max_displacement for r in sub]))
            print(f"{tid:<22} {cond:<12} {len(sub):>3} {uer.value:>10.3f} "
                  f"{umr.value:>7.3f} {utir.value:>7.3f} {gdr.value:>6.3f} "
                  f"{eef_med:>8.4f} {obj_med:>8.4f}")
            per_task.append({
                "task_id": tid, "condition": cond, "n": len(sub),
                "legacy_uer": uer.value, "umr": umr.value, "utir": utir.value,
                "gdr": gdr.value, "eef_median": eef_med, "obj_median": obj_med,
            })
    report["per_task"] = per_task

    # ---------------- 2b. Task-State Displacement 严重度曲线 ----------------
    print("\n" + "=" * 78)
    print("2b) Task-State Displacement 严重度曲线（§2.2：这是严重度，不是'是否交互'）")
    print("=" * 78)
    sat = [r for r in recs if r.condition == "satisfied"]
    print(f"{'τ (物体位移 m)':>16} {'rate':>8} {'n 满足':>8}")
    print("-" * 78)
    curve = task_state_displacement_curve(sat, DEFAULT_DISPLACEMENT_SWEEP, quantity="object")
    for pt in curve:
        t = pt["object_threshold_m"]
        n_hit = int(round(pt["rate"] * pt["n"])) if pt["n"] else 0
        print(f"{t:>16.2f} {pt['rate']:>8.3f} {n_hit:>8}")
    report["task_state_displacement_object"] = curve

    print(f"\n{'task':<22} " + " ".join(f"{p['object_threshold_m']:>7.2f}" for p in curve))
    print("-" * 78)
    per_task_curve = {}
    for tid in sorted({r.task_id for r in sat}):
        c = task_state_displacement_curve(
            [r for r in sat if r.task_id == tid], DEFAULT_DISPLACEMENT_SWEEP,
            quantity="object")
        per_task_curve[tid] = c
        print(f"{tid:<22} " + " ".join(f"{p['rate']:>7.3f}" for p in c))
    report["task_state_displacement_object_per_task"] = per_task_curve

    # 关节曲线（articulated 用，横轴是归一化行程比例，§3.6 不与物体混轴）
    print("\n[articulated] 归一化关节偏离曲线（横轴 = 占行程比例，仅重录后才非零）")
    jc = task_state_displacement_curve(sat, DEFAULT_JOINT_SWEEP, quantity="joint")
    print(f"{'τ (归一化)':>16} {'rate':>8} {'n 满足':>8}")
    print("-" * 78)
    for pt in jc:
        n_hit = int(round(pt["rate"] * pt["n"])) if pt["n"] else 0
        print(f"{pt['joint_normalized_threshold']:>16.2f} {pt['rate']:>8.3f} {n_hit:>8}")
    report["task_state_displacement_joint"] = jc

    # ---------------- 3. control_A / control_B 可复算性 ----------------
    print("\n" + "=" * 78)
    print("3) 对照实验的原始记录是否还在（决定它们的数字能否重算）")
    print("=" * 78)
    ctrl = {}
    for name in ("control_A", "control_B", "final_v1", "fixed_action_v1"):
        d = ROOT / "results/m1" / name
        if not d.exists():
            ctrl[name] = "目录不存在"
            print(f"   {name:<18} <目录不存在>")
            continue
        js = [p for p in d.glob("*.json") if p.name not in ("manifest.json", "metrics.json")]
        vids = list((d / "videos").glob("*.mp4")) if (d / "videos").exists() else []
        verdict = "可复算" if js else "**不可复算**（只有视频，无 per-episode JSON）"
        ctrl[name] = {"n_json": len(js), "n_videos": len(vids), "recomputable": bool(js)}
        print(f"   {name:<18} JSON={len(js):<4} videos={len(vids):<4} {verdict}")
    report["controls"] = ctrl

    # ---------------- 4. v2 总入口（含未测量项） ----------------
    print("\n" + "=" * 78)
    print("4) compute_all_v2 总览（含显式未测量项）")
    print("=" * 78)
    agg = compute_all_v2(recs, thresholds=TH)
    for k in ("legacy_uer", "umr", "task_contact_rate", "utir_displacement_only",
              "gdr", "gdr_without_probe_requirement", "fsr"):
        v = agg[k]
        mark = "" if v.get("measured", True) else "  <- 未测量"
        print(f"   {k:<12} value={v['value']}  n={v['n']}{mark}")
    print(f"   contact coverage: {agg['contact_coverage']}")
    cum = agg["cumulative"]["eef_path_length"]
    print(f"   cumulative.eef_path_length  measured={cum['measured']}  n={cum['n']}")
    report["compute_all_v2"] = agg

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n[out] {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
