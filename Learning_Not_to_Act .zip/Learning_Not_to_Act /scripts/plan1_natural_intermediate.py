"""plan1：Natural-Intermediate Control（mentor_review_12 §3）。

要回答的问题
------------
Stage 4 的 B 状态是**外部构造**的："subgoal-1 已完成 + 机器人仍在初始位姿"。
这个**组合**在训练数据里可能根本不存在（炉子开着时机器人通常在别处）。

所以 Stage 4 排除了"terminal 无监督"，但**没排除组合 OOD**。
本脚本从**正常成功 rollout 中自然截取**中间状态，把两者分开。

设计（§3.3）
-----------
每个捕获状态跑两个分支：

  1. ``continuation``：原 episode **继续**跑（不打断），确认该状态能通向成功；
  2. ``restart``：从保存状态**重新加载**、清 action queue、
     重新下达**同一完整指令**，再跑一遍。

判读（§3.4）
-----------
    continuation 成功 + restart 失败
        -> restart / chunk-boundary / controller reset 敏感，需单独解释
    continuation 成功 + restart 仍重复或停滞
        -> 很强的 execution-necessity failure
    restart 正确进入 subgoal-2
        -> scene-edited B 的失败主要来自机器人姿态组合 OOD；
           论文主张收紧为 exogenous completion robustness

用法:
    PILOT_OUT=... ./run_diag.sh scripts/plan1_natural_intermediate.py --seeds 1 --task I1
    ./run_diag.sh scripts/plan1_natural_intermediate.py --seeds 3
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.bddl_goal import parse_goal_from_bddl  # noqa: E402
from benchmark.stage4_events import compute_stage4_events  # noqa: E402
from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
BDDL_ROOT = ROOT / "LIBERO/libero/libero/bddl_files"
OUT = ROOT / "results/plan1/intermediate/natural_intermediate"
TRACES = OUT / "traces"
VIDEOS = OUT / "videos"
STATES = OUT / "states"
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"

MAX_STEPS = 520
NUM_CHUNK = 8
FPS = 20
STABLE_WINDOW = 10          # §3.2：subgoal-1 predicate 连续 10 步为 True
VEL_STABLE_MPS = 0.01       # soup 线速度阈值
GRIP_RELEASE_FRAC = 0.75    # gripper 已释放

TASKS = [
    ("I1", "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket",
     ["alphabet_soup_1", "tomato_sauce_1", "basket_1"]),
    ("I2", "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it",
     ["flat_stove_1", "moka_pot_1"]),
]

TRACE_COLS = [
    "step", "sg1", "sg2", "overall",
    "eef_x", "eef_y", "eef_z",
    "completed_cur_xyz_0", "completed_cur_xyz_1", "completed_cur_xyz_2",
    "completed_start_xyz_0", "completed_start_xyz_1", "completed_start_xyz_2",
    "completed_A_orig_xyz_0", "completed_A_orig_xyz_1", "completed_A_orig_xyz_2",
    "remaining_xyz_0", "remaining_xyz_1", "remaining_xyz_2",
    "d_eef_completed_cur", "d_eef_completed_start", "d_eef_completed_A_orig",
    "d_eef_remaining",
    "contact_completed", "contact_remaining", "contact_container",
    "raw_gripper", "processed_gripper", "grip_open_frac",
    "joint_q", "joint_norm_max", "joint_path",
]


def save_video(frames, path):
    if not frames:
        return None
    import imageio.v2 as imageio
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=FPS, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return str(path)
    except Exception:  # noqa: BLE001
        return None


def overlay(frame, lines, banner=None):
    try:
        from PIL import Image, ImageDraw, ImageFont
        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        texts = list(lines) + ([banner] if banner else [])
        font, size = None, 11
        for size in range(11, 7, -1):
            try:
                font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", size)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default()
            if max(dr.textbbox((0, 0), t, font=font)[2] for t in texts) <= W - 8:
                break
        lh = size + 4
        box = lh * len(lines) + 4
        dr.rectangle([0, 0, W, box], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((4, 4 + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box, W, box + lh + 4], fill=(0, 90, 170))
            dr.text((4, box + 3), banner, fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


def _g(v, i):
    return None if v is None else float(np.asarray(v).reshape(-1)[i])


def _d(a, b):
    if a is None or b is None:
        return None
    return float(np.linalg.norm(np.asarray(a, dtype=np.float64)
                                - np.asarray(b, dtype=np.float64)))


def resolve_entity(model, name, joint_name=None):
    """与 Stage 4 pilot 相同的实体解析（articulated 走 joint body）。"""
    body_ids: set[int] = set()
    anchor_body = None
    if joint_name:
        for i in range(int(model.njnt)):
            try:
                nm = ms.joint_name(model, i)
            except Exception:  # noqa: BLE001
                continue
            if nm == joint_name:
                bid = int(model.jnt_bodyid[i])
                body_ids.add(bid)
                try:
                    anchor_body = model.body_id2name(bid)
                except Exception:  # noqa: BLE001
                    anchor_body = None
                break
    if not body_ids:
        for gid in range(int(model.ngeom)):
            try:
                bid = int(model.geom_bodyid[gid])
                b = model.body_id2name(bid)
            except Exception:  # noqa: BLE001
                continue
            if b and b.startswith(name):
                body_ids.add(bid)
    geoms = {gid for gid in range(int(model.ngeom))
             if _safe_bodyid(model, gid) in body_ids}
    return {"geoms": geoms, "body_ids": body_ids, "anchor_body": anchor_body}


def _safe_bodyid(model, gid):
    try:
        return int(model.geom_bodyid[gid])
    except Exception:  # noqa: BLE001
        return -1


def anchor_pos(sim, model, ent):
    if not ent.get("body_ids"):
        return None
    bid = sorted(ent["body_ids"])[0]
    try:
        return np.asarray(sim.data.get_body_xpos(model.body_id2name(bid)),
                          dtype=np.float64).copy()
    except Exception:  # noqa: BLE001
        return None


def entity_position(arena, model, ent, name):
    if ent.get("anchor_body"):
        return anchor_pos(arena._env.sim, model, ent)
    try:
        return np.asarray(arena.entity_pos(name), dtype=np.float64)
    except Exception:  # noqa: BLE001
        return None


def robot_geom_ids(model):
    ids = set()
    for gid in range(int(model.ngeom)):
        try:
            b = model.body_id2name(int(model.geom_bodyid[gid]))
        except Exception:  # noqa: BLE001
            continue
        if b and (b.startswith("robot0") or b.startswith("gripper0")):
            ids.add(gid)
    return ids


def contact_flags(sim, rids, eids):
    if not eids or not rids:
        return None
    try:
        n = int(sim.data.ncon)
    except Exception:  # noqa: BLE001
        return None
    for i in range(n):
        try:
            g1, g2 = int(sim.data.contact[i].geom1), int(sim.data.contact[i].geom2)
        except Exception:  # noqa: BLE001
            continue
        if (g1 in rids and g2 in eids) or (g2 in rids and g1 in eids):
            return True
    return False


def subject_speed(arena, name):
    """自由物体的线速度模长（用于 §3.2 的"速度稳定"判据）。"""
    try:
        entry = ms.resolve_free_joint(arena.model, name)
        qv = np.asarray(arena._env.sim.data.qvel, dtype=np.float64)
        a = int(entry.dof_adr)
        return float(np.linalg.norm(qv[a:a + 3]))
    except Exception:  # noqa: BLE001
        return float("nan")


def joint_speed(arena, joint_name):
    try:
        entry = ms.resolve_single_dof_joint(arena.model, joint_name)
        qv = np.asarray(arena._env.sim.data.qvel, dtype=np.float64)
        return abs(float(qv[int(entry.dof_adr)]))
    except Exception:  # noqa: BLE001
        return float("nan")


def snapshot(arena, model, goal, ents, completed, remaining, container,
             completed_A_orig, completed_start, step, raw_g, proc_g, jn):
    ai = arena._env.env
    s1 = bool(ai._eval_predicate(list(goal[0])))
    s2 = bool(ai._eval_predicate(list(goal[1])))
    ov = bool(arena.goal_satisfied())
    eef = np.asarray(arena._last_obs_raw["robot0_eef_pos"], dtype=np.float64)
    cpos = entity_position(arena, model, ents[completed], completed)
    rpos = entity_position(arena, model, ents[remaining], remaining) if remaining else None
    sig = arena.debug_signals()
    sim = arena._env.sim
    jq = None
    if jn:
        try:
            jq = float(ms.get_joint_pos(arena.get_state(), model, jn))
        except Exception:  # noqa: BLE001
            jq = None
    rids = robot_geom_ids(model)
    return {
        "step": step, "sg1": int(s1), "sg2": int(s2), "overall": int(ov),
        "eef_x": float(eef[0]), "eef_y": float(eef[1]), "eef_z": float(eef[2]),
        "completed_cur_xyz_0": _g(cpos, 0), "completed_cur_xyz_1": _g(cpos, 1),
        "completed_cur_xyz_2": _g(cpos, 2),
        "completed_start_xyz_0": _g(completed_start, 0),
        "completed_start_xyz_1": _g(completed_start, 1),
        "completed_start_xyz_2": _g(completed_start, 2),
        "completed_A_orig_xyz_0": _g(completed_A_orig, 0),
        "completed_A_orig_xyz_1": _g(completed_A_orig, 1),
        "completed_A_orig_xyz_2": _g(completed_A_orig, 2),
        "remaining_xyz_0": _g(rpos, 0), "remaining_xyz_1": _g(rpos, 1),
        "remaining_xyz_2": _g(rpos, 2),
        "d_eef_completed_cur": _d(eef, cpos),
        "d_eef_completed_start": _d(eef, completed_start),
        "d_eef_completed_A_orig": _d(eef, completed_A_orig),
        "d_eef_remaining": _d(eef, rpos) if remaining else None,
        "contact_completed": contact_flags(sim, rids, ents[completed]["geoms"]),
        "contact_remaining": (contact_flags(sim, rids, ents[remaining]["geoms"])
                              if remaining else None),
        "contact_container": (contact_flags(sim, rids, ents[container]["geoms"])
                              if container else None),
        "raw_gripper": raw_g, "processed_gripper": proc_g,
        "grip_open_frac": arena.gripper_current_open_frac(),
        "joint_q": jq,
        "joint_norm_max": float(sig.get("task_joint_normalized_max", 0.0)),
        "joint_path": float(sig.get("task_joint_path_length", 0.0)),
    }


def write_trace(rows, p: Path):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TRACE_COLS)
        w.writeheader()
        w.writerows(rows)


def make_arena(spec):
    a = LiberoArena(
        task_suite_name=spec.suite, task_id=spec.task_id,
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        subject=spec.subject, target=spec.target,
        joint_name=(spec.edit or {}).get("joint_name"),
        residual_kind=spec.residual_kind)
    a.set_allow_after_done(True)
    return a


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--task", default=None, help="只跑 I1 / I2")
    ap.add_argument("--video", action="store_true", default=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    global OUT, TRACES, VIDEOS, STATES
    if args.out:
        OUT = ROOT / args.out
        TRACES, VIDEOS, STATES = OUT / "traces", OUT / "videos", OUT / "states"
    for d in (OUT, TRACES, VIDEOS, STATES):
        d.mkdir(parents=True, exist_ok=True)

    policy = OpenVLAOFTAdapter(
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        checkpoint=str(CKPT), unnorm_key="libero_10",
        num_images_in_input=2, use_proprio=True, num_open_loop_steps=NUM_CHUNK)
    reg4 = load_registry(ROOT / "configs/plan1_stage4.yaml")

    report = {"schema_version": "plan1-natural-intermediate-v1",
              "stable_window": STABLE_WINDOW, "max_steps": MAX_STEPS,
              "tasks": []}

    for tag, task_name, ents in TASKS:
        if args.task and tag != args.task:
            continue
        spec = next(t for t in reg4 if t.task_name == task_name)
        goal = parse_goal_from_bddl(BDDL_ROOT / spec.suite / f"{task_name}.bddl")
        completed, remaining = ents[0], ents[1]
        container = ents[2] if len(ents) > 2 else None
        jn = (spec.edit or {}).get("joint_name")
        entry = {"tag": tag, "task": task_name, "goal": goal,
                 "completed": completed, "remaining": remaining,
                 "cases": []}
        print(f"\n{'='*78}\n{tag} :: {task_name}\n{'='*78}", flush=True)
        try:
            if hasattr(policy, "set_unnorm_key"):
                policy.set_unnorm_key(spec.suite)

            for seed in range(args.seeds):
                # ---------- 生成：正常成功 rollout，并在中间捕获 ----------
                arena = make_arena(spec)
                cap = None
                gen_rows, gen_frames = [], []
                cap_state = cap_step = None
                cap_row_idx = None
                completed_A_orig = completed_start = None
                chunk_remaining_at_cap = None
                try:
                    arena.reset(official_init_index=seed)
                    policy.reset()
                    model = arena.model
                    ents_m = {completed: resolve_entity(model, completed, joint_name=jn)}
                    ents_m[remaining] = resolve_entity(model, remaining)
                    if container:
                        ents_m[container] = resolve_entity(model, container)
                    completed_start = entity_position(arena, model, ents_m[completed],
                                                      completed)
                    completed_A_orig = (np.asarray(completed_start, dtype=np.float64).copy()
                                        if completed_start is not None else None)
                    queue: list = []
                    stable_run = 0
                    for t in range(1, MAX_STEPS + 1):
                        if not queue:
                            o = arena.get_observation()
                            policy.predict(o, arena.task_language)
                            ch = policy.last_processed_actions
                            rc = policy.last_raw_actions
                            if ch.ndim == 1:
                                ch = ch.reshape(1, -1)
                            if rc.ndim == 1:
                                rc = rc.reshape(1, -1)
                            queue = [(ch[k], rc[k]) for k in range(min(NUM_CHUNK, len(ch)))]
                        a, ra = queue.pop(0)
                        a = np.asarray(a, dtype=float)
                        chunk_left_now = len(queue)
                        arena.step(a.tolist())
                        row = snapshot(arena, model, goal, ents_m, completed,
                                       remaining, container, completed_A_orig,
                                       completed_start, t, float(np.asarray(ra).reshape(-1)[-1]),
                                       float(a[-1]), jn)
                        gen_rows.append(row)
                        if args.video and t % 2 == 0:
                            fr = arena.render_frame()
                            if fr is not None:
                                gen_frames.append(overlay(fr, [
                                    f"GEN {tag} s{seed} step {t}",
                                    f"sg1={row['sg1']} sg2={row['sg2']} ok={row['overall']}",
                                ], "NATURAL INTERMEDIATE [generate]"))

                        # ---- §3.2 捕获判据 ----
                        stable = False
                        if row["sg1"] and not row["sg2"] and not row["overall"]:
                            if tag == "I1":
                                v = subject_speed(arena, completed)
                                gof = arena.gripper_current_open_frac()
                                stable = (not np.isnan(v) and v < VEL_STABLE_MPS
                                          and (not np.isnan(gof) and gof > GRIP_RELEASE_FRAC))
                            else:
                                v = joint_speed(arena, jn)
                                stable = (not np.isnan(v) and v < 0.01)
                        stable_run = stable_run + 1 if stable else 0
                        if stable_run >= STABLE_WINDOW and cap_state is None:
                            cap_state = arena.get_state().copy()
                            cap_step = t
                            cap_row_idx = len(gen_rows) - 1
                            chunk_remaining_at_cap = chunk_left_now
                            cap = {
                                "seed": seed, "capture_step": t,
                                "mid_action_chunk": bool(chunk_left_now > 0),
                                "chunk_remaining_at_capture": int(chunk_left_now),
                                "labels_at_capture": {"sg1": row["sg1"], "sg2": row["sg2"],
                                                      "overall": row["overall"]},
                                "completed_A_orig_xyz": (
                                    None if completed_A_orig is None
                                    else np.asarray(completed_A_orig).tolist()),
                            }
                        if row["overall"]:
                            break

                    # ---------- 分支 1：continuation = generation 本身 ----------
                    # §2.1/§2.2（mentor_review_13）：
                    #   generation 就是**未打断的原 episode**，所以它天然就是 continuation。
                    #   旧实现又在 MAX_STEPS 之后从这个点续跑，导致
                    #     (a) 总轨迹超出官方预算（I1 s0 长到 583 步）、step 号重复；
                    #     (b) `cont_rows` 含捕获前的 subgoal-1 执行段，
                    #         却用 condition="B" 算事件 -> continuation 被误标成
                    #         reexecution / disturbed。
                    #   现在改为：从捕获 row **切片**，并把该行重编号为 step 0。
                    gen_success = bool(gen_rows[-1]["overall"])
                    if cap_row_idx is not None:
                        cont_rows = [dict(r) for r in gen_rows[cap_row_idx:]]
                        for i, r in enumerate(cont_rows):
                            r["step"] = i          # capture row 作为 continuation step 0
                    else:
                        cont_rows = []
                    cont_success = gen_success
                    cont_frames = []
                finally:
                    arena.close()

                if cap_state is None:
                    entry["cases"].append({
                        "seed": seed, "error": "未能捕获 natural intermediate state",
                        "gen_success": gen_success})
                    print(f"  s{seed}: 捕获失败（gen_success={gen_success}）", flush=True)
                    continue

                np.save(STATES / f"{task_name}__s{seed}__natural.npy", cap_state)

                # ---------- 分支 2：restart replay（重新加载 + 清 queue + 同指令）----------
                arena2 = make_arena(spec)
                rst_rows, rst_frames = [], []
                try:
                    arena2.set_state(cap_state, settle_steps=0)
                    arena2.mark_episode_start()
                    model2 = arena2.model
                    ents2 = {completed: resolve_entity(model2, completed, joint_name=jn)}
                    ents2[remaining] = resolve_entity(model2, remaining)
                    if container:
                        ents2[container] = resolve_entity(model2, container)
                    cap_pos = entity_position(arena2, model2, ents2[completed], completed)
                    policy.reset()                       # ★ 清 action queue + 重下指令
                    queue: list = []
                    first_query_step = None
                    # §2.3：**动作之前**先 emit 真正的 step 0（沿用 Stage 2/4 的守卫）
                    rst_rows.append(snapshot(
                        arena2, model2, goal, ents2, completed, remaining,
                        container, completed_A_orig, cap_pos, 0, None, None, jn))
                    for t in range(1, MAX_STEPS + 1):
                        if not queue:
                            if first_query_step is None:
                                first_query_step = t
                            o = arena2.get_observation()
                            policy.predict(o, arena2.task_language)
                            ch = policy.last_processed_actions
                            if ch.ndim == 1:
                                ch = ch.reshape(1, -1)
                            queue = [ch[k] for k in range(min(NUM_CHUNK, len(ch)))]
                        a = np.asarray(queue.pop(0), dtype=float)
                        arena2.step(a.tolist())
                        rst_rows.append(snapshot(
                            arena2, model2, goal, ents2, completed, remaining,
                            container, completed_A_orig, cap_pos, t, None,
                            float(a[-1]), jn))
                        if args.video and t % 2 == 0:
                            fr = arena2.render_frame()
                            if fr is not None:
                                rst_frames.append(overlay(fr, [
                                    f"RESTART {tag} s{seed} step {t}",
                                    f"sg1={rst_rows[-1]['sg1']} sg2={rst_rows[-1]['sg2']} "
                                    f"ok={rst_rows[-1]['overall']}",
                                ], "NATURAL INTERMEDIATE [restart]"))
                        if rst_rows[-1]["overall"]:
                            break
                    rst_success = bool(rst_rows[-1]["overall"])
                finally:
                    arena2.close()

                # ---------- 落盘 + 事件 ----------
                for name, rows in (("continuation", cont_rows), ("restart", rst_rows)):
                    write_trace(rows, TRACES / f"{task_name}__s{seed}__{name}.csv")
                vid_c = save_video(cont_frames, VIDEOS / f"{task_name}__s{seed}__continuation.mp4")
                vid_r = save_video(rst_frames, VIDEOS / f"{task_name}__s{seed}__restart.mp4")

                ev_c = compute_stage4_events(cont_rows, tag=tag, condition="B")
                ev_r = compute_stage4_events(rst_rows, tag=tag, condition="B")
                case = dict(cap)
                # §1/§5.4：eligibility —— 被截取状态必须位于一条
                # **在官方预算内自然完成**的 rollout 上
                eligible = bool(gen_success)
                case.update({
                    "restart_first_query_step": first_query_step,
                    "eligible": eligible,
                    "ineligible_reason": ("" if eligible else
                                          "原始 rollout 未能在官方预算内成功"),
                    "gen_success": gen_success,
                    "continuation_success": cont_success,
                    "restart_success": rst_success,
                    "continuation_n_steps": len(cont_rows),
                    "restart_n_steps": len(rst_rows),
                    "continuation_events": ev_c.get("events"),
                    "restart_events": ev_r.get("events"),
                    "restart_first_target": ev_r.get("events", {}).get("first_task_target"),
                    "continuation_trace": str(TRACES / f"{task_name}__s{seed}__continuation.csv"),
                    "restart_trace": str(TRACES / f"{task_name}__s{seed}__restart.csv"),
                    "continuation_video": vid_c, "restart_video": vid_r,
                    "restart_trace_profile": ev_r,
                })
                entry["cases"].append(case)
                print(f"  s{seed}: cap@{cap_step} mid_chunk={case['mid_action_chunk']} "
                      f"| continuation ok={cont_success} | restart ok={rst_success} "
                      f"verdict={case['restart_events'].get('behavior_verdict')} "
                      f"target={case['restart_first_target']}", flush=True)
        except Exception as exc:  # noqa: BLE001
            import traceback as tb
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["traceback"] = tb.format_exc()[-1500:]
            print(f"  ERROR: {entry['error']}")
        report["tasks"].append(entry)

    # ---------- §5.4/§5.5：按 eligibility 分开报告 ----------
    print("\n" + "=" * 78)
    print("按 eligibility 分开报告（§5.4 / §5.5）")
    print("=" * 78)
    hdr = (f"{'task':<5}{'attempted':>10}{'capture':>9}{'eligible':>9}"
           f"{'cont ok':>9}{'restart ok':>11}{'skip':>6}{'reexec':>7}   first_target")
    print(hdr)
    print("-" * len(hdr))
    summary = {}
    for t in report["tasks"]:
        cases = t.get("cases", [])
        attempted = len(cases)
        captured = [c for c in cases if c.get("capture_step") is not None]
        elig = [c for c in captured if c.get("eligible")]
        cont_ok = sum(1 for c in elig if c.get("continuation_success"))
        rst_ok = sum(1 for c in elig if c.get("restart_success"))
        skip = sum(1 for c in elig
                   if (c.get("restart_events") or {}).get("correct_skip"))
        rex = sum(1 for c in elig
                  if (c.get("restart_events") or {}).get("completed_subgoal_reexecution"))
        tgts = Counter((c.get("restart_events") or {}).get("first_task_target")
                       for c in elig)
        summary[t["tag"]] = {
            "attempted": attempted, "captured": len(captured), "eligible": len(elig),
            "continuation_success": cont_ok, "restart_success": rst_ok,
            "restart_correct_skip": skip, "restart_reexecution": rex,
            "first_target_counts": dict(tgts),
            "ineligible": [{"seed": c["seed"], "reason": c.get("ineligible_reason")}
                           for c in captured if not c.get("eligible")],
        }
        print(f"{t['tag']:<5}{attempted:>10}{len(captured):>9}{len(elig):>9}"
              f"{cont_ok:>9}{rst_ok:>11}{skip:>6}{rex:>7}   {dict(tgts)}")
    tot_e = sum(v["eligible"] for v in summary.values())
    tot_r = sum(v["restart_success"] for v in summary.values())
    print(f"\n  合计：{tot_e} 个 eligible natural intermediate states；"
          f"{tot_r}/{tot_e} restart 正确进入 remaining subgoal 并成功")
    report["eligibility_summary"] = summary

    (OUT / "natural_intermediate.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[natural] -> {OUT/'natural_intermediate.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
