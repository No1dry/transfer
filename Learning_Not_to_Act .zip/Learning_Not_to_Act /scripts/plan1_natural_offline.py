"""自然中间状态对照的**离线**汇总（从 trace 重算）。

背景：`plan1_natural_intermediate.py` 在写 JSON 前因 `Counter` 未导入而崩，
但**所有 trace / state / video 都已落盘**。按本项目一贯原则
（在线值不可信时从 trace 重算），这里从 trace 重建完整结果表。

eligibility（mentor_review_13 §1）：被截取状态必须位于一条
**在官方预算内自然完成**的 rollout 上 —— 即 continuation 成功。

用法: ./run_diag.sh scripts/plan1_natural_offline.py --run results/plan1/intermediate/natural_v2
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.stage4_events import compute_stage4_events  # noqa: E402
from plan1_stage4_offline import read_trace  # type: ignore  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
TASKS = {
    "I1": "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket",
    "I2": "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it",
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="results/plan1/intermediate/natural_v2")
    a = ap.parse_args()
    run = ROOT / a.run
    tr = run / "traces"
    if not tr.exists():
        print(f"[FAIL] {tr} 不存在")
        return 1

    rows_all, summary = [], {}
    for tag, task in TASKS.items():
        cases = []
        for p in sorted(tr.glob(f"{task}__s*__continuation.csv")):
            seed = int(p.stem.split("__s")[1].split("__")[0])
            pr = tr / f"{task}__s{seed}__restart.csv"
            if not pr.exists():
                continue
            cont = read_trace(p)
            rst = read_trace(pr)
            # continuation trace 已从捕获行切片、step 重编号为 0
            cont_ok = bool(cont[-1]["overall"]) if cont else False
            off = compute_stage4_events(rst, tag=tag, condition="B")
            ev = off.get("events", {})
            q = off.get("quantities", {})
            cases.append({
                "seed": seed,
                "eligible": cont_ok,
                "ineligible_reason": "" if cont_ok else "原始 rollout 未在官方预算内成功",
                "continuation_success": cont_ok,
                "continuation_n_steps": len(cont),
                "restart_success": bool(rst[-1]["overall"]) if rst else False,
                "restart_n_steps": len(rst),
                "restart_verdict": ev.get("behavior_verdict"),
                "restart_correct_skip": ev.get("correct_skip"),
                "restart_reexecution": ev.get("completed_subgoal_reexecution"),
                "restart_disturbed": ev.get("completed_subgoal_disturbed"),
                "first_task_target": ev.get("first_task_target"),
                "approach_remaining": q.get("approach_remaining"),
                "approach_completed_A_orig": q.get("approach_completed_A_orig"),
                "closed_gripper_near_remaining": q.get("close_near_remaining"),
                "trace_continuation": str(p), "trace_restart": str(pr),
            })
        elig = [c for c in cases if c["eligible"]]
        summary[tag] = {
            "attempted": len(cases), "eligible": len(elig),
            "ineligible": [{"seed": c["seed"], "reason": c["ineligible_reason"]}
                           for c in cases if not c["eligible"]],
            "eligible_continuation_success": sum(1 for c in elig if c["continuation_success"]),
            "eligible_restart_success": sum(1 for c in elig if c["restart_success"]),
            "eligible_restart_correct_skip": sum(1 for c in elig if c["restart_correct_skip"]),
            "eligible_restart_reexecution": sum(1 for c in elig if c["restart_reexecution"]),
            "first_target_counts": dict(Counter(c["first_task_target"] for c in elig)),
        }
        rows_all += [dict(c, tag=tag) for c in cases]

    print("=" * 96)
    print("Natural-Intermediate Control —— 离线汇总（由 trace 重算）")
    print("=" * 96)
    hdr = (f"{'task':<5}{'attempted':>10}{'eligible':>9}{'cont ok':>9}"
           f"{'restart ok':>11}{'skip':>6}{'reexec':>7}   first_target")
    print(hdr); print("-" * len(hdr))
    for tag, v in summary.items():
        print(f"{tag:<5}{v['attempted']:>10}{v['eligible']:>9}"
              f"{v['eligible_continuation_success']:>9}{v['eligible_restart_success']:>11}"
              f"{v['eligible_restart_correct_skip']:>6}"
              f"{v['eligible_restart_reexecution']:>7}   {v['first_target_counts']}")
    te = sum(v["eligible"] for v in summary.values())
    tr_ = sum(v["eligible_restart_success"] for v in summary.values())
    ts = sum(v["eligible_restart_correct_skip"] for v in summary.values())
    print(f"\n  合计：{te} 个 eligible natural intermediate states；"
          f"restart 成功 {tr_}/{te}，correct_skip {ts}/{te}")
    print("\n  逐 seed：")
    for c in rows_all:
        print(f"    {c['tag']} s{c['seed']}: eligible={c['eligible']} "
              f"cont_ok={c['continuation_success']} restart_ok={c['restart_success']} "
              f"verdict={c['restart_verdict']} target={c['first_task_target']}")

    (run / "natural_offline_summary.json").write_text(json.dumps({
        "schema_version": "plan1-natural-offline-v1",
        "source": str(tr), "summary": summary, "cases": rows_all,
        "note": "全部由 trace 离线重算；continuation trace 已从捕获行切片并重编号为 step 0",
    }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    with (run / "natural_offline_summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows_all[0].keys()))
        w.writeheader(); w.writerows(rows_all)
    print(f"\n[out] {run}/natural_offline_summary.{{json,csv}}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
