"""plan1 Stage 4：完整任务能力门槛（mentor_review_5 §6.1）。

在跑 paired pilot 之前，先确认模型**会做完整任务**。
否则"不跳过已完成子目标"会被误读成"不会做任务"。

规格（§6.1）：
  - 2 tasks × 5 official init indices；
  - **官方初始状态**（suite.get_task_init_states）；
  - 正确的 suite unnorm key（这里的两个任务都属 libero_10）；
  - 官方 max step budget（libero_10 = 520，另加 10 步 wait）；
  - 保存逐步 trace 与视频；
  - 报 overall SR 与**各 subgoal 首次翻转时间 / 达成顺序**。

门槛：每任务 >= 4/5。若任一任务 < 4/5，停止该任务并汇报，不得降低门槛。

产物：`results/plan1/intermediate/capability/{capability.json, traces/, videos/}`

用法:
    ./run_diag.sh scripts/plan1_stage4_capability.py            # 全部
    ./run_diag.sh scripts/plan1_stage4_capability.py --n 5      # 每任务几个 init index
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from libero.libero import benchmark as B  # noqa: E402
from libero.libero.envs import OffScreenRenderEnv  # noqa: E402
from benchmark.bddl_goal import parse_goal_from_bddl  # noqa: E402
from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
BDDL_ROOT = ROOT / "LIBERO/libero/libero/bddl_files"
OUT = ROOT / "results/plan1/intermediate/capability"
TRACES = OUT / "traces"
VIDEOS = OUT / "videos"
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"

MAX_STEPS = 520        # TASK_MAX_STEPS[LIBERO_10]
NUM_STEPS_WAIT = 10
NUM_CHUNK = 8
FPS = 20
GATE = 4               # 至少 4/5

TASKS = [
    ("libero_10",
     "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket"),
    ("libero_10",
     "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it"),
]

TRACE_COLS = ["step", "subgoal1", "subgoal2", "overall", "eef_x", "eef_y", "eef_z"]


def overlay(frame, lines, banner=None):
    try:
        from PIL import Image, ImageDraw, ImageFont

        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        texts = list(lines) + ([banner] if banner else [])
        font, size = None, 11
        for size in range(11, 7, -1):
            try:
                font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", size)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default()
            if max(dr.textbbox((0, 0), t, font=font)[2] for t in texts) <= W - 8:
                break
        lh = size + 4
        box = lh * len(lines) + 4
        dr.rectangle([0, 0, W, box], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((4, 4 + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box, W, box + lh + 4], fill=(0, 90, 170))
            dr.text((4, box + 3), banner, fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


def save_video(frames, path):
    if not frames:
        return None
    import imageio.v2 as imageio

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=FPS, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return str(path)
    except Exception:  # noqa: BLE001
        return None


def first_true_step(seq):
    for s, v in seq:
        if v:
            return s
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--video", action="store_true", default=True)
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    TRACES.mkdir(parents=True, exist_ok=True)

    policy = OpenVLAOFTAdapter(
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        checkpoint=str(CKPT), unnorm_key="libero_10",
        num_images_in_input=2, use_proprio=True,
        num_open_loop_steps=NUM_CHUNK,
    )

    report: dict = {"schema_version": "plan1-stage4-capability-v1",
                    "max_steps": MAX_STEPS, "num_steps_wait": NUM_STEPS_WAIT,
                    "gate": f">= {GATE}/{args.n}", "tasks": []}

    for suite_name, task_name in TASKS:
        print(f"\n{'='*78}\n{suite_name} :: {task_name}\n{'='*78}", flush=True)
        suite = B.get_benchmark_dict()[suite_name]()
        idx = next(i for i, t in enumerate(suite.tasks) if t.name == task_name)
        task = suite.tasks[idx]
        bddl = BDDL_ROOT / suite_name / f"{task_name}.bddl"
        goal = parse_goal_from_bddl(bddl)
        init_states = suite.get_task_init_states(idx)
        # 不再单独建 env：谓词从 arena 自己的 simulator 读（见下）。
        env = None
        inner = None
        entry = {"task": task_name, "language": task.language,
                 "goal_predicates": goal, "n_init_states": len(init_states),
                 "n_episodes": args.n, "episodes": []}
        arena = None
        try:
            # 每个 suite 切一次 unnorm key（跨 suite 必须切，否则动作被错缩放）
            if hasattr(policy, "set_unnorm_key"):
                policy.set_unnorm_key(suite_name)

            # 用 LiberoArena：复用**已验证过**的 observation 构造
            # （含 mentor_review_3 的 refresh 修复），不再手搓 obs。
            from benchmark.tasks import load_registry
            from benchmark.arena.libero import LiberoArena

            reg4 = load_registry(ROOT / "configs/plan1_stage4.yaml")
            spec = next(t for t in reg4 if t.task_name == task_name)
            arena = LiberoArena(
                task_suite_name=spec.suite, task_id=spec.task_id,
                openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
                subject=spec.subject, target=spec.target,
                joint_name=(spec.edit or {}).get("joint_name"),
                residual_kind=spec.residual_kind,
            )
            arena.set_allow_after_done(True)

            for ep in range(args.n):
                t0 = time.time()
                arena.reset(official_init_index=ep)
                policy.reset()
                queue: list = []
                rows, frames = [], []
                first_sg1 = first_sg2 = first_overall = None

                for t in range(MAX_STEPS + NUM_STEPS_WAIT):
                    if t < NUM_STEPS_WAIT:
                        arena.step(arena.no_op_action())
                    else:
                        if not queue:
                            o = arena.get_observation()
                            policy.predict(o, arena.task_language)
                            chunk = policy.last_processed_actions
                            if chunk.ndim == 1:
                                chunk = chunk.reshape(1, -1)
                            queue = [chunk[k] for k in
                                     range(min(NUM_CHUNK, len(chunk)))]
                        a = np.asarray(queue.pop(0), dtype=float)
                        arena.step(a.tolist())

                    # ⚠️ 必须读 **arena 的** inner env！
                    # 之前用另一个独立创建的 `inner`，它从未 step 过，
                    # `object_states_dict` 是陈旧值，导致每条 episode 都报
                    # "sg1@1 sg2@1"（两个子目标在第 1 步就为真）—— 纯属误读。
                    a_inner = arena._env.env
                    s1 = bool(a_inner._eval_predicate(list(goal[0])))
                    s2 = bool(a_inner._eval_predicate(list(goal[1])))
                    ov = bool(arena.goal_satisfied())
                    eef = np.asarray(arena._last_obs_raw["robot0_eef_pos"],
                                     dtype=np.float64)
                    if t >= NUM_STEPS_WAIT:
                        step_no = t - NUM_STEPS_WAIT + 1
                        if s1 and first_sg1 is None:
                            first_sg1 = step_no
                        if s2 and first_sg2 is None:
                            first_sg2 = step_no
                        if ov and first_overall is None:
                            first_overall = step_no
                        rows.append({"step": step_no,
                                     "subgoal1": int(s1), "subgoal2": int(s2),
                                     "overall": int(ov),
                                     "eef_x": float(eef[0]), "eef_y": float(eef[1]),
                                     "eef_z": float(eef[2])})
                    if args.video and t % 2 == 0:
                        fr = arena.render_frame()
                        if fr is not None:
                            frames.append(overlay(fr, [
                                f"{spec.id} ep{ep} step {t}",
                                f"sg1={int(s1)} sg2={int(s2)} success={int(ov)}",
                            ], "CAPABILITY BASELINE"))
                    if first_overall is not None:
                        break

                p = TRACES / f"{task_name}__ep{ep}.csv"
                with p.open("w", newline="", encoding="utf-8") as f:
                    w = csv.DictWriter(f, fieldnames=TRACE_COLS)
                    w.writeheader(); w.writerows(rows)
                vid = save_video(frames, VIDEOS / f"{task_name}__ep{ep}.mp4") \
                    if args.video else None
                rec = {"ep": ep, "official_init_index": ep,
                       "success": first_overall is not None,
                       "first_overall_step": first_overall,
                       "first_subgoal1_step": first_sg1,
                       "first_subgoal2_step": first_sg2,
                       "n_steps": len(rows),
                       "order": ("sg1_then_sg2" if (first_sg1 or 1e9) < (first_sg2 or 1e9)
                                 else "sg2_then_sg1" if first_sg2 else "sg1_only"
                                 if first_sg1 else "none"),
                       "trace": str(p), "video": vid,
                       "wall_time_s": time.time() - t0}
                entry["episodes"].append(rec)
                print(f"  ep{ep}: success={rec['success']} "
                      f"first_overall={first_overall} sg1@{first_sg1} sg2@{first_sg2} "
                      f"order={rec['order']} ({rec['wall_time_s']:.0f}s)", flush=True)
        except Exception as exc:  # noqa: BLE001
            import traceback as tb
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["traceback"] = tb.format_exc()[-1200:]
            print(f"  ERROR: {entry['error']}")
        finally:
            if arena is not None:
                try:
                    arena.close()
                except Exception:  # noqa: BLE001
                    pass

        eps = entry.get("episodes", [])
        n_ok = sum(1 for e in eps if e["success"])
        entry["n_success"] = n_ok
        entry["sr"] = (n_ok / len(eps)) if eps else None
        entry["gate_pass"] = bool(len(eps) >= args.n and n_ok >= GATE)
        print(f"  -> SR = {n_ok}/{len(eps)}  门槛({'PASS' if entry['gate_pass'] else 'FAIL'})",
              flush=True)
        report["tasks"].append(entry)

    report["all_gate_pass"] = all(t.get("gate_pass") for t in report["tasks"])
    (OUT / "capability.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[capability] all_gate_pass = {report['all_gate_pass']}  -> {OUT/'capability.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
