"""plan1 Stage 4-A：Intermediate Completed-Subgoal 可行性验证（mentor_review_4 §5.1）。

目标（**不加载 7B 模型**）：
  1. 在当前 LIBERO 版本确认多阶段任务真实存在；
  2. **解析官方 BDDL 的 :goal**，而不是手写 task_id / 手写谓词；
  3. 为每个任务定义可审计的 subgoal-1 / subgoal-2 predicate；
  4. 用 LIBERO 自己的 `_eval_predicate` 评估（不重新实现语义）；
  5. 构造 paired states：A（subgoal-1 未完成、overall 未完成）、
     B（subgoal-1 已完成、overall 未完成）；
  6. 验证 A/B 的机器人前 9 关节、非任务实体、provenance；
  7. 每任务 2 seed 状态构造 smoke；
  8. 保存 state / predicate 报告 / 起点图像。

产物：`results/plan1/intermediate/feasibility.json` + `states/` + `images/`

用法: ./run_diag.sh scripts/plan1_stage4_feasibility.py
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from libero.libero import benchmark as B  # noqa: E402
from libero.libero.envs import OffScreenRenderEnv  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
BDDL_ROOT = ROOT / "LIBERO/libero/libero/bddl_files"
OUT = ROOT / "results/plan1/intermediate"
STATES = OUT / "states"
IMAGES = OUT / "images"

# mentor_review_4 §5.1 指定的首选任务
CANDIDATES = [
    ("libero_goal", "open_the_top_drawer_and_put_the_bowl_inside"),
    ("libero_10", "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it"),
]


def parse_goal_from_bddl(path: Path) -> list[list[str]]:
    """从 BDDL 文本解析 `:goal` 的顶层谓词（**官方来源**，不手写）。"""
    txt = path.read_text()
    i = txt.find("(:goal")
    if i < 0:
        raise ValueError(f"{path} 里找不到 :goal")
    depth, out = 0, []
    for ch in txt[i:]:
        out.append(ch)
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                break
    body = "".join(out)
    m = body.find("(:goal")
    body = body[m + len("(:goal"):].strip()
    while body.endswith(")"):
        body = body[:-1]
    inner = body.strip()
    if inner.lower().startswith("(and"):
        inner = inner[4:].strip()
    preds, depth, cur = [], 0, ""
    for ch in inner:
        if ch == "(":
            depth += 1
            if depth == 1:
                cur = ""
                continue
        if ch == ")":
            depth -= 1
            if depth == 0:
                toks = [t for t in cur.strip().split() if t]
                # ⚠️ BDDL 里谓词名是首字母大写（In / Turnon / On），
                # 而 LIBERO 的 VALIDATE_PREDICATE_FN_DICT 键是**全小写**；
                # 不归一化会在 _eval_predicate 里 assert 失败。
                # 只把谓词名小写，对象/区域名保持原样。
                if toks:
                    toks[0] = toks[0].lower()
                preds.append(toks)
                continue
        if depth >= 1:
            cur += ch
    return preds


class TaskProbe:
    """封装一个多阶段任务的环境 + 官方谓词评估。"""

    def __init__(self, suite_name: str, task_name: str):
        self.suite_name = suite_name
        self.task_name = task_name
        suite = B.get_benchmark_dict()[suite_name]()
        self.task = next(t for t in suite.tasks if t.name == task_name)
        self.bddl = BDDL_ROOT / suite_name / f"{task_name}.bddl"
        self.goal_preds = parse_goal_from_bddl(self.bddl)
        self.env = OffScreenRenderEnv(
            bddl_file_name=str(self.bddl), camera_heights=256, camera_widths=256)
        self.inner = self.env.env
        # 与 BDDL 解析结果交叉核对：环境自己读出来的 goal_state 必须一致
        self.env_goal = [list(p) for p in self.inner.parsed_problem["goal_state"]]

    # ---- 官方谓词评估 ----
    def eval_pred(self, pred: list[str]) -> bool:
        return bool(self.inner._eval_predicate(list(pred)))

    def eval_all(self, preds) -> bool:
        return all(self.eval_pred(p) for p in preds)

    def overall(self) -> bool:
        return self.eval_all(self.goal_preds)

    def reset(self):
        self.env.reset()

    def state(self) -> np.ndarray:
        return np.asarray(self.inner.sim.get_state().flatten(), dtype=np.float64).copy()

    def set_state(self, s):
        self.inner.sim.set_state_from_flattened(np.asarray(s, dtype=np.float64))
        self.inner.sim.forward()

    def robot_qpos(self, s) -> np.ndarray:
        """机器人前 9 个关节（7 臂 + 2 夹爪）。

        LIBERO 的 qpos 布局里机器人关节在最前面，所以直接取前 9 维
        （与 `ms.set_robot_qpos(..., n=9)` 的约定一致）。
        不用 `ms.get_robot_qpos`：它要 `StateLayout` 而不是 model。
        """
        return np.asarray(s, dtype=np.float64)[:9].copy()

    def entity_pos(self, s, name):
        try:
            return ms.get_object_pos(np.asarray(s, dtype=np.float64),
                                     self.inner.sim.model, name)
        except Exception:  # noqa: BLE001
            return None

    def image(self) -> np.ndarray:
        try:
            return np.asarray(self.inner.sim.render(width=256, height=256,
                                                    camera_name="agentview"))
        except Exception:  # noqa: BLE001
            return None

    def joint_names_matching(self, *keys) -> list[str]:
        m = self.inner.sim.model
        out = []
        for i in range(int(m.njnt)):
            nm = ms.joint_name(m, i)
            if nm and any(k in nm for k in keys):
                out.append(nm)
        return out

    def close(self):
        try:
            self.env.close()
        except Exception:  # noqa: BLE001
            pass


def build_B(probe: TaskProbe, subgoal1: list[str]) -> tuple[np.ndarray | None, dict]:
    """尝试构造 B 状态：subgoal-1 完成、overall 未完成。

    做法：从官方初始状态出发，**只改与 subgoal-1 直接相关的关节**
    （例如炉子的开关关节），不碰机器人、不碰其他物体。
    返回 (state, 诊断)。
    """
    diag: dict = {"method": None, "tried": []}
    probe.reset()
    base = probe.state()
    if probe.eval_pred(subgoal1):
        return base, {"method": "official_init_already_satisfies_subgoal1",
                      "tried": []}

    # 候选关节：名字里含 subgoal 谓词涉及的对象
    obj = subgoal1[-1] if len(subgoal1) == 2 else subgoal1[1]
    key = obj.split("_1")[0]           # flat_stove_1 -> flat_stove
    cands = probe.joint_names_matching(key)
    diag["candidate_joints"] = cands

    m = probe.inner.sim.model
    for jn in cands:
        for val in (0.0, 1.0, -1.0, 0.5, -0.5):
            try:
                s = ms.set_joint_pos(base.copy(), m, jn, float(val))
            except Exception as e:  # noqa: BLE001
                diag["tried"].append({"joint": jn, "value": val,
                                      "error": f"{type(e).__name__}: {e}"})
                continue
            probe.set_state(s)
            ok1 = probe.eval_pred(subgoal1)
            ok_all = probe.overall()
            diag["tried"].append({"joint": jn, "value": val,
                                  "subgoal1": ok1, "overall": ok_all})
            if ok1 and not ok_all:
                diag["method"] = f"set {jn}={val}"
                return s, diag
    return None, diag


def main() -> int:
    STATES.mkdir(parents=True, exist_ok=True)
    IMAGES.mkdir(parents=True, exist_ok=True)
    report: dict = {"schema_version": "plan1-stage4-feasibility-v1",
                    "tasks": [], "notes": []}

    for suite_name, task_name in CANDIDATES:
        print(f"\n{'='*78}\n{suite_name} :: {task_name}\n{'='*78}", flush=True)
        entry: dict = {"suite": suite_name, "task": task_name}
        probe = None
        try:
            probe = TaskProbe(suite_name, task_name)
            entry["language"] = probe.task.language
            entry["bddl_path"] = str(probe.bddl)
            entry["goal_from_bddl"] = probe.goal_preds
            entry["goal_from_env"] = probe.env_goal
            # 大小写已在解析时归一化，这里做**逐谓词**的严格比对
            entry["bddl_matches_env"] = (probe.goal_preds == probe.env_goal)
            if not entry["bddl_matches_env"]:
                entry["bddl_vs_env_diff"] = {
                    "bddl": probe.goal_preds, "env": probe.env_goal}
            print(f"  bddl : {probe.bddl}")
            print(f"  lang : {probe.task.language}")
            print(f"  官方 goal 谓词 ({len(probe.goal_preds)} 个):")
            for k, p in enumerate(probe.goal_preds, 1):
                print(f"    subgoal-{k}: {p}")
            print(f"  BDDL 解析与 env.parsed_problem 一致: {entry['bddl_matches_env']}")

            n_pred = len(probe.goal_preds)
            entry["is_genuinely_multi_predicate"] = n_pred >= 2
            if n_pred < 2:
                entry["verdict"] = (
                    "NOT SUITABLE：官方 goal 只有 1 个谓词，"
                    "任务名里的 'and' 不在 goal 里，无法定义 official subgoal-1")
                print(f"  ⚠ {entry['verdict']}")
                report["tasks"].append(entry)
                continue

            sub1, sub2 = probe.goal_preds[0], probe.goal_preds[1]
            probe.reset()
            entry["A_official_init"] = {
                "subgoal1": probe.eval_pred(sub1),
                "subgoal2": probe.eval_pred(sub2),
                "overall": probe.overall(),
            }
            print(f"\n  A（官方初始）: subgoal1={entry['A_official_init']['subgoal1']} "
                  f"subgoal2={entry['A_official_init']['subgoal2']} "
                  f"overall={entry['A_official_init']['overall']}")

            st_B, diag = build_B(probe, sub1)
            entry["build_B"] = diag
            if st_B is None:
                entry["verdict"] = "B 构造失败"
                print(f"  ✗ B 构造失败；尝试过 {len(diag.get('tried', []))} 种")
                report["tasks"].append(entry)
                continue

            probe.set_state(st_B)
            entry["B_constructed"] = {
                "method": diag["method"],
                "subgoal1": probe.eval_pred(sub1),
                "subgoal2": probe.eval_pred(sub2),
                "overall": probe.overall(),
            }
            print(f"  B（{diag['method']}）: subgoal1={entry['B_constructed']['subgoal1']} "
                  f"subgoal2={entry['B_constructed']['subgoal2']} "
                  f"overall={entry['B_constructed']['overall']}")

            # ---- 一致性验证 ----
            probe.reset()
            st_A = probe.state()
            probe.set_state(st_A)
            qA = probe.robot_qpos(st_A)
            probe.set_state(st_B)
            qB = probe.robot_qpos(st_B)
            entry["consistency"] = {
                "robot_qpos_max_abs_diff": float(np.abs(qA - qB).max()),
                "robot_qpos_identical": bool(np.abs(qA - qB).max() < 1e-12),
                "A_state_size": int(st_A.size), "B_state_size": int(st_B.size),
            }
            # 非任务实体是否被改动（用自由物体位置近似）
            others = {}
            for name in ("moka_pot_1", "chefmate_8_frypan_1", "akita_black_bowl_1"):
                pa = probe.entity_pos(st_A, name)
                pb = probe.entity_pos(st_B, name)
                if pa is not None and pb is not None:
                    others[name] = float(np.linalg.norm(np.asarray(pa) - np.asarray(pb)))
            entry["consistency"]["non_task_entity_shift_m"] = others
            print(f"  机器人前 9 关节 A/B 一致: {entry['consistency']['robot_qpos_identical']}")
            print(f"  非任务实体位移: {others}")

            # ---- 保存（2 seed smoke：同一 A/B，用不同 official init index）----
            saved = []
            # 官方初始状态由 LIBERO 的模块级函数提供
            # （`run_libero_eval.py` 也是这么取的），不是 inner env 的属性。
            task_id = suite_index = None
            suite = B.get_benchmark_dict()[suite_name]()
            for i, t in enumerate(suite.tasks):
                if t.name == task_name:
                    suite_index = i
                    break
            # 官方初始状态是 **suite 的方法**：`task_suite.get_task_init_states(i)`
            # （官方 run_libero_eval.py:232 就是这么取的），
            # 不是 inner env 的属性，也不是模块级函数。
            init_states = None
            try:
                init_states = suite.get_task_init_states(suite_index)
            except Exception as e:  # noqa: BLE001
                entry["init_states_error"] = f"{type(e).__name__}: {e}"
            entry["n_official_init_states"] = (len(init_states) if init_states is not None
                                               else None)
            for seed in range(2):
                try:
                    if init_states is None:
                        raise RuntimeError("拿不到官方 init states")
                    probe.env.reset()
                    probe.env.set_init_state(init_states[seed])
                    probe.inner.sim.forward()
                    sA = probe.state()
                except Exception as e:  # noqa: BLE001
                    print(f"    seed {seed}: official init 取用失败 {type(e).__name__}: {e}")
                    continue
                rec = {"seed": seed,
                       "A_official_init": {"subgoal1": probe.eval_pred(sub1),
                                           "subgoal2": probe.eval_pred(sub2),
                                           "overall": probe.overall()}}
                pA = STATES / f"{task_name}__s{seed}__A.npy"
                np.save(pA, sA)
                rec["A_path"] = str(pA)
                imgA = probe.image()
                if imgA is not None:
                    import imageio.v2 as imageio
                    pi = IMAGES / f"{task_name}__s{seed}__A.png"
                    imageio.imwrite(pi, imgA)
                    rec["A_image"] = str(pi)
                # B = 在 A 的基础上只改 subgoal-1 相关关节（保持机器人一致）
                st_B_seed, d2 = build_B(probe, sub1)
                if st_B_seed is not None:
                    pB = STATES / f"{task_name}__s{seed}__B.npy"
                    np.save(pB, st_B_seed)
                    rec["B_path"] = str(pB)
                    rec["B_method"] = d2["method"]
                    probe.set_state(st_B_seed)
                    rec["B"] = {"subgoal1": probe.eval_pred(sub1),
                                "subgoal2": probe.eval_pred(sub2),
                                "overall": probe.overall()}
                    imgB = probe.image()
                    if imgB is not None:
                        import imageio.v2 as imageio
                        pi = IMAGES / f"{task_name}__s{seed}__B.png"
                        imageio.imwrite(pi, imgB)
                        rec["B_image"] = str(pi)
                saved.append(rec)
            entry["smoke_seeds"] = saved
            entry["verdict"] = "OK" if entry["bddl_matches_env"] else "参考不一致"
        except Exception as exc:  # noqa: BLE001
            import traceback as tb
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["traceback"] = tb.format_exc()
            print(f"  ERROR: {entry['error']}")
        finally:
            if probe is not None:
                probe.close()
        report["tasks"].append(entry)

    report["notes"] = [
        "goal 谓词全部来自官方 BDDL 的 :goal，并与 env.parsed_problem 交叉核对。",
        "谓词评估使用 LIBERO 自己的 _eval_predicate，未重新实现语义。",
        "B 状态只修改 subgoal-1 直接相关的关节，不动机器人与其他物体。",
    ]
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "feasibility.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[stage4-A] -> {OUT/'feasibility.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
