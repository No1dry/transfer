"""Stage 4 gate：smoke 的**语义**验收闸门（mentor_review_9 §3）。

为什么需要加强：上一版 7 项只检查"列存在/非空"，
所以 I2 的距离列**语义错误**（用的是 stove body 而不是 button）也能 PASS。
闸门必须验证字段的 **provenance**，而不只是 schema。

本脚本同时验收 I1 的既有 trace 与 I2 的新 trace（§5.5）。

用法:
    ./run_diag.sh scripts/plan1_stage4_gate.py \\
        --i1 results/plan1/intermediate/pilot_v2 \\
        --i2 results/plan1/intermediate/pilot_v2_i2
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

FIRST_STEP_HARD_LIMIT_M = 0.05
A_ORIG_B_MIN_SEP_M = 0.05
EXPECTED_BUTTON_BODY = "flat_stove_1_button"


def read_trace(p: Path) -> list[dict]:
    with p.open(encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fnum(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def xyz(row, key):
    xs = [fnum(row.get(f"{key}_{i}")) for i in range(3)]
    return None if any(v is None for v in xs) else np.asarray(xs, dtype=np.float64)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--i1", default="results/plan1/intermediate/pilot_v2")
    ap.add_argument("--i2", default="results/plan1/intermediate/pilot_v2_i2")
    args = ap.parse_args()
    root0 = Path("/HUBU-AI004/zp/ICML")
    roots = [("I1", root0 / args.i1), ("I2", root0 / args.i2)]

    checks: dict[str, bool] = {}
    detail: dict = {}
    traces: dict[tuple, Path] = {}

    for tag, root in roots:
        cands = sorted(root.glob("pilot_v2*.json")) if root.exists() else []
        if not cands:
            print(f"[skip] {tag}: {root} 下没有结果 JSON")
            continue
        rep = json.loads(cands[0].read_text(encoding="utf-8"))
        td = next((t for t in rep["tasks"] if t.get("tag") == tag), rep["tasks"][0])
        meta = td.get("entity_meta", {})
        pair_meta = td.get("pair_meta", {})

        # ---- §3.1 anchor provenance（I2 必须是 button joint body）----
        if tag == "I2":
            seen, ok = [], True
            for key, m in meta.items():
                for ent, info in m.items():
                    if ent != td["completed"]:
                        continue
                    seen.append((key, info.get("anchor_body"),
                                 info.get("anchor_source")))
                    if info.get("anchor_body") != EXPECTED_BUTTON_BODY:
                        ok = False
            checks["I2_anchor_provenance_valid"] = ok
            detail["I2_anchor_seen"] = seen[:3]
            cok = bool(meta) and all(
                set(m[td["completed"]]["body_names"]) == {EXPECTED_BUTTON_BODY}
                for m in meta.values() if td["completed"] in m)
            checks["I2_contact_geom_bodies_are_button"] = cok

        for e in td.get("episodes", []):
            traces[(tag, e["seed"], e["condition"], e["mode"])] = Path(e["trace"])
            # 不从 JSON 读 coverage（在线值可能因 bug 不可信），
            # 而是**从 trace 重算** —— 这才是 §3.7 "可离线复算" 的精神。
            p_tr = Path(e["trace"])
            if p_tr.exists():
                rws = read_trace(p_tr)
                req_cols = (["contact_completed", "contact_remaining"]
                            + (["contact_container"] if tag == "I1" else []))
                bad = [c for c in req_cols
                       if sum(1 for r in rws if r.get(c) not in ("", "None", None))
                       != len(rws)]
                checks.setdefault("contact_coverage_complete", True)
                if bad or not rws:
                    checks["contact_coverage_complete"] = False
                    detail.setdefault("coverage_missing", {})[str(p_tr.name)] = bad

        # ---- §3.4 同 seed 四条 rollout 的 A-orig 必须一致 ----
        for s_key in (pair_meta or {}):
            seed = int(str(s_key).lstrip("s"))
            vals = []
            for cond in ("A", "B"):
                for mode in ("policy", "noop"):
                    p = traces.get((tag, seed, cond, mode))
                    if p is None or not p.exists():
                        continue
                    vals.append(tuple(xyz(read_trace(p)[0], "completed_A_orig_xyz")
                                      if xyz(read_trace(p)[0], "completed_A_orig_xyz")
                                      is not None else None))
            checks[f"{tag}_A_orig_shared_across_rollouts"] = (len(set(vals)) <= 1)

        # ---- §3.5 / §3.6 起点关系 ----
        seeds = sorted({k[1] for k in traces if k[0] == tag})
        shared_ok = True
        for s in seeds:
            pb, pn = traces.get((tag, s, "B", "policy")), traces.get((tag, s, "B", "noop"))
            if not (pb and pn and pb.exists() and pn.exists()):
                continue
            cb = xyz(read_trace(pb)[0], "completed_start_xyz")
            cn = xyz(read_trace(pn)[0], "completed_start_xyz")
            if cb is None or cn is None or not np.allclose(cb, cn, atol=1e-9):
                shared_ok = False
            ao = xyz(read_trace(pb)[0], "completed_A_orig_xyz")
            if cb is not None and ao is not None:
                sep = float(np.linalg.norm(cb - ao))
                detail[f"{tag}_B_start_vs_A_orig_m"] = sep
                if tag == "I1":
                    checks["I1_B_completed_start_differs_from_A_orig"] = (
                        sep > A_ORIG_B_MIN_SEP_M)
        checks[f"{tag}_completed_start_shared_policy_noop"] = shared_ok

        # ---- §3.2 policy/noop step0 一致（A 条件）----
        step0_same = True
        for s in seeds:
            pa, pn = traces.get((tag, s, "A", "policy")), traces.get((tag, s, "A", "noop"))
            if not (pa and pn and pa.exists() and pn.exists()):
                continue
            ra, rn = read_trace(pa)[0], read_trace(pn)[0]
            ea = np.asarray([fnum(ra.get(f"eef_{k}")) or 0 for k in "xyz"])
            en = np.asarray([fnum(rn.get(f"eef_{k}")) or 0 for k in "xyz"])
            if not np.allclose(ea, en, atol=1e-9):
                step0_same = False
        checks[f"{tag}_policy_noop_step0_equal"] = step0_same

    # ---- §3.2 / §3.3 step0 存在 + 首步位移硬上限 ----
    step0_ok = bool(traces)
    guard_ok = True
    for key, p in traces.items():
        if not p.exists():
            step0_ok = False
            continue
        rows = read_trace(p)
        if not rows or rows[0].get("step") != "0":
            step0_ok = False
            continue
        if len(rows) > 1:
            e0 = np.asarray([fnum(rows[0].get(f"eef_{k}")) or 0 for k in "xyz"])
            e1 = np.asarray([fnum(rows[1].get(f"eef_{k}")) or 0 for k in "xyz"])
            d = float(np.linalg.norm(e1 - e0))
            if d > FIRST_STEP_HARD_LIMIT_M:
                guard_ok = False
                detail.setdefault("bad_first_step", {})[str(key)] = d
    checks["trace_has_step0"] = step0_ok
    checks["first_step_guard"] = guard_ok

    print("=" * 72)
    print("Stage 4 gate（含 mentor_review_9 §3 的语义检查）")
    print("=" * 72)
    for k in sorted(checks):
        print(f"  [{'PASS' if checks[k] else 'FAIL'}] {k}")
    if detail.get("I2_anchor_seen"):
        print(f"\n  I2 anchor 抽样: {detail['I2_anchor_seen'][:2]}")
    for k in ("I1_B_start_vs_A_orig_m", "I2_B_start_vs_A_orig_m"):
        if k in detail:
            print(f"  {k} = {detail[k]:.4f} m")
    allok = bool(checks) and all(checks.values())
    print(f"\nGATE: {'ALL PASS' if allok else 'SOME FAILED'}")

    out = root0 / "results/plan1/intermediate/gate_report.json"
    out.write_text(json.dumps({"checks": checks, "detail": detail},
                              indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"[out] {out}")
    return 0 if allok else 1


if __name__ == "__main__":
    raise SystemExit(main())
