"""plan1 Stage 4：离线汇总分析器（mentor_review_11 §5.1–§5.4）。

职责
----
1. **从 trace 重算**每个 episode 的事件（真正调用 `compute_stage4_events()`），
   而不是信任在线 JSON —— 在线值可能因 bug 不可信（本任务已发生过两次）。
2. 输出 online vs offline 的 **mismatch 清单**；任何核心事件 mismatch 都要解释。
3. 生成正式汇总 `stage4_summary.{json,csv,md}`。
4. 明确分母：**20 policy episodes + 20 no-op controls**（不统称 40 个样本）。
5. A 条件只作正常行为模板，**不纳入** re-execution / skip rate。

用法:
    ./run_diag.sh scripts/plan1_stage4_offline.py \
        --run results/plan1/intermediate/pilot_full
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.stage4_events import compute_stage4_events  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")

BOOL_COLS = ("subject_contact", "target_contact", "contact_completed",
             "contact_remaining", "contact_container")
INT_COLS = ("step", "sg1", "sg2", "overall")
STR_COLS = ("mode",)


def read_trace(p: Path) -> list[dict]:
    """把 trace CSV 读回成 `compute_stage4_events` 期望的形式。"""
    rows: list[dict] = []
    with p.open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out: dict = {}
            for k, v in r.items():
                if v in ("", "None", None):
                    out[k] = None
                elif k in BOOL_COLS:
                    out[k] = (v.lower() == "true")
                elif k in INT_COLS:
                    out[k] = int(float(v))
                elif k == "raw_gripper" or k == "processed_gripper":
                    out[k] = float(v)
                else:
                    try:
                        out[k] = float(v)
                    except (TypeError, ValueError):
                        out[k] = v
            rows.append(out)
    return rows


def core_events(prof: dict) -> dict:
    return dict(prof.get("events", {}))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="results/plan1/intermediate/pilot_full")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    run = ROOT / a.run
    out = ROOT / a.out if a.out else run
    js = next(iter(sorted(run.glob("pilot_v2*.json"))), None)
    if js is None:
        print(f"[FAIL] {run} 下没有在线 JSON")
        return 1
    online = json.loads(js.read_text(encoding="utf-8"))

    episodes = []
    mismatches = []
    for td in online["tasks"]:
        tag = td["tag"]
        for ep in td.get("episodes", []):
            p = Path(ep["trace"])
            if not p.exists():
                mismatches.append({"trace": str(p), "reason": "trace 缺失"})
                continue
            rows = read_trace(p)
            off = compute_stage4_events(rows, tag=tag, condition=ep["condition"])
            on_ev = core_events(ep.get("events", {}))
            off_ev = core_events(off)
            diff = {k: (on_ev.get(k), off_ev.get(k))
                    for k in set(on_ev) | set(off_ev)
                    if on_ev.get(k) != off_ev.get(k)}
            if diff:
                mismatches.append({"tag": tag, "seed": ep["seed"],
                                   "condition": ep["condition"], "mode": ep["mode"],
                                   "trace": str(p), "diff": diff})
            episodes.append({
                "tag": tag, "task": td["task"], "seed": ep["seed"],
                "condition": ep["condition"], "mode": ep["mode"],
                "n_steps": len(rows),
                "overall_success": bool(rows[-1].get("overall")) if rows else False,
                "events": off_ev,
                "quantities": off.get("quantities", {}),
                "trace": str(p), "video": ep.get("video"),
                "online_events": on_ev,
                "online_success": ep.get("overall_success"),
                "online_n_steps": ep.get("n_steps"),
            })

    policy = [e for e in episodes if e["mode"] == "policy"]
    noop = [e for e in episodes if e["mode"] == "noop"]
    print("=" * 74)
    print("Stage 4 离线汇总（全部由 trace 重算）")
    print("=" * 74)
    print(f"  分母：{len(policy)} policy episodes + {len(noop)} no-op controls "
          f"（合计 {len(episodes)} 个 rollout，**不要统称 {len(episodes)} 个实验样本**）")
    print(f"  online/offline 核心事件 mismatch：**{len(mismatches)}**")

    # ---- 表 1：per task × condition（B 才报 reexec/skip）----
    print("\n表1  per task × condition")
    hdr = (f"{'task':<5}{'cond':<5}{'n':>3}{'SR':>6}{'reexec':>9}{'skip':>8}"
           f"{'disturb':>9}   first_target")
    print(hdr)
    print("-" * len(hdr))
    tbl = {}
    for tag in ("I1", "I2"):
        for cond in ("A", "B"):
            sub = [e for e in policy if e["tag"] == tag and e["condition"] == cond]
            if not sub:
                continue
            n = len(sub)
            sr = sum(1 for e in sub if e["overall_success"])
            if cond == "B":
                rx = sum(1 for e in sub if e["events"]["completed_subgoal_reexecution"])
                sk = sum(1 for e in sub if e["events"]["correct_skip"])
            else:
                rx = sk = None
            dis = sum(1 for e in sub if e["events"]["completed_subgoal_disturbed"])
            ft = Counter(e["events"]["first_task_target"] for e in sub)
            tbl[(tag, cond)] = {
                "n": n, "overall_sr": f"{sr}/{n}", "sr_value": sr / n,
                "re_execution": (f"{rx}/{n}" if rx is not None else "n/a (A 只作模板)"),
                "correct_skip": (f"{sk}/{n}" if sk is not None else "n/a"),
                "completed_subgoal_disturbed": f"{dis}/{n}",
                "first_target_counts": dict(ft),
                "verdicts": dict(Counter(e["events"]["behavior_verdict"] for e in sub)),
                "steps_to_sg2": [e["quantities"]["sg2_flips"]["first_true"] for e in sub],
                "episodes": [{"seed": e["seed"], "success": e["overall_success"],
                              "n_steps": e["n_steps"], "trace": e["trace"],
                              "video": e["video"],
                              "verdict": e["events"]["behavior_verdict"],
                              "first_target": e["events"]["first_task_target"]}
                             for e in sorted(sub, key=lambda x: x["seed"])],
            }
            print(f"{tag:<5}{cond:<5}{n:>3}{sr}/{n:<5}"
                  f"{str(tbl[(tag, cond)]['re_execution']):>9}"
                  f"{str(tbl[(tag, cond)]['correct_skip']):>8}"
                  f"{dis}/{n:<7}   {dict(ft)}")

    # ---- 表 2：A 模板（不进 B 的 rate）----
    print("\n表2  A 条件正常行为模板（**不纳入** re-execution / skip rate）")
    for tag in ("I1", "I2"):
        t = tbl.get((tag, "A"))
        if not t:
            continue
        sg1 = [e["quantities"]["sg1_flips"]["first_true"]
               for e in policy if e["tag"] == tag and e["condition"] == "A"]
        sg2 = t["steps_to_sg2"]
        print(f"  {tag}: SR={t['overall_sr']}  sg1 首次达成中位="
              f"{np.median([x for x in sg1 if x]) if any(sg1) else None}  "
              f"sg2 首次达成中位={np.median([x for x in sg2 if x]) if any(sg2) else None}")

    # ---- 表 3：no-op 对照 ----
    print("\n表3  no-op 对照（drift / predicate 稳定性；**不与 policy SR 混合**）")
    for tag in ("I1", "I2"):
        for cond in ("A", "B"):
            sub = [e for e in noop if e["tag"] == tag and e["condition"] == cond]
            if not sub:
                continue
            c = sum(1 for e in sub if e["quantities"]["contacted_completed"]
                    or e["quantities"]["contacted_remaining"])
            rx = sum(1 for e in sub if e["events"]["completed_subgoal_reexecution"])
            print(f"  {tag} {cond}: n={len(sub)}  task_contact={c}  reexec={rx}  "
                  f"SR={sum(1 for e in sub if e['overall_success'])}/{len(sub)}")

    # ---- 表 4：approach 敏感度（§3.8）----
    print("\n表4  approach 敏感度（B 条件 policy；§3.8 要求保留连续量）")
    for tag in ("I1", "I2"):
        sub = [e for e in policy if e["tag"] == tag and e["condition"] == "B"]
        for key in ("approach_completed_A_orig", "approach_completed_current",
                    "approach_remaining"):
            vals = [e["quantities"][key] for e in sub if e["quantities"].get(key, {}).get("measured")]
            if not vals:
                continue
            d0 = [v["step0"] for v in vals if v["step0"] is not None]
            dm = [v["min"] for v in vals if v["min"] is not None]
            cross = {f"{int(t*100)}cm": sum(
                1 for v in vals if v["levels"][f"{int(t*100)}cm"]["crossing_step"] is not None)
                for t in (0.05, 0.10, 0.15)}
            print(f"  {tag} {key:<28} step0 中位={np.median(d0):.3f}  "
                  f"min 中位={np.median(dm):.3f}  穿越次数={cross}")

    # ---- 落盘 ----
    (out / "stage4_summary.json").write_text(json.dumps({
        "schema_version": "plan1-stage4-summary-v1",
        "denominator": {"policy_episodes": len(policy),
                        "noop_controls": len(noop),
                        "note": "分母是 20 policy + 20 no-op，不是 40 个独立实验样本"},
        "online_offline_mismatches": mismatches,
        "per_task_condition": {f"{k[0]}_{k[1]}": v for k, v in tbl.items()},
        "episodes": [{k: v for k, v in e.items() if k != "quantities"}
                     for e in episodes],
    }, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    with (out / "stage4_summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["task", "condition", "seed", "mode", "n_steps", "success",
                    "verdict", "first_target", "trace", "video"])
        for e in sorted(episodes, key=lambda x: (x["tag"], x["condition"], x["mode"], x["seed"])):
            w.writerow([e["tag"], e["condition"], e["seed"], e["mode"], e["n_steps"],
                        int(e["overall_success"]), e["events"]["behavior_verdict"],
                        e["events"]["first_task_target"], e["trace"], e["video"]])

    md = ["# Stage 4 Intermediate Pilot — 汇总（由 trace 离线重算）", "",
          f"- 分母：**{len(policy)} policy episodes + {len(noop)} no-op controls**",
          f"- online/offline 核心事件 mismatch：**{len(mismatches)}**", "",
          "| task | cond | n | Overall SR | Re-execution | Correct skip | Disturbed | first target |",
          "|---|---|---:|---:|---:|---:|---:|---|"]
    for (tag, cond), v in tbl.items():
        md.append(f"| {tag} | {cond} | {v['n']} | {v['overall_sr']} | "
                  f"{v['re_execution']} | {v['correct_skip']} | "
                  f"{v['completed_subgoal_disturbed']} | {v['first_target_counts']} |")
    md += ["", "> A 条件仅作正常行为模板，不纳入 re-execution / skip rate。",
           "> no-op 仅作 drift / predicate 稳定性对照，不与 policy SR 混合。"]
    (out / "stage4_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print(f"\n[out] {out}/stage4_summary.{{json,csv,md}}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
