"""plan1 Stage 4：paired state builder（mentor_review_5 §3 / §4 修正版）。

相对上一版的修正：

  §3.1  `build_B(probe, sub, base_state=sA)` **必须显式传入 base state**；
        函数内部**禁止 reset**（不传就报错）。上一版内部偷偷 reset，
        导致 B 不是从 A 原地构造，非任务实体出现 1.6–4.0 cm 偏移。
  §3.2  robot qpos 用 `StateLayout.from_model(model)` + `get_robot_qpos`，
        **不能** `state[:9]` —— 扁平状态第 0 维是 `time`。
  §3.3  A/B 做**逐维 diff 白名单**，并把差异映射回 qpos joint / qvel dof 名字。
  §3.4  关节取值必须有物理依据：记录 joint range、predicate 阈值范围、
        所选值与交集关系；不再盲试 (0,1,-1,0.5,-0.5)。
  §4    新 I1 = LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket
        （soup 作为 completed object）。

产物：`results/plan1/intermediate/pairs_v2/{pairs.json, states/, images/}`

用法: ./run_diag.sh scripts/plan1_stage4_pairs.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from libero.libero import benchmark as B  # noqa: E402
from libero.libero.envs import OffScreenRenderEnv  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402
from benchmark.states.mujoco_state import StateLayout, get_robot_qpos  # noqa: E402
from benchmark.bddl_goal import parse_goal_from_bddl  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
BDDL_ROOT = ROOT / "LIBERO/libero/libero/bddl_files"
OUT = ROOT / "results/plan1/intermediate/pairs_v2"
STATES = OUT / "states"
IMAGES = OUT / "images"

N_ROBOT_QPOS = 9
NOOP_STABLE_STEPS = 10
OFFICIAL_WAIT_STEPS = 10   # §2.1：正式评估语义包含 10 个 official wait steps


def official_dummy_action(model_family: str = "openvla"):
    """§2.1：用 LIBERO / OpenVLA **官方** dummy action，不手写全零。

    来源与 `LiberoArena.no_op_action()` 完全一致
    （openvla-oft 的 `experiments.robot.libero.libero_utils`）。
    """
    from experiments.robot.libero.libero_utils import get_libero_dummy_action
    return list(get_libero_dummy_action(model_family))


def state_hash(s: np.ndarray) -> str:
    import hashlib
    return hashlib.sha256(np.asarray(s, dtype=np.float64).tobytes()).hexdigest()[:16]

N_SEEDS = int(__import__("os").environ.get("PAIR_SEEDS", "2"))
"""构造多少个 official init index 的配对。pilot 需要 5。"""

TASKS = [
    # (suite, task, completed_object, placement_site_key)
    ("libero_10",
     "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket",
     "alphabet_soup_1", "basket_1_contain_region"),
    ("libero_10",
     "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it",
     None, None),          # 用关节方式构造
]


class Probe:
    def __init__(self, suite_name: str, task_name: str):
        self.suite_name, self.task_name = suite_name, task_name
        self.suite = B.get_benchmark_dict()[suite_name]()
        self.index = next(i for i, t in enumerate(self.suite.tasks)
                          if t.name == task_name)
        self.task = self.suite.tasks[self.index]
        self.bddl = BDDL_ROOT / suite_name / f"{task_name}.bddl"
        self.goal = parse_goal_from_bddl(self.bddl)
        self.env = OffScreenRenderEnv(bddl_file_name=str(self.bddl),
                                      camera_heights=256, camera_widths=256)
        self.inner = self.env.env
        self.model = self.inner.sim.model
        self.layout = StateLayout.from_model(self.model)
        self.env_goal = [list(p) for p in self.inner.parsed_problem["goal_state"]]

    # ---- 谓词（用 LIBERO 自己的实现）----
    def ev(self, p) -> bool:
        return bool(self.inner._eval_predicate(list(p)))

    def overall(self) -> bool:
        return all(self.ev(p) for p in self.goal)

    def labels(self) -> dict:
        return {"subgoal1": self.ev(self.goal[0]),
                "subgoal2": self.ev(self.goal[1]) if len(self.goal) > 1 else None,
                "overall": self.overall()}

    # ---- 状态 ----
    def state(self) -> np.ndarray:
        return np.asarray(self.inner.sim.get_state().flatten(), dtype=np.float64).copy()

    def load(self, s):
        self.inner.sim.set_state_from_flattened(np.asarray(s, dtype=np.float64))
        self.inner.sim.forward()

    def robot_qpos(self, s) -> np.ndarray:
        """§3.2：必须走 StateLayout，不能 state[:9]（第 0 维是 time）。"""
        return get_robot_qpos(np.asarray(s, dtype=np.float64), self.layout,
                              n=N_ROBOT_QPOS)

    def step(self, action=None):
        a = self.inner.action_dim * [0.0] if action is None else action
        return self.inner.step(np.asarray(a, dtype=np.float64))

    def image(self):
        try:
            return np.asarray(self.inner.sim.render(width=256, height=256,
                                                    camera_name="agentview"))
        except Exception:  # noqa: BLE001
            return None

    def close(self):
        try:
            self.env.close()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# §3.3 逐维 diff 白名单
# ---------------------------------------------------------------------------

def qpos_index_to_name(model, idx: int) -> str:
    for i in range(int(model.njnt)):
        adr = int(model.jnt_qposadr[i])
        dim = 7 if int(model.jnt_type[i]) == 0 else 1   # free joint 占 7
        if adr <= idx < adr + dim:
            nm = ms.joint_name(model, i)
            return nm if dim == 1 else f"{nm}[{idx - adr}]"
    return f"<qpos#{idx}>"


def qvel_index_to_name(model, idx: int) -> str:
    for i in range(int(model.njnt)):
        adr = int(model.jnt_dofadr[i])
        dim = 6 if int(model.jnt_type[i]) == 0 else 1
        if adr <= idx < adr + dim:
            nm = ms.joint_name(model, i)
            return nm if dim == 1 else f"{nm}[{idx - adr}]"
    return f"<qvel#{idx}>"


def state_diff_whitelist(model, layout, sA, sB, allowed_prefixes: list[str]) -> dict:
    """§3.3：逐维 diff，映射回 qpos/qvel 名字，判断是否只动了白名单内的量。"""
    d = np.abs(np.asarray(sA, dtype=np.float64) - np.asarray(sB, dtype=np.float64))
    changed = np.flatnonzero(d > 1e-9)
    qs, qe = layout.qpos_slice.start, layout.qpos_slice.stop
    vs, ve = layout.qvel_slice.start, layout.qvel_slice.stop
    resolved, unexpected = [], []
    for i in changed:
        i = int(i)
        if i == 0:
            name, seg = "time", "time"
        elif qs <= i < qe:
            name, seg = qpos_index_to_name(model, i - qs), "qpos"
        elif vs <= i < ve:
            name, seg = qvel_index_to_name(model, i - vs), "qvel"
        else:
            name, seg = f"<act#{i}>", "act"
        ok = any(name.startswith(p) for p in allowed_prefixes)
        resolved.append({"index": i, "segment": seg, "name": name,
                         "abs_diff": float(d[i]), "allowed": bool(ok)})
        if not ok:
            unexpected.append(name)
    return {
        "changed_indices": [int(i) for i in changed],
        "resolved_names": resolved,
        "n_changed": int(changed.size),
        "max_unexpected_abs_diff": (
            float(max([r["abs_diff"] for r in resolved if not r["allowed"]], default=0.0))),
        "unexpected_names": sorted(set(unexpected)),
        "pair_valid": len(unexpected) == 0,
    }


# ---------------------------------------------------------------------------
# §4 B 状态构造：**必须从传入的 base state 原地构造，禁止 reset**
# ---------------------------------------------------------------------------

def build_B_object(probe: Probe, base: np.ndarray, obj: str,
                   site_key: str) -> tuple[np.ndarray | None, dict]:
    """把 completed object 放到 basket contain region（§4.2）。"""
    model = probe.model
    site_i = next((i for i in range(int(model.nsite))
                   if model.site_id2name(i) == site_key), None)
    if site_i is None:
        return None, {"error": f"找不到 site {site_key}"}
    tgt = np.asarray(probe.inner.sim.data.site_xpos[site_i], dtype=np.float64).copy()
    # 放到 region 中心稍上方，让它自然落入
    placed = tgt + np.array([0.0, 0.0, 0.03])
    sB = ms.set_object_pos(base.copy(), model, obj, placed)
    # qvel 清零：放置后应静止（§4.2 允许改 completed object 的 qvel）
    try:
        # 签名是 (state, model, name_or_prefix)
        sB = ms.clear_object_velocity(sB, model, obj)
    except Exception as e:  # noqa: BLE001
        return None, {"error": f"clear_object_velocity 失败: {type(e).__name__}: {e}"}
    probe.load(sB)
    return sB, {"method": f"set_object_pos({obj}) -> {site_key}+3cm, qvel=0",
                "target_xpos": tgt.tolist(), "placed_xpos": placed.tolist()}


def build_B_joint(probe: Probe, base: np.ndarray, subgoal1: list[str]) -> tuple[np.ndarray | None, dict]:
    """把 subgoal-1 相关关节设到「打开」值（§3.4：取值必须有物理依据）。"""
    model = probe.model
    obj = subgoal1[-1]
    key = obj.split("_1")[0]
    cands = [ms.joint_name(model, i) for i in range(int(model.njnt))
             if ms.joint_name(model, i) and key in ms.joint_name(model, i)]
    diag: dict = {"candidate_joints": cands, "attempts": []}
    for jn in cands:
        # §3.4：读 joint range，并在 range 内取**靠近上界**的值（turnon 通常需要大值）
        entry = ms.resolve_single_dof_joint(model, jn)
        jid = next((i for i in range(int(model.njnt))
                    if ms.joint_name(model, i) == entry.name), None)
        if jid is None:
            continue
        lo, hi = float(model.jnt_range[jid][0]), float(model.jnt_range[jid][1])
        # §2.3：先**扫描出 predicate-valid 下界**，再取它与上界的中点，
        # 避免把 B 放在机械极限上。
        valid_lo = None
        for frac in np.linspace(0.0, 1.0, 21):
            v = lo + frac * (hi - lo)
            probe.load(ms.set_joint_pos(base.copy(), model, jn, float(v)))
            if probe.ev(subgoal1):
                valid_lo = float(v)
                break
        if valid_lo is not None:
            midpoint = (valid_lo + hi) / 2.0
            diag["predicate_valid_range"] = [valid_lo, hi]
            candidates = (midpoint, hi, valid_lo)
        else:
            diag["predicate_valid_range"] = None
            candidates = (hi, (lo + hi) / 2.0, lo)
        probe.load(base)
        for val in candidates:
            sB = ms.set_joint_pos(base.copy(), model, jn, float(val))
            probe.load(sB)
            rec = {"joint": jn, "joint_range": [lo, hi], "chosen_value": float(val),
                   "in_range": bool(lo <= val <= hi)}
            rec.update(probe.labels())
            diag["attempts"].append(rec)
            if rec["subgoal1"] and not rec["overall"]:
                diag.update({"method": f"set {jn}={val}", "joint_range": [lo, hi],
                             "chosen_value": float(val),
                             "chosen_in_range": bool(lo <= val <= hi),
                             "predicate_valid_range": diag.get("predicate_valid_range"),
                             "chosen_is_midpoint": bool(
                                 diag.get("predicate_valid_range")
                                 and abs(val - (diag["predicate_valid_range"][0]
                                                + diag["predicate_valid_range"][1]) / 2.0) < 1e-9)})
                return sB, diag
    return None, diag


def noop_stability(probe: Probe, steps: int = NOOP_STABLE_STEPS) -> dict:
    """§4.2：no-op 稳定窗口内 subgoal 标签不得改变。"""
    seq = [probe.labels()]
    for _ in range(steps):
        probe.step()
        seq.append(probe.labels())
    ok = all(x == seq[0] for x in seq)
    return {"stable": bool(ok), "steps": steps, "labels_at_start": seq[0],
            "labels_at_end": seq[-1]}


def main() -> int:
    STATES.mkdir(parents=True, exist_ok=True)
    IMAGES.mkdir(parents=True, exist_ok=True)
    import imageio.v2 as imageio

    report: dict = {"schema_version": "plan1-stage4-pairs-v2", "tasks": []}
    for suite_name, task_name, obj, site_key in TASKS:
        print(f"\n{'='*78}\n{suite_name} :: {task_name}\n{'='*78}", flush=True)
        entry: dict = {"suite": suite_name, "task": task_name,
                       "completed_object": obj}
        probe = None
        try:
            probe = Probe(suite_name, task_name)
            entry["language"] = probe.task.language
            entry["goal_from_bddl"] = probe.goal
            entry["goal_from_env"] = probe.env_goal
            entry["bddl_matches_env"] = (probe.goal == probe.env_goal)
            entry["n_goal_predicates"] = len(probe.goal)
            print(f"  goal ({len(probe.goal)}): {probe.goal}")
            print(f"  BDDL 解析 == env.parsed_problem : {entry['bddl_matches_env']}")
            if len(probe.goal) < 2:
                entry["verdict"] = "NOT SUITABLE：官方 goal 少于 2 个谓词"
                report["tasks"].append(entry); continue

            sub1, sub2 = probe.goal[0], probe.goal[1]
            entry["subgoal1"], entry["subgoal2"] = sub1, sub2
            # 机器人关节白名单：机器人 qpos 归 jnt 名
            robot_prefixes = [ms.joint_name(probe.model, i)
                              for i in range(int(probe.model.njnt))
                              if ms.joint_name(probe.model, i)
                              and (ms.joint_name(probe.model, i).startswith("robot0")
                                   or ms.joint_name(probe.model, i).startswith("gripper0"))]
            entry["robot_joint_names"] = robot_prefixes

            init_states = probe.suite.get_task_init_states(probe.index)
            entry["n_official_init_states"] = len(init_states)
            seeds = []
            for seed in range(N_SEEDS):
                rec: dict = {"seed": seed, "task_name": task_name}
                # §2.1：A 必须是"官方初始状态 + **恰好** 10 步官方 wait"之后的稳定态。
                # 不再调用 probe.env.reset()（那是重复的，会造成 double wait）。
                probe.env.set_init_state(init_states[seed])
                probe.inner.sim.forward()
                dummy = official_dummy_action()
                for _ in range(OFFICIAL_WAIT_STEPS):
                    probe.inner.step(np.asarray(dummy, dtype=np.float64))
                sA = probe.state()
                rec["A_provenance"] = {
                    "official_init_index": seed,
                    "wait_steps": OFFICIAL_WAIT_STEPS,
                    "dummy_action": [float(x) for x in dummy],
                    "state_hash": state_hash(sA),
                    "note": "official init state + exactly 10 official dummy steps",
                }
                rec["A_labels"] = probe.labels()
                pA = STATES / f"{task_name}__s{seed}__A.npy"
                np.save(pA, sA); rec["A_path"] = str(pA)
                imgA = probe.image()
                if imgA is not None:
                    pi = IMAGES / f"{task_name}__s{seed}__A.png"
                    imageio.imwrite(pi, imgA); rec["A_image"] = str(pi)

                # ---- B：**从 sA 原地构造** ----
                if obj is not None:
                    sB, diag = build_B_object(probe, sA, obj, site_key)
                else:
                    sB, diag = build_B_joint(probe, sA, sub1)
                rec["build_B"] = {k: v for k, v in diag.items() if k != "attempts"}
                if len(diag.get("attempts", [])) > 4:
                    rec["build_B"]["attempts_head"] = diag["attempts"][:4]
                if sB is None:
                    rec["B_error"] = "构造失败"
                    seeds.append(rec); continue
                rec["B_labels"] = probe.labels()

                # ---- §3.2 机器人 9 关节一致 ----
                qA = probe.robot_qpos(sA)
                qB = probe.robot_qpos(sB)
                rec["robot_qpos_max_abs_diff"] = float(np.abs(qA - qB).max())
                rec["robot_qpos_identical"] = bool(np.abs(qA - qB).max() < 1e-12)
                rec["robot_qpos_A"] = qA.tolist()

                # ---- §3.3 白名单 diff ----
                allowed = [obj] if obj is not None else [sub1[-1]]
                wl = state_diff_whitelist(probe.model, probe.layout, sA, sB, allowed)
                rec["state_diff_whitelist"] = {
                    "allowed_prefixes": allowed,
                    "n_changed": wl["n_changed"],
                    "unexpected_names": wl["unexpected_names"],
                    "max_unexpected_abs_diff": wl["max_unexpected_abs_diff"],
                    "pair_valid": wl["pair_valid"],
                }
                # ---- §4.2 no-op 稳定窗口 ----
                probe.load(sB)
                rec["B_noop_stability"] = noop_stability(probe)
                # 稳定性检查会推进物理，写回原 sB 再存
                probe.load(sB)
                rec["B_provenance"] = {
                    "built_from": "stabilized A (same seed)",
                    "state_hash": state_hash(sB),
                    "wait_steps_before_B": 0,
                    "note": "in-place from stabilized A; no reset",
                }
                pB = STATES / f"{task_name}__s{seed}__B.npy"
                np.save(pB, sB); rec["B_path"] = str(pB)
                imgB = probe.image()
                if imgB is not None:
                    pi = IMAGES / f"{task_name}__s{seed}__B.png"
                    imageio.imwrite(pi, imgB); rec["B_image"] = str(pi)

                rec["pair_valid"] = bool(
                    rec["A_labels"] == {"subgoal1": False, "subgoal2": False,
                                        "overall": False}
                    and rec["B_labels"]["subgoal1"] is True
                    and rec["B_labels"]["subgoal2"] is False
                    and rec["B_labels"]["overall"] is False
                    and rec["robot_qpos_identical"]
                    and rec["state_diff_whitelist"]["pair_valid"]
                    and rec["B_noop_stability"]["stable"])
                seeds.append(rec)
                print(f"  seed {seed}: A={rec['A_labels']}  B={rec['B_labels']}"
                      f"  robot_same={rec['robot_qpos_identical']}"
                      f"  wl_valid={rec['state_diff_whitelist']['pair_valid']}"
                      f"  noop_stable={rec['B_noop_stability']['stable']}"
                      f"  -> pair_valid={rec['pair_valid']}", flush=True)
            entry["seeds"] = seeds
            entry["verdict"] = ("OK" if seeds and all(s.get("pair_valid") for s in seeds)
                                else "存在问题")
        except Exception as exc:  # noqa: BLE001
            import traceback as tb
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["traceback"] = tb.format_exc()[-1500:]
            print(f"  ERROR: {entry['error']}")
        finally:
            if probe is not None:
                probe.close()
        report["tasks"].append(entry)

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "pairs.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[stage4-pairs] -> {OUT/'pairs.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
