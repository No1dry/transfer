"""plan1 Stage 4-B：Intermediate Completed-Subgoal pilot（mentor_review_6 §3–§6）。

设计要点
--------
* 起点口径（§2.1）：A/B 都来自 `pairs_v2`——即 "official init + **恰好 10** 步
  官方 dummy action" 稳定后的 state；B 是从该 A **原地**构造的。
* 条件：
    A = subgoal-1 未完成（官方稳定初始态）
    B = subgoal-1 已完成、subgoal-2 未完成
* 每个 rollout 都保存**逐 step trace**，含 §4 要求的实体：
    - I1：EEF、soup 当前位置、**soup 在 A 中的原位置**、tomato、basket region、
          到三者的距离、robot↔soup/tomato/basket contact、gripper、三个 predicate
    - I2：EEF、button anchor、moka pot、cook region、到两者的距离、
          robot↔button/moka/region contact、button qpos/norm/path、gripper、predicate
  "soup 的 A 原位置" 是 §4.1 特别要求的：模型可能照训练动作去旧位置抓空，
  只测 completed-object contact 会漏判。
* 事件（§5）**预注册**在 `benchmark/stage4_events.py`，不在跑完后凭视频定义。
* paired no-op 只作 drift / predicate 稳定性对照（§6）。

用法:
    ./run_diag.sh scripts/plan1_stage4_pilot.py --smoke      # I1 s0 + I2 s0
    ./run_diag.sh scripts/plan1_stage4_pilot.py --seeds 5    # 全量 20 episodes
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from libero.libero import benchmark as B  # noqa: E402
from benchmark.bddl_goal import parse_goal_from_bddl  # noqa: E402
from benchmark.stage4_events import compute_stage4_events  # noqa: E402
from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
BDDL_ROOT = ROOT / "LIBERO/libero/libero/bddl_files"
PAIRS = ROOT / "results/plan1/intermediate/pairs_v2"
OUT = ROOT / "results/plan1/intermediate/pilot_v2"   # 运行时由 --out 覆盖（§2）
TRACES = OUT / "traces"
VIDEOS = OUT / "videos"
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"
MAX_STEPS = 520
NUM_CHUNK = 8
FPS = 20

TASKS = [
    ("I1", "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket",
     ["alphabet_soup_1", "tomato_sauce_1", "basket_1"]),
    ("I2", "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it",
     ["flat_stove_1", "moka_pot_1"]),
]

TRACE_COLS = [
    "step", "sg1", "sg2", "overall",
    "eef_x", "eef_y", "eef_z",
    # §2/§3：三套参考坐标必须分开，绝不混用
    "completed_cur_xyz_0", "completed_cur_xyz_1", "completed_cur_xyz_2",
    "completed_start_xyz_0", "completed_start_xyz_1", "completed_start_xyz_2",
    "completed_A_orig_xyz_0", "completed_A_orig_xyz_1", "completed_A_orig_xyz_2",
    "remaining_xyz_0", "remaining_xyz_1", "remaining_xyz_2",
    "d_eef_completed_cur", "d_eef_completed_start", "d_eef_completed_A_orig",
    "d_eef_remaining",
    "contact_completed", "contact_remaining", "contact_container",
    "raw_gripper", "processed_gripper", "grip_open_frac",
    "joint_q", "joint_norm_max", "joint_path",
]


def save_video(frames, path):
    if not frames:
        return None
    import imageio.v2 as imageio
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=FPS, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return str(path)
    except Exception:  # noqa: BLE001
        return None


def overlay(frame, lines, banner=None):
    try:
        from PIL import Image, ImageDraw, ImageFont
        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        texts = list(lines) + ([banner] if banner else [])
        font, size = None, 11
        for size in range(11, 7, -1):
            try:
                font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", size)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default()
            if max(dr.textbbox((0, 0), t, font=font)[2] for t in texts) <= W - 8:
                break
        lh = size + 4
        box = lh * len(lines) + 4
        dr.rectangle([0, 0, W, box], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((4, 4 + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box, W, box + lh + 4], fill=(0, 90, 170))
            dr.text((4, box + 3), banner, fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


def resolve_entity(model, name, joint_name=None):
    """解析实体的 geom 集与 anchor body（§5）。

    对 I2 尤其重要：用 `flat_stove_1` 当前缀会**扫进整台炉子**
    （main / base / burner / burner_plate / **button**）。
    正确做法是从"执行该子目标的 joint"反查 body：

        joint `flat_stove_1_button` -> jnt_bodyid=29
        -> body `flat_stove_1_button` -> 该 body 名下 19 个 geom（实测 134..152）

    找不到 joint 时退化为前缀匹配（placement 实体用这条）。
    """
    from benchmark.states import mujoco_state as _ms

    body_ids: set[int] = set()
    anchor_body = None
    if joint_name:
        for i in range(int(model.njnt)):
            try:
                nm = _ms.joint_name(model, i)
            except Exception:  # noqa: BLE001
                continue
            if nm == joint_name:
                bid = int(model.jnt_bodyid[i])
                body_ids.add(bid)
                try:
                    anchor_body = model.body_id2name(bid)
                except Exception:  # noqa: BLE001
                    anchor_body = None
                break
    if not body_ids:
        for gid in range(int(model.ngeom)):
            try:
                bid = int(model.geom_bodyid[gid])
                b = model.body_id2name(bid)
            except Exception:  # noqa: BLE001
                continue
            if b and b.startswith(name):
                body_ids.add(bid)
    geoms, names = set(), []
    for gid in range(int(model.ngeom)):
        try:
            bid = int(model.geom_bodyid[gid])
            b = model.body_id2name(bid)
        except Exception:  # noqa: BLE001
            continue
        if bid in body_ids:
            geoms.add(gid)
            names.append(b)
    return {"geoms": geoms, "body_ids": body_ids, "anchor_body": anchor_body,
            "body_names": sorted(set(names))}


def anchor_pos(sim, model, ent):
    """anchor 世界坐标。解析不出来就返回 None（未测量），绝不用别的 body 顶替。"""
    if not ent.get("body_ids"):
        return None
    bid = sorted(ent["body_ids"])[0]
    try:
        return np.asarray(sim.data.get_body_xpos(model.body_id2name(bid)),
                          dtype=np.float64).copy()
    except Exception:  # noqa: BLE001
        return None


def _g(v, i):
    """取第 i 个分量；None -> None（未测量，绝不填 0）。"""
    return None if v is None else float(np.asarray(v).reshape(-1)[i])


def _d(a, b):
    """两点距离；任一为 None -> None。"""
    if a is None or b is None:
        return None
    return float(np.linalg.norm(np.asarray(a, dtype=np.float64)
                                - np.asarray(b, dtype=np.float64)))


def entity_position(arena, model, ent, name):
    """实体位置（§2）。

    **articulated 实体必须用 joint 反查出的 anchor body**，不能用
    `arena.entity_pos(name)` —— 后者对 I2 给出的是 stove fixture body，
    不是 button。上一轮就是"anchor_pos 实现了但从未被调用"，
    导致 I2 的 distance 全部语义错误（review9 §2）。
    """
    if ent.get("anchor_body"):
        p = anchor_pos(arena._env.sim, model, ent)
        if p is not None:
            return p
        return None                      # 解析失败 -> None（未测量），不顶替
    try:
        return np.asarray(arena.entity_pos(name), dtype=np.float64)
    except Exception:  # noqa: BLE001
        return None


def entity_geom_ids(model, prefix):
    ids = set()
    for gid in range(int(model.ngeom)):
        try:
            body = model.body_id2name(int(model.geom_bodyid[gid]))
        except Exception:  # noqa: BLE001
            continue
        if body and body.startswith(prefix):
            ids.add(gid)
    return ids


def robot_geom_ids(model):
    ids = set()
    for gid in range(int(model.ngeom)):
        try:
            body = model.body_id2name(int(model.geom_bodyid[gid]))
        except Exception:  # noqa: BLE001
            continue
        if body and (body.startswith("robot0") or body.startswith("gripper0")):
            ids.add(gid)
    return ids


def contact_flags(sim, robot_ids, ent_ids):
    """robot ↔ 某实体的接触。ent_ids 为空 -> None（未测量）。"""
    if not ent_ids or not robot_ids:
        return None
    try:
        n = int(sim.data.ncon)
    except Exception:  # noqa: BLE001
        return None
    for i in range(n):
        try:
            g1, g2 = int(sim.data.contact[i].geom1), int(sim.data.contact[i].geom2)
        except Exception:  # noqa: BLE001
            continue
        if (g1 in robot_ids and g2 in ent_ids) or (g2 in robot_ids and g1 in ent_ids):
            return True
    return False


def _contact_coverage(rows, required: tuple[str, ...],
                      optional: tuple[str, ...] = ()) -> dict:
    """§4.2：显式声明 required / optional / unsupported，而不是"有值就算过"。

    旧实现会自动跳过全 None 的列并仍写 `complete=True` ——
    于是 I2 的 `contact_container`（本来就不适用）会被静默忽略，
    而真正的 required 列缺失也可能蒙混过关。
    """
    # ⚠️ 去重：同一个列可能同时出现在 required 与 optional 里
    # （例如 I1 的 contact_container 既必需、又在 optional 里说明"不适用时可为空"）。
    # 不去重会把该列按出现次数重复计数 -> non_null 变成 2n -> 被误判为 missing。
    seen: set[str] = set()
    cols: list[str] = []
    for c in tuple(required) + tuple(optional):
        if c not in seen:
            seen.add(c)
            cols.append(c)
    tot = {c: 0 for c in cols}
    n = len(rows)
    for r in rows:
        for c in cols:
            v = r.get(c)
            if v is not None and v != "":
                tot[c] += 1
    unsupported = tuple(c for c in optional if tot.get(c, 0) == 0)
    miss = [c for c in required if tot.get(c, 0) != n]
    return {
        "n_rows": n,
        "required_columns": list(required),
        "optional_columns": list(optional),
        "unsupported_columns": list(unsupported),
        "non_null_counts": tot,
        "missing_required": miss,
        "complete": bool(not miss and n > 0),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true", help="只跑 I1 s0 + I2 s0")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--noop", action="store_true", default=True)
    ap.add_argument("--task", default=None, help="只跑某个 tag (I1/I2)")
    ap.add_argument("--out", default=None,
                    help="输出目录（显式参数，不再用环境变量；mentor_review_10 §2）")
    ap.add_argument("--pairs", default=None, help="paired states 目录")
    args = ap.parse_args()

    global OUT, TRACES, VIDEOS, PAIRS
    if args.out:
        OUT = ROOT / args.out
    if args.pairs:
        PAIRS = ROOT / args.pairs
    TRACES = OUT / "traces"
    VIDEOS = OUT / "videos"
    OUT.mkdir(parents=True, exist_ok=True)
    TRACES.mkdir(parents=True, exist_ok=True)
    n_seeds = 1 if args.smoke else args.seeds

    policy = OpenVLAOFTAdapter(
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        checkpoint=str(CKPT), unnorm_key="libero_10",
        num_images_in_input=2, use_proprio=True,
        num_open_loop_steps=NUM_CHUNK,
    )
    reg4 = load_registry(ROOT / "configs/plan1_stage4.yaml")

    report: dict = {"schema_version": "plan1-stage4-pilot-v2",
                    "mode": "smoke" if args.smoke else "full",
                    "max_steps": MAX_STEPS, "seeds": n_seeds, "tasks": []}

    for tag, task_name, ents in TASKS:
        spec = next(t for t in reg4 if t.task_name == task_name)
        goal = parse_goal_from_bddl(BDDL_ROOT / spec.suite / f"{task_name}.bddl")
        completed, remaining = ents[0], ents[1] if len(ents) > 1 else None
        container = ents[2] if len(ents) > 2 else None
        entry = {"tag": tag, "task": task_name, "goal": goal,
                 "completed": completed, "remaining": remaining,
                 "container": container, "episodes": []}
        print(f"\n{'='*78}\n{tag} :: {task_name}\n{'='*78}", flush=True)
        try:
            if hasattr(policy, "set_unnorm_key"):
                policy.set_unnorm_key(spec.suite)
            for seed in range(n_seeds):
                sA = np.load(PAIRS / "states" / f"{task_name}__s{seed}__A.npy")
                sB = np.load(PAIRS / "states" / f"{task_name}__s{seed}__B.npy")

                # ★★ §2：completed object 在 **A 中的原位置**，必须在
                #    condition 循环**之前**、从保存的 sA 解析。
                #    上一版把它写在循环内，于是 B 条件下拿到的是 B 自己的起点，
                #    导致"去旧位置抓空"的结论完全是参考系错误（review7 §2）。
                _probe = LiberoArena(
                    task_suite_name=spec.suite, task_id=spec.task_id,
                    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
                    subject=spec.subject, target=spec.target,
                    joint_name=(spec.edit or {}).get("joint_name"),
                    residual_kind=spec.residual_kind)
                _probe.set_state(sA, settle_steps=0)
                # §2：A 原位置必须用**与 rollout 相同的解析方式**（button anchor）
                _pm = _probe.model
                _jn0 = (spec.edit or {}).get("joint_name")
                _ent0 = resolve_entity(_pm, completed, joint_name=_jn0)
                _pa = entity_position(_probe, _pm, _ent0, completed)
                completed_A_orig = (np.asarray(_pa, dtype=np.float64).copy()
                                    if _pa is not None else None)
                _probe.close()
                entry.setdefault("pair_meta", {})[f"s{seed}"] = {
                    "completed_A_orig_xyz": completed_A_orig.tolist()}

                for cond, st in (("A", sA), ("B", sB)):
                    for mode in (["policy", "noop"] if args.noop else ["policy"]):
                        t0 = time.time()
                        arena = LiberoArena(
                            task_suite_name=spec.suite, task_id=spec.task_id,
                            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
                            subject=spec.subject, target=spec.target,
                            joint_name=(spec.edit or {}).get("joint_name"),
                            residual_kind=spec.residual_kind,
                        )
                        arena.set_allow_after_done(True)
                        rows, frames = [], []
                        try:
                            arena.set_state(st, settle_steps=0)
                            arena.mark_episode_start()
                            model = arena.model
                            rids = robot_geom_ids(model)
                            # §5：I2 的 completed 用 joint 解析出的 button，
                            #     而不是整台 stove
                            jn = (spec.edit or {}).get("joint_name")
                            ent = {completed: resolve_entity(model, completed,
                                                             joint_name=jn)}
                            if remaining:
                                ent[remaining] = resolve_entity(model, remaining)
                            if container:
                                ent[container] = resolve_entity(model, container)
                            # §7：contact coverage 元数据（geom/body 名写进报告）
                            entry.setdefault("entity_meta", {})[f"{cond}_{mode}_s{seed}"] = {
                                k: {"n_geoms": len(v["geoms"]),
                                    "body_names": v["body_names"],
                                    "anchor_body": v["anchor_body"],
                                    "body_ids": sorted(v["body_ids"]),
                                    "geom_ids": sorted(v["geoms"]),
                                    "anchor_source": ("joint_body" if v["anchor_body"]
                                                      else "prefix_geoms"),
                                    "joint_name": jn if k == completed else None}
                                for k, v in ent.items()}
                            _ps = entity_position(arena, model, ent[completed], completed)
                            completed_start = (np.asarray(_ps, dtype=np.float64).copy()
                                               if _ps is not None else None)
                            if mode == "policy":
                                policy.reset()
                            queue: list = []

                            def snap(step, raw_g, proc_g):
                                ai = arena._env.env
                                s1 = bool(ai._eval_predicate(list(goal[0])))
                                s2 = bool(ai._eval_predicate(list(goal[1])))
                                ov = bool(arena.goal_satisfied())
                                eef = np.asarray(
                                    arena._last_obs_raw["robot0_eef_pos"],
                                    dtype=np.float64)
                                cpos = entity_position(arena, model, ent[completed],
                                                       completed)
                                rpos = (entity_position(arena, model, ent[remaining],
                                                        remaining)
                                        if remaining else None)
                                sig = arena.debug_signals()
                                sim = arena._env.sim
                                jq = None
                                if jn:
                                    try:
                                        jq = float(ms.get_joint_pos(
                                            arena.get_state(), model, jn))
                                    except Exception:  # noqa: BLE001
                                        jq = None
                                return {
                                    "step": step,
                                    "sg1": int(s1), "sg2": int(s2), "overall": int(ov),
                                    "eef_x": float(eef[0]), "eef_y": float(eef[1]),
                                    "eef_z": float(eef[2]),
                                    "completed_cur_xyz_0": _g(cpos, 0),
                                    "completed_cur_xyz_1": _g(cpos, 1),
                                    "completed_cur_xyz_2": _g(cpos, 2),
                                    "completed_start_xyz_0": _g(completed_start, 0),
                                    "completed_start_xyz_1": _g(completed_start, 1),
                                    "completed_start_xyz_2": _g(completed_start, 2),
                                    "completed_A_orig_xyz_0": _g(completed_A_orig, 0),
                                    "completed_A_orig_xyz_1": _g(completed_A_orig, 1),
                                    "completed_A_orig_xyz_2": _g(completed_A_orig, 2),
                                    "remaining_xyz_0": _g(rpos, 0),
                                    "remaining_xyz_1": _g(rpos, 1),
                                    "remaining_xyz_2": _g(rpos, 2),
                                    "d_eef_completed_cur": _d(eef, cpos),
                                    "d_eef_completed_start": _d(eef, completed_start),
                                    "d_eef_completed_A_orig": _d(eef, completed_A_orig),
                                    "d_eef_remaining": _d(eef, rpos) if remaining else None,
                                    "contact_completed": contact_flags(
                                        sim, rids, ent[completed]["geoms"]),
                                    "contact_remaining": (contact_flags(
                                        sim, rids, ent[remaining]["geoms"])
                                        if remaining else None),
                                    "contact_container": (contact_flags(
                                        sim, rids, ent[container]["geoms"])
                                        if container else None),
                                    "raw_gripper": raw_g,
                                    "processed_gripper": proc_g,
                                    "grip_open_frac": arena.gripper_current_open_frac(),
                                    "joint_q": jq,
                                    "joint_norm_max": float(
                                        sig.get("task_joint_normalized_max", 0.0)),
                                    "joint_path": float(
                                        sig.get("task_joint_path_length", 0.0)),
                                }

                            # ---- §4：先 emit **真正的 step 0**，再执行动作 ----
                            rows.append(snap(0, None, None))
                            for t in range(1, MAX_STEPS + 1):
                                if mode == "noop":
                                    a = np.asarray(arena.no_op_action(), dtype=float)
                                    raw_g = proc_g = None
                                else:
                                    if not queue:
                                        o = arena.get_observation()
                                        policy.predict(o, arena.task_language)
                                        ch = policy.last_processed_actions
                                        rc = policy.last_raw_actions
                                        if ch.ndim == 1:
                                            ch = ch.reshape(1, -1)
                                        if rc.ndim == 1:
                                            rc = rc.reshape(1, -1)
                                        queue = [(ch[k], rc[k]) for k in
                                                 range(min(NUM_CHUNK, len(ch)))]
                                    a, ra = queue.pop(0)
                                    a = np.asarray(a, dtype=float)
                                    raw_g = float(np.asarray(ra).reshape(-1)[-1])
                                    proc_g = float(a[-1])
                                arena.step(a.tolist())
                                rows.append(snap(t, raw_g, proc_g))
                                if frames is not None and t % 2 == 0:
                                    fr = arena.render_frame()
                                    if fr is not None:
                                        r0 = rows[-1]
                                        frames.append(overlay(fr, [
                                            f"{tag} {mode} {cond} s{seed} step {t}",
                                            f"sg1={r0['sg1']} sg2={r0['sg2']} ok={r0['overall']}",
                                            f"d_cur={r0['d_eef_completed_cur']:.3f} "
                                            f"d_Aorig={r0['d_eef_completed_A_orig']:.3f}",
                                        ], f"STAGE4 PILOT v2 [{cond}/{mode}]"))
                                if rows[-1]["overall"] and mode == "policy":
                                    break
                        finally:
                            arena.close()

                        p = TRACES / f"{task_name}__s{seed}__{cond}__{mode}.csv"
                        with p.open("w", newline="", encoding="utf-8") as f:
                            w = csv.DictWriter(f, fieldnames=TRACE_COLS)
                            w.writeheader(); w.writerows(rows)
                        vid = save_video(
                            frames, VIDEOS / f"{task_name}__s{seed}__{cond}__{mode}.mp4")
                        events = compute_stage4_events(rows, tag=tag, condition=cond)
                        req = (("contact_completed", "contact_remaining",
                                "contact_container") if container
                               else ("contact_completed", "contact_remaining"))
                        cov = _contact_coverage(rows, required=req,
                                                optional=("contact_container",))
                        ep = {"seed": seed, "condition": cond, "mode": mode,
                              "n_steps": len(rows),
                              "overall_success": bool(rows[-1]["overall"]),
                              "first_overall_step": next(
                                  (r["step"] for r in rows if r["overall"]), None),
                              "events": events, "contact_coverage": cov,
                              "trace": str(p), "video": vid,
                              "wall_time_s": time.time() - t0}
                        entry["episodes"].append(ep)
                        ev = events.get("events", {})
                        print(f"  {cond}/{mode} s{seed}: steps={len(rows)} "
                              f"ok={ep['overall_success']} "
                              f"verdict={ev.get('behavior_verdict')} "
                              f"target={ev.get('first_task_target')} "
                              f"cov={cov['complete']} ({ep['wall_time_s']:.0f}s)",
                              flush=True)
        except Exception as exc:  # noqa: BLE001
            import traceback as tb
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["traceback"] = tb.format_exc()[-1500:]
            print(f"  ERROR: {entry['error']}")
        report["tasks"].append(entry)

    (OUT / ("pilot_v2_smoke.json" if args.smoke else "pilot_v2.json")).write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[stage4-pilot] -> {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
