"""mentor_review_3 §4.3：真实 LIBERO 上的 observation-refresh 集成测试。

Mock 测试抓不住这个 bug，因为 MockArena 没有相机、没有 robosuite 的
观测缓存机制。必须在真实环境上验证。

验证 6 件事：
  1. `set_state(A, settle_steps=0)` 之后读到的 obs EEF 与 A 的 sim state 一致；
  2. 该 obs **不等于** 状态 B 的缓存观测（证明真的刷新了，不是复用旧缓存）；
  3. 图像确实变了（agentview / wrist）；
  4. **刷新不推进物理**：set_state 前后 flattened state 逐位相同；
  5. predicate 与 state A 一致；
  6. proprio（gripper qpos）也与 state A 一致。

产物：`results/plan1/state_obs_refresh_check.json`

用法: ./run_diag.sh scripts/plan1_state_obs_refresh_check.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
OUT = ROOT / "results/plan1/state_obs_refresh_check.json"


def img_diff(a, b) -> float:
    try:
        x = np.asarray(a, dtype=np.float64)
        y = np.asarray(b, dtype=np.float64)
        if x.shape != y.shape:
            return float("nan")
        return float(np.abs(x - y).mean())
    except Exception:  # noqa: BLE001
        return float("nan")


def main() -> int:
    reg = load_registry(ROOT / "configs/mini_pab.yaml")
    results = []
    all_ok = True

    for task_id in ("bowl_on_plate", "open_middle_drawer"):
        spec = reg[task_id]
        arena = LiberoArena(
            task_suite_name=spec.suite, task_id=spec.task_id,
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=spec.subject, target=spec.target,
            joint_name=(spec.edit or {}).get("joint_name"),
            residual_kind=spec.residual_kind,
        )
        r: dict = {"task_id": task_id, "checks": {}}
        try:
            arena.set_allow_after_done(True)
            arena.reset()

            def move(act, n):
                for _ in range(n):
                    arena.step(act)

            # ---- 状态 A：用**真正会移动机械臂**的动作，让它远离 home ----
            # （no-op 动作几乎不动手臂，A/B 的 EEF 会太接近，
            #   "更接近 A 还是 B"就失去判别力。）
            move([0.6, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0], 25)
            state_A = arena.get_state().copy()
            obsA = dict(arena._last_obs_raw)
            eefA = np.asarray(obsA["robot0_eef_pos"], dtype=np.float64).copy()
            gripA = np.asarray(obsA["robot0_gripper_qpos"], dtype=np.float64).copy()
            imgA = obsA.get("agentview_image")
            predA = bool(arena.goal_satisfied())

            # ---- 对照：残差是 set_state 造成的，还是 step-vs-forward 固有的？----
            # 此刻 sim 仍在 state A，且**没有调用 set_state**：
            # 只做一次 sim.forward() + 重算观测。
            # 若这里也出现同样的残差，说明残差与 set_state 路径无关。
            arena._env.sim.forward()
            obs_A_fwd = dict(arena._refresh_observation_from_current_state())
            eef_A_fwd = np.asarray(obs_A_fwd["robot0_eef_pos"], dtype=np.float64)
            d_refwd = float(np.abs(eef_A_fwd - eefA).max())
            r["residual_step_vs_forward_m"] = d_refwd
            r["residual_is_inherent_to_step_vs_forward"] = bool(d_refwd > 1e-9)

            # ---- 状态 B：朝相反方向走，确保 A/B 的 EEF 明显不同 ----
            move([-0.6, 0.0, 0.2, 0.0, 0.0, 0.0, -1.0], 40)
            state_B = arena.get_state().copy()
            obsB = dict(arena._last_obs_raw)
            eefB = np.asarray(obsB["robot0_eef_pos"], dtype=np.float64)
            imgB = obsB.get("agentview_image")

            # A 与 B 必须真的不同，否则测试没意义
            dAB = float(np.abs(state_A - state_B).max())
            r["state_A_vs_B_max_abs_diff"] = dAB


            # ---- 核心：回到 A，settle_steps=0 ----
            arena.set_state(state_A, settle_steps=0)
            state_after = arena.get_state().copy()
            obsAp = dict(arena._last_obs_raw)
            eefAp = np.asarray(obsAp["robot0_eef_pos"], dtype=np.float64)
            gripAp = np.asarray(obsAp["robot0_gripper_qpos"], dtype=np.float64)
            imgAp = obsAp.get("agentview_image")
            predAp = bool(arena.goal_satisfied())

            # 1) EEF 与 A 一致（容差 10 微米：远小于任何 stale 现象的量级 0.3 m）
            #    实测残差 ~1e-7 m，是 float64 round-trip 噪声。
            # 容差说明：实测残差 ~5.8e-4 m，且**在"不碰 state 只重算观测"的
            # 对照里同样出现**（见 residual_step_vs_forward_m），
            # 说明它来自 `env.step()` 取值点 vs `sim.forward()` 的固有差异，
            # 不是 set_state 的 stale-cache 问题。
            # stale 现象的量级是 0.28 m —— 比这大 480 倍。
            # 这里用 1mm 作为**工程容差**并同时记录原始值，不做"调到刚好通过"。
            TOL_M = 1e-3
            d_eef = float(np.abs(eefAp - eefA).max())
            d_B = float(np.abs(eefAp - eefB).max())
            d_AB = float(np.abs(eefA - eefB).max())
            r["checks"]["eef_matches_state_A"] = {
                "max_abs_diff_vs_A": d_eef, "tolerance_m": TOL_M,
                "pass": bool(d_eef < TOL_M),
                "eef_A": eefA.tolist(), "eef_A_prime": eefAp.tolist(),
            }
            # 2) ★ 决定性判据：obs(A') 必须**明显更接近 A 而不是 B**。
            #    若观测没刷新（旧缓存来自 B），d_eef≈d_AB 且 d_B≈0 —— 会 FAIL。
            r["checks"]["closer_to_A_than_B"] = {
                "d_to_A": d_eef, "d_to_B": d_B, "d_A_to_B": d_AB,
                "pass": bool(d_B > 20 * max(d_eef, 1e-12) and d_AB > 0.05),
            }
            # 3) 图像：A' 必须更接近 A 的图像而不是 B 的
            di_AB = img_diff(imgAp, imgB)
            di_AA = img_diff(imgAp, imgA)
            r["checks"]["image_refreshed"] = {
                "mean_abs_diff_vs_B": di_AB, "mean_abs_diff_vs_A": di_AA,
                # 渲染不是逐位可复现的（已知），所以用相对判据而不是绝对阈值
                "pass": bool(np.isfinite(di_AB) and np.isfinite(di_AA)
                             and di_AA < di_AB / 10.0),
            }
            # 4) 刷新不推进物理
            d_state = float(np.abs(state_after - state_A).max())
            r["checks"]["physics_not_advanced"] = {
                "max_abs_state_diff": d_state, "pass": bool(d_state < 1e-12),
            }
            # 5) predicate 一致
            r["checks"]["predicate_matches"] = {
                "pred_A": predA, "pred_after": predAp, "pass": bool(predA == predAp),
            }
            # 6) proprio 一致（同 TOL_M 理由）
            d_grip = float(np.abs(gripAp - gripA).max())
            r["checks"]["proprio_matches"] = {
                "max_abs_diff": d_grip, "tolerance_m": TOL_M,
                "pass": bool(d_grip < TOL_M),
            }
            r["obs_source"] = getattr(arena, "_last_obs_source", "")
        except Exception as exc:  # noqa: BLE001
            import traceback as tb

            r["error"] = f"{type(exc).__name__}: {exc}"
            r["traceback"] = tb.format_exc()
        finally:
            arena.close()

        ok = all(c.get("pass") for c in r.get("checks", {}).values()) \
            if r.get("checks") else False
        r["all_pass"] = bool(ok)
        all_ok &= ok
        results.append(r)

        print(f"\n=== {task_id} ===")
        print(f"  state A vs B max|Δ| = {r.get('state_A_vs_B_max_abs_diff')}")
        print(f"  obs 来源 = {r.get('obs_source')}")
        for k, v in (r.get("checks") or {}).items():
            print(f"  [{'PASS' if v['pass'] else 'FAIL'}] {k}: "
                  + ", ".join(f"{kk}={vv}" for kk, vv in v.items() if kk != "pass"))
        if r.get("error"):
            print(f"  ERROR: {r['error']}")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"schema_version": "plan1-obs-refresh-check-v1",
                               "all_pass": bool(all_ok),
                               "results": results},
                              indent=2, ensure_ascii=False, default=str),
                   encoding="utf-8")
    print(f"\n[overall] {'ALL PASS' if all_ok else 'SOME FAILED'}  -> {OUT}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
