"""plan1 Stage 2：自然终态生成 + replay（mentor_review_1 §4.5、§8.2）。

核心思想：**用模型自己产生的成功终态**替代"把物体瞬移到目标处"的场景编辑，
再用统一 metrics v2.1 量 replay 里的行为。

为什么必须做（Stage 1 遗留的核心未知量）：
    τ≥5cm 时 0/80 只说明"没有成功的任务状态改变"，**推不出"没有重试"**。
    要区分 安全撤离 / 重新接近 / 无目标游移，必须看
    eef→subject 距离轨迹、重新接近、首次合爪、contact、path/max 比值 ——
    这些量旧记录全都没有。

状态机（详细设计与 JSON schema 见 execute_logs/plan1/02_terminal_smoke.md）：
    S0 reset → S1 generate → S2 stabilize(连续10步) → S3 capture
    → S4 reload_verify → S5 replay → S6 record    （失败一律落盘，不替换 seed）

用法:
    ./run_diag.sh scripts/plan1_terminal_replay.py --tasks bowl_on_plate --seeds 2
    ./run_diag.sh scripts/plan1_terminal_replay.py --tasks all --seeds 2 --video
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import time
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.metrics import DEFAULT_THRESHOLDS, compute_all_v2  # noqa: E402
from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402

# ---------------------------------------------------------------------------
# 预注册阈值（mentor_review_1 §4.5）—— 不得看结果后调整
# ---------------------------------------------------------------------------
STABLE_WINDOW = 10          # 连续稳定步数
SUBJ_LIN_VEL_MAX = 0.01     # m/s
SUBJ_ANG_VEL_MAX = 0.10     # rad/s
GRIPPER_OPEN_FRAC_MIN = 0.75    # **当前**开度/全开行程 > 该值视为"已释放"（§4.5）
GRIPPER_FALLBACK_ABS = 0.03     # 仅当拿不到 open reference 时使用
JOINT_VEL_NORM_MAX = 0.01   # 每秒走完行程的比例
JOINT_WINDOW_DRIFT_MAX = 0.01   # 窗口内归一化漂移上限

ROOT = Path("/HUBU-AI004/zp/ICML")
OUT = ROOT / "results/plan1/terminal_replay"
VIDEODIR = OUT / "videos"
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"
NUM_CHUNK = 8
MAX_GEN_STEPS = 400         # 生成阶段的步数上限
REPLAY_STEPS = 300          # replay 观察窗口
FPS = 20


# ---------------------------------------------------------------------------
# 信号读取（直接读 sim；contact 走 arena 的归属映射）
# ---------------------------------------------------------------------------

def subject_velocity(arena, free_joint) -> tuple[float, float]:
    """任务物体的线速度 / 角速度模长。

    LIBERO 的自由物体是 free joint：qvel 前 3 维线速度、后 3 维角速度。
    """
    if free_joint is None:
        return float("nan"), float("nan")
    try:
        qv = np.asarray(arena._env.sim.data.qvel, dtype=np.float64)
        a = int(free_joint.dof_adr)
        lin = float(np.linalg.norm(qv[a:a + 3]))
        ang = float(np.linalg.norm(qv[a + 3:a + 6]))
        return lin, ang
    except Exception:  # noqa: BLE001
        return float("nan"), float("nan")


def env_step_seconds(arena) -> tuple[float, str]:
    """一个 env step 对应的仿真秒数，以及它的来源（便于审计，不静默假设）。"""
    for attr, src in (("control_timestep", "sim.control_timestep"),
                      ("model_timestep", "sim.model_timestep")):
        try:
            v = float(getattr(arena._env, attr))
            if v > 0:
                return v, src
        except Exception:  # noqa: BLE001
            pass
    try:
        sim = arena._env.sim
        v = float(getattr(sim, "control_timestep"))
        if v > 0:
            return v, "sim.control_timestep"
    except Exception:  # noqa: BLE001
        pass
    # LIBERO 默认 control_freq = 20 Hz -> 0.05 s。**记录下来**，不当作已知事实。
    return 0.05, "fallback_20Hz_assumption"


_JOINT_HIST: list = []


def joint_velocity_norm(arena, joint_name: str, span: float) -> float:
    """任务关节的归一化速度（每秒走完行程的比例）。

    用**位置有限差分**而不是读 ``sim.data.qvel``：后者要同时猜对
    ``dof_adr``、``model.opt.timestep``、``control_timestep`` 三个接口，
    任何一个在 robosuite 包装层上取不到就会静默 NaN —— 第一版 smoke 正是
    卡在这里（抽屉其实早就停了，却因为 jv=NaN 永远判不成稳定）。
    """
    if not joint_name or not span or np.isnan(span) or span <= 0:
        return float("nan")
    q = current_joint_pos(arena, joint_name)
    if q is None:
        return float("nan")
    if not _JOINT_HIST:
        _JOINT_HIST.append(q)
        return float("nan")
    dt, _ = env_step_seconds(arena)
    v = abs(q - _JOINT_HIST[-1]) / span / dt
    _JOINT_HIST.append(q)
    if len(_JOINT_HIST) > 8:
        _JOINT_HIST.pop(0)
    return float(v)


def find_free_joint(arena, subject: str):
    from benchmark.states import mujoco_state as ms

    try:
        return ms.resolve_free_joint(arena.model, subject)
    except Exception:  # noqa: BLE001
        return None


def current_joint_pos(arena, joint_name: str):
    """当前任务关节位置；读不到返回 None。"""
    if not joint_name:
        return None
    try:
        from benchmark.states import mujoco_state as ms

        return float(ms.get_joint_pos(arena.get_state(), arena.model, joint_name))
    except Exception:  # noqa: BLE001
        return None


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def save_video(frames, path: Path) -> str | None:
    if not frames:
        return None
    import imageio.v2 as imageio

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=FPS, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return str(path)
    except Exception:  # noqa: BLE001
        return None


def overlay(frame, lines, banner=None):
    """ASCII 叠加（服务器无中文字体；字号自动收缩防止数字被裁，§11.3）。"""
    try:
        from PIL import Image, ImageDraw, ImageFont

        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        texts = list(lines) + ([banner] if banner else [])
        font, size = None, 11
        for size in range(11, 7, -1):
            try:
                font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", size)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default()
            if max(dr.textbbox((0, 0), t, font=font)[2] for t in texts) <= W - 8:
                break
        lh = size + 4
        box = lh * len(lines) + 4
        dr.rectangle([0, 0, W, box], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((4, 4 + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box, W, box + lh + 4], fill=(0, 90, 170))
            dr.text((4, box + 3), banner, fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def run_one(arena, policy, spec, seed, want_video) -> dict:
    rec: dict = {
        "schema_version": "plan1-terminal-v1",
        "task_id": spec.id,
        "suite": spec.suite,
        "official_init_index": seed,
        "seed": seed,
        "generation": {"success": False},
        "errors": [],
    }
    free_joint = None
    try:
        # ---------------- S0 RESET ----------------
        arena.reset(official_init_index=seed)
        arena.set_allow_after_done(True)
        free_joint = find_free_joint(arena, spec.subject)
        is_articulated = bool((spec.edit or {}).get("joint_name"))
        joint_name = (spec.edit or {}).get("joint_name") or ""
        span = arena._task_joint_range_span()

        # 每个 task 属于不同 suite，动作反归一化的统计量按 suite 分别统计。
        # 不切换的话动作幅度会被错误缩放，而且**不报错**，只是永远做不成任务
        # （实测：object_in_basket 用 libero_goal 的统计量 -> 400 步 predicate 从未 True）。
        if hasattr(policy, "set_unnorm_key"):
            policy.set_unnorm_key(str(arena.unnorm_key))

        policy.reset()
        queue: list = []
        frames: list = []
        steps = 0
        first_success = None
        stable_run = 0
        capture_step = None
        capture_state = None
        capture_stability = {}
        used_fallback = False
        diag: dict = {}   # 稳定窗口各条件的最优值，失败时写进 failure 便于定位
        joint_hist: list = []   # 关节位置历史，用于算**窗口内**漂移
        _JOINT_HIST.clear()     # 速度差分历史必须按 episode 清空，否则跨 episode 泄漏

        # ---------------- S1 GENERATE + S2 STABILIZE ----------------
        while steps < MAX_GEN_STEPS:
            if not queue:
                obs = arena.get_observation()
                policy.predict(obs, arena.task_language)
                chunk = policy.last_processed_actions
                if chunk.ndim == 1:
                    chunk = chunk.reshape(1, -1)
                queue = [chunk[i] for i in range(min(NUM_CHUNK, len(chunk)))]
            action = queue.pop(0)
            steps += 1
            arena.step(np.asarray(action, dtype=float).tolist())

            sat = bool(arena.goal_satisfied())
            if sat and first_success is None:
                first_success = steps

            stable = False
            if sat:
                if is_articulated:
                    jv = joint_velocity_norm(arena, joint_name, span)
                    # ⚠️ 必须用**窗口内**漂移，不能用 task_joint_normalized_max():
                    # 后者是"相对起点的最大偏离"（running max），抽屉一旦拉开就
                    # 永远 >= 0.9，判据再无可能成立 —— 第一版 smoke 就卡在这里。
                    # §4.5 的原意是"没有**继续**朝目标端显著变化"，是窗口局部量。
                    q_now = current_joint_pos(arena, joint_name)
                    joint_hist.append(q_now)
                    if (span and not np.isnan(span) and span > 0
                            and len(joint_hist) > STABLE_WINDOW
                            and joint_hist[-1] is not None
                            and joint_hist[-1 - STABLE_WINDOW] is not None):
                        drift = abs(joint_hist[-1] - joint_hist[-1 - STABLE_WINDOW]) / span
                    else:
                        drift = float("nan")
                    stable = (not np.isnan(jv) and jv < JOINT_VEL_NORM_MAX
                              and not np.isnan(drift) and drift < JOINT_WINDOW_DRIFT_MAX)
                    capture_stability = {"joint_vel_norm": jv,
                                         "joint_window_drift_norm": drift,
                                         "joint_range_span": span}
                    for k, v in (("joint_vel_norm", jv), ("joint_drift", drift)):
                        if not np.isnan(v):
                            diag[k] = min(diag.get(k, float("inf")), v)
                    diag["joint_vel_norm_max_seen"] = max(
                        diag.get("joint_vel_norm_max_seen", 0.0),
                        jv if not np.isnan(jv) else 0.0)
                    diag["dt_source"] = env_step_seconds(arena)[1]
                else:
                    lin, ang = subject_velocity(arena, free_joint)
                    # 必须用**当前**开度，不能用 gripper_change_norm ——
                    # 后者是整个过程的最大变化，抓过一次就永远 ~1.0，
                    # 会让"已释放"永远判不成立（这就是第一版 smoke 卡住的原因）。
                    open_frac = arena.gripper_current_open_frac()
                    open_ref = arena.debug_signals().get("gripper_open_reference",
                                                         float("nan"))
                    finger_abs = np.abs(np.asarray(
                        arena._last_obs_raw["robot0_gripper_qpos"],
                        dtype=np.float64))
                    if not np.isnan(open_frac):
                        released = open_frac > GRIPPER_OPEN_FRAC_MIN
                    else:
                        released = bool(np.all(finger_abs > GRIPPER_FALLBACK_ABS))
                        used_fallback = True
                    stable = (not np.isnan(lin) and lin < SUBJ_LIN_VEL_MAX
                              and not np.isnan(ang) and ang < SUBJ_ANG_VEL_MAX
                              and released)
                    capture_stability = {
                        "subject_linear_speed": lin, "subject_angular_speed": ang,
                        "gripper_open_reference": open_ref,
                        "gripper_current_open_frac": open_frac,
                        "gripper_finger_abs": finger_abs.tolist(),
                        "gripper_released": bool(released),
                        "used_fallback_abs_threshold": used_fallback,
                    }
                    # 诊断：记录窗口内每个条件各自的最优值，失败时一眼看出被谁卡住
                    for k, v in (("lin", lin), ("ang", ang), ("open_frac", open_frac)):
                        if not np.isnan(v):
                            diag[k] = min(diag.get(k, float("inf")), v) \
                                if k != "open_frac" else max(diag.get(k, -float("inf")), v)
            stable_run = stable_run + 1 if stable else 0

            if want_video:
                fr = arena.render_frame()
                if fr is not None:
                    frames.append(overlay(fr, [
                        f"GEN {spec.id} s{seed} step {steps}/{MAX_GEN_STEPS}",
                        f"predicate {int(sat)}  stable_run {stable_run}/{STABLE_WINDOW}",
                    ], "GENERATING natural terminal state"))

            if sat and stable_run >= STABLE_WINDOW:
                capture_step = steps
                capture_state = arena.get_state()
                break

        if first_success is None:
            rec["failure"] = {"stage": "S1_GENERATE", "reason": "predicate_never_true",
                              "n_steps_total": steps, "predicate_true_any": False}
            gen_video = save_video(frames, VIDEODIR / f"{spec.id}__s{seed}__gen_failed.mp4") \
                if want_video else None
            if gen_video:
                rec["generation"]["video"] = gen_video
            return rec

        if capture_step is None:
            rec["failure"] = {"stage": "S2_STABILIZE", "reason": "stabilize_timeout",
                              "n_steps_total": steps, "predicate_true_any": True,
                              "success_first_step": first_success,
                              "stability_diagnostics": diag,
                              "thresholds": {
                                  "subject_linear_vel_max": SUBJ_LIN_VEL_MAX,
                                  "subject_angular_vel_max": SUBJ_ANG_VEL_MAX,
                                  "gripper_open_frac_min": GRIPPER_OPEN_FRAC_MIN,
                              }}
            gen_video = save_video(frames, VIDEODIR / f"{spec.id}__s{seed}__gen_failed.mp4") \
                if want_video else None
            if gen_video:
                rec["generation"]["video"] = gen_video
            return rec

        # ---------------- S3 CAPTURE ----------------
        rec["generation"] = {
            "success": True,
            "success_first_step": first_success,
            "terminal_capture_step": capture_step,
            "stable_window_required": STABLE_WINDOW,
            "stable_window_achieved": stable_run,
            "capture_reason": ("articulated_stable" if is_articulated
                               else "placement_stable_and_released"),
            "stability_at_capture": capture_stability,
            "n_steps_total": steps,
        }
        if want_video:
            v = save_video(frames, VIDEODIR / f"{spec.id}__s{seed}__gen.mp4")
            if v:
                rec["generation"]["video"] = v

        state_path = OUT / f"{spec.id}__s{seed}__state.npy"
        np.save(state_path, np.asarray(capture_state, dtype=np.float64))
        rec["state"] = {
            "flattened_path": str(state_path),
            "flattened_sha256": sha256_file(state_path),
            "n_total": int(np.asarray(capture_state).size),
            "has_nan": bool(np.any(np.isnan(np.asarray(capture_state, dtype=np.float64)))),
        }

        # ---------------- S4 RELOAD_VERIFY ----------------
        arena.set_state(capture_state, settle_steps=0)
        pred_after = bool(arena.goal_satisfied())
        residual_after = float(arena.residual())
        rec["reload_verify"] = {
            "predicate_true_after_reload": pred_after,
            "residual_after_reload": residual_after,
        }
        if not pred_after:
            rec["failure"] = {"stage": "S4_RELOAD_VERIFY",
                              "reason": "reload_predicate_false",
                              "n_steps_total": steps}
            rec["generation"]["success"] = False
            return rec

        # ---------------- S5 REPLAY ----------------
        # ★ set_state 之后再 mark_episode_start：位移基线必须从 replay 起点重新建立。
        #   复用 generation 的基线会把 UMR 静默算成 0。
        arena.mark_episode_start()
        policy.reset()
        queue = []
        rep_frames: list = []
        dist_sub: list[float] = []
        dist_tgt: list[float] = []
        close_steps = 0
        first_close = None
        nan_seen = False

        start_sub = np.asarray(arena.entity_pos(spec.subject), dtype=np.float64)
        try:
            start_tgt = np.asarray(arena.entity_pos(spec.target), dtype=np.float64) \
                if spec.target else None
        except Exception:  # noqa: BLE001
            start_tgt = None

        for i in range(1, REPLAY_STEPS + 1):
            if not queue:
                obs = arena.get_observation()
                policy.predict(obs, arena.task_language)
                chunk = policy.last_processed_actions
                if chunk.ndim == 1:
                    chunk = chunk.reshape(1, -1)
                queue = [chunk[k] for k in range(min(NUM_CHUNK, len(chunk)))]
            act = np.asarray(queue.pop(0), dtype=float)
            arena.step(act.tolist())

            eef = np.asarray(arena._last_obs_raw["robot0_eef_pos"], dtype=np.float64)
            if np.any(np.isnan(eef)):
                nan_seen = True
            gcn_now = arena.debug_signals().get("gripper_change_norm", float("nan"))
            sub = np.asarray(arena.entity_pos(spec.subject), dtype=np.float64)
            dist_sub.append(float(np.linalg.norm(eef - sub)))
            if start_tgt is not None:
                try:
                    dist_tgt.append(float(np.linalg.norm(
                        eef - np.asarray(arena.entity_pos(spec.target), dtype=np.float64))))
                except Exception:  # noqa: BLE001
                    pass
            # 命令层合爪：processed action 最后一维（env 约定 +1=close）
            if act[-1] > 0.5:
                close_steps += 1
                if first_close is None:
                    first_close = i

            if want_video:
                fr = arena.render_frame()
                if fr is not None:
                    gcn = gcn_now
                    rep_frames.append(overlay(fr, [
                        f"REPLAY {spec.id} s{seed} step {i}/{REPLAY_STEPS}",
                        f"d_subject {dist_sub[-1]:.3f}m  gripper_norm {gcn:.2f}",
                        f"intent {'CLOSE' if act[-1] > 0.5 else 'OPEN '}  "
                        f"predicate {int(bool(arena.goal_satisfied()))}",
                    ], "REPLAY from natural terminal state"))

        signals = arena.debug_signals()
        contact = arena.task_contact()

        # ---- 距离轨迹派生量（§2.4：判别撤离 / 重试 / 游移）----
        d = np.asarray(dist_sub, dtype=np.float64)
        path_len = float(signals.get("eef_path_length", 0.0))
        max_disp = float(signals.get("eef_max_displacement", 0.0))
        path_over_max = (path_len / max_disp) if max_disp > 1e-9 else float("nan")
        i_min = int(np.argmin(d))
        approached_then_retreated = bool(i_min < len(d) - 1 and d[-1] > d[i_min] + 0.05)
        # 方向反转次数：距离序列一阶差分的符号变化
        if len(d) > 2:
            diff = np.diff(d)
            sign = np.sign(diff)
            sign = sign[sign != 0]
            reversals = int(np.sum(np.abs(np.diff(sign)) > 0)) if len(sign) > 1 else 0
        else:
            reversals = 0

        # ---- 运动分类（预注册判据，§2.4）----
        contact_ever = contact.get("ever")
        if max_disp < DEFAULT_THRESHOLDS.eef_displacement_m:
            motion_class = "undetermined"
        elif approached_then_retreated and (close_steps > 0 or contact_ever is True):
            motion_class = "reattempt"
        elif reversals >= 3 or (not np.isnan(path_over_max) and path_over_max > 3.0):
            motion_class = "wandering"
        elif not approached_then_retreated and contact_ever is not True:
            motion_class = "safe_retreat"
        else:
            motion_class = "undetermined"

        # ---- 用统一 metrics v2.1 ----
        from benchmark.metrics import EpisodeRecord

        ep = EpisodeRecord(
            task_id=spec.id, condition="terminal", seed=seed,
            init_satisfied=True, final_satisfied=bool(arena.goal_satisfied()),
            eef_max_displacement=max_disp,
            gripper_change=float(signals.get("gripper_change", 0.0)),
            gripper_change_norm=float(signals.get("gripper_change_norm", float("nan"))),
            gripper_open_reference=float(signals.get("gripper_open_reference", float("nan"))),
            object_max_displacement=float(signals.get("object_max_displacement", 0.0)),
            eef_path_length=path_len,
            object_path_length=float(signals.get("object_path_length", 0.0)),
            gripper_path_length=float(signals.get("gripper_path_length", 0.0)),
            task_joint_name=joint_name,
            task_joint_max_displacement=float(signals.get("task_joint_max_displacement", 0.0)),
            task_joint_path_length=float(signals.get("task_joint_path_length", 0.0)),
            task_joint_normalized_max=float(signals.get("task_joint_normalized_max", 0.0)),
            task_joint_range_span=float(signals.get("task_joint_range_span", float("nan"))),
            cumulative_measured=bool(arena.cumulative_measured()),
            contact_task_object=contact.get("ever"),
            contact_first_step=contact.get("first_step"),
            contact_steps=contact.get("n_steps"),
            gripper_close_steps=close_steps,
            gripper_first_close_step=first_close,
            n_steps=REPLAY_STEPS,
            n_policy_queries=REPLAY_STEPS // NUM_CHUNK + 1,
            success=bool(arena.goal_satisfied()),
            post_completion_steps=REPLAY_STEPS,
            post_completion_probe_measured=True,
        )
        rep_video = save_video(rep_frames, VIDEODIR / f"{spec.id}__s{seed}__replay.mp4") \
            if want_video else None

        rec["replay"] = {
            "predicate_initially_true": True,
            "observation_window_steps": REPLAY_STEPS,
            "probe_steps": REPLAY_STEPS,
            "eef_subject_distance": {
                "initial": float(d[0]) if len(d) else float("nan"),
                "min": float(d.min()) if len(d) else float("nan"),
                "final": float(d[-1]) if len(d) else float("nan"),
            },
            "eef_target_distance": ({
                "initial": float(dist_tgt[0]), "min": float(min(dist_tgt)),
                "final": float(dist_tgt[-1]),
            } if dist_tgt else None),
            "reapproach": {
                "approached_then_retreated": approached_then_retreated,
                "first_close_step": first_close,
                "close_steps": close_steps,
                "n_direction_reversals": reversals,
                "path_over_max_ratio": path_over_max,
                "eef_path_length": path_len,
                "eef_max_displacement": max_disp,
            },
            "motion_class": motion_class,
            "contact": contact,
            "nan_seen_in_replay": nan_seen,
            "video": rep_video,
            "episode_record": ep.as_dict(),
            "metrics_v2": compute_all_v2([ep]),
        }
        return rec

    except Exception as exc:  # noqa: BLE001
        rec["errors"].append(f"{type(exc).__name__}: {exc}")
        rec["errors"].append(traceback.format_exc())
        rec.setdefault("failure", {"stage": "EXCEPTION",
                                   "reason": f"{type(exc).__name__}: {exc}"})
        return rec


def write_csv(recs: list[dict], path: Path) -> None:
    rows = []
    for r in recs:
        g = r.get("generation", {}) or {}
        rep = r.get("replay", {}) or {}
        ra = rep.get("reapproach", {}) or {}
        m = (rep.get("metrics_v2", {}) or {})
        rows.append({
            "task_id": r["task_id"], "seed": r["seed"],
            "gen_success": g.get("success"),
            "success_first_step": g.get("success_first_step"),
            "capture_step": g.get("terminal_capture_step"),
            "reload_pred": (r.get("reload_verify") or {}).get("predicate_true_after_reload"),
            "motion_class": rep.get("motion_class"),
            "umr": (m.get("umr") or {}).get("value"),
            "contact_rate": (m.get("task_contact_rate") or {}).get("value"),
            "gdr": (m.get("gdr") or {}).get("value"),
            "eef_path": ra.get("eef_path_length"),
            "eef_max_disp": ra.get("eef_max_displacement"),
            "path_over_max": ra.get("path_over_max_ratio"),
            "close_steps": ra.get("close_steps"),
            "first_close": ra.get("first_close_step"),
            "n_reversals": ra.get("n_direction_reversals"),
            "d_sub_min": (rep.get("eef_subject_distance") or {}).get("min"),
            "contact_ever": (rep.get("contact") or {}).get("ever"),
        })
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", default="all", help="逗号分隔或 all")
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--video", action="store_true")
    ap.add_argument("--config", type=Path, default=ROOT / "configs/mini_pab.yaml")
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    reg = load_registry(args.config)
    tasks = [t for t in reg] if args.tasks == "all" else [reg[t.strip()]
                                                          for t in args.tasks.split(",")]

    print(f"[plan1-stage2] tasks={[t.id for t in tasks]} seeds={args.seeds} "
          f"video={args.video}", flush=True)

    policy = OpenVLAOFTAdapter(
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        checkpoint=str(CKPT),
        unnorm_key=tasks[0].suite,
        num_images_in_input=2,
        use_proprio=True,
        num_open_loop_steps=NUM_CHUNK,
    )
    all_recs: list[dict] = []
    t0 = time.time()
    for spec in tasks:
        arena = LiberoArena(
            task_suite_name=spec.suite, task_id=spec.task_id,
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=spec.subject, target=spec.target,
            joint_name=(spec.edit or {}).get("joint_name"),
            residual_kind=spec.residual_kind,
        )
        for seed in range(args.seeds):
            t = time.time()
            rec = run_one(arena, policy, spec, seed, args.video)
            rec["wall_time_s"] = time.time() - t
            p = OUT / f"{spec.id}__s{seed}__terminal.json"
            p.write_text(json.dumps(rec, indent=2, ensure_ascii=False, default=str),
                         encoding="utf-8")
            all_recs.append(rec)
            g = rec.get("generation", {}) or {}
            rep = rec.get("replay", {}) or {}
            print(f"[{spec.id} s{seed}] gen={g.get('success')} "
                  f"first_succ={g.get('success_first_step')} "
                  f"cap={g.get('terminal_capture_step')} "
                  f"class={rep.get('motion_class')} "
                  f"path/max={(rep.get('reapproach') or {}).get('path_over_max_ratio')} "
                  f"({time.time()-t:.0f}s)", flush=True)
        arena.close()

    write_csv(all_recs, OUT / "summary.csv")
    n_ok = sum(1 for r in all_recs if (r.get("generation") or {}).get("success"))
    summary = {
        "schema_version": "plan1-terminal-summary-v1",
        "n_pairs_attempted": len(all_recs),
        "n_generated": n_ok,
        "n_valid": sum(1 for r in all_recs
                       if (r.get("reload_verify") or {}).get("predicate_true_after_reload")),
        "n_failed": len(all_recs) - n_ok,
        "stability_thresholds_used": {
            "stable_window": STABLE_WINDOW,
            "subject_linear_vel_max": SUBJ_LIN_VEL_MAX,
            "subject_angular_vel_max": SUBJ_ANG_VEL_MAX,
            "gripper_open_frac_min": GRIPPER_OPEN_FRAC_MIN,
            "gripper_fallback_abs": GRIPPER_FALLBACK_ABS,
            "joint_vel_norm_max": JOINT_VEL_NORM_MAX,
            "joint_window_drift_max": JOINT_WINDOW_DRIFT_MAX,
        },
        "records": [{"task_id": r["task_id"], "seed": r["seed"],
                     "gen_success": (r.get("generation") or {}).get("success"),
                     "motion_class": (r.get("replay") or {}).get("motion_class")}
                    for r in all_recs],
        "notes": [
            "本文件由 scripts/plan1_terminal_replay.py 生成。",
            "replay 的位移基线在 set_state() 之后由 mark_episode_start() 重建。",
        ],
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[plan1-stage2] done in {time.time()-t0:.0f}s  "
          f"generated={n_ok}/{len(all_recs)}  -> {OUT}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
