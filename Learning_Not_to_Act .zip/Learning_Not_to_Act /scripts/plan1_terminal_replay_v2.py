"""plan1 Stage 2 smoke-v2：paired replay + no-op control + 逐 step trace。

mentor_review_2 §9.2 批准的修正运行。**复用已经保存的 8 个 terminal `.npy`**，
不重新生成自然终态。

相对第一版的修正（每条都对应 review 里的一个确定性问题）：

  §3.1  reapproach 拆成独立的 approach_delta / retreat_delta，
        不再把 "initial == min" 误判为重新接近
  §3.2  记录**真正的 step-0**（在任何 step 之前）
  §3.3  方向反转带死区，并给 1/2/5mm 三档敏感度
  §2.4  predicate 时间线 -> transient goal violation（T-GDR）
  §3.4  **每个 state 跑两遍**：policy replay + no-op replay（paired control）
  §3.5  多标签 event profile，不强制单一 motion class
  §4    contact 拆成 subject / target / any
  §5    articulated 的 eef-subject 距离无法解析时标未测量
  §7    保存完整逐 step trace（CSV），所有汇总**离线从 CSV 重算**

输出目录：`results/plan1/terminal_replay_v2/`（**不覆盖**第一版）

用法:
    ./run_diag.sh scripts/plan1_terminal_replay_v2.py --steps 300 --video
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.event_profile import (  # noqa: E402
    DEFAULT_EVENT_THRESHOLDS,
    compute_event_profile,
    derive_single_label,
)
from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
SRC = ROOT / "results/plan1/terminal_replay"          # 第一版（只读）
OUT = ROOT / "results/plan1/terminal_replay_v2"       # 本次输出
TRACES = OUT / "traces"
VIDEODIR = OUT / "videos"
CKPT = ROOT / "checkpoints/openvla-7b-oft-libero-sog10"
NUM_CHUNK = 8
FPS = 20

# trace 列（§7 规定的最小集合）
TRACE_COLS = [
    "step", "mode",
    "eef_x", "eef_y", "eef_z",
    "subject_x", "subject_y", "subject_z",
    "target_x", "target_y", "target_z",
    "task_joint_q",
    "d_eef_subject", "d_eef_target",
    "raw_gripper", "processed_gripper", "finger_open_frac",
    "subject_contact", "target_contact",
    "overall_predicate",
    "object_max_displacement", "task_joint_normalized_max",
]


def save_video(frames, path: Path):
    if not frames:
        return None
    import imageio.v2 as imageio

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=FPS, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return str(path)
    except Exception:  # noqa: BLE001
        return None


def overlay(frame, lines, banner=None):
    try:
        from PIL import Image, ImageDraw, ImageFont

        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        texts = list(lines) + ([banner] if banner else [])
        font, size = None, 11
        for size in range(11, 7, -1):
            try:
                font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", size)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default()
            if max(dr.textbbox((0, 0), t, font=font)[2] for t in texts) <= W - 8:
                break
        lh = size + 4
        box = lh * len(lines) + 4
        dr.rectangle([0, 0, W, box], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((4, 4 + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box, W, box + lh + 4], fill=(0, 90, 170))
            dr.text((4, box + 3), banner, fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


def _vec(arena, name):
    """实体位置；失败返回 None（而不是编一个坐标出来）。"""
    try:
        v = np.asarray(arena.entity_pos(name), dtype=np.float64).reshape(-1)
        return v if v.size >= 3 else None
    except Exception:  # noqa: BLE001
        return None


def snapshot(arena, spec, articulated: bool) -> dict:
    """某一时刻的完整信号快照。**step 0 也用它**（§3.2）。"""
    obs = arena._last_obs_raw or {}
    eef = np.asarray(obs.get("robot0_eef_pos", [np.nan] * 3), dtype=np.float64)
    sub = None if articulated else _vec(arena, spec.subject)
    tgt = _vec(arena, spec.target) if spec.target else None
    jq = None
    if articulated:
        try:
            from benchmark.states import mujoco_state as ms

            jq = float(ms.get_joint_pos(arena.get_state(), arena.model,
                                        (spec.edit or {}).get("joint_name")))
        except Exception:  # noqa: BLE001
            jq = None
    cf = arena._contact_flags()
    sig = arena.debug_signals()
    return {
        "eef": eef,
        "subject": sub,
        "target": tgt,
        "joint": jq,
        "d_sub": float(np.linalg.norm(eef - sub)) if sub is not None else None,
        "d_tgt": float(np.linalg.norm(eef - tgt)) if tgt is not None else None,
        "grip_open_frac": arena.gripper_current_open_frac(),
        "subject_contact": cf["subject"],
        "target_contact": cf["target"],
        "predicate": bool(arena.goal_satisfied()),
        "obj_disp": float(sig.get("object_max_displacement", 0.0)),
        "joint_norm": float(sig.get("task_joint_normalized_max", 0.0)),
    }


def rollout(arena, policy, spec, seed: int, state, steps: int, mode: str,
            want_video: bool):
    """跑一种模式（policy / noop），返回逐 step trace 行 + 视频路径。

    返回的 trace **包含 step 0**（进入循环之前的状态），这是 §3.2 的要求。
    """
    articulated = bool((spec.edit or {}).get("joint_name"))
    arena.set_state(state, settle_steps=0)
    arena.mark_episode_start()          # ★ 必须在 set_state 之后
    if hasattr(policy, "set_unnorm_key") and mode == "policy":
        policy.set_unnorm_key(str(arena.unnorm_key))
    if mode == "policy":
        policy.reset()

    rows: list[dict] = []
    frames: list = []

    def emit(step: int, raw_g, proc_g, snap: dict):
        rows.append({
            "step": step, "mode": mode,
            "eef_x": float(snap["eef"][0]), "eef_y": float(snap["eef"][1]),
            "eef_z": float(snap["eef"][2]),
            "subject_x": None if snap["subject"] is None else float(snap["subject"][0]),
            "subject_y": None if snap["subject"] is None else float(snap["subject"][1]),
            "subject_z": None if snap["subject"] is None else float(snap["subject"][2]),
            "target_x": None if snap["target"] is None else float(snap["target"][0]),
            "target_y": None if snap["target"] is None else float(snap["target"][1]),
            "target_z": None if snap["target"] is None else float(snap["target"][2]),
            "task_joint_q": snap["joint"],
            "d_eef_subject": snap["d_sub"],
            "d_eef_target": snap["d_tgt"],
            "raw_gripper": raw_g,
            "processed_gripper": proc_g,
            "finger_open_frac": snap["grip_open_frac"],
            "subject_contact": snap["subject_contact"],
            "target_contact": snap["target_contact"],
            "overall_predicate": int(snap["predicate"]),
            "object_max_displacement": snap["obj_disp"],
            "task_joint_normalized_max": snap["joint_norm"],
        })

    # ---- step 0：任何 step 之前 ----
    emit(0, None, None, snapshot(arena, spec, articulated))

    queue: list = []
    for i in range(1, steps + 1):
        if mode == "noop":
            act = np.asarray(arena.no_op_action(), dtype=float)
            raw_g = proc_g = None
        else:
            if not queue:
                obs = arena.get_observation()
                policy.predict(obs, arena.task_language)
                chunk = policy.last_processed_actions
                raw_chunk = policy.last_raw_actions
                if chunk.ndim == 1:
                    chunk = chunk.reshape(1, -1)
                if raw_chunk.ndim == 1:
                    raw_chunk = raw_chunk.reshape(1, -1)
                queue = [(chunk[k], raw_chunk[k])
                         for k in range(min(NUM_CHUNK, len(chunk)))]
            act, raw_a = queue.pop(0)
            act = np.asarray(act, dtype=float)
            raw_g = float(np.asarray(raw_a).reshape(-1)[-1])
            proc_g = float(act[-1])
        arena.step(act.tolist())
        snap = snapshot(arena, spec, articulated)
        emit(i, raw_g, proc_g, snap)

        if want_video:
            fr = arena.render_frame()
            if fr is not None:
                d = snap["d_sub"]
                gof = snap["grip_open_frac"]
                d_txt = "NA" if d is None else f"{d:.3f}m"
                g_txt = "NA" if (gof is None or np.isnan(gof)) else f"{gof:.2f}"
                i_txt = "CLOSE" if (proc_g or 0) > 0.5 else "OPEN "
                lines = [
                    f"{mode.upper()} {spec.id} s{seed} step {i}/{steps}",
                    f"d_subject {d_txt}  grip_open {g_txt}",
                    f"predicate {int(snap['predicate'])}  intent {i_txt}",
                ]
                frames.append(overlay(fr, lines, f"REPLAY v2 [{mode}]"))
    vid = None
    if want_video:
        vid = save_video(frames, VIDEODIR / f"{spec.id}__s{seed}__{mode}.mp4")
    # arena 侧累计信号（路径长度等无法从 trace 单独重算的量，一并落盘）
    return rows, vid, dict(arena.debug_signals()), arena.task_contact()


def write_trace(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TRACE_COLS)
        w.writeheader()
        w.writerows(rows)


def read_trace(path: Path) -> dict[str, list]:
    """把 CSV 读成 列名 -> 序列，供 event_profile 离线使用（§7）。"""
    cols: dict[str, list] = {c: [] for c in TRACE_COLS}
    with path.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            for c in TRACE_COLS:
                v = row.get(c)
                if v in ("", "None", None):
                    cols[c].append(None)
                elif c in ("step", "overall_predicate"):
                    cols[c].append(int(float(v)))
                elif c in ("subject_contact", "target_contact"):
                    cols[c].append(None if v == "" else v.lower() == "true")
                else:
                    try:
                        cols[c].append(float(v))
                    except (TypeError, ValueError):
                        cols[c].append(None)
    return cols


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--video", action="store_true")
    ap.add_argument("--only", default=None, help="只跑某个 task_id")
    args = ap.parse_args()

    TRACES.mkdir(parents=True, exist_ok=True)
    reg = load_registry(ROOT / "configs/mini_pab.yaml")

    states = sorted(SRC.glob("*__state.npy"))
    if args.only:
        states = [p for p in states if p.name.startswith(args.only)]
    if not states:
        print(f"[FAIL] {SRC} 下没有 __state.npy；smoke-v2 需要复用第一版终态")
        return 1
    print(f"[smoke-v2] {len(states)} 个 terminal state, steps={args.steps}", flush=True)

    policy = OpenVLAOFTAdapter(
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        checkpoint=str(CKPT),
        unnorm_key="libero_goal",
        num_images_in_input=2,
        use_proprio=True,
        num_open_loop_steps=NUM_CHUNK,
    )

    per_pair = []
    t0 = time.time()
    for sp_path in states:
        stem = sp_path.name[: -len("__state.npy")]
        task_id, seed_s = stem.rsplit("__s", 1)
        seed = int(seed_s)
        if task_id not in [t.id for t in reg]:
            print(f"[skip] 未知 task {task_id}")
            continue
        spec = reg[task_id]
        state = np.load(sp_path)
        arena = LiberoArena(
            task_suite_name=spec.suite, task_id=spec.task_id,
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=spec.subject, target=spec.target,
            joint_name=(spec.edit or {}).get("joint_name"),
            residual_kind=spec.residual_kind,
        )
        rec = {"schema_version": "plan1-terminal-v2", "task_id": task_id,
               "seed": seed, "state_path": str(sp_path), "steps": args.steps,
               "errors": []}
        try:
            arena.set_allow_after_done(True)
            # 重载校验
            arena.set_state(state, settle_steps=0)
            rec["reload"] = {"predicate_true": bool(arena.goal_satisfied()),
                             "residual": float(arena.residual())}

            # ---- A: policy replay ----
            tA = time.time()
            rowsA, vidA, sigA, conA = rollout(arena, policy, spec, seed, state,
                                              args.steps, "policy", args.video)
            pA = TRACES / f"{task_id}__s{seed}__policy.csv"
            write_trace(rowsA, pA)

            # ---- B: no-op control（同一 state, 同一窗口）----
            tB = time.time()
            rowsB, vidB, sigB, conB = rollout(arena, policy, spec, seed, state,
                                              args.steps, "noop", args.video)
            pB = TRACES / f"{task_id}__s{seed}__noop.csv"
            write_trace(rowsB, pB)

            # ---- 离线分析：只读 CSV，不依赖在线变量（§7）----
            def analyze(path: Path) -> dict:
                cols = read_trace(path)
                prof = compute_event_profile(cols)
                prof["single_label"] = derive_single_label(prof)
                preds = [p for p in cols["overall_predicate"] if p is not None]
                prof["predicate_true_any"] = bool(any(preds))
                prof["predicate_false_any"] = bool(any(not p for p in preds))
                return prof

            profA, profB = analyze(pA), analyze(pB)
            rec["policy"] = {"trace": str(pA), "video": vidA,
                             "event_profile": profA, "signals": sigA,
                             "contact": conA, "wall_time_s": time.time() - tA}
            rec["noop"] = {"trace": str(pB), "video": vidB,
                           "event_profile": profB, "signals": sigB,
                           "contact": conB, "wall_time_s": time.time() - tB}

            # ---- paired difference ----
            def q(prof, *keys):
                cur = prof
                for k in keys:
                    if cur is None:
                        return None
                    cur = cur.get(k) if isinstance(cur, dict) else None
                return cur

            rec["paired"] = {
                "eef_path_length": {
                    "policy": sigA.get("eef_path_length"),
                    "noop": sigB.get("eef_path_length"),
                    "paired_diff": (sigA.get("eef_path_length", float("nan"))
                                    - sigB.get("eef_path_length", float("nan"))),
                },
                "eef_max_displacement": {
                    "policy": sigA.get("eef_max_displacement"),
                    "noop": sigB.get("eef_max_displacement"),
                    "paired_diff": (sigA.get("eef_max_displacement", float("nan"))
                                    - sigB.get("eef_max_displacement", float("nan"))),
                },
                "reversals_main": {
                    "policy": q(profA, "quantities", "reversals_main"),
                    "noop": q(profB, "quantities", "reversals_main"),
                },
                "reversals_sensitivity": {
                    "policy": q(profA, "quantities", "reversals"),
                    "noop": q(profB, "quantities", "reversals"),
                },
                "close_steps": {
                    "policy": q(profA, "quantities", "close_steps"),
                    "noop": q(profB, "quantities", "close_steps"),
                },
                "contacted_subject": {
                    "policy": q(profA, "events", "contacted_subject"),
                    "noop": q(profB, "events", "contacted_subject"),
                },
                "goal_ever_broken": {
                    "policy": q(profA, "events", "goal_ever_broken"),
                    "noop": q(profB, "events", "goal_ever_broken"),
                },
                "task_state_changed": {
                    "policy": q(profA, "events", "task_state_changed"),
                    "noop": q(profB, "events", "task_state_changed"),
                },
            }
        except Exception as exc:  # noqa: BLE001
            import traceback as tb

            rec["errors"].append(f"{type(exc).__name__}: {exc}")
            rec["errors"].append(tb.format_exc())
        finally:
            arena.close()

        (OUT / f"{task_id}__s{seed}__v2.json").write_text(
            json.dumps(rec, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8")
        per_pair.append(rec)
        pl = (rec.get("policy") or {}).get("event_profile", {})
        nl = (rec.get("noop") or {}).get("event_profile", {})
        print(f"[{task_id} s{seed}] policy_label={pl.get('single_label')} "
              f"rev={pl.get('quantities', {}).get('reversals_main')} "
              f"reappr={pl.get('events', {}).get('reapproached_subject')} "
              f"broken={pl.get('events', {}).get('goal_ever_broken')} | "
              f"noop_label={nl.get('single_label')} "
              f"noop_rev={nl.get('quantities', {}).get('reversals_main')}",
              flush=True)

    (OUT / "summary_v2.json").write_text(
        json.dumps({"schema_version": "plan1-terminal-v2-summary",
                    "n_pairs": len(per_pair),
                    "steps": args.steps,
                    "thresholds": DEFAULT_EVENT_THRESHOLDS.as_dict(),
                    "records": [{"task_id": r["task_id"], "seed": r["seed"],
                                 "policy_label": (r.get("policy") or {})
                                 .get("event_profile", {}).get("single_label"),
                                 "noop_label": (r.get("noop") or {})
                                 .get("event_profile", {}).get("single_label")}
                                for r in per_pair]},
                   indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[smoke-v2] done in {time.time()-t0:.0f}s -> {OUT}", flush=True)
    print("[smoke-v2] 按 mentor_review_2 §9.2 第 6 条：**到此暂停**，等复审。",
          flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
