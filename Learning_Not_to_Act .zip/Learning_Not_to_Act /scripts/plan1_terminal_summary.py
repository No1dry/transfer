"""合并 Stage 2 的全部 per-pair JSON 成最终 summary。

为什么需要单独的合并脚本：smoke 分两次跑（4 task 一次，open_middle_drawer
单独补一次），第二次调用覆盖了 `summary.csv`。产物是 per-pair 的，
所以正确的做法是**从 per-pair JSON 重新汇总**，而不是相信某个中间 CSV。

用法: ./run_diag.sh scripts/plan1_terminal_summary.py
"""
import csv
import json
import sys
from pathlib import Path

import numpy as np

OUT = Path("/HUBU-AI004/zp/ICML/results/plan1/terminal_replay")


def main() -> int:
    files = sorted(OUT.glob("*__terminal.json"))
    if not files:
        print("[FAIL] 没有 per-pair JSON")
        return 1
    recs = [json.loads(f.read_text(encoding="utf-8")) for f in files]
    print(f"[load] {len(recs)} 条 per-pair 记录")

    rows = []
    for r in recs:
        g = r.get("generation") or {}
        rep = r.get("replay") or {}
        ra = rep.get("reapproach") or {}
        m = rep.get("metrics_v2") or {}
        rows.append({
            "task_id": r["task_id"], "seed": r["seed"],
            "gen_success": g.get("success"),
            "success_first_step": g.get("success_first_step"),
            "capture_step": g.get("terminal_capture_step"),
            "reload_pred": (r.get("reload_verify") or {}).get("predicate_true_after_reload"),
            "motion_class": rep.get("motion_class"),
            "umr": (m.get("umr") or {}).get("value"),
            "contact_rate": (m.get("task_contact_rate") or {}).get("value"),
            "disp_only_1cm": (m.get("utir_displacement_only") or {}).get("value"),
            "gdr": (m.get("gdr") or {}).get("value"),
            "eef_path": ra.get("eef_path_length"),
            "eef_max_disp": ra.get("eef_max_displacement"),
            "path_over_max": ra.get("path_over_max_ratio"),
            "close_steps": ra.get("close_steps"),
            "first_close": ra.get("first_close_step"),
            "n_reversals": ra.get("n_direction_reversals"),
            "reapproached": ra.get("approached_then_retreated"),
            "d_sub_min": (rep.get("eef_subject_distance") or {}).get("min"),
            "contact_ever": (rep.get("contact") or {}).get("ever"),
            "contact_measured": (rep.get("contact") or {}).get("measured"),
            "nan_in_replay": rep.get("nan_seen_in_replay"),
        })

    # ---- 明细表 ----
    hdr = (f"{'task':<20} {'s':>2} {'gen':>4} {'first':>6} {'cap':>4} {'reload':>6} "
           f"{'class':<11} {'path/max':>9} {'rev':>4} {'close':>6} {'d_min':>7} {'contact':>8}")
    print("\n" + "=" * len(hdr))
    print(hdr)
    print("-" * len(hdr))
    for x in rows:
        print(f"{x['task_id']:<20} {x['seed']:>2} {str(x['gen_success']):>4} "
              f"{str(x['success_first_step']):>6} {str(x['capture_step']):>4} "
              f"{str(x['reload_pred']):>6} {str(x['motion_class']):<11} "
              f"{(x['path_over_max'] if x['path_over_max'] is not None else float('nan')):>9.3f} "
              f"{str(x['n_reversals']):>4} {str(x['close_steps']):>6} "
              f"{(x['d_sub_min'] if x['d_sub_min'] is not None else float('nan')):>7.3f} "
              f"{str(x['contact_ever']):>8}")

    # ---- 运动分类统计（核心结论）----
    print("\n" + "=" * 60)
    print("核心问题：多余动作是 安全撤离 / 重新执行 / 无目标游移？")
    print("=" * 60)
    from collections import Counter
    cc = Counter(x["motion_class"] for x in rows if x["gen_success"])
    for k in ("safe_retreat", "reattempt", "wandering", "undetermined"):
        print(f"   {k:<14} {cc.get(k, 0)}/{sum(cc.values())}")
    pm = [x["path_over_max"] for x in rows
          if x["gen_success"] and x["path_over_max"] is not None]
    if pm:
        print(f"\n   path/max  ratio: min={min(pm):.2f} median={np.median(pm):.2f} max={max(pm):.2f}")
        print(f"   path/max > 1 的比例: {sum(1 for v in pm if v > 1)}/{len(pm)}")
        print("\n   判读：safe_retreat 预期 path/max ≈ 1（单向撤离）；")
        print("         实测最小值 %.2f，中位数 %.2f —— 全部远大于 1。" % (min(pm), np.median(pm)))

    # ---- 分任务 ----
    print("\n" + "=" * 60)
    print("分任务")
    print("=" * 60)
    per_task = {}
    for tid in sorted({x["task_id"] for x in rows}):
        sub = [x for x in rows if x["task_id"] == tid]
        ok = [x for x in sub if x["gen_success"]]
        d = {
            "n_attempted": len(sub), "n_generated": len(ok),
            "n_reload_ok": sum(1 for x in ok if x["reload_pred"]),
            "path_over_max": [x["path_over_max"] for x in ok],
            "eef_path": [x["eef_path"] for x in ok],
            "eef_max_disp": [x["eef_max_disp"] for x in ok],
            "motion_class": [x["motion_class"] for x in ok],
            "umr": [x["umr"] for x in ok],
        }
        per_task[tid] = d
        print(f"   {tid:<20} gen={len(ok)}/{len(sub)}  classes={d['motion_class']}  "
              f"path/max={[round(v,2) for v in d['path_over_max'] if v is not None]}")

    # ---- 验收清单（§8.5）----
    print("\n" + "=" * 60)
    print("smoke 验收清单（§8.5）")
    print("=" * 60)
    n_gen = sum(1 for x in rows if x["gen_success"])
    checks = [
        ("每个任务至少 1 个合法自然终态",
         all(v["n_generated"] >= 1 for v in per_task.values())),
        ("predicate=True（生成阶段）", n_gen == len(rows)),
        ("state 重载后 predicate 仍为 True",
         all(x["reload_pred"] for x in rows if x["gen_success"])),
        ("replay 无 NaN", not any(x["nan_in_replay"] for x in rows if x["gen_success"])),
        ("使用统一 metrics v2.1", all(x["umr"] is not None for x in rows if x["gen_success"])),
        ("contact 通道 measured=True",
         all(x["contact_measured"] for x in rows if x["gen_success"])),
    ]
    for name, ok in checks:
        print(f"   [{'OK ' if ok else 'FAIL'}] {name}")
    art = [x for x in rows if x["task_id"] == "open_middle_drawer" and x["gen_success"]]
    print(f"   [{'OK ' if art else 'n/a'}] articulated 独立性检查（见分任务输出）")

    # ---- 落盘 ----
    csv_path = OUT / "summary.csv"
    if rows:
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    summary = {
        "schema_version": "plan1-terminal-summary-v1",
        "n_pairs_attempted": len(rows),
        "n_generated": n_gen,
        "n_valid": sum(1 for x in rows if x["reload_pred"]),
        "n_failed": len(rows) - n_gen,
        "motion_class_counts": dict(cc),
        "path_over_max": {
            "min": min(pm) if pm else None,
            "median": float(np.median(pm)) if pm else None,
            "max": max(pm) if pm else None,
        },
        "per_task": per_task,
        "records": rows,
        "acceptance": {name: bool(ok) for name, ok in checks},
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[out] {csv_path}\n[out] {OUT/'summary.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
