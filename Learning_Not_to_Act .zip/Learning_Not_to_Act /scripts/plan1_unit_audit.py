"""单位审计：gripper 通道、joint 通道、阈值是否有物理意义。

Codex 的 mentor_review_1 §3.3 提出一个可疑点：

    gripper_change 来自真实 finger qpos，历史完整开合的变化约为 0.05，
    而阈值写成 0.2，并注释成"归一化单位"。因此当前 gripper 物理通道
    几乎永远不会触发。

这个脚本用**已有数据**直接验证该说法，并顺带标定：
  - finger qpos 在 OPEN / CLOSE 两个极端下的实测值
  - 历史 160 条记录里 gripper_change 的分布
  - 在阈值 0.2 下有多少条会被 gripper 通道命中（对 UMR 的实际贡献）
  - task joint 的 range（判断 §3.5 的跨任务可比性问题）

不加载模型、不占 GPU。

用法: ./run_diag.sh scripts/plan1_unit_audit.py
"""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.metrics import DEFAULT_THRESHOLDS  # noqa: E402
from benchmark.runner import load_records  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402

ROOT = Path("/HUBU-AI004/zp/ICML")
FINAL = ROOT / "results/m1/final"
TH = DEFAULT_THRESHOLDS


def dist(name, arr):
    arr = np.asarray(arr, dtype=np.float64)
    arr = arr[~np.isnan(arr)]
    if arr.size == 0:
        print(f"   {name:<26} <无数据>")
        return None
    q = np.quantile(arr, [0.0, 0.1, 0.5, 0.9, 1.0])
    print(f"   {name:<26} min={q[0]:.4f} p10={q[1]:.4f} median={q[2]:.4f} "
          f"p90={q[3]:.4f} max={q[4]:.4f}  n={arr.size}")
    return q


print("=" * 80)
print("1) gripper 通道单位审计（验证 mentor_review_1 §3.3）")
print("=" * 80)

recs = load_records(FINAL) if FINAL.exists() else []
sat = [r for r in recs if r.condition == "satisfied" and r.init_satisfied]
uns = [r for r in recs if r.condition == "unsatisfied"]

print(f"\n[satisfied  n={len(sat)}] gripper_change 分布:")
q_sat = dist("gripper_change(sat)", [r.gripper_change for r in sat])
print(f"[unsatisfied n={len(uns)}] gripper_change 分布:")
q_uns = dist("gripper_change(unsat)", [r.gripper_change for r in uns])

thr = TH.gripper_change
if q_sat is not None and q_uns is not None:
    n_sat_hit = sum(1 for r in sat if r.gripper_change > thr)
    n_uns_hit = sum(1 for r in uns if r.gripper_change > thr)
    print(f"\n阈值 gripper_change = {thr}")
    print(f"   satisfied   命中: {n_sat_hit}/{len(sat)} "
          f"({n_sat_hit/max(len(sat),1):.3f})")
    print(f"   unsatisfied 命中: {n_uns_hit}/{len(uns)} "
          f"({n_uns_hit/max(len(uns),1):.3f})")
    print(f"   unsatisfied 的 max = {q_uns[4]:.4f}")
    verdict = "成立" if q_uns[4] < thr else "不成立"
    print(f"\n[结论] 'gripper 物理通道几乎永不触发' 这个说法: **{verdict}**")
    if q_uns[4] < thr:
        print("       → 连真正成功抓取的 episode（unsatisfied）都没超过阈值，")
        print("         说明 UMR 的 gripper 分支实际上从未贡献过任何一次判定。")

# 实测 finger qpos 的两个极端：官方初始态（张开） vs 强行闭合
print("\n" + "=" * 80)
print("2) finger qpos 实测标定（OPEN vs CLOSE 两端）")
print("=" * 80)

reg = load_registry(ROOT / "configs/mini_pab.yaml")
spec = reg["bowl_on_plate"]
arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
arena.reset()
g_open = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=np.float64)
print(f"   官方初始态 finger qpos        = {g_open}   |·|={np.linalg.norm(g_open):.4f}")

# 用力闭合到底，测量极限
close_action = arena.no_op_action()
close_action[-1] = 1.0   # env 约定 +1 = close
for _ in range(40):
    arena.step(close_action)
g_closed = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=np.float64)
print(f"   持续闭合后 finger qpos        = {g_closed}   |·|={np.linalg.norm(g_closed):.4f}")

full = float(np.linalg.norm(g_closed - g_open))
print(f"\n   完整 OPEN→CLOSE 的 L2 变化量   = {full:.4f}")
print(f"   历史阈值                       = {thr}")
print(f"   比值 (阈值 / 完整变化)          = {thr / full if full else float('nan'):.2f}x")

if full > 0:
    if thr > full:
        print(f"\n[结论] 阈值 {thr} 比物理上可能的最大变化 {full:.4f} 还大 "
              f"{thr/full:.1f} 倍 ——")
        print("       物理 gripper 通道在任何情况下都不可能触发。这是**确定性的量纲错误**。")
    else:
        print(f"\n[结论] 阈值 {thr} 在物理可达范围内（完整变化 {full:.4f}）")
    print(f"       建议物理阈值取完整变化的 ~50%: {0.5*full:.4f}")

# joint range（§3.5）
print("\n" + "=" * 80)
print("3) task joint range（验证 §3.5 的跨任务可比性）")
print("=" * 80)
for sp in reg:
    tid = sp.id
    jn = (sp.edit or {}).get("joint_name")
    if not jn:
        print(f"   {tid:<22} <无 joint（placement 任务）>")
        continue
    try:
        a = LiberoArena(
            task_suite_name=sp.suite, task_id=sp.task_id,
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=sp.subject, target=sp.target,
            joint_name=jn, residual_kind=sp.residual_kind,
        )
        from benchmark.states import mujoco_state as ms
        model = a.model
        entry = ms.resolve_single_dof_joint(model, jn)
        # jnt_range 按 joint id 索引，用名字反查
        jid = None
        for i in range(int(model.njnt)):
            try:
                nm = model.joint_id2name(i) if hasattr(model, "joint_id2name") else None
            except Exception:  # noqa: BLE001
                nm = None
            if nm == entry.name:
                jid = i
                break
        jtype = int(entry.mj_type)
        unit = "m(滑轨/slide)" if jtype == 2 else ("rad(铰链/hinge)" if jtype == 3 else f"type={jtype}")
        if jid is not None:
            lo, hi = float(model.jnt_range[jid][0]), float(model.jnt_range[jid][1])
            print(f"   {tid:<22} joint={entry.name:<30} "
                  f"range=[{lo:.4f}, {hi:.4f}] span={hi-lo:.4f} {unit}")
        else:
            print(f"   {tid:<22} joint={entry.name:<30} <range 不可得> {unit}")
        a.close()
    except Exception as e:  # noqa: BLE001
        print(f"   {tid:<22} joint={jn} <读取失败 {type(e).__name__}: {e}>")

arena.close()
print("\n[unit-audit] done")
