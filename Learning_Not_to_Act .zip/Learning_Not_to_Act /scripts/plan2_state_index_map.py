"""plan2 P2.1 准备：**只读**导出 state-index 白名单（不加载 7B 模型、不跑 GPU episode）。

背景（mentor_review_14 §3.1）
-----------------------------
plan2 草案把因子写成 "NAT-obj / EXO-obj"，这只是**数据生成方式**，
不是 state-only VLA 能观察到的变量。因子必须重写成**可观察分量**：

    因子 O：task/environment configuration（非机器人状态分量）
    因子 R：robot phase/pose（机器人状态分量）

要做 paired intervention，就必须知道**每个分量落在 flattened state 的哪几个下标上**。
本脚本把这件事变成可审计的表，输出 `results/plan2/state_index_map.json`。

它做什么
--------
对每个 Stage 4 任务构造 arena（CPU 侧编译 MuJoCo 模型，**不加载 policy**），
打印 flattened state 布局 `[time(1) | qpos(nq) | qvel(nv) | act(na)]`，
并对每个 joint 给出名字 / 类型 / qpos 地址 / 映射到的 flat 下标 / 维度 / range。

角色分类（本文件只做**机械**划分，不做语义判断）：

    R : robot0_joint* + gripper0_finger_joint*      -> 因子 R 的可写集合
    O : 其余全部（自由物体 xyz+quat、articulated 关节）-> 因子 O 的可写集合

并额外标注 completed / remaining / container / task_joint 分别落在哪些下标。

用法
----
    ./run_diag.sh scripts/plan2_state_index_map.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

ROOT = Path("/HUBU-AI004/zp/ICML")
OUT = ROOT / "results/plan2/state_index_map.json"

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402

MJ_TYPE = {0: "free", 1: "ball", 2: "slide", 3: "hinge"}

TASKS = [
    {
        "tag": "I1",
        "suite": "libero_10",
        "task_id": 0,
        "task_name": "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket",
        "subject": "alphabet_soup_1",
        "target": "basket_1",
        "joint_name": None,
        "completed": "alphabet_soup_1",
        "remaining": "tomato_sauce_1",
        "container": "basket_1",
    },
    {
        "tag": "I2",
        "suite": "libero_10",
        "task_id": 2,
        "task_name": "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it",
        "subject": "moka_pot_1",
        "target": "flat_stove_1",
        "joint_name": "flat_stove_1_button",
        "completed": "flat_stove_1_button",
        "remaining": "moka_pot_1",
        "container": "flat_stove_1",
    },
]


def role_of(name: str) -> str:
    name = name or ""
    if name.startswith("robot0_joint") or name.startswith("gripper0_finger_joint"):
        return "R"
    return "O"


def entity_indices(model, layout, name: str, joint_name: str | None) -> dict:
    """实体 -> flat 下标。自由物体走 free joint，articulated 走指定关节。"""
    qbase = int(layout.qpos_slice.start)
    vbase = int(layout.qvel_slice.start)

    if joint_name:
        try:
            je = ms.resolve_single_dof_joint(model, joint_name)
            qadr, qdim = int(je.qpos_adr), int(je.qpos_dim)
            dadr, ddim = int(je.dof_adr), int(je.dof_dim)
            return {
                "entity": name, "kind": "articulated",
                "joint": je.name, "flat_qpos_indices": [qbase + qadr + k for k in range(qdim)],
                "flat_qvel_indices": [vbase + dadr + k for k in range(ddim)],
            }
        except Exception as exc:  # noqa: BLE001
            return {"entity": name, "kind": "articulated_resolve_failed",
                    "error": f"{type(exc).__name__}: {exc}"}

    try:
        je = ms.resolve_free_joint(model, name)
    except Exception as exc:  # noqa: BLE001
        # 退路：按名字前缀匹配任意关节
        hits = [j for j in ms.iter_joints(model) if j.name and name.split("_1")[0] in j.name]
        return {"entity": name, "kind": "free_resolve_failed",
                "error": f"{type(exc).__name__}: {exc}",
                "prefix_hits": [{"joint": h.name, "qpos_adr": int(h.qpos_adr),
                                 "qpos_dim": int(h.qpos_dim)} for h in hits]}
    return {
        "entity": name, "kind": "free", "joint": je.name,
        "flat_qpos_indices": [qbase + int(je.qpos_adr) + k for k in range(int(je.qpos_dim))],
        "flat_qvel_indices": [vbase + int(je.dof_adr) + k for k in range(int(je.dof_dim))],
    }


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    report: dict = {
        "schema_version": "plan2-state-index-map-v1",
        "note": "只读：不加载 policy，不跑 episode；用于 P2.1 的 state-index 白名单",
        "layout": "[time(1) | qpos(nq) | qvel(nv) | act(na)]",
        "tasks": [],
    }

    for spec in TASKS:
        print("=" * 78)
        print(f"{spec['tag']} :: {spec['task_name']}")
        print("=" * 78)
        entry: dict = {"tag": spec["tag"], "task_name": spec["task_name"],
                       "arena": {}, "joints": [], "roles": {}, "entities": {}}
        arena = LiberoArena(
            task_suite_name=spec["suite"], task_id=spec["task_id"],
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=spec["subject"], target=spec["target"],
            joint_name=spec["joint_name"], residual_kind="placement",
        )
        try:
            arena.reset(official_init_index=0)
            model = arena.model
            state = np.asarray(arena.get_state(), dtype=np.float64)
            layout = ms.StateLayout.from_model(model)
            entry["arena"] = {
                "nq": int(layout.nq), "nv": int(layout.nv), "na": int(layout.na),
                "total_dim": int(state.shape[0]),
                "qpos_slice": [int(layout.qpos_slice.start), int(layout.qpos_slice.stop)],
                "qvel_slice": [int(layout.qvel_slice.start), int(layout.qvel_slice.stop)],
                "act_slice": ([int(layout.act_slice.start), int(layout.act_slice.stop)]
                              if layout.act_slice is not None else None),
                "num_steps_wait_inside_reset": int(arena._num_steps_wait),
                "task_language": arena.task_language,
            }
            print(json.dumps(entry["arena"], ensure_ascii=False))

            qbase = int(layout.qpos_slice.start)
            vbase = int(layout.qvel_slice.start)
            for je in ms.iter_joints(model):
                entry["joints"].append({
                    "name": je.name,
                    "type": MJ_TYPE.get(int(je.mj_type), f"type{int(je.mj_type)}"),
                    "role": role_of(je.name),
                    "qpos_adr": int(je.qpos_adr),
                    "qpos_dim": int(je.qpos_dim),
                    "dof_adr": int(je.dof_adr),
                    "dof_dim": int(je.dof_dim),
                    "flat_qpos_indices": [qbase + int(je.qpos_adr) + k
                                          for k in range(int(je.qpos_dim))],
                    "flat_qvel_indices": [vbase + int(je.dof_adr) + k
                                          for k in range(int(je.dof_dim))],
                })

            for rec in entry["joints"]:
                if rec["role"] == "O":
                    print(f"  O {rec['name']:<34} {rec['type']:<6} "
                          f"qpos_adr={rec['qpos_adr']:>3} dim={rec['qpos_dim']} "
                          f"flat={rec['flat_qpos_indices']}")
            for rec in entry["joints"]:
                if rec["role"] == "R":
                    print(f"  R {rec['name']:<34} {rec['type']:<6} "
                          f"qpos_adr={rec['qpos_adr']:>3} dim={rec['qpos_dim']} "
                          f"flat={rec['flat_qpos_indices']}")

            r_idx = sorted(i for r in entry["joints"] if r["role"] == "R"
                           for i in r["flat_qpos_indices"])
            o_idx = sorted(i for r in entry["joints"] if r["role"] == "O"
                           for i in r["flat_qpos_indices"])
            entry["roles"] = {
                "R_flat_qpos_indices": r_idx,
                "O_flat_qpos_indices": o_idx,
                "n_R": len(r_idx), "n_O": len(o_idx),
                "R_is_contiguous_from_qpos_base": bool(
                    r_idx == list(range(qbase, qbase + len(r_idx)))),
            }

            entry["entities"]["completed"] = entity_indices(
                model, layout, spec["completed"], spec["joint_name"])
            entry["entities"]["remaining"] = entity_indices(
                model, layout, spec["remaining"], None)
            entry["entities"]["container"] = entity_indices(
                model, layout, spec["container"], None)
            if spec["joint_name"]:
                entry["entities"]["task_joint"] = entity_indices(
                    model, layout, spec["joint_name"], spec["joint_name"])

            print("\n  roles:", json.dumps(
                {k: v for k, v in entry["roles"].items() if not k.startswith("O_flat")
                 and not k.startswith("R_flat")}, ensure_ascii=False))
            print("  R idx:", r_idx)
            print("  entities:", json.dumps(entry["entities"], ensure_ascii=False))
        finally:
            arena.close()
        report["tasks"].append(entry)
        print()

    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[ok] wrote {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
