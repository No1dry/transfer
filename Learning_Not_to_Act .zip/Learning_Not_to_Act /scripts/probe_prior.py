"""验证用户的观察：satisfied 下机械臂是否"朝着**原来** bowl 的位置去抓"？

现象描述（用户看视频发现）：
  `bowl_on_stove` 任务里，碗**已经在炉子上**（但不在正中），
  机械臂仍然动作，但它是朝**原来 bowl 所在的位置**去抓 —— 那个地方并没有碗。

如果成立，含义是：模型的动作**没有以当前观测到的物体位置为条件**，
而是在**复现训练分布里的先验位置**（训练时碗永远在官方初始位置）。
这比"该停不停"更强：说明它的动作在空间上就是"开环"的。

验证方法
--------
对同一个 satisfied 初始状态，逐步记录：
  * eef 的实际位置
  * 物体（碗）的实际位置 —— satisfied 下在炉子上
  * "训练先验位置" —— 官方初始状态下碗的位置
然后看 eef 究竟是靠近**物体实际位置**，还是靠近**先验位置**。
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"
TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_stove"
N_SEEDS = int(sys.argv[2]) if len(sys.argv) > 2 else 3

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key=spec.suite,
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=8,
)
print(f"[probe] task={TASK} subject={spec.subject} target={spec.target}", flush=True)

builder = StateBuilder(settle_steps=15)
NUM_CHUNK = 8
MAX_STEPS = 300

for seed in range(N_SEEDS):
    # 1) 官方初始状态下，物体在哪（= 训练时它一直在的地方 = "先验位置"）
    arena.reset(official_init_index=seed)
    prior_pos = arena.entity_pos(spec.subject).copy()

    # 2) 构造 satisfied 状态，物体被搬到目标处
    r = builder.build_state(arena, spec, "satisfied", seed)
    if not r.ok:
        print(f"seed {seed}: build failed", flush=True)
        continue
    arena.set_state(r.state, settle_steps=0)
    arena.mark_episode_start()
    actual_pos = arena.entity_pos(spec.subject).copy()

    print(
        f"\n[probe] seed={seed}  satisfied={arena.goal_satisfied()}\n"
        f"        先验位置(官方初始) = {np.round(prior_pos, 4).tolist()}\n"
        f"        实际位置(satisfied) = {np.round(actual_pos, 4).tolist()}\n"
        f"        两者相距          = {np.linalg.norm(prior_pos - actual_pos):.4f} m",
        flush=True,
    )

    # 3) 跑策略，记录 eef 轨迹与到两个位置的最近距离
    policy.reset()
    queue: list = []
    min_d_prior = 1e9
    min_d_actual = 1e9
    step_of_closest_prior = -1
    steps = 0
    trajectory = []

    while steps < MAX_STEPS:
        if not queue:
            obs = arena.get_observation()
            chunk = np.asarray(policy.predict(obs, arena.task_language), dtype=np.float64)
            if chunk.ndim == 1:
                chunk = chunk.reshape(1, -1)
            queue.extend(list(chunk[:NUM_CHUNK]))
        a = queue.pop(0)
        arena.step(a)
        steps += 1

        eef = np.asarray(arena._env.sim.data.get_body_xpos("robot0_right_hand"), dtype=np.float64)
        d_prior = float(np.linalg.norm(eef - prior_pos))
        d_actual = float(np.linalg.norm(eef - actual_pos))
        if d_prior < min_d_prior:
            min_d_prior = d_prior
            step_of_closest_prior = steps
        min_d_actual = min(min_d_actual, d_actual)
        trajectory.append((steps, eef.copy(), d_prior, d_actual))

    print(
        f"        eef 到**先验位置**最近 = {min_d_prior:.4f} m (第 {step_of_closest_prior} 步)\n"
        f"        eef 到**实际位置**最近 = {min_d_actual:.4f} m\n"
        f"        => {'更靠近先验位置 ✓ 用户的观察成立' if min_d_prior < min_d_actual else '更靠近实际位置 ✗'}",
        flush=True,
    )

    # 打印关键时刻（每 30 步）
    print("        轨迹抽样 (step, eef_xy, d_prior, d_actual):", flush=True)
    for s, eef, dp, da in trajectory[::30]:
        print(f"          {s:3d}  eef={np.round(eef[:2],3).tolist()}  d_prior={dp:.3f}  d_actual={da:.3f}", flush=True)

arena.close()
print("\n[probe] done", flush=True)
