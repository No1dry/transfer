"""profile 状态构造的热点（到底是 reset / settle / set_state 哪一步慢）。"""
import sys
import time

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from pathlib import Path

from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)

# 1) reset 成本
t0 = time.time()
arena.reset(official_init_index=0)
print(f"reset(0)                 : {time.time() - t0:6.2f}s", flush=True)

# 2) 再来一次 reset（验证是否可重复，以及是否有首次开销）
t0 = time.time()
arena.reset(official_init_index=0)
print(f"reset(0) again           : {time.time() - t0:6.2f}s", flush=True)

# 3) settle 成本（逐步计时）
st = arena.get_state()
for n in (5, 15, 30):
    t0 = time.time()
    arena.set_state(st, settle_steps=n)
    dt = time.time() - t0
    print(f"set_state(settle={n:2d})      : {dt:6.2f}s  -> {dt / n * 1000:6.0f} ms/step", flush=True)

# 4) 纯 set_state（无 settle）
t0 = time.time()
for _ in range(20):
    arena.set_state(st, settle_steps=0)
print(f"set_state(settle=0) x20  : {time.time() - t0:6.2f}s", flush=True)

# 5) goal_satisfied / residual 成本
t0 = time.time()
for _ in range(20):
    arena.goal_satisfied()
print(f"goal_satisfied x20       : {time.time() - t0:6.2f}s", flush=True)

t0 = time.time()
for _ in range(20):
    arena.residual()
print(f"residual x20             : {time.time() - t0:6.2f}s", flush=True)

# 6) 单次 env.step 成本
t0 = time.time()
for _ in range(20):
    arena.step(arena.no_op_action())
dt = time.time() - t0
print(f"env.step x20             : {dt:6.2f}s  -> {dt / 20 * 1000:6.0f} ms/step", flush=True)

arena.close()
