"""测量视频编码耗时，判断 unsatisfied episode 变慢是否由录像引起。"""
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

out = Path("/HUBU-AI004/zp/ICML/results/m1/_enc_test")
out.mkdir(parents=True, exist_ok=True)

for n_frames in (120, 320):
    frames = [np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8) for _ in range(n_frames)]

    p = out / f"test_{n_frames}.mp4"
    t0 = time.time()
    try:
        import imageio.v2 as imageio

        with imageio.get_writer(p, fps=20, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        dt = time.time() - t0
        print(f"[enc] {n_frames} frames (mp4, 256x256) -> {dt:6.2f}s", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[enc] {n_frames} mp4 FAILED: {type(e).__name__}: {e}", flush=True)

    pg = out / f"test_{n_frames}.gif"
    t0 = time.time()
    try:
        import imageio.v2 as imageio

        imageio.mimsave(pg, frames, fps=20)
        print(f"[enc] {n_frames} frames (gif)          -> {time.time() - t0:6.2f}s", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[enc] {n_frames} gif FAILED: {type(e).__name__}: {e}", flush=True)

print("[enc] done", flush=True)
