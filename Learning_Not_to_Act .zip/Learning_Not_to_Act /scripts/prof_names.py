"""测量名字查询与关节解析的开销，确认缓存是否解决了构造慢的问题。"""
import sys
import time

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states import mujoco_state as ms

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="plate_1",
    residual_kind="placement",
)
model = arena.model
print(f"njnt={model.njnt} nbody={model.nbody} ngeom={model.ngeom}", flush=True)


def bench(label, fn, n=200):
    # 先热一次，避免把首次开销算进来
    fn()
    t0 = time.time()
    for _ in range(n):
        fn()
    dt = (time.time() - t0) / n
    print(f"{label:38s}: {dt * 1e6:9.1f} us/call", flush=True)


bench("iter_joints()", lambda: ms.iter_joints(model))
bench("all_body_names()", lambda: ms.all_body_names(model))
bench("find_body_id('plate_1')", lambda: ms.find_body_id(model, "plate_1"))
bench("resolve_free_joint('akita_bowl')", lambda: ms.resolve_free_joint(model, "akita_black_bowl_1"))
bench("get_joint_range(drawer)", lambda: ms.get_joint_range(model, "wooden_cabinet_1_middle_level"))

# 直接测名字查询本身的成本
import mujoco

t0 = time.time()
for _ in range(1000):
    mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, 0)
print(f"{'raw mj_id2name x1000':38s}: {(time.time() - t0) * 1e6 / 1000:9.1f} us/call", flush=True)

# 枚举全部 body 名一次的成本（缓存未命中时每个 body 都要付一次）
t0 = time.time()
from robosuite.utils import binding_utils

rb = binding_utils.mujoco
for i in range(model.nbody):
    rb.mj_id2name(model, rb.mjtObj.mjOBJ_BODY, i)
print(f"{'robosuite mj_id2name x nbody':38s}: {(time.time() - t0) * 1e3:9.2f} ms total", flush=True)

arena.close()
