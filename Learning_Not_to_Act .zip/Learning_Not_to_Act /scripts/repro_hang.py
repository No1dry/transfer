"""复现并定位：satisfied+unsatisfied 连续构造时的卡死点。

模拟 run_mini_pab 里每个 episode 的调用顺序，并打印每一步耗时与当时的状态，
以便定位到底卡在 reset / settle / candidate 搜索 / finalize 的哪一处。
"""
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]

T0 = time.time()


def log(msg: str) -> None:
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


# 关键：完全复刻 run_mini_pab 的做法 —— 每个 episode 新建一个 arena，
# 而不是复用同一个。这是怀疑点：反复创建/关闭 OffScreenRenderEnv
# 可能耗尽了 EGL context 或者触发了某种退化。
for episode_i in range(4):
    for cond in ("satisfied", "unsatisfied"):
        log(f"--- episode {episode_i} cond={cond}: creating arena ---")
        t0 = time.time()
        arena = LiberoArena(
            task_suite_name=spec.suite,
            task_id=spec.task_id,
            openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
            subject=spec.subject,
            target=spec.target,
            residual_kind=spec.residual_kind,
        )
        log(f"    arena created in {time.time() - t0:.1f}s")

        builder = StateBuilder(settle_steps=15)
        t0 = time.time()
        try:
            r = builder.build_state(arena, spec, cond, episode_i)
            log(
                f"    build_state: ok={r.ok} {time.time() - t0:.1f}s "
                f"attempts={len(r.attempts)} residual={r.residual_after_build:.4f}"
            )
        except Exception as e:  # noqa: BLE001
            log(f"    build_state EXCEPTION after {time.time() - t0:.1f}s: {type(e).__name__}: {e}")

        t0 = time.time()
        arena.close()
        log(f"    arena closed in {time.time() - t0:.1f}s")

log("done")
