"""定位 runner 路径中的卡点：逐步计时 run_episode 的每个阶段。

与 run_mini_pab 的唯一区别是不加载 7B 模型（用一个 0.2s 的假策略替代），
以排除 GPU 因素，专注仿真侧。
"""
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.manifest import EpisodeSpec
from benchmark.policy.base import DummyPolicy
from benchmark.runner import EpisodeRunner, RunConfig
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]

T0 = time.time()


def log(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)
log("arena created")

runner = EpisodeRunner(
    reg,
    None,
    RunConfig(max_policy_queries=80, post_completion_probe_steps=15, save_video=True, num_open_loop_steps=8),
)
policy = DummyPolicy("noop")

video_dir = Path("/HUBU-AI004/zp/ICML/results/m1/probe_runner/videos")

for cond, seed in (("satisfied", 0), ("unsatisfied", 0), ("satisfied", 1), ("unsatisfied", 1)):
    es = EpisodeSpec(
        episode_id=f"{spec.id}__{cond}__s{seed:03d}",
        task_id=spec.id,
        suite=spec.suite,
        libero_task_id=spec.task_id,
        task_name=spec.task_name,
        condition=cond,
        seed=seed,
    )
    t0 = time.time()
    rec = runner.run_episode(arena, policy, es, video_dir=video_dir)
    log(
        f"{cond:12s} seed={seed} -> {time.time() - t0:6.1f}s  "
        f"success={rec.success} final_sat={rec.final_satisfied} "
        f"n_steps={rec.n_steps} queries={rec.n_policy_queries} "
        f"eef={rec.eef_max_displacement:.4f} err={rec.error[:60]}"
    )

arena.close()
log("done")
