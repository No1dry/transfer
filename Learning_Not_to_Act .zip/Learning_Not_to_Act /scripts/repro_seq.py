"""精确定位：同一个 arena 上先 satisfied 再 unsatisfied 构造，看卡在哪一步。

并且区分"冷缓存 reset"与"热缓存 reset"，以及候选搜索是否在循环。
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]

T0 = time.time()


def log(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)
log("arena created")

builder = StateBuilder(settle_steps=15)

# 先跑 satisfied（会 cold reset + 缓存）
t0 = time.time()
r1 = builder.build_state(arena, spec, "satisfied", 0)
log(f"satisfied seed0: ok={r1.ok} in {time.time() - t0:.1f}s attempts={len(r1.attempts)}")

# 紧接着 unsatisfied 同一个 seed（应该命中 reset 缓存）
t0 = time.time()
r2 = builder.build_state(arena, spec, "unsatisfied", 0)
log(f"unsatisfied seed0: ok={r2.ok} in {time.time() - t0:.1f}s attempts={len(r2.attempts)}")
for a in r2.attempts[:5]:
    log(f"    attempt: {a.as_dict()}")

# 再跑一个未被缓存过的 seed 的 satisfied（cold reset），然后该 seed 的 unsatisfied
t0 = time.time()
r3 = builder.build_state(arena, spec, "satisfied", 1)
log(f"satisfied seed1: ok={r3.ok} in {time.time() - t0:.1f}s attempts={len(r3.attempts)}")

t0 = time.time()
r4 = builder.build_state(arena, spec, "unsatisfied", 1)
log(f"unsatisfied seed1: ok={r4.ok} in {time.time() - t0:.1f}s attempts={len(r4.attempts)}")

arena.close()
log("done")
