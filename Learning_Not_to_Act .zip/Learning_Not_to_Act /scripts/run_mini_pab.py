#!/usr/bin/env python
"""Step 4-6 主入口：跑 Mini-PAB 160 episodes 并产出指标与报告。

**在 GPU 机器上跑**（需要 OpenVLA-OFT 权重）。

流程
----
    1. 载入 (或生成) manifest
    2. 对每条 episode: StateBuilder 造状态 -> 装上环境 -> policy 跑 -> 记录
    3. 汇总 UER / GDR / SR / Post-Completion Steps
    4. 生成 markdown 报告与 CSV

用法
----
    # 全量 160 episodes
    python scripts/run_mini_pab.py \
        --openvla_oft_root /path/to/openvla-oft \
        --checkpoint moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10

    # 先小规模试跑
    python scripts/run_mini_pab.py --openvla_oft_root ... --checkpoint ... --limit 8

    # 与官方 eval 完全一致（关闭 post-completion probe，此时 GDR 不可测）
    python scripts/run_mini_pab.py ... --probe_steps 0
"""

from __future__ import annotations

import argparse
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from benchmark.manifest import build_manifest  # noqa: E402
from benchmark.metrics import compute_all  # noqa: E402
from benchmark.report import render_report, write_metrics_json, write_summary_csv  # noqa: E402
from benchmark.runner import EpisodeRunner, RunConfig, load_records  # noqa: E402
from benchmark.states.builder import StateBuilder  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402


def _build_arena_factory(spec_lookup, args):
    """返回 ``spec -> Arena`` 的工厂，**每个 task 复用一个环境实例**。

    为什么必须复用（实测教训）
    -------------------------
    LIBERO 的 ``env.reset()`` 要重建整个场景，实测**冷启动 29.7s**、
    热启动约 8s（缓存命中后 2s）。最初每条 episode 都新建一个 arena，
    结果是每一次 reset 都是冷启动 —— 仅状态准备就 30s+/episode，
    160 个 episode 要一个多小时，而且中途看起来像"卡死"。

    复用后 ``LiberoArena._reset_cache`` 才有意义：同一 (task, seed) 的
    首次 reset 付冷启动成本，后续（另一 condition、重跑）几乎免费。

    关于 §65.2「无 reset artifact」：复用是**安全**的，因为每条 episode
    在构造状态前都会显式 reset 到官方初始状态，而 reset 走的是
    ``set_init_state``（含 num_steps_wait 空转），本身就会清掉上一条
    episode 的残留。此外 runner 不依赖 arena 的跨 episode 状态。
    """
    from benchmark.arena.libero import LiberoArena

    cache: dict[str, object] = {}

    def factory(episode_spec):
        key = episode_spec.task_id
        if key not in cache:
            task_spec = spec_lookup[key]
            cache[key] = LiberoArena(
                task_suite_name=task_spec.suite,
                task_id=task_spec.task_id,
                openvla_oft_root=args.openvla_oft_root,
                env_img_res=args.env_img_res,
                num_steps_wait=args.num_steps_wait,
                seed=0,
                subject=task_spec.subject,
                target=task_spec.target,
                joint_name=(task_spec.edit or {}).get("joint_name"),
                residual_kind=task_spec.residual_kind,
            )
        return cache[key]

    factory._arena_cache = cache  # type: ignore[attr-defined]
    return factory


def _build_policy(args):
    if args.policy == "dummy_noop":
        from benchmark.policy.base import DummyPolicy

        return DummyPolicy("noop")
    if args.policy == "dummy_push":
        from benchmark.policy.base import DummyPolicy

        return DummyPolicy("push")
    if args.policy == "dummy_scripted":
        from benchmark.policy.base import DummyPolicy

        return DummyPolicy("scripted")

    from benchmark.policy.base import OpenVLAOFTAdapter

    return OpenVLAOFTAdapter(
        openvla_oft_root=args.openvla_oft_root,
        checkpoint=args.checkpoint,
        unnorm_key=args.unnorm_key,
        num_images_in_input=args.num_images_in_input,
        use_proprio=not args.no_proprio,
        num_open_loop_steps=args.num_open_loop_steps,
        center_crop=not args.no_center_crop,
        lora_rank=args.lora_rank,
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--openvla_oft_root", default=None, help="openvla-oft 仓库根目录")
    p.add_argument("--checkpoint", default="moojink/openvla-7b-oft-finetuned-libero-spatial-object-goal-10")
    p.add_argument("--unnorm_key", default="libero_goal", help="动作反归一化 key")
    p.add_argument("--config", type=Path, default=None)
    p.add_argument("--manifest", type=Path, default=None, help="已有的 manifest；省略则现场生成")
    p.add_argument(
        "--policy",
        default="openvla",
        choices=["openvla", "dummy_noop", "dummy_push", "dummy_scripted"],
        help="dummy_* 用于在没有 GPU 的机器上验证 harness",
    )
    p.add_argument("--limit", type=int, default=None, help="只跑前 N 条（试跑用）")
    p.add_argument(
        "--only_conditions",
        default=None,
        help=(
            "只跑指定 condition，逗号分隔（例如 unsatisfied）。"
            "用于调整执行顺序：manifest 默认按 task->condition->seed 排序，"
            "而 unsatisfied 是验证「官方初始状态能否成功」的关键段，"
            "先跑它可以在更短时间内确认 harness 是否可信。"
        ),
    )
    p.add_argument("--seeds", type=int, default=None, help="覆盖 seeds 数量")
    p.add_argument("--probe_steps", type=int, default=15, help="post-completion probe 步数；0 = 与官方 eval 一致")
    p.add_argument(
        "--probe_steps_satisfied",
        type=int,
        default=None,
        help=(
            "satisfied 条件单独指定探针步数。实测量到夹爪开始闭合平均要 ~100-112 步，"
            "所以要看「会不会真的抓」需要 200+ 步。"
        ),
    )
    p.add_argument(
        "--probe_steps_unsatisfied",
        type=int,
        default=None,
        help="unsatisfied 条件单独指定探针步数（通常无需很长）",
    )
    p.add_argument("--max_policy_queries", type=int, default=80)
    p.add_argument("--num_open_loop_steps", type=int, default=8)
    p.add_argument("--num_images_in_input", type=int, default=2)
    p.add_argument("--lora_rank", type=int, default=32)
    p.add_argument("--no_proprio", action="store_true")
    p.add_argument("--no_center_crop", action="store_true")
    p.add_argument("--env_img_res", type=int, default=256)
    p.add_argument("--num_steps_wait", type=int, default=10)
    p.add_argument("--settle_steps", type=int, default=30)
    p.add_argument("--no_skip_existing", action="store_true", help="不跳过已有结果（重跑）")
    p.add_argument(
        "--redo_conditions",
        default=None,
        help=(
            "强制重跑指定 condition，逗号分隔（例如 unsatisfied）。"
            "用于给「已有结果但缺视频」的 episode 补录，不必重跑整轮。"
        ),
    )
    p.add_argument(
        "--save_video",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "录制任务视频。**默认开启** —— 跑 task 就应该留下能直接看的视频，"
            "否则事后只能看数字，没法判断现象真假。用 --no-save_video 关闭。"
        ),
    )
    p.add_argument(
        "--video_conditions",
        default=None,
        help="只录指定 condition，逗号分隔（例如 satisfied）。默认全部",
    )
    p.add_argument("--video_fps", type=int, default=20)
    p.add_argument("--run_name", default=None)
    args = p.parse_args(argv)

    if args.policy == "openvla" and not args.openvla_oft_root:
        p.error("--policy openvla 需要 --openvla_oft_root")

    registry = load_registry(args.config)
    spec_lookup = {s.id: s for s in registry}

    # --- manifest ---
    if args.manifest and args.manifest.is_file():
        from benchmark.manifest import Manifest

        manifest = Manifest.read(args.manifest)
        print(f"[manifest] 复用 {args.manifest}  ({len(manifest)} episodes, hash={manifest.content_hash[:16]})")
    else:
        policy = _build_policy(args) if args.policy.startswith("dummy") else None
        model_name = getattr(policy, "name", None) or Path(args.checkpoint).name
        manifest = build_manifest(
            registry,
            model_name=model_name,
            seeds=list(range(args.seeds)) if args.seeds else None,
        )
        print(f"[manifest] 现场生成  ({len(manifest)} episodes, hash={manifest.content_hash[:16]})")

    # 条件过滤：调整实际执行顺序（不改变 manifest 内容与 hash）
    if args.only_conditions:
        wanted = {x.strip() for x in args.only_conditions.split(",") if x.strip()}
        before = len(manifest.episodes)
        manifest.episodes = [e for e in manifest.episodes if e.condition in wanted]
        print(f"[filter] only_conditions={sorted(wanted)}: {before} -> {len(manifest.episodes)} episodes")

    # --- run 目录（§63：不得覆盖旧结果）---
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    run_name = args.run_name or f"{stamp}_{manifest.model_name}_mini_pab"
    run_dir = REPO_ROOT / "results" / "m1" / run_name
    if run_dir.exists() and not args.no_skip_existing:
        existing = list(run_dir.glob("*.json"))
        if existing:
            print(f"[run] 目录已存在且有 {len(existing)} 个结果，将跳过已完成的 episode")
    run_dir.mkdir(parents=True, exist_ok=True)
    manifest.write(run_dir / "manifest.json")

    # --- 跑 ---
    policy = _build_policy(args)
    runner = EpisodeRunner(
        registry,
        StateBuilder(settle_steps=args.settle_steps),
        RunConfig(
            max_policy_queries=args.max_policy_queries,
            num_steps_wait=args.num_steps_wait,
            num_open_loop_steps=args.num_open_loop_steps,
            post_completion_probe_steps=args.probe_steps,
            post_completion_probe_steps_by_condition={
                k: v
                for k, v in (
                    ("satisfied", args.probe_steps_satisfied),
                    ("unsatisfied", args.probe_steps_unsatisfied),
                )
                if v is not None
            }
            or None,
            save_video=args.save_video,
            save_video_conditions=(
                tuple(x.strip() for x in args.video_conditions.split(",") if x.strip())
                if args.video_conditions
                else None
            ),
            video_fps=args.video_fps,
        ),
    )

    import time as _time

    _ep_t0 = {"t": _time.time()}

    def _mark_start(i, n, spec):
        """在每条 episode **开始**时打一行，便于判断当前在跑哪一条。

        没有这个标记时，日志只在 episode 结束时刷新；一条 unsatisfied
        episode 可能跑 1~2 分钟，看起来就像卡住了（排查过程中确实被误导过）。
        """
        _ep_t0["t"] = _time.time()
        print(f"[{i:3d}/{n:3d}] ...  {spec.episode_id}  (started)", flush=True)

    def progress(i, n, spec, rec):
        flag = "OK " if rec.success else "   "
        err = f"  ERR={rec.error[:60]}" if rec.error else ""
        print(
            f"[{i:3d}/{n:3d}] {flag} {spec.episode_id:42s} "
            f"final_sat={str(rec.final_satisfied):5s} eef={rec.eef_max_displacement:.4f} "
            f"gdr_ok={str(rec.init_satisfied and not rec.final_satisfied):5s}{err}"
        )

    if args.redo_conditions:
        print(
            "[redo] 注意：现在不需要手工删结果来补录视频。"
            "runner 会检测「结果存在但缺视频」并自动重跑那些 episode。"
        )

    _factory = _build_arena_factory(spec_lookup, args)

    print()
    try:
        records = runner.run_manifest(
            manifest,
            policy,
            _factory,
            out_dir=run_dir,
            limit=args.limit,
            skip_existing=not args.no_skip_existing,
            progress_callback=progress,
            start_callback=_mark_start,
            close_arena=False,
        )
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        print("[error] 运行中断；已完成的 episode 结果仍保留在 run 目录中，可重跑续做")
        return 2

    # --- 关闭复用中的环境（factory 里缓存了每个 task 一个实例）---
    for _a in getattr(_factory, "_arena_cache", {}).values():
        try:
            _a.close()  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    # --- 汇总 ---
    records = load_records(run_dir)
    metrics = compute_all(records)
    write_metrics_json(metrics, run_dir / "metrics.json")
    write_summary_csv(records, REPO_ROOT / "results" / "m1" / "mini_pab_summary.csv")

    # 执行方案 §13 要求的 episode 级原始记录（一份 JSON 汇总，便于二次分析）
    import json as _json

    raw_path = REPO_ROOT / "results" / "m1" / "mini_pab_raw.json"
    raw_path.write_text(
        _json.dumps(
            {
                "benchmark_version": manifest.benchmark_version,
                "model_name": manifest.model_name,
                "manifest_content_hash": manifest.content_hash,
                "run_dir": str(run_dir),
                "n_records": len(records),
                "metrics": metrics,
                "episodes": [r.as_dict() for r in records],
            },
            indent=2,
            ensure_ascii=False,
            default=str,
        )
        + "\n",
        encoding="utf-8",
    )

    notes = list(getattr(args, "_notes", []) or [])
    if args.probe_steps <= 0:
        notes.append(
            "post_completion_probe_steps=0：与官方 eval 一致，任务达成即终止，"
            "因此 GDR 与 Post-Completion Steps **不可测**（不是 0，是没测）。"
        )
    text = render_report(records, manifest=manifest, model_name=manifest.model_name, extra_notes=notes)
    report_path = REPO_ROOT / "reports" / f"m1_w1_sanity_{run_name}.md"
    from benchmark.report import write_report

    write_report(text, report_path)

    print()
    print("=" * 74)
    print(f"记录数         : {metrics['n_records']} (可用 {metrics['n_usable']}, 剔除 {metrics['n_dropped']})")
    print(f"UER            : {metrics['uer']['value']:.4f}  (n={metrics['uer']['n']})")
    print(f"GDR            : {metrics['gdr']['value']:.4f}  (n={metrics['gdr']['n']})")
    print(f"SR (satisfied) : {metrics['success_rate_satisfied']['value']:.4f}")
    print(f"SR (unsatisfied): {metrics['success_rate_unsatisfied']['value']:.4f}")
    print()
    print(f"[ok] run 目录   : {run_dir}")
    print(f"[ok] metrics    : {run_dir / 'metrics.json'}")
    print(f"[ok] 报告       : {report_path}")
    print(f"[ok] CSV        : {REPO_ROOT / 'results' / 'm1' / 'mini_pab_summary.csv'}")
    print(f"[ok] raw json   : {raw_path}")
    if args.save_video:
        n_vid = len(list((run_dir / "videos").glob("*.*"))) if (run_dir / "videos").is_dir() else 0
        print(f"[ok] 视频       : {run_dir / 'videos'}  ({n_vid} 个)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
