import sys
from pathlib import Path
sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry
reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_stove"]
b = StateBuilder(settle_steps=12)
arena = LiberoArena(task_suite_name=spec.suite, task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject, target=spec.target, residual_kind=spec.residual_kind)
import numpy as np
print("target anchor =", np.round(arena._body_pos(spec.target), 4).tolist(), flush=True)
for seed in range(4):
    r = b.build_state(arena, spec, "satisfied", seed)
    print(f"seed={seed} ok={r.ok} attempts={len(r.attempts)} residual={r.residual_after_build:.4f}", flush=True)
    if r.ok:
        last = r.attempts[-1]
        print("     ", last.note, flush=True)
arena.close()
