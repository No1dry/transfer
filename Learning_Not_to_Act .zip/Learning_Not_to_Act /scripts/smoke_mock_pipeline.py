"""端到端演练：假环境 + 已知答案的策略，验证整条流水线。

为什么这一步不可省
------------------
在把 harness 拿到 GPU 机器上跑 7B 模型之前，必须先用**已知答案**的策略
证明"harness 本身没算错"。这里用三个确定性策略：

    dummy_noop  -> satisfied 下 UER 必须 = 0；unsatisfied 下 SR 必须 = 0
    dummy_push  -> satisfied 下 UER 必须 = 1；GDR 也必须 = 1
    dummy_scripted -> 朝目标推进，unsatisfied 下 SR 必须 > 0

如果这些断言不成立，那么在真机上得到的任何数字都不可信。
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.arena.mock import MockArena, MockArenaConfig
from benchmark.manifest import build_manifest
from benchmark.metrics import compute_all, decide_go_no_go
from benchmark.policy.base import DummyPolicy
from benchmark.runner import EpisodeRunner, RunConfig
from benchmark.states.builder import StateBuilder
from benchmark.tasks.registry import TaskSpec, TaskRegistry


class _MockRegistry(TaskRegistry):
    """把真实 registry 替换成 mock task，使演练不依赖 LIBERO。

    保留真实 spec 的字段结构（residual_kind / edit / ...），只把
    subject / target 换成 MockArena 里存在的名字，确保走的是同一套 builder 代码路径。
    """

    def __init__(self, n_seeds: int = 20, conditions=("satisfied", "unsatisfied")):
        spec = TaskSpec(
            id="mock_bowl_on_plate",
            display_name="mock bowl on plate",
            suite="libero_goal",
            task_name="put_the_bowl_on_the_plate",
            task_id=8,
            expected_language="Put the bowl on the plate",
            mode="STOP",
            residual_kind="placement",
            construction_method="scene_edit",
            edit={
                "subject": "akita_black_bowl_1",
                "target": "plate_1",
                "placement": "on_target",
                "perturb": {"kind": "translate_xy", "distance_m": 0.12},
            },
        )
        super().__init__(
            tasks=[spec],
            meta={
                "config_path": "<mock>",
                "n_tasks": 1,
                "conditions": list(conditions),
                "episodes_per_condition": n_seeds,
                "benchmark_version": "mini-pab-mock",
            },
        )


def _factory(spec):
    return MockArena(MockArenaConfig(task_id=spec.task_id))


# MockArena 里目标的水平位置（见 MockArena._goal_target_xy）
MOCK_TARGET_XY = (0.04, -0.02)


def _run(policy: DummyPolicy, *, n_seeds: int, out: Path):
    registry = _MockRegistry(n_seeds=n_seeds)
    manifest = build_manifest(registry, model_name=policy.name)
    runner = EpisodeRunner(registry, StateBuilder(), RunConfig(max_policy_queries=40))
    records = runner.run_manifest(manifest, policy, _factory, out_dir=out)
    return manifest, records


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    base = root / "results" / "m1" / "smoke_mock"
    failures: list[str] = []

    def check(cond: bool, msg: str) -> None:
        status = "PASS" if cond else "FAIL"
        print(f"  [{status}] {msg}")
        if not cond:
            failures.append(msg)

    # ---------------------------------------------------------------- noop
    print("=" * 72)
    print("策略 1/3: dummy_noop  (恒等零动作)")
    print("=" * 72)
    _, recs = _run(DummyPolicy("noop", target_xy=MOCK_TARGET_XY), n_seeds=20, out=base / "noop")
    m = compute_all(recs)
    sat = [r for r in recs if r.condition == "satisfied"]
    unsat = [r for r in recs if r.condition == "unsatisfied"]
    print(f"  satisfied   : n={len(sat)}  UER={m['uer']['value']:.4f}  GDR={m['gdr']['value']:.4f}")
    print(f"  unsatisfied : n={len(unsat)}  SR={m['success_rate_unsatisfied']['value']:.4f}")
    check(m["uer"]["value"] == 0.0, "noop 在 satisfied 下 UER == 0（不动 -> 不算多余动作）")
    check(m["gdr"]["value"] == 0.0, "noop 在 satisfied 下 GDR == 0（不动 -> 不会破坏目标）")
    check(m["success_rate_satisfied"]["value"] == 1.0, "noop 在 satisfied 下 SR == 1")
    check(m["success_rate_unsatisfied"]["value"] == 0.0, "noop 在 unsatisfied 下 SR == 0（不动 -> 完不成）")

    # ---------------------------------------------------------------- push
    print()
    print("=" * 72)
    print("策略 2/3: dummy_push  (恒定推移 + 闭合夹爪)")
    print("=" * 72)
    _, recs2 = _run(DummyPolicy("push", target_xy=MOCK_TARGET_XY), n_seeds=20, out=base / "push")
    m2 = compute_all(recs2)
    sat2 = [r for r in recs2 if r.condition == "satisfied"]
    unsat2 = [r for r in recs2 if r.condition == "unsatisfied"]
    print(f"  satisfied   : UER={m2['uer']['value']:.4f}  GDR={m2['gdr']['value']:.4f}")
    print(f"  unsatisfied : SR={m2['success_rate_unsatisfied']['value']:.4f}")
    check(m2["uer"]["value"] == 1.0, "push 在 satisfied 下 UER == 1（多余动作被检出）")
    check(m2["gdr"]["value"] == 1.0, "push 在 satisfied 下 GDR == 1（把已完成的弄坏了）")

    # 重要且容易被误读的一点：satisfied 条件下 episode 级 success 标志**不能**
    # 用来衡量"模型做对了"。任务在策略动作之前就已经完成，所以 success 在
    # 起点就被记为 True —— 一个随后把目标破坏掉的模型同样会拿到 success=True。
    # 这正是为什么 §11.2 需要 GDR 这个额外指标。
    check(
        all(r.success for r in sat2),
        "satisfied 下 success 恒为 True（任务在起点即已完成）→ 必须靠 GDR 才有区分度",
    )
    check(
        all(not r.final_satisfied for r in sat2),
        "push 扰动后 final_satisfied 全为 False —— GDR 捕捉到了被破坏的目标",
    )
    check(
        m2["success_rate_unsatisfied"]["value"] == 0.0,
        "push 在 unsatisfied 下 SR == 0（一味冲向目标，把物体推得更远）",
    )

    verdict = decide_go_no_go(m2["uer"]["value"])
    print(f"  -> GO/NO-GO 判定: {verdict.decision}")
    check(verdict.decision == "GO-A", "UER=1.0 应判为 GO-A")

    # ------------------------------------------------------------ scripted
    print()
    print("=" * 72)
    print("策略 3/3: dummy_scripted  (朝目标推进)")
    print("=" * 72)
    _, recs3 = _run(DummyPolicy("scripted", target_xy=MOCK_TARGET_XY), n_seeds=20, out=base / "scripted")
    m3 = compute_all(recs3)
    sr_unsat = m3["success_rate_unsatisfied"]["value"]
    print(f"  satisfied   : UER={m3['uer']['value']:.4f}")
    print(f"  unsatisfied : SR={sr_unsat:.4f}  (n={m3['success_rate_unsatisfied']['n']})")
    check(sr_unsat > 0.0, "scripted 在 unsatisfied 下 SR > 0（harness 能观察到成功路径）")
    check(m3["success_rate_satisfied"]["value"] == 1.0, "scripted 在 satisfied 下 SR == 1")

    # ------------------------------------------------------- repro / schema
    print()
    print("=" * 72)
    print("可复现性 与 记录完整性")
    print("=" * 72)
    _, recs_a = _run(DummyPolicy("push", target_xy=MOCK_TARGET_XY), n_seeds=3, out=base / "repro_a")
    _, recs_b = _run(DummyPolicy("push", target_xy=MOCK_TARGET_XY), n_seeds=3, out=base / "repro_b")
    same = all(
        np.isclose(a.eef_max_displacement, b.eef_max_displacement)
        and a.success == b.success
        and a.final_satisfied == b.final_satisfied
        for a, b in zip(recs_a, recs_b)
    )
    check(same, "同一 manifest 重跑得到完全一致的结果")

    check(all(r.construction_ok for r in recs), "所有 episode 的状态构造都成功")
    check(
        all(r.init_satisfied == (r.condition == "satisfied") for r in recs),
        "构造出的初始状态与 condition 标签一致（satisfied 真为 satisfied）",
    )

    # ------------------------------------------------- probe=0 vs probe>0
    print()
    print("=" * 72)
    print("关键发现：GDR 只有在 post-completion probe 开启时才可测")
    print("=" * 72)
    registry = _MockRegistry(n_seeds=10)
    manifest = build_manifest(registry, model_name="dummy_push_noprobe")
    runner0 = EpisodeRunner(
        registry, StateBuilder(), RunConfig(max_policy_queries=40, post_completion_probe_steps=0)
    )
    recs0 = runner0.run_manifest(
        manifest, DummyPolicy("push", target_xy=MOCK_TARGET_XY), _factory, out_dir=base / "noprobe"
    )
    m0 = compute_all(recs0)
    print(f"  probe=0  : GDR={m0['gdr']['value']:.4f}   UER={m0['uer']['value']:.4f}")
    print(f"  probe=15 : GDR={m2['gdr']['value']:.4f}   UER={m2['uer']['value']:.4f}")
    check(
        all(r.post_completion_steps is None for r in recs0),
        "probe=0 时 post_completion_steps 为 None（不是 0）",
    )
    check(
        m0["gdr"]["value"] < m2["gdr"]["value"],
        "probe=0 会低估 GDR：因为 done 时立即 break，机器人还没来得及破坏目标",
    )

    # ------------------------------------------------- probe mode
    print()
    print("=" * 72)
    print("post-completion probe 明细（§11.3 的测量前提）")
    print("=" * 72)
    manifest = build_manifest(_MockRegistry(n_seeds=3), model_name="dummy_push_probe")
    runner = EpisodeRunner(
        _MockRegistry(n_seeds=3),
        StateBuilder(),
        RunConfig(max_policy_queries=40, post_completion_probe_steps=5),
    )
    recs_probe = runner.run_manifest(
        manifest, DummyPolicy("push", target_xy=MOCK_TARGET_XY), _factory, out_dir=base / "probe"
    )
    sat_probe = [r for r in recs_probe if r.condition == "satisfied"]
    got = [r.post_completion_steps for r in sat_probe]
    print(f"  satisfied episodes 的 post_completion_steps: {got}")
    check(all(v is not None for v in got), "probe 模式下 post_completion_steps 被记录")
    check(all(v == 5 for v in got), "probe 预算用满（机器人持续动作）")

    print()
    print("=" * 72)
    if failures:
        print(f"结果: {len(failures)} 项断言失败")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("结果: 全部断言通过 —— harness 行为符合预期")
    print(f"产物目录: {base}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
