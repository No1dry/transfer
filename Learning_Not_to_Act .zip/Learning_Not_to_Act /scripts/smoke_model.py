"""冒烟测试：确认 OpenVLA-OFT checkpoint 能加载并产出 7 维 action chunk。

只跑一次前向，用来在正式跑 160 episode 之前排除权重/配置问题。
"""
import sys
import time

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"

arena = LiberoArena(
    task_suite_name="libero_goal",
    task_id=8,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject="akita_black_bowl_1",
    target="plate_1",
    residual_kind="placement",
)
arena.reset(official_init_index=0)
obs = arena.get_observation()
print(f"[smoke] obs: full={obs.full_image.shape} wrist={obs.wrist_image.shape} state={obs.state.shape}", flush=True)

t0 = time.time()
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key="libero_goal",
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=8,
)
actions = policy.predict(obs, arena.task_language)
print(f"[smoke] load+forward: {time.time() - t0:.1f}s", flush=True)
print(f"[smoke] action chunk shape: {np.asarray(actions).shape}", flush=True)
print(f"[smoke] actions[0]: {np.round(np.asarray(actions)[0], 5)}", flush=True)

# 再测一次纯推理耗时
t0 = time.time()
for _ in range(3):
    policy.predict(obs, arena.task_language)
dt = (time.time() - t0) / 3
print(f"[smoke] steady-state policy query: {dt * 1000:.0f} ms", flush=True)

arena.close()
print("[smoke] OK", flush=True)
