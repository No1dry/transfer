import glob
import json
import statistics as st
from collections import defaultdict

rows = [json.load(open(f)) for f in glob.glob("results/m1/final/openvla*.json")]
g = defaultdict(list)
for r in rows:
    g[(r["task_id"], r["condition"])].append(r)

hdr = "{:20s} {:12s} {:>3s} {:>6s} {:>9s} {:>8s} {:>8s}"
print(hdr.format("task", "cond", "n", "SR", "obj中位", "步数中位", "首次闭合"))
for k in sorted(g):
    pool = g[k]
    sr = sum(1 for r in pool if r["success"]) / len(pool)
    obj = st.median([r["object_max_displacement"] for r in pool])
    stp = st.median([r["n_steps"] for r in pool])
    fc = [(r.get("extra") or {}).get("gripper_action", {}).get("first_close_step") for r in pool]
    fc = [v for v in fc if v is not None]
    fcs = str(int(st.median(fc))) if fc else "-"
    print(hdr.format(k[0], k[1], str(len(pool)), "{:.2f}".format(sr),
                     "{:.4f}".format(obj), "{:.0f}".format(stp), fcs))
