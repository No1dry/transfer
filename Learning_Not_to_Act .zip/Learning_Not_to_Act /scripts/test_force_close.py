"""P0：success 之后，系统是否仍然允许夹爪真正闭合？

为什么必须先做这个
------------------
主实验的 `0/80 真抓到`、对照 A 的 `UER=60%`，都建立在同一个前提上：

    "夹爪能正常闭合，只是模型没让它闭合"

但这个前提**从未被验证过**。我们的 runner 为了在 success 后继续观察，
会清掉 `env.done`（`set_allow_after_done`）。如果有人以为"清 done 就够了"，
而 robosuite / controller 层另有 gating，那么"satisfied 下不闭夹爪"
就可能是**系统行为**而不是 policy 行为 —— 所有相关结论都要作废。

做法
----
在 NOT satisfied / satisfied（含 success 后）三种情形下，绕过 VLA，
**人工送入一个确定的 close 指令**，看手指关节是否真的动。

判定
----
* 三种情形下手指都能闭合  -> 无 gating，原结论可信
* 只有 success 后闭不上    -> 存在 gating，satisfied 的结论必须重做
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter
from benchmark.tasks import load_registry

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"
reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg["bowl_on_plate"]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    residual_kind=spec.residual_kind,
)


def finger_qpos(arena):
    """读手指关节位置（两个手指）。"""
    try:
        g = np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=float)
        return g.copy()
    except Exception:  # noqa: BLE001
        return None


def force_close(arena, n_steps=25, close_value=+1.0):
    """人工送 close 指令若干步，返回 (起始手指, 结束手指, 变化量)。"""
    a = np.zeros(7)
    a[-1] = close_value
    g0 = finger_qpos(arena)
    for _ in range(n_steps):
        arena.step(a.tolist())
    g1 = finger_qpos(arena)
    if g0 is None or g1 is None:
        return None, None, float("nan")
    return g0, g1, float(np.linalg.norm(g1 - g0))


print("=" * 78)
print("场景 1：NOT satisfied（官方初始状态，未成功）")
print("=" * 78)
arena.reset(official_init_index=0)
print(f"  goal_satisfied = {arena.goal_satisfied()}")
g0, g1, d = force_close(arena)
print(f"  送 close 前手指 = {np.round(g0,4).tolist()}")
print(f"  送 close 后手指 = {np.round(g1,4).tolist()}")
print(f"  手指变化量      = {d:.4f}")
print(f"  -> 夹爪{'能' if d > 0.01 else '不能'}闭合", flush=True)

print()
print("=" * 78)
print("场景 2：satisfied（场景编辑版：碗已在盘上）")
print("=" * 78)
from benchmark.states.builder import StateBuilder

b = StateBuilder(settle_steps=15)
r = b.build_state(arena, spec, "satisfied", 0)
arena.set_state(r.state, settle_steps=0)
arena.mark_episode_start()
print(f"  goal_satisfied = {arena.goal_satisfied()}")
# 先走一步让 env.done 有机会被置上
arena.set_allow_after_done(True)
arena.step(arena.no_op_action())
print(f"  走一步后 env.done = {getattr(arena._env, 'done', None)}  (allow_after_done=True)")
g0, g1, d = force_close(arena)
print(f"  送 close 前手指 = {np.round(g0,4).tolist()}")
print(f"  送 close 后手指 = {np.round(g1,4).tolist()}")
print(f"  手指变化量      = {d:.4f}")
print(f"  -> 夹爪{'能' if d > 0.01 else '不能'}闭合", flush=True)

print()
print("=" * 78)
print("场景 3：让模型自己成功，然后在 success 之后送 close")
print("=" * 78)
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key=spec.suite,
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=8,
)
arena.reset(official_init_index=0)
policy.reset()
q = []
steps = 0
success = False
while steps < 320 and not success:
    if not q:
        obs = arena.get_observation()
        c = np.asarray(policy.predict(obs, arena.task_language), dtype=float)
        if c.ndim == 1:
            c = c.reshape(1, -1)
        q.extend(list(c[:8]))
    arena.step(q.pop(0).tolist())
    steps += 1
    if arena.goal_satisfied():
        success = True

print(f"  模型成功 = {success}（用了 {steps} 步）")
print(f"  env.done = {getattr(arena._env, 'done', None)}")
print(f"  goal_satisfied = {arena.goal_satisfied()}")
arena.set_allow_after_done(True)
# 先打开夹爪（确认双向都能动），再闭合
g0, g1, d_open = force_close(arena, n_steps=20, close_value=-1.0)
print(f"  送 OPEN  : {np.round(g0,4).tolist()} -> {np.round(g1,4).tolist()}  变化 {d_open:.4f}")
g2, g3, d_close = force_close(arena, n_steps=25, close_value=+1.0)
print(f"  送 CLOSE : {np.round(g2,4).tolist()} -> {np.round(g3,4).tolist()}  变化 {d_close:.4f}")
print(f"  -> success 后夹爪{'能' if d_close > 0.01 else '不能'}闭合", flush=True)

arena.close()
print("\n[done]", flush=True)
