"""测量单次状态构造的耗时（定位校验为何慢）。"""
import sys
import time

sys.path.insert(0, "/HUBU-AI004/zp/ICML")
from pathlib import Path

from benchmark.arena.libero import LiberoArena
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
builder = StateBuilder(settle_steps=15)

for tid in ("bowl_on_plate", "object_in_basket"):
    spec = reg[tid]
    t0 = time.time()
    arena = LiberoArena(
        task_suite_name=spec.suite,
        task_id=spec.task_id,
        openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
        subject=spec.subject,
        target=spec.target,
        joint_name=(spec.edit or {}).get("joint_name"),
        residual_kind=spec.residual_kind,
    )
    print(f"[timing] {tid}: arena create {time.time() - t0:.1f}s", flush=True)

    for cond in ("satisfied", "unsatisfied"):
        for seed in (0, 1):
            t0 = time.time()
            r = builder.build_state(arena, spec, cond, seed)
            dt = time.time() - t0
            n_att = len(r.attempts)
            print(
                f"[timing] {tid:20s} {cond:12s} seed={seed} ok={r.ok} "
                f"{dt:6.1f}s  attempts={n_att}  residual={r.residual_after_build:.4f}",
                flush=True,
            )
    arena.close()
print("[timing] done", flush=True)
