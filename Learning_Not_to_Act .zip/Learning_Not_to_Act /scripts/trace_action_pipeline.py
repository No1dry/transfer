"""Experiment A: Action Causality Trace

目的
----
排除一个系统级替代解释：

> "机械臂到 bowl 附近不闭合夹爪，不是模型不想抓，而是 success 之后
>  runner / controller / environment 阻止了夹爪动作。"

必须能把整条链路分清：

    Model(raw) -> Postprocess(processed) -> Controller(ctrl) -> Physics(finger_qpos)

要记录的四种情况（文档 §5.4）
-----------------------------
Case A  raw=OPEN,  processed=OPEN                  -> 模型自己没产生 grasp decision（policy-side）
Case B  raw=CLOSE, processed=OPEN                  -> postprocess bug，结论作废
Case C  processed=CLOSE, actuator=OPEN             -> 存在 system-level gating
Case D  processed=CLOSE, actuator=CLOSE, 手指不动  -> controller / contact / physics

符号约定
--------
* 模型**原始**输出：0 = close, 1 = open（官方 dataloader 的约定）
* 后处理**送环境**的值：-1 = open, +1 = close

用法
----
    ./run_diag.sh scripts/trace_action_pipeline.py <task> <n_episodes> [conds] [--video]

    conds 逗号分隔，默认 satisfied。跑 satisfied,unsatisfied 时模型只加载一次：
        ./run_diag.sh scripts/trace_action_pipeline.py bowl_on_plate 3 satisfied,unsatisfied --video

加 --video 会录 mp4 到 results/mechanism/action_trace/videos/，画面顶部叠加
"目标是否已达成 / 到碗距离 / eef 高出碗多少 / 模型原始合爪意图 / 手指开度"。
这一步很关键：**光看数字看不出"悬停空合爪"，画面一眼就能看出来**。
"""
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/HUBU-AI004/zp/ICML")

from benchmark.arena.libero import LiberoArena
from benchmark.policy.base import OpenVLAOFTAdapter
from benchmark.states.builder import StateBuilder
from benchmark.tasks import load_registry

CKPT = "/HUBU-AI004/zp/ICML/checkpoints/openvla-7b-oft-libero-sog10"
TASK = sys.argv[1] if len(sys.argv) > 1 else "bowl_on_plate"
N_EP = int(sys.argv[2]) if len(sys.argv) > 2 else 6
# 条件：satisfied（目标已达成）/ unsatisfied（官方初始状态，需真正执行）
# 两者的对照是 Experiment A 的校准：unsatisfied 是"成功抓取"的参考轨迹。
# 支持一次跑多个条件（模型只加载一次）: "satisfied,unsatisfied"
CONDS = (sys.argv[3] if len(sys.argv) > 3 else "satisfied").split(",")
VIDEO = "--video" in sys.argv

NUM_CHUNK = 8
PROBE = 300
NEAR = 0.05   # "接近物体"的判据 5cm

OUT = Path("/HUBU-AI004/zp/ICML/results/mechanism/action_trace")
OUT.mkdir(parents=True, exist_ok=True)
VIDEODIR = OUT / "videos"
VIDEODIR.mkdir(parents=True, exist_ok=True)

reg = load_registry(Path("/HUBU-AI004/zp/ICML/configs/mini_pab.yaml"))
spec = reg[TASK]

arena = LiberoArena(
    task_suite_name=spec.suite,
    task_id=spec.task_id,
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    subject=spec.subject,
    target=spec.target,
    joint_name=(spec.edit or {}).get("joint_name"),
    residual_kind=spec.residual_kind,
)
policy = OpenVLAOFTAdapter(
    openvla_oft_root="/HUBU-AI004/lgm/openvla-oft",
    checkpoint=CKPT,
    unnorm_key=spec.suite,
    num_images_in_input=2,
    use_proprio=True,
    num_open_loop_steps=NUM_CHUNK,
)
builder = StateBuilder(settle_steps=15)


def eef_xyz(arena):
    """**官方 eef**（= ``gripper0_grip_site``，两指之间的抓取点）。

    必须用这个，不能用手腕 body ``robot0_right_hand``：两者竖直方向差
    **0.097 m**（见 ``scripts/check_eef_reference.py``）。第一版就是用了
    ``robot0_right_hand``，于是算出"satisfied 下机械臂悬在碗上方 10cm
    从不下降"——这 10cm 几乎正好是手腕到指尖的偏移，结论完全是假的。
    unsatisfied（成功抓取）算出来"同样悬空 11-13cm"才暴露了它：
    成功的 episode 不可能够不着碗。
    """
    return np.asarray(arena._last_obs_raw["robot0_eef_pos"], dtype=float)


def wrist_xyz(arena):
    """手腕 body 位置，仅作对照记录（就是差 0.097m 的那个参考点）。"""
    try:
        return np.asarray(
            arena._env.sim.data.get_body_xpos("robot0_right_hand"), dtype=float
        )
    except Exception:  # noqa: BLE001
        return np.full(3, np.nan)


def obj_xyz(arena):
    try:
        return arena.entity_pos(spec.subject)
    except Exception:  # noqa: BLE001
        return np.full(3, np.nan)


def finger_qpos(arena):
    try:
        return np.asarray(arena._last_obs_raw["robot0_gripper_qpos"], dtype=float)
    except Exception:  # noqa: BLE001
        return np.full(2, np.nan)


def gripper_ctrl(arena):
    """夹爪执行器当前控制量（controller 层）。取夹爪 actuator 的 ctrl 值。"""
    try:
        sim = arena._env.sim
        ctrl = np.asarray(sim.data.ctrl, dtype=float)
        names = list(getattr(sim.model, "actuator_names", None) or [])
        idx = [i for i, n in enumerate(names) if "gripper" in n.lower()]
        if idx:
            return ctrl[idx]
        return ctrl[-2:]
    except Exception:  # noqa: BLE001
        return np.full(2, np.nan)


# ---------------------------------------------------------------------------
# 视频叠加：把"模型此刻在想什么"直接画在画面角上，避免只看画面靠猜
# ---------------------------------------------------------------------------
_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSansMono.ttf",
]


def _load_font(size=15):
    """服务器上没有中文字体（只有 DejaVu/Liberation），所以叠加文字必须用 ASCII。

    否则中文会渲染成豆腐块 ▯▯▯，录像就没法看了。
    """
    from PIL import ImageFont

    for p in _FONT_CANDIDATES:
        try:
            return ImageFont.truetype(p, size)
        except Exception:  # noqa: BLE001
            continue
    return ImageFont.load_default()


_FONT = None
FONT_SIZE = 11
_MIN_FONT_SIZE = 8
_PAD = 4
_FONT_CACHE: dict = {}


def _font(size):
    """按字号取字体（带缓存）。"""
    if size not in _FONT_CACHE:
        _FONT_CACHE[size] = _load_font(size)
    return _FONT_CACHE[size]


def draw_overlay(frame, lines, banner=None, banner_color=(170, 0, 0)):
    """在画面顶部叠加 ASCII 文本。

    会**自动选一个所有行都放得下的字号**（从 FONT_SIZE 往下试）。
    这一点很关键：之前因为字号写死成 15，256px 的画面把 "dz +0.154" 和
    横幅后半句整个截掉了 —— 数字被截掉比没画还危险，会让人误读。
    失败时原样返回，绝不让录像把实验搞挂。
    """
    try:
        from PIL import Image, ImageDraw

        img = Image.fromarray(frame).convert("RGB")
        dr = ImageDraw.Draw(img)
        W = img.size[0]
        max_w = W - 2 * _PAD
        texts = list(lines) + ([banner] if banner else [])

        # 逐级缩小字号，直到最长的一行也放得下
        font, size = _font(FONT_SIZE), FONT_SIZE
        for size in range(FONT_SIZE, _MIN_FONT_SIZE - 1, -1):
            font = _font(size)
            widest = max(dr.textbbox((0, 0), t, font=font)[2] for t in texts)
            if widest <= max_w:
                break

        lh = size + 4
        box_h = lh * len(lines) + _PAD
        dr.rectangle([0, 0, W, box_h], fill=(0, 0, 0))
        for i, t in enumerate(lines):
            dr.text((_PAD, _PAD + i * lh), t, fill=(255, 255, 255), font=font)
        if banner:
            dr.rectangle([0, box_h, W, box_h + lh + 4], fill=banner_color)
            dr.text((_PAD, box_h + 3), banner[:80], fill=(255, 255, 255), font=font)
        return np.asarray(img)
    except Exception:  # noqa: BLE001
        return frame


def save_video(frames, path, fps=20):
    """写 mp4；失败退回 gif。录像是证据，不能因为它让实验失败。"""
    import imageio.v2 as imageio

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with imageio.get_writer(path, fps=fps, macro_block_size=1) as w:
            for f in frames:
                w.append_data(f)
        return path
    except Exception:  # noqa: BLE001
        try:
            gif = path.with_suffix(".gif")
            imageio.mimsave(gif, frames, fps=fps)
            return gif
        except Exception:  # noqa: BLE001
            return None


def classify(seq):
    """四类判定：pipeline 哪一层把合爪命令吃掉了。

    A 模型自己没产生合爪决策 / B 后处理丢了 / C 执行器没收到 / D 手指没动。
    返回 OK 说明"命令合 -> 手指确实合"，即本层无 gating。
    """
    if not seq:
        return "n/a"
    raw_close = sum(1 for x in seq if x["raw_gripper"] < 0.5)
    proc_close = sum(1 for x in seq if x["processed_gripper"] > 0.5)
    ctrl_close = sum(1 for x in seq if not np.isnan(x["ctrl_g0"]) and x["ctrl_g0"] > 0.0)
    fq = [x["finger_l"] for x in seq if not np.isnan(x["finger_l"])]
    fq_span = (max(fq) - min(fq)) if len(fq) > 1 else 0.0
    if proc_close == 0:
        return "A: raw&processed 都不合 -> policy-side（模型没产生 grasp 决策）"
    if raw_close == 0 and proc_close > 0:
        return "B: raw 不合但 processed 合 -> postprocess 有问题"
    if proc_close > 0 and ctrl_close == 0:
        return "C: processed 合但 actuator 没合 -> system-level gating"
    if proc_close > 0 and fq_span < 0.005:
        return "D: actuator 合但手指不动 -> controller/contact/physics"
    return "OK: 命令合且手指确实动了"


def run_condition(cond, n_ep, want_video):
    """跑一个条件的 n_ep 个 episode，写 CSV（+可选视频），并打印诊断。"""
    summary = []
    for seed in range(n_ep):
        r = builder.build_state(arena, spec, cond, seed)
        if not r.ok:
            print(f"[trace] cond={cond} seed={seed} 构造失败，跳过", flush=True)
            continue
        arena.set_state(r.state, settle_steps=0)
        arena.mark_episode_start()
        arena.set_allow_after_done(True)

        policy.reset()
        queue: list = []
        rows = []
        frames = []
        step = 0
        while step < PROBE:
            if not queue:
                obs = arena.get_observation()
                _ = policy.predict(obs, arena.task_language)
                chunk = policy.last_processed_actions
                raw_chunk = policy.last_raw_actions
                if chunk.ndim == 1:
                    chunk = chunk.reshape(1, -1)
                if raw_chunk.ndim == 1:
                    raw_chunk = raw_chunk.reshape(1, -1)
                queue = [(chunk[i], raw_chunk[i]) for i in range(min(NUM_CHUNK, len(chunk)))]

            proc_a, raw_a = queue.pop(0)
            step += 1

            arena.step(np.asarray(proc_a, dtype=float).tolist())

            e = eef_xyz(arena)
            w = wrist_xyz(arena)
            o = obj_xyz(arena)
            d = float(np.linalg.norm(e - o))
            fq = finger_qpos(arena)
            ctrl = gripper_ctrl(arena)
            done_now = int(bool(arena.goal_satisfied()))
            raw_g = float(np.asarray(raw_a).reshape(-1)[-1])

            rows.append(
                {
                    "step": step,
                    "goal_satisfied": done_now,
                    "eef_x": e[0], "eef_y": e[1], "eef_z": e[2],
                    "wrist_x": w[0], "wrist_y": w[1], "wrist_z": w[2],
                    "obj_x": o[0], "obj_y": o[1], "obj_z": o[2],
                    "eef_obj_dist": d,
                    "eef_xy_dist": float(np.hypot(e[0] - o[0], e[1] - o[1])),
                    "raw_gripper": raw_g,
                    "processed_gripper": float(np.asarray(proc_a).reshape(-1)[-1]),
                    "ctrl_g0": ctrl[0] if len(ctrl) > 0 else np.nan,
                    "ctrl_g1": ctrl[1] if len(ctrl) > 1 else np.nan,
                    "finger_l": fq[0], "finger_r": fq[1],
                    "env_done": getattr(arena._env, "done", None),
                    "allow_after_done": 1,
                }
            )

            if want_video:
                fr = arena.render_frame()
                if fr is not None:
                    intent = "CLOSE" if raw_g < 0.5 else "OPEN "
                    dxy_now = float(np.hypot(e[0] - o[0], e[1] - o[1]))
                    tag = "SAT" if cond == "satisfied" else "UNSAT"
                    # 版面约束：256px 宽 + DejaVuSansMono 11 -> 每行 <= 36 字符。
                    # 改动文案后务必跑 scripts/check_overlay_layout.py 复验。
                    lines = [
                        f"{tag}  s{seed}  step {step:3d}/{PROBE}",
                        f"d_bowl {d:.3f}m  xy {dxy_now:.3f}m",
                        f"eef_z {e[2]:.3f}  bowl {o[2]:.3f}  dz {e[2]-o[2]:+.3f}",
                        f"intent {intent}  fingers {fq[0]:.4f}",
                    ]
                    banner = None
                    if cond == "satisfied":
                        banner = "SATISFIED AT START - still acting?"
                    elif done_now:
                        banner = f"GOAL REACHED at {step} - still acting?"
                    frames.append(draw_overlay(fr, lines, banner=banner))

        csv_path = OUT / f"{TASK}__{cond}__s{seed:03d}.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

        vid_path = None
        if want_video and frames:
            vid_path = save_video(frames, VIDEODIR / f"{TASK}__{cond}__s{seed:03d}__trace.mp4")

        # ---- 分析 ----
        near = [x for x in rows if x["eef_obj_dist"] < NEAR]
        raw_want_close = [x for x in rows if x["raw_gripper"] < 0.5]
        raw_want_open = [x for x in rows if x["raw_gripper"] >= 0.5]
        zmin = min(x["eef_z"] for x in rows)
        obj_z0 = rows[0]["obj_z"]
        dxymin = min(x["eef_xy_dist"] for x in rows)

        print(
            f"\n[trace] cond={cond}  seed={seed}  steps={step}  "
            f"min_dist={min(x['eef_obj_dist'] for x in rows):.4f}  "
            f"near(<{NEAR*100:.0f}cm)={len(near)}  "
            f"raw想合={len(raw_want_close)}  raw想开={len(raw_want_open)}",
            flush=True,
        )
        print(
            f"        下降诊断 : eef_z_min={zmin:.4f}  碗z={obj_z0:.4f}  "
            f"高出碗={zmin - obj_z0:+.4f}m  xy最近={dxymin:.4f}m",
            flush=True,
        )
        print(f"        全程判定 : {classify(rows)}", flush=True)
        print(f"        近物窗口 : {classify(near)}", flush=True)
        if vid_path:
            print(f"        视频     : {vid_path}", flush=True)
        summary.append((seed, step, len(near), classify(rows), classify(near)))

    print("\n" + "=" * 78, flush=True)
    print(f"[trace] cond={cond} 汇总 n={len(summary)}", flush=True)
    for lbl, idx in (("全程", 3), ("近物窗口", 4)):
        c = Counter(s[idx].split(":")[0] for s in summary)
        print(f"  {lbl}判定分布: {dict(c)}", flush=True)
    print(f"  CSV 输出: {OUT}", flush=True)
    if want_video:
        print(f"  视频输出: {VIDEODIR}", flush=True)
    return summary


from collections import Counter  # noqa: E402

ALL_SUMMARY = []
for _cond in CONDS:
    ALL_SUMMARY += run_condition(_cond, N_EP, VIDEO)

arena.close()
print("[trace] done", flush=True)
