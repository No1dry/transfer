#!/usr/bin/env python
"""Step 3 验证入口：在真实 LIBERO 上构造状态并校验 predicate。

**必须在装了 LIBERO 的机器上跑**（CPU 即可，不需要 GPU、不需要 VLA 权重）。

它做什么
--------
对每个 task × condition × seed：
  1. 用 ``StateBuilder`` 构造初始状态；
  2. 用 LIBERO 自己的 ``env.check_success()``（simulator ground truth）校验；
  3. 检查机器人关节在两种 condition 下完全一致（§65.2 reset artifact 约束）；
  4. 记录残差 D(s,l)，供 M2 的连续标签 n_t 使用；
  5. 输出每个 task 的初始画面快照，供人工检查是否存在视觉 shortcut。

为什么先跑这个再跑模型
----------------------
如果状态构造本身不成立（例如 satisfied 其实没满足、或两种 condition 的
机器人位姿不同），那么后面 160 episode 得到的任何 UER 都是假的。
先把这一层钉死，再花 GPU 时间。

用法
----
    python scripts/validate_states.py --openvla_oft_root /path/to/openvla-oft
    python scripts/validate_states.py --openvla_oft_root ... --save_images
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from benchmark.states.builder import StateBuilder, verify_robot_joints_unchanged  # noqa: E402
from benchmark.tasks import load_registry  # noqa: E402


def _make_arena(spec, args):
    from benchmark.arena.libero import LiberoArena

    return LiberoArena(
        task_suite_name=spec.suite,
        task_id=spec.task_id,
        openvla_oft_root=args.openvla_oft_root,
        env_img_res=args.env_img_res,
        num_steps_wait=args.num_steps_wait,
        seed=0,
        subject=spec.subject,
        target=spec.target,
        joint_name=(spec.edit or {}).get("joint_name"),
        residual_kind=spec.residual_kind,
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--openvla_oft_root", required=True, help="openvla-oft 仓库根目录（复用其 libero_utils）")
    p.add_argument("--config", type=Path, default=None)
    p.add_argument("--seeds", type=int, default=20)
    p.add_argument("--env_img_res", type=int, default=256)
    p.add_argument("--num_steps_wait", type=int, default=10)
    p.add_argument("--settle_steps", type=int, default=30, help="构造状态后让物理收敛的空转步数")
    p.add_argument("--save_images", action="store_true", help="保存初始画面快照")
    p.add_argument("--out", type=Path, default=REPO_ROOT / "results" / "m1" / "state_validation.json")
    args = p.parse_args(argv)

    registry = load_registry(args.config)
    builder = StateBuilder(settle_steps=args.settle_steps)

    img_dir = REPO_ROOT / "results" / "m1" / "state_images"
    if args.save_images:
        img_dir.mkdir(parents=True, exist_ok=True)

    report: dict = {"benchmark": registry.meta["benchmark_version"], "tasks": {}}
    n_fail = 0
    n_total = 0

    for spec in registry:
        print("=" * 74)
        print(f"task {spec.id}  ({spec.suite}#{spec.task_id})  {spec.task_name}")
        print("=" * 74)
        task_entry: dict = {"suite": spec.suite, "task_id": spec.task_id, "conditions": {}}

        try:
            arena = _make_arena(spec, args)
        except Exception as exc:  # noqa: BLE001
            print(f"  [ERROR] 无法创建 LIBERO 环境: {exc}")
            traceback.print_exc()
            task_entry["error"] = f"{type(exc).__name__}: {exc}"
            report["tasks"][spec.id] = task_entry
            n_fail += 1
            continue

        try:
            # 语言一致性校验：我们记录的是期望值，真值必须来自 LIBERO
            lang_match = arena.task_language == spec.expected_language
            task_entry["language_actual"] = arena.task_language
            task_entry["language_expected"] = spec.expected_language
            task_entry["language_match"] = lang_match
            mark = "ok" if lang_match else "MISMATCH"
            print(f"  language [{mark}]: {arena.task_language!r}")
            if not lang_match:
                print(f"     期望值: {spec.expected_language!r}")

            states_by_cond: dict[str, list[np.ndarray]] = {"satisfied": [], "unsatisfied": []}
            residuals: dict[str, list[float]] = {"satisfied": [], "unsatisfied": []}

            for cond in ("satisfied", "unsatisfied"):
                ok_count = 0
                attempts_total = 0
                for seed in range(args.seeds):
                    n_total += 1
                    try:
                        result = builder.build_state(arena, spec, cond, seed)
                    except Exception as exc:  # noqa: BLE001
                        print(f"    [{cond} seed={seed}] 构造抛异常: {exc}")
                        n_fail += 1
                        continue

                    attempts_total += len(result.attempts)
                    if not result.ok or result.state is None:
                        n_fail += 1
                        print(f"    [{cond} seed={seed}] FAIL: {result.failure_reason[:100]}")
                        continue

                    # 独立复核：把状态装回环境，用 predicate 再判一次
                    arena.set_state(result.state, settle_steps=0)
                    recheck = bool(arena.goal_satisfied())
                    expected = cond == "satisfied"
                    if recheck != expected:
                        n_fail += 1
                        print(f"    [{cond} seed={seed}] 复核不一致: predicate={recheck}")
                        continue

                    ok_count += 1
                    states_by_cond[cond].append(result.state)
                    residuals[cond].append(float(arena.residual()))

                    if args.save_images:
                        obs = arena.get_observation()
                        try:
                            import imageio

                            imageio.imwrite(
                                img_dir / f"{spec.id}__{cond}__s{seed:03d}.png", obs.full_image
                            )
                        except Exception:  # noqa: BLE001
                            pass

                task_entry["conditions"][cond] = {
                    "n_ok": ok_count,
                    "n_attempted": args.seeds,
                    "mean_attempts_per_episode": round(attempts_total / max(args.seeds, 1), 3),
                    "residual_mean": float(np.mean(residuals[cond])) if residuals[cond] else None,
                    "residual_std": float(np.std(residuals[cond])) if residuals[cond] else None,
                }
                print(
                    f"  {cond:12s}: {ok_count}/{args.seeds} 构造成功   "
                    f"residual mean={np.mean(residuals[cond]) if residuals[cond] else float('nan'):.5f}"
                )

            # §65.2：两种 condition 的机器人关节必须一致
            if states_by_cond["satisfied"] and states_by_cond["unsatisfied"]:
                same = all(
                    verify_robot_joints_unchanged(s, u, arena.model)
                    for s, u in zip(states_by_cond["satisfied"], states_by_cond["unsatisfied"])
                )
                task_entry["robot_joints_identical_across_conditions"] = bool(same)
                print(f"  机器人关节跨 condition 一致: {same}")
                if not same:
                    n_fail += 1

        finally:
            arena.close()

        report["tasks"][spec.id] = task_entry

    report["summary"] = {"n_checks": n_total, "n_failed": n_fail}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

    print()
    print("=" * 74)
    print(f"检查总数 {n_total}，失败 {n_fail}")
    print(f"[ok] 报告写入 {args.out}")
    if args.save_images:
        print(f"[ok] 初始画面快照目录 {img_dir}")
    return 1 if n_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
