import glob
import json

fs = sorted(glob.glob("results/m1/final/openvla*.json"))
print("episodes:", len(fs))
bad = 0
for f in fs:
    d = json.load(open(f))
    ok = d["init_satisfied"] == (d["condition"] == "satisfied")
    if not ok:
        bad += 1
    ga = (d.get("extra") or {}).get("gripper_action", {}) or {}
    print(
        "  {:16s} {:12s} s{:02d}  init_sat={:5s} final_sat={:5s} steps={:3d} 1st_close={} obj={:.4f}".format(
            d["task_id"], d["condition"], d["seed"],
            str(d["init_satisfied"]), str(d["final_satisfied"]),
            d["n_steps"], ga.get("first_close_step"), d["object_max_displacement"],
        )
    )
print("condition/init mismatches:", bad)
