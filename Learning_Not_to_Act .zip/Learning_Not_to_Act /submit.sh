#!/bin/bash
# 远程后台作业提交器。
#
# 为什么需要它：直接在 ssh 命令行里用 `&` 后台运行，ssh 会一直等 stdout/stderr
# 管道关闭，导致连接挂住。这里用 setsid 脱离会话 + 三路重定向到文件，
# 保证 ssh 立刻返回，作业继续在服务器上跑。
#
# 用法:
#   ./submit.sh <job_name> <command...>
#   ./submit.sh validate ./run_validate.sh --seeds 20
#   ./submit.sh minipab  ./run_minipab.sh --limit 8
#
# 产物: logs/<job_name>.log, logs/<job_name>.pid

set -uo pipefail

JOB="$1"; shift
ROOT=/HUBU-AI004/zp/ICML
mkdir -p "$ROOT/logs"
cd "$ROOT"

LOG="$ROOT/logs/${JOB}.log"
PIDFILE="$ROOT/logs/${JOB}.pid"

# 已经在跑就不重复启动
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "ALREADY_RUNNING pid=$(cat "$PIDFILE") log=$LOG"
    exit 0
fi

setsid nohup "$@" > "$LOG" 2>&1 < /dev/null &
PID=$!
echo "$PID" > "$PIDFILE"

# 等一下确认没立刻崩
sleep 3
if kill -0 "$PID" 2>/dev/null; then
    echo "STARTED pid=$PID log=$LOG"
else
    echo "FAILED_TO_START log=$LOG"
    tail -5 "$LOG" 2>/dev/null
    exit 1
fi
