"""构造一个假的 MuJoCo model/data，用于在无 MuJoCo 的机器上单测状态编辑逻辑。

假模型刻意模仿 LIBERO 桌面上场景的真实布局：

    joints:
        0..6   robot0_joint1..7         hinge
        7,8    robot0_gripper_joint1/2  hinge
        9      akita_black_bowl_1_joint_0   free
        10     plate_1_joint_0              free
        11     cream_cheese_1_joint_0       free
        12     wine_bottle_1_joint_0        free

对应的状态数组：[time(1) | qpos(37) | qvel(33)]，总长 71。
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

N_ROBOT_JOINTS = 7
N_GRIPPER_JOINTS = 2
FREE_OBJECTS = [
    "akita_black_bowl_1_joint_0",
    "plate_1_joint_0",
    "cream_cheese_1_joint_0",
    "wine_bottle_1_joint_0",
]


@dataclass
class FakeModel:
    nq: int
    nv: int
    njnt: int
    na: int = 0
    nbody: int = 0
    ngeom: int = 0
    joint_names: list[str] = field(default_factory=list)
    jnt_type: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int32))
    jnt_qposadr: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int32))
    jnt_dofadr: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int32))
    jnt_range: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), dtype=np.float64))
    body_names: list[str] = field(default_factory=list)
    geom_bodyid: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int32))
    geom_type: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int32))
    geom_rbound: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float64))


@dataclass
class FakeData:
    qpos: np.ndarray
    qvel: np.ndarray
    xpos: np.ndarray
    geom_xpos: np.ndarray


def build_fake_model(
    *,
    object_heights: dict[str, float] | None = None,
    object_top_z: dict[str, float] | None = None,
    drawer: bool = False,
) -> tuple[FakeModel, FakeData]:
    """构造假 model/data。

    object_heights: 物体高度，用于设置 geom_rbound（半高）。
    object_top_z:   目标物体顶面的世界 z，用于验证 resting z 推算。
    """
    object_heights = object_heights or {
        "akita_black_bowl_1": 0.05,
        "plate_1": 0.02,
        "cream_cheese_1": 0.04,
        "wine_bottle_1": 0.20,
    }
    object_top_z = object_top_z or {"plate_1": 0.42}

    joint_names: list[str] = []
    jnt_type: list[int] = []
    jnt_qposadr: list[int] = []
    jnt_dofadr: list[int] = []
    jnt_range: list[tuple[float, float]] = []

    qpos_adr = 0
    dof_adr = 0

    for i in range(N_ROBOT_JOINTS):
        joint_names.append(f"robot0_joint{i + 1}")
        jnt_type.append(3)  # mjJNT_HINGE
        jnt_qposadr.append(qpos_adr)
        jnt_dofadr.append(dof_adr)
        jnt_range.append((-3.0, 3.0))
        qpos_adr += 1
        dof_adr += 1

    for i in range(N_GRIPPER_JOINTS):
        # 与真实 LIBERO / robosuite 一致：夹爪前缀是 gripper0_ 而不是 robot0_，
        # 且两个手指关节的 range 方向相反。
        joint_names.append(f"gripper0_finger_joint{i + 1}")
        jnt_type.append(2)  # mjJNT_SLIDE
        jnt_qposadr.append(qpos_adr)
        jnt_dofadr.append(dof_adr)
        jnt_range.append((0.0, 0.04) if i == 0 else (-0.04, 0.0))
        qpos_adr += 1
        dof_adr += 1

    if drawer:
        # 真实 LIBERO 的抽屉是 **slide** joint（type=2），
        # range 为 [-0.16, 0.01]，即"打开"对应**负端** —— 这个反直觉的方向
        # 正是 StateBuilder 必须两端探测、不能假定"开 = 上限"的原因。
        joint_names.append("wooden_cabinet_1_middle_level")
        jnt_type.append(2)  # mjJNT_SLIDE
        jnt_qposadr.append(qpos_adr)
        jnt_dofadr.append(dof_adr)
        jnt_range.append((-0.16, 0.01))
        qpos_adr += 1
        dof_adr += 1

    for obj in FREE_OBJECTS:
        joint_names.append(obj)
        jnt_type.append(0)  # mjJNT_FREE
        jnt_qposadr.append(qpos_adr)
        jnt_dofadr.append(dof_adr)
        jnt_range.append((0.0, 0.0))  # free joint 无 range
        qpos_adr += 7
        dof_adr += 6

    nq, nv, njnt = qpos_adr, dof_adr, len(joint_names)

    # --- 几何：每个物体一个 sphere geom，rbound = 半高 ---
    body_names = ["world", "robot0_base"]
    geom_bodyid: list[int] = []
    geom_type: list[int] = []
    geom_rbound: list[float] = []

    body_names.append("akita_black_bowl_1_main")
    bowl_body = len(body_names) - 1
    geom_bodyid.append(bowl_body)
    geom_type.append(2)  # mjGEOM_SPHERE
    geom_rbound.append(object_heights["akita_black_bowl_1"] / 2.0)

    body_names.append("plate_1_main")
    plate_body = len(body_names) - 1
    geom_bodyid.append(plate_body)
    geom_type.append(2)
    geom_rbound.append(object_heights["plate_1"] / 2.0)

    model = FakeModel(
        nq=nq,
        nv=nv,
        njnt=njnt,
        nbody=len(body_names),
        ngeom=len(geom_bodyid),
        joint_names=joint_names,
        jnt_type=np.array(jnt_type, dtype=np.int32),
        jnt_qposadr=np.array(jnt_qposadr, dtype=np.int32),
        jnt_dofadr=np.array(jnt_dofadr, dtype=np.int32),
        jnt_range=np.array(jnt_range, dtype=np.float64),
        body_names=body_names,
        geom_bodyid=np.array(geom_bodyid, dtype=np.int32),
        geom_type=np.array(geom_type, dtype=np.int32),
        geom_rbound=np.array(geom_rbound, dtype=np.float64),
    )

    # --- data ---
    qpos = np.zeros(nq, dtype=np.float64)
    # 每个 free joint 的四元数设为 identity (w,x,y,z)
    for j in range(njnt):
        if jnt_type[j] == 0:
            adr = jnt_qposadr[j]
            qpos[adr + 3] = 1.0

    # 给物体一个初始位置
    def _set_free(obj_name: str, xyz: tuple[float, float, float]) -> None:
        idx = joint_names.index(obj_name)
        adr = jnt_qposadr[idx]
        qpos[adr : adr + 3] = xyz

    _set_free("akita_black_bowl_1_joint_0", (-0.09, 0.0, 0.44))
    _set_free("plate_1_joint_0", (0.04, -0.02, float(object_top_z["plate_1"]) - object_heights["plate_1"] / 2.0))
    _set_free("cream_cheese_1_joint_0", (-0.05, 0.13, 0.44))
    _set_free("wine_bottle_1_joint_0", (-0.20, -0.05, 0.50))

    qvel = np.zeros(nv, dtype=np.float64)

    nbody = len(body_names)
    xpos = np.zeros((nbody, 3), dtype=np.float64)
    bowl_idx = joint_names.index("akita_black_bowl_1_joint_0")
    plate_idx = joint_names.index("plate_1_joint_0")
    xpos[bowl_body] = qpos[jnt_qposadr[bowl_idx] : jnt_qposadr[bowl_idx] + 3]
    xpos[plate_body] = qpos[jnt_qposadr[plate_idx] : jnt_qposadr[plate_idx] + 3]

    geom_xpos = np.zeros((len(geom_bodyid), 3), dtype=np.float64)
    geom_xpos[0] = xpos[bowl_body]
    geom_xpos[1] = xpos[plate_body]

    data = FakeData(qpos=qpos, qvel=qvel, xpos=xpos, geom_xpos=geom_xpos)
    return model, data


def make_state(model: FakeModel, data: FakeData) -> np.ndarray:
    """按 [time | qpos | qvel] 拼出扁平状态数组。"""
    return np.concatenate([[0.0], data.qpos, data.qvel])
