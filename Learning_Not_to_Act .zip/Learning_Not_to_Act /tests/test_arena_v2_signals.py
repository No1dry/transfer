"""Arena 层 v2 信号测试（mentor_review_1 §6.5、§6.6）。

用 MockArena（真 MuJoCo 模型，无 LIBERO / 无 GPU）验证：

  1. **单步 path length**（§3.1）：一次移动的路径必须等于该步位移，
     而不是 0。原实现把 `_prev_signal` 设成 None，会漏掉"起点→第一步"。
  2. path length 是**累加**的，多步往返后显著大于净位移。
  3. 关节三件套（§3.2）：max / path / normalized 在 MockArena 上语义正确。
  4. contact 归属映射（§6.5）：用合成 contact 列表做阳性/阴性测试
     （MockArena 本身不模拟接触，所以这部分直接单测归属逻辑）。
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.arena.libero import LiberoArena  # noqa: E402
from benchmark.arena.mock import MockArena, MockArenaConfig  # noqa: E402


def make_arena(**kw) -> MockArena:
    return MockArena(MockArenaConfig(**kw))


# ---------------------------------------------------------------------------
# §6.6 单步 path length
# ---------------------------------------------------------------------------


def test_single_step_path_length_equals_displacement():
    """走一步 -> path length 必须等于这一步的位移（不是 0）。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    start = np.array(arena._eef, dtype=np.float64)

    # 纯平移动作：前 3 维给一个明确位移，夹爪不动
    action = [0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    arena.step(action)

    moved = float(np.linalg.norm(np.array(arena._eef, dtype=np.float64) - start))
    sig = arena.debug_signals()
    assert moved > 0, "这一步应该真的移动了"
    assert sig["eef_path_length"] == pytest.approx(moved, abs=1e-9), (
        f"单步 path({sig['eef_path_length']}) 应等于位移({moved})；"
        "差很多说明漏掉了'起点→第一步'"
    )


def test_path_length_accumulates_and_exceeds_net_displacement():
    """来回往返：路径长度应显著大于净位移。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    start = np.array(arena._eef, dtype=np.float64)

    for _ in range(5):
        arena.step([0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    for _ in range(5):
        arena.step([-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])   # 回到起点

    net = float(np.linalg.norm(np.array(arena._eef, dtype=np.float64) - start))
    sig = arena.debug_signals()
    assert sig["eef_path_length"] > net + 1e-6, "往返后路径必须大于净位移"
    assert sig["eef_max_displacement"] > 0


def test_cumulative_measured_flag_lifecycle():
    """cumulative_measured 必须从 False（未测）变成 True（测过）。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    assert arena.cumulative_measured() is False
    arena.step([0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    assert arena.cumulative_measured() is True


def test_mock_gripper_open_reference_is_normalized_unit():
    """§3.3：MockArena 的 _gripper 本身是归一化开度，参考值应为 1.0。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    sig = arena.debug_signals()
    assert sig["gripper_open_reference"] == pytest.approx(1.0)


def test_mock_gripper_change_norm_tracks_closure():
    """夹爪闭合一半 -> gripper_change_norm 应接近 0.5（而不是被旧阈值吞掉）。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    arena.step([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5])
    arena.step([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5])   # 累计 1.0 被 clip 到 1.0
    sig = arena.debug_signals()
    assert sig["gripper_change_norm"] == pytest.approx(1.0, abs=0.01)
    assert sig["gripper_change_norm"] > 0.2, "归一化后应超过 0.2"


# ---------------------------------------------------------------------------
# §3.2 关节三件套
# ---------------------------------------------------------------------------


def test_joint_triplet_on_articulated_mock():
    """articulated：max / path / normalized 三个量都要有，且归一化分母非零。"""
    arena = make_arena(articulated=True, subject="mock_drawer", target="mock_drawer",
               joint_name="wooden_cabinet_1_middle_level")
    arena.reset()
    arena.mark_episode_start()

    for _ in range(4):
        arena.step([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

    sig = arena.debug_signals()
    assert "task_joint_max_displacement" in sig
    assert "task_joint_path_length" in sig
    assert "task_joint_normalized_max" in sig
    span = sig["task_joint_range_span"]
    assert not np.isnan(span) and span > 0, f"关节行程应可读，实际 {span}"


def test_joint_path_ge_max_on_mock():
    """关节路径长度必须 >= 最大偏离（数学必然）。"""
    arena = make_arena(articulated=True, subject="mock_drawer", target="mock_drawer",
               joint_name="wooden_cabinet_1_middle_level")
    arena.reset()
    arena.mark_episode_start()
    for _ in range(3):
        arena.step([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    sig = arena.debug_signals()
    assert sig["task_joint_path_length"] >= sig["task_joint_max_displacement"] - 1e-12


def test_placement_mock_has_no_joint_signal():
    """placement 任务没有关节通道，不应伪造出非零值。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    arena.step([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    sig = arena.debug_signals()
    assert sig["task_joint_max_displacement"] == 0.0
    assert sig["task_joint_path_length"] == 0.0


# ---------------------------------------------------------------------------
# §6.5 contact 归属映射（阳性 / 阴性）
# ---------------------------------------------------------------------------


class _FakeContact:
    def __init__(self, g1: int, g2: int) -> None:
        self.geom1, self.geom2 = g1, g2


class _FakeData:
    def __init__(self, contacts) -> None:
        self.contact = contacts
        self.ncon = len(contacts)


class _FakeSim:
    def __init__(self, contacts) -> None:
        self.data = _FakeData(contacts)


class _FakeEnv:
    def __init__(self, contacts) -> None:
        self.sim = _FakeSim(contacts)


class _FakeModel:
    """geom_bodyid / body_id2name：0=world, 1..=任务实体, 10..=机器人。"""

    geom_bodyid = [0, 1, 1, 10, 10, 2]          # geom 0..5 的归属 body
    ngeom = 6
    _bodies = {0: "world", 1: "akita_black_bowl_1_main", 2: "plate_1_main",
               10: "gripper0_leftfinger"}

    def body_id2name(self, i):
        return self._bodies.get(i)


def _bare_arena(contacts, subject="akita_black_bowl_1", target="plate_1"):
    """构造一个只带 contact 归属所需属性的 LiberoArena（不初始化 MuJoCo）。"""
    a = object.__new__(LiberoArena)
    a._subject = subject
    a._target = target
    a.model = _FakeModel()
    a._task_geom_cache = None
    a._robot_geom_cache = None
    a._env = _FakeEnv(contacts)
    return a


def test_contact_attribution_positive():
    """机器人 geom(3) 与碗 geom(1) 接触 -> True。"""
    a = _bare_arena([_FakeContact(3, 1)])
    assert a._has_task_contact() is True


def test_contact_attribution_negative_when_only_robot_self_contact():
    """机器人自己两个 geom 接触（3 与 4）-> False，不能误判为任务接触。"""
    a = _bare_arena([_FakeContact(3, 4)])
    assert a._has_task_contact() is False


def test_contact_attribution_negative_when_object_touches_table():
    """任务物体只和桌面(world, geom 0)接触 -> 不算机器人与任务接触。"""
    a = _bare_arena([_FakeContact(1, 0)])
    assert a._has_task_contact() is False


def test_contact_attribution_handles_target_object():
    """碰到 target（盘子, geom 5）也算任务相关接触。"""
    a = _bare_arena([_FakeContact(3, 5)])
    assert a._has_task_contact() is True


def test_contact_attribution_respects_geom_order():
    """geom1/geom2 顺序反过来也要能识别。"""
    a = _bare_arena([_FakeContact(1, 3)])
    assert a._has_task_contact() is True


def test_contact_unmeasured_when_no_geom_mapping():
    """归属映射为空时返回 None（未测量），而不是 False（没接触）。"""
    a = object.__new__(LiberoArena)
    a._subject = "nonexistent_object"
    a._target = None
    a.model = _FakeModel()
    a._task_geom_cache = None
    a._robot_geom_cache = None
    a._env = _FakeEnv([_FakeContact(3, 1)])
    assert a._has_task_contact() is None, "映射不出来必须说不知道，不能说没接触"


def test_mock_contact_is_unmeasured_not_false():
    """MockArena 不模拟接触 -> task_contact() 必须 measured=False。"""
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    c = arena.task_contact()
    assert c["measured"] is False
    assert c["ever"] is None, "未测量时 ever 不能是 False"


# ---------------------------------------------------------------------------
# mentor_review_2 §4：contact 必须区分 subject / target
# ---------------------------------------------------------------------------


def test_contact_flags_separate_subject_and_target():
    """碰到 target（盘子）不能被算成碰到 subject（碗）。"""
    a = _bare_arena([_FakeContact(3, 5)])       # 机器人 ↔ plate(geom 5)
    f = a._contact_flags()
    assert f["target"] is True
    assert f["subject"] is False, "碰盘子不等于碰碗 —— 这正是 §4 要拆开的点"
    assert f["any"] is True


def test_contact_flags_subject_only():
    a = _bare_arena([_FakeContact(3, 1)])       # 机器人 ↔ bowl(geom 1)
    f = a._contact_flags()
    assert f["subject"] is True
    assert f["target"] is False
    assert f["any"] is True


def test_contact_flags_both_in_same_step():
    """同一步同时接触 subject 与 target，两个都要为 True。"""
    a = _bare_arena([_FakeContact(3, 1), _FakeContact(4, 5)])
    f = a._contact_flags()
    assert f["subject"] is True and f["target"] is True and f["any"] is True


def test_contact_flags_none_when_unmappable():
    """映射不出 geom 时必须是 None（未测量），不能是 False（没接触）。"""
    a = object.__new__(LiberoArena)
    a._subject = "nonexistent_object"
    a._target = None
    a.model = _FakeModel()
    a._task_geom_cache = None
    a._robot_geom_cache = None
    a._subject_geom_cache = None
    a._target_geom_cache = None
    a._env = _FakeEnv([_FakeContact(3, 1)])
    f = a._contact_flags()
    assert f["subject"] is None and f["target"] is None and f["any"] is None


def test_task_contact_payload_has_per_kind_slots():
    """task_contact() 必须给出 subject/target/any 三组，各带 4 个字段。"""
    a = _bare_arena([_FakeContact(3, 1)])
    a._contact = {
        k: {"measured": False, "ever": False, "first_step": None, "n_steps": 0}
        for k in ("subject", "target", "any")
    }
    # 手工灌一个值，模拟 _update_displacement 的累加结果
    a._contact["subject"] = {"measured": True, "ever": True,
                             "first_step": 7, "n_steps": 3}
    out = a.task_contact()
    for k in ("subject", "target", "any"):
        assert k in out, f"缺 {k} 槽位"
        for fld in ("measured", "ever", "first_step", "n_steps"):
            assert fld in out[k], f"{k} 缺字段 {fld}"
    assert out["subject"]["first_step"] == 7
    assert out["target"]["measured"] is False
    assert out["target"]["ever"] is None, "未测量时 ever 必须是 None"


def test_mock_contact_payload_has_three_slots():
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    c = arena.task_contact()
    for k in ("subject", "target", "any"):
        assert c[k]["measured"] is False
        assert c[k]["ever"] is None


def test_contact_state_survives_step_not_just_mark_episode_start():
    """守卫测试：`mark_episode_start` **之后 step** 不能让 contact 结构退化。

    mentor_review_2 之后的 smoke-v2 第一轮就是这样全废的：
    `_contact` 的结构在 `__init__` 与 `mark_episode_start` 里各写了一份，
    只改了前者，于是 `_update_displacement` 里 `self._contact["subject"]`
    直接 KeyError。这个测试保证两处结构一致且 step 后仍完整。
    """
    arena = make_arena()
    arena.reset()
    arena.mark_episode_start()
    # 关键：step 会走 _update_displacement -> _contact_flags -> 逐 kind 累加
    arena.step([0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    for kind in ("subject", "target", "any"):
        assert kind in arena._contact, f"step 后丢了 {kind} 槽位"
        for fld in ("measured", "ever", "first_step", "n_steps"):
            assert fld in arena._contact[kind], f"{kind} 缺 {fld}"
    c = arena.task_contact()
    for kind in ("subject", "target", "any"):
        assert kind in c


def test_contact_accumulator_has_one_definition():
    """两个 arena 都必须用同一个工厂函数建 contact 结构（防止再次漏改）。"""
    for cls in (LiberoArena, MockArena):
        st = cls._new_contact_state()
        assert set(st) == {"subject", "target", "any"}
        for v in st.values():
            assert set(v) == {"measured", "ever", "first_step", "n_steps"}


def test_contact_flags_accumulate_across_steps():
    """连续两步接触 subject：n_steps 累加、first_step 记第一次。"""
    a = _bare_arena([_FakeContact(3, 1)])
    a._contact = LiberoArena._new_contact_state()
    a._episode_start = {"step": 0}
    for expected_step in (1, 2):
        a._episode_start["step"] = expected_step - 1
        flags = a._contact_flags()
        for kind in ("subject", "target", "any"):
            v = flags.get(kind)
            if v is None:
                continue
            slot = a._contact[kind]
            slot["measured"] = True
            if v:
                slot["n_steps"] += 1
                if not slot["ever"]:
                    slot["ever"] = True
                    slot["first_step"] = expected_step
    out = a.task_contact()
    assert out["subject"]["ever"] is True
    assert out["subject"]["first_step"] == 1
    assert out["subject"]["n_steps"] == 2
    assert out["target"]["measured"] is True
    assert out["target"]["ever"] is False, "测过但没接触 -> False，不是 None"
