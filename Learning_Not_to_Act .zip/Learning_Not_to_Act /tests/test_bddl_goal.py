"""BDDL `:goal` 解析器的单元测试（mentor_review_5 §5 第 1–3 条）。

**纯函数测试，不需要 LIBERO / MuJoCo / GPU**，可本地运行。
覆盖：
  1. 能解析 1-predicate 与 2-predicate goal；
  2. 谓词名小写化**不改变**对象名 / region 名；
  3. 解析结果与 LIBERO `env.parsed_problem["goal_state"]` 的格式一致
     （一致性由远端 integration 脚本核对，这里测格式契约）。
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.bddl_goal import parse_goal_from_bddl  # noqa: E402

# ---------------------------------------------------------------------------
# 真实 BDDL 片段（取自本仓库实际任务文件的结构）
# ---------------------------------------------------------------------------

SINGLE = """
(define (problem LIBERO_Floor_Manipulation)
  (:domain robosuite)
  (:language open the top drawer and put the bowl inside)
  (:objects akita_black_bowl_1 - akita_black_bowl)
  (:init
    (On akita_black_bowl_1 living_room_table)
  )
  (:goal
    (And (In akita_black_bowl_1 wooden_cabinet_1_top_region))
  )
)
"""

DOUBLE = """
(define (problem LIBERO_Kitchen_Tabletop_Manipulation)
  (:domain robosuite)
  (:language turn on the stove and put the moka pot on it)
  (:goal
    (And (Turnon flat_stove_1) (On moka_pot_1 flat_stove_1_cook_region))
  )
)
"""

DOUBLE_IN = """
(define (problem LIBERO_Living_Room_Manipulation)
  (:goal
    (And (In alphabet_soup_1 basket_1_contain_region)
         (In tomato_sauce_1 basket_1_contain_region))
  )
)
"""


def _write(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "t.bddl"
    p.write_text(text)
    return p


# ---------------------------------------------------------------------------
# 1. 解析 1 / 2 谓词
# ---------------------------------------------------------------------------


def test_parses_single_predicate_goal(tmp_path):
    preds = parse_goal_from_bddl(_write(tmp_path, SINGLE))
    assert preds == [["in", "akita_black_bowl_1", "wooden_cabinet_1_top_region"]]
    assert len(preds) == 1


def test_parses_two_predicate_goal(tmp_path):
    preds = parse_goal_from_bddl(_write(tmp_path, DOUBLE))
    assert preds == [["turnon", "flat_stove_1"],
                     ["on", "moka_pot_1", "flat_stove_1_cook_region"]]
    assert len(preds) == 2


def test_parses_two_binary_predicates(tmp_path):
    preds = parse_goal_from_bddl(_write(tmp_path, DOUBLE_IN))
    assert preds == [["in", "alphabet_soup_1", "basket_1_contain_region"],
                     ["in", "tomato_sauce_1", "basket_1_contain_region"]]


def test_missing_goal_raises(tmp_path):
    p = _write(tmp_path, "(define (problem x) (:init (On a b)))")
    with pytest.raises(ValueError):
        parse_goal_from_bddl(p)


# ---------------------------------------------------------------------------
# 2. 大小写：只小写谓词名，对象/region 原样保留
# ---------------------------------------------------------------------------


def test_predicate_name_lowercased_but_objects_preserved(tmp_path):
    """★ 这是最容易写错的一条：整体 .lower() 会把对象名也毁掉。"""
    preds = parse_goal_from_bddl(_write(tmp_path, DOUBLE))
    assert preds[0][0] == "turnon", "谓词名必须小写（LIBERO 的 dict 键是小写）"
    assert preds[0][1] == "flat_stove_1", "对象名必须保持原样"
    assert preds[1] == ["on", "moka_pot_1", "flat_stove_1_cook_region"]
    assert preds[1][2] == "flat_stove_1_cook_region", "region 名必须保持原样"


def test_case_insensitive_predicate_mixed_case(tmp_path):
    text = DOUBLE.replace("Turnon", "TURNON").replace("On ", "On ")
    preds = parse_goal_from_bddl(_write(tmp_path, text))
    assert preds[0][0] == "turnon"
    assert preds[1][0] == "on"


def test_does_not_lowercase_object_names_with_uppercase(tmp_path):
    """构造一个对象名含大写的假 BDDL，确认不被小写化。"""
    text = """
    (:goal
      (And (In BowlA basket_1_contain_region))
    )
    """
    preds = parse_goal_from_bddl(_write(tmp_path, text))
    assert preds == [["in", "BowlA", "basket_1_contain_region"]], \
        "对象名 BowlA 必须保持大小写"


# ---------------------------------------------------------------------------
# 3. 格式契约（与 env.parsed_problem["goal_state"] 一致）
# ---------------------------------------------------------------------------


def test_output_shape_matches_libero_contract(tmp_path):
    """LIBERO 的 goal_state 是 ``list[list[str]]``，每项 2 或 3 个 token。"""
    for text in (SINGLE, DOUBLE, DOUBLE_IN):
        preds = parse_goal_from_bddl(_write(tmp_path, text))
        assert isinstance(preds, list)
        for p in preds:
            assert isinstance(p, list)
            assert all(isinstance(t, str) for t in p)
            assert len(p) in (2, 3), f"谓词长度应为 2(unary) 或 3(binary)，实际 {p}"
            assert p[0] == p[0].lower(), f"谓词名必须小写: {p}"


def test_unary_and_binary_mixed(tmp_path):
    """真实 I2 就是 unary + binary 混合。"""
    preds = parse_goal_from_bddl(_write(tmp_path, DOUBLE))
    assert len(preds[0]) == 2 and len(preds[1]) == 3
