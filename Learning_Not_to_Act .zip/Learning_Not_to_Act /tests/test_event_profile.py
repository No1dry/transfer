"""event_profile 的单元测试（mentor_review_2 §3、§2.4）。

重点覆盖 review 指出的**确定性逻辑错误**，每一条都对应一个曾经算错的量：

  §3.1 `initial == min` 的轨迹被误判为 "approached_then_retreated"
  §3.2 step-0 距离必须来自真正的起点（这里用序列首元素语义验证）
  §3.3 方向反转必须对仿真抖动免疫（死区）
  §2.4 只看 final predicate 会漏掉"中途破坏、末尾恢复"
  §3.5 不再强制单标签，允许 mixed
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.event_profile import (  # noqa: E402
    EventThresholds,
    approach_metrics,
    compute_event_profile,
    count_reversals,
    derive_single_label,
    reversal_sensitivity,
    transient_goal_stats,
)


# ---------------------------------------------------------------------------
# §3.1 approach / retreat 必须是两个独立量
# ---------------------------------------------------------------------------


def test_initial_equals_min_is_not_reapproach():
    """★ mentor_review_2 §3.1 的核心 bug。

    轨迹从最近点**一路离开**（d 单调增）：initial == min。
    旧实现只看 "argmin 不在末尾 且 final > min + 0.05"，
    会把它错标成 approached_then_retreated=True。
    正确结果：approach_delta = 0 -> reapproached=False，但 retreated=True。
    """
    d = [0.10, 0.15, 0.22, 0.30, 0.40]      # 单调远离
    m = approach_metrics(d)
    assert m["d_step0"] == pytest.approx(0.10)
    assert m["d_min"] == pytest.approx(0.10)
    assert m["approach_delta"] == pytest.approx(0.0)
    assert m["reapproached"] is False, "从最近点直接离开，不是'重新接近'"
    assert m["retreated"] is True
    assert m["retreat_delta"] == pytest.approx(0.30)


def test_genuine_reapproach_is_detected():
    """真的靠近了 2cm 以上才算 reapproached。"""
    d = [0.30, 0.20, 0.10, 0.12, 0.25]
    m = approach_metrics(d)
    assert m["approach_delta"] == pytest.approx(0.20)
    assert m["reapproached"] is True
    assert m["retreated"] is True, "之后又远离了 0.15"


def test_small_approach_below_margin_is_not_reapproach():
    """只靠近 1cm（< 2cm 阈值）不算重新接近 —— 阈值预注册，不随结果调。"""
    d = [0.20, 0.19, 0.30]
    m = approach_metrics(d)
    assert m["approach_delta"] == pytest.approx(0.01)
    assert m["reapproached"] is False


def test_retreat_below_margin_is_not_retreat():
    d = [0.30, 0.20, 0.23]      # 只远离 3cm < 5cm
    m = approach_metrics(d)
    assert m["reapproached"] is True
    assert m["retreated"] is False


def test_approach_metrics_handles_empty_and_custom_thresholds():
    m = approach_metrics([])
    assert m["measured"] is False
    th = EventThresholds(approach_margin_m=0.005)
    assert approach_metrics([0.20, 0.19, 0.30], th)["reapproached"] is True


# ---------------------------------------------------------------------------
# §3.3 方向反转必须带死区
# ---------------------------------------------------------------------------


def test_reversals_ignore_sub_millimetre_jitter():
    """纯抖动（±0.5mm）在 1mm 死区下不应产生任何反转。"""
    jitter = [0.100, 0.1005, 0.1002, 0.1004, 0.1001, 0.1003]
    assert count_reversals(jitter, 0.001) == 0, "±0.5mm 抖动不该算方向反转"
    # 无死区时会误报很多次
    assert count_reversals(jitter, 0.0) > 3


def test_reversals_count_real_oscillation():
    """真正的来回（幅度 1cm）应当被数出来。

    [0.10,0.20,0.10,0.20,0.10,0.20] 的差分是 +,-,+,-,+，
    符号变化 4 次 —— 反转数定义为**符号变化次数**，不是"段数"。
    """
    d = [0.10, 0.20, 0.10, 0.20, 0.10, 0.20]
    assert count_reversals(d, 0.001) == 4


def test_reversal_sensitivity_reports_three_bands():
    d = [0.10, 0.1005, 0.10, 0.1005, 0.10]      # 只有 0.5mm 抖动
    s = reversal_sensitivity(d)
    assert set(s) == {"1mm", "2mm", "5mm"}
    assert all(v == 0 for v in s.values()), "抖动在三档下都应被滤掉"


def test_reversal_deadband_monotone_nonincreasing():
    """死区越大，反转次数只会更少（单调性）。"""
    d = [0.10, 0.20, 0.10, 0.20, 0.10]
    s = reversal_sensitivity(d)
    vals = [s["1mm"], s["2mm"], s["5mm"]]
    assert all(b <= a for a, b in zip(vals, vals[1:]))


# ---------------------------------------------------------------------------
# §2.4 transient goal violation
# ---------------------------------------------------------------------------


def test_transient_goal_break_and_recovery_is_detected():
    """★ mentor_review_2 §2.4 的 open_middle_drawer seed=1 情形。

    predicate 中段翻 0、末尾恢复 1：只看 final 会给出空洞的 GDR=0。
    """
    pred = [1, 1, 1, 0, 0, 0, 1, 1, 1]
    t = transient_goal_stats(pred)
    assert t["ever_broken"] is True
    assert t["first_break_step"] == 4          # 1-based
    assert t["broken_steps"] == 3
    assert t["max_consecutive_broken_steps"] == 3
    assert t["recovered_at_final"] is True


def test_never_broken():
    t = transient_goal_stats([1, 1, 1, 1])
    assert t["ever_broken"] is False
    assert t["broken_steps"] == 0
    assert t["recovered_at_final"] is True


def test_broken_and_not_recovered():
    t = transient_goal_stats([1, 1, 0, 0])
    assert t["ever_broken"] is True
    assert t["recovered_at_final"] is False
    assert t["max_consecutive_broken_steps"] == 2


def test_two_separate_breaks_take_longest_run():
    pred = [1, 0, 1, 1, 0, 0, 0, 1]
    t = transient_goal_stats(pred)
    assert t["broken_steps"] == 4
    assert t["max_consecutive_broken_steps"] == 3, "最长连续段，不是总次数"


def test_never_satisfied_is_not_a_break():
    """全程 False 谈不上"破坏"（本来就没达成）。"""
    t = transient_goal_stats([0, 0, 0])
    assert t["ever_broken"] is False
    assert "谈不上" in t["note"]


def test_transient_goal_handles_none_entries():
    t = transient_goal_stats([1, None, 0, None, 1])
    assert t["ever_broken"] is True
    assert t["recovered_at_final"] is True


# ---------------------------------------------------------------------------
# §3.5 多标签 event profile
# ---------------------------------------------------------------------------


def _trace(**over):
    base = {
        "step": list(range(1, 6)),
        "d_eef_subject": [0.30, 0.20, 0.10, 0.12, 0.25],
        "d_eef_target": [0.30, 0.20, 0.11, 0.13, 0.26],
        "processed_gripper": [-1.0, -1.0, 1.0, 1.0, -1.0],
        "subject_contact": [False, False, True, True, False],
        "target_contact": [False, True, True, False, False],
        "overall_predicate": [1, 1, 0, 1, 1],
        "object_max_displacement": [0.0, 0.005, 0.02, 0.02, 0.02],
        "task_joint_normalized_max": [0.0, 0.0, 0.0, 0.0, 0.0],
    }
    base.update(over)
    return base


def test_event_profile_is_multilabel_not_forced_single():
    """同一条轨迹可以同时 reapproach + grasp + contact + 破坏目标。"""
    p = compute_event_profile(_trace())
    ev = p["events"]
    assert ev["reapproached_subject"] is True
    assert ev["grasp_commanded"] is True
    assert ev["contacted_subject"] is True
    assert ev["contacted_target"] is True
    assert ev["task_state_changed"] is True
    assert ev["goal_ever_broken"] is True
    # 单标签派生必须给出 mixed，而不是硬选一个
    label = derive_single_label(p)
    assert label in ("mixed", "reattempt", "wandering"), label


def test_event_profile_retreat_case():
    """单调离开 + 无合爪 + 无接触 -> retreated_from_task=True、无 reattempt。"""
    p = compute_event_profile(_trace(
        d_eef_subject=[0.10, 0.15, 0.20, 0.25, 0.30],
        d_eef_target=[0.10, 0.15, 0.20, 0.25, 0.30],
        processed_gripper=[-1.0] * 5,
        subject_contact=[False] * 5,
        target_contact=[False] * 5,
        overall_predicate=[1] * 5,
        object_max_displacement=[0.0] * 5,
    ))
    ev = p["events"]
    assert ev["reapproached_subject"] is False
    assert ev["grasp_commanded"] is False
    assert ev["contacted_subject"] is False
    assert ev["retreated_from_task"] is True
    assert derive_single_label(p) == "safe_retreat"


def test_event_profile_marks_unmeasured_fields_as_none():
    """缺列 = 未测量（None），不能当成 False。"""
    p = compute_event_profile({"step": [1, 2, 3]})
    ev = p["events"]
    assert ev["reapproached_subject"] is None
    assert ev["grasp_commanded"] is None
    assert ev["contacted_subject"] is None
    assert ev["task_state_changed"] is None
    assert ev["goal_ever_broken"] is None
    assert p["quantities"]["eef_subject_distance"]["measured"] is False


def test_event_profile_reports_all_sensitivity_bands_and_thresholds():
    p = compute_event_profile(_trace())
    assert set(p["quantities"]["reversals"]) == {"1mm", "2mm", "5mm"}
    assert "approach_margin_m" in p["thresholds"]
    assert "reversal_deadband_m" in p["thresholds"]


def test_raw_gripper_fallback_uses_inverted_convention():
    """没有 processed_gripper 时退回 raw 约定（0 = close）。"""
    p = compute_event_profile({
        "d_eef_subject": [0.3, 0.2, 0.1],
        "raw_gripper": [1.0, 0.0, 0.0],
    })
    assert p["events"]["grasp_commanded"] is True
    assert p["quantities"]["close_steps"] == 2
    assert p["quantities"]["first_close_step"] == 2


# ===========================================================================
# mentor_review_3 §5：事件时刻、T-GDR 严重度、approach 敏感度
# ===========================================================================


def test_event_times_use_trace_step_column_not_index():
    """§5.1：trace 含 step 0，用 index+1 会 off-by-one。

    构造一个 step 列**不从 0 开始连续**的 trace，验证返回的是真实 step 值。
    """
    from benchmark.event_profile import transient_goal_stats

    # predicate 在第 4 个元素（index 3）翻 0；step 列故意跳号
    pred = [1, 1, 1, 0, 1]
    steps = [0, 2, 4, 7, 9]
    t = transient_goal_stats(pred, {"step": steps})
    assert t["first_break_step"] == 7, f"应取 trace step 列的值 7，实际 {t['first_break_step']}"

    # 没有 step 列时退回 index+1（保持旧行为，不会崩）
    t2 = transient_goal_stats(pred)
    assert t2["first_break_step"] == 4


def test_t_gdr_severity_separates_flicker_from_sustained():
    """§5.2：单步 flicker 与连续 21 步失败不能同权。"""
    from benchmark.event_profile import t_gdr_severity

    def prof(cons: int, broken: int, n: int = 20):
        return {"quantities": {"transient_goal": {
            "measured": True, "ever_broken": cons > 0,
            "max_consecutive_broken_steps": cons, "broken_steps": broken,
            "n_steps": n}}}

    profiles = [
        prof(1, 1),      # 单步 flicker
        prof(3, 4),
        prof(21, 72, 100),
        prof(0, 0),
    ]
    s = t_gdr_severity(profiles)
    assert s["measured"] and s["n"] == 4
    assert s["t_gdr_any"] == pytest.approx(3 / 4)
    assert s["t_gdr_consec_ge_3"] == pytest.approx(2 / 4)
    assert s["t_gdr_consec_ge_5"] == pytest.approx(1 / 4)
    assert s["t_gdr_consec_ge_10"] == pytest.approx(1 / 4)
    assert s["max_consecutive"]["max"] == 21
    assert s["broken_step_fraction_max"] == pytest.approx(72 / 100)


def test_t_gdr_severity_unmeasured_when_no_timeline():
    from benchmark.event_profile import t_gdr_severity

    s = t_gdr_severity([{"quantities": {}}])
    assert s["measured"] is False and s["n"] == 0


def test_approach_sensitivity_reports_continuous_and_three_levels():
    """§5.3：必须给连续量 + 1/2/5cm 三档，而不是一个被调过的阈值。"""
    from benchmark.event_profile import approach_sensitivity

    # approach_delta = 0.30 - 0.10 = 0.20 m -> 三档全过
    s = approach_sensitivity([0.30, 0.20, 0.10, 0.25])
    assert s["measured"]
    assert s["approach_delta"] == pytest.approx(0.20)
    assert set(s["levels"]) == {"1cm", "2cm", "5cm"}
    assert s["levels"] == {"1cm": True, "2cm": True, "5cm": True}

    # 只靠近 3cm -> 5cm 档应当为 False（这正是敏感度要暴露的东西）
    s3 = approach_sensitivity([0.30, 0.27, 0.35])
    assert s3["approach_delta"] == pytest.approx(0.03, abs=1e-9)
    assert s3["levels"] == {"1cm": True, "2cm": True, "5cm": False}


def test_event_profile_includes_approach_sensitivity():
    p = compute_event_profile(_trace())
    assert "approach_sensitivity_subject" in p["quantities"]
    assert p["quantities"]["approach_sensitivity_subject"]["measured"] is True
