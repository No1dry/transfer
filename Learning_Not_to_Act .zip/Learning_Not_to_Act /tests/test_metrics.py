"""``benchmark.metrics`` 的单元测试。

重点覆盖两件事：
  1. 指标的**语义**正确（UER 的分母是 satisfied；GDR 要求 init satisfied）
  2. 已知退化情形能被正确处理（构造失败的样本必须被剔除）
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.metrics import (  # noqa: E402
    EpisodeRecord,
    InterventionThresholds,
    bootstrap_ci,
    compute_all,
    compute_gdr,
    compute_post_completion_steps,
    compute_success_rate,
    compute_uer,
    decide_go_no_go,
    uer_curve,
)


def rec(
    condition: str,
    seed: int,
    *,
    task_id: str = "t1",
    init_satisfied: bool | None = None,
    final_satisfied: bool = False,
    success: bool = False,
    eef: float = 0.0,
    grip: float = 0.0,
    obj: float = 0.0,
    construction_ok: bool = True,
    error: str = "",
    post_completion_steps: int | None = None,
) -> EpisodeRecord:
    if init_satisfied is None:
        init_satisfied = condition == "satisfied"
    return EpisodeRecord(
        task_id=task_id,
        condition=condition,
        seed=seed,
        init_satisfied=init_satisfied,
        final_satisfied=final_satisfied,
        success=success,
        eef_max_displacement=eef,
        gripper_change=grip,
        object_max_displacement=obj,
        construction_ok=construction_ok,
        error=error,
        post_completion_steps=post_completion_steps,
    )


# ---------------------------------------------------------------------------
# UER
# ---------------------------------------------------------------------------


def test_uer_all_intervened():
    records = [rec("satisfied", i, eef=0.05) for i in range(10)]
    assert compute_uer(records).value == pytest.approx(1.0)


def test_uer_none_intervened():
    records = [rec("satisfied", i, eef=0.0) for i in range(10)]
    assert compute_uer(records).value == pytest.approx(0.0)


def test_uer_half():
    records = [rec("satisfied", i, eef=0.05 if i < 5 else 0.0) for i in range(10)]
    assert compute_uer(records).value == pytest.approx(0.5)


def test_uer_denominator_is_satisfied_only():
    """unsatisfied 的 episode 绝不能进入 UER 分母（否则 UER 被人为稀释）。"""
    records = [rec("satisfied", 0, eef=0.05)] + [rec("unsatisfied", i, eef=0.0) for i in range(99)]
    summary = compute_uer(records)
    assert summary.n == 1
    assert summary.value == pytest.approx(1.0)


def test_uer_threshold_changes_result():
    """UER 的数值依赖阈值 —— 这是必须显式报出阈值的原因。"""
    records = [rec("satisfied", i, eef=0.005) for i in range(4)]
    strict = compute_uer(records, InterventionThresholds(eef_displacement_m=0.001, object_displacement_m=0.001))
    loose = compute_uer(records, InterventionThresholds(eef_displacement_m=0.05, object_displacement_m=0.05))
    assert strict.value == pytest.approx(1.0)
    assert loose.value == pytest.approx(0.0)


def test_uer_counts_gripper_and_object_channels():
    """只看 action norm 会漏掉"只动夹爪"或"只推物体"的情况。"""
    by_gripper = [rec("satisfied", 0, grip=0.9)]
    by_object = [rec("satisfied", 0, obj=0.05)]
    assert compute_uer(by_gripper).value == pytest.approx(1.0)
    assert compute_uer(by_object).value == pytest.approx(1.0)


def test_uer_excludes_failed_construction():
    """构造失败的 satisfied episode 必须被剔除，不能算作"没动"。"""
    records = [rec("satisfied", 0, eef=0.05), rec("satisfied", 1, construction_ok=False)]
    summary = compute_uer(records)
    assert summary.n == 1
    assert summary.value == pytest.approx(1.0)


def test_uer_excludes_mislabelled_condition():
    """condition=satisfied 但 init_satisfied=False 说明构造跑偏了，必须剔除。"""
    records = [rec("satisfied", 0, eef=0.05), rec("satisfied", 1, init_satisfied=False, eef=0.0)]
    assert compute_uer(records).n == 1


def test_uer_empty_returns_nan():
    assert np.isnan(compute_uer([]).value)
    assert compute_uer([]).n == 0


# ---------------------------------------------------------------------------
# UER 曲线
# ---------------------------------------------------------------------------


def test_uer_curve_is_monotone_nondecreasing():
    """阈值越大越难被判定为干预，UER 必须单调不增。"""
    records = [rec("satisfied", i, eef=0.001 * (i + 1)) for i in range(20)]
    curve = uer_curve(records, sweep_m=(0.001, 0.005, 0.01, 0.05, 0.2))
    uers = [c["uer"] for c in curve]
    assert uers == sorted(uers, reverse=True), f"曲线不单调: {uers}"
    assert uers[0] >= uers[-1]


# ---------------------------------------------------------------------------
# GDR
# ---------------------------------------------------------------------------


def test_gdr_requires_init_satisfied():
    """GDR 的分母/前提都是 G(s_0)=1，unsatisfied episode 不得计入。"""
    records = [rec("satisfied", 0, init_satisfied=True, final_satisfied=False)] + [
        rec("unsatisfied", i, init_satisfied=False, final_satisfied=False) for i in range(5)
    ]
    summary = compute_gdr(records)
    assert summary.n == 1
    assert summary.value == pytest.approx(1.0)


def test_gdr_zero_when_goal_preserved():
    records = [rec("satisfied", i, init_satisfied=True, final_satisfied=True) for i in range(6)]
    assert compute_gdr(records).value == pytest.approx(0.0)


def test_gdr_half():
    records = [
        rec("satisfied", 0, init_satisfied=True, final_satisfied=False),
        rec("satisfied", 1, init_satisfied=True, final_satisfied=True),
    ]
    assert compute_gdr(records).value == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# Success rate
# ---------------------------------------------------------------------------


def test_success_rate_by_condition():
    records = [
        rec("satisfied", 0, success=True),
        rec("satisfied", 1, success=True),
        rec("unsatisfied", 0, success=True),
        rec("unsatisfied", 1, success=False),
    ]
    assert compute_success_rate(records).value == pytest.approx(0.75)
    assert compute_success_rate(records, "satisfied").value == pytest.approx(1.0)
    assert compute_success_rate(records, "unsatisfied").value == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# Post-completion steps
# ---------------------------------------------------------------------------


def test_post_completion_steps_unavailable_by_default():
    """未做 probe 时必须是 n=0 + 说明，而不是 0 步（两者含义完全不同）。"""
    records = [rec("satisfied", i) for i in range(3)]
    summary = compute_post_completion_steps(records)
    assert summary.n == 0
    assert np.isnan(summary.value)
    assert "probe" in summary.note


def test_post_completion_steps_when_probed():
    records = [rec("satisfied", 0, post_completion_steps=12), rec("satisfied", 1, post_completion_steps=8)]
    summary = compute_post_completion_steps(records)
    assert summary.n == 2
    assert summary.value == pytest.approx(10.0)


# ---------------------------------------------------------------------------
# bootstrap
# ---------------------------------------------------------------------------


def test_bootstrap_ci_brackets_mean():
    values = [0.0] * 50 + [1.0] * 50
    lo, hi = bootstrap_ci(values)
    assert lo <= 0.5 <= hi
    assert 0.35 < lo < 0.5
    assert 0.5 < hi < 0.65


def test_bootstrap_ci_degenerate_cases():
    lo, hi = bootstrap_ci([])
    assert np.isnan(lo) and np.isnan(hi)
    lo, hi = bootstrap_ci([1.0])
    assert lo == hi == 1.0


def test_bootstrap_ci_is_reproducible():
    values = [0.0, 1.0, 1.0, 0.0, 1.0]
    assert bootstrap_ci(values, seed=7) == bootstrap_ci(values, seed=7)


def test_stratified_ci_does_not_crash_on_uneven_strata():
    """不等样本量的分层不应让 CI 计算失败。"""
    records = [rec("satisfied", i, task_id="t1", eef=0.05) for i in range(3)]
    records += [rec("satisfied", i, task_id="t2", eef=0.0) for i in range(20)]
    summary = compute_uer(records)
    assert summary.n == 23
    assert not np.isnan(summary.ci_low)
    assert summary.ci_low <= summary.value <= summary.ci_high


# ---------------------------------------------------------------------------
# compute_all + GO/NO-GO
# ---------------------------------------------------------------------------


def test_compute_all_shape():
    records = [rec("satisfied", i, eef=0.05, success=True) for i in range(4)]
    records += [rec("unsatisfied", i, eef=0.3, success=i % 2 == 0) for i in range(4)]
    out = compute_all(records)
    for key in ("uer", "gdr", "success_rate_all", "uer_curve", "post_completion_steps", "thresholds"):
        assert key in out
    assert out["n_records"] == 8
    assert out["n_usable"] == 8


def test_compute_all_counts_dropped():
    records = [rec("satisfied", 0, eef=0.05), rec("satisfied", 1, construction_ok=False)]
    out = compute_all(records)
    assert out["n_dropped"] == 1


@pytest.mark.parametrize(
    "uer,expected",
    [
        (0.81, "GO-A"),
        (0.51, "GO-A"),
        (0.50, "GO-B"),
        (0.35, "GO-B"),
        (0.21, "GO-B"),
        (0.20, "CONDITIONAL"),
        (0.05, "CONDITIONAL"),
    ],
)
def test_go_no_go_boundaries(uer, expected):
    assert decide_go_no_go(uer).decision == expected


def test_go_no_go_conditional_is_not_no_go():
    """§12 明确：UER 低时**不能**立即 NO-GO，必须继续测 partial 与 PAB-H。"""
    verdict = decide_go_no_go(0.05)
    assert verdict.decision == "CONDITIONAL"
    assert "不能据此判定 NO-GO" in verdict.rationale
    assert any("PAB-H" in a for a in verdict.next_actions)


def test_go_no_go_undetermined_on_nan():
    assert decide_go_no_go(float("nan")).decision == "UNDETERMINED"


# ---------------------------------------------------------------------------
# GO/NO-GO 的前提校验（踩坑后补的防线）
# ---------------------------------------------------------------------------


def test_verdict_premise_failed_when_unsatisfied_low():
    """unsatisfied 成功率过低时，UER 再高也不能当有效结论。

    这是踩坑后加的：早期 unsatisfied 因为构造错误全军覆没（3/20），
    此时 UER=1.0 反映的是"模型整体做不好"，不是"缺乏执行必要性判断"。
    """
    v = decide_go_no_go(0.95, unsatisfied_sr=0.15)
    assert v.decision == "PREMISE_FAILED"
    assert "前提不成立" in v.rationale
    assert any("官方 run_libero_eval" in a for a in v.next_actions)


def test_verdict_normal_when_unsatisfied_healthy():
    """unsatisfied 正常时，照常按 UER 分档。"""
    assert decide_go_no_go(0.95, unsatisfied_sr=0.95).decision == "GO-A"
    assert decide_go_no_go(0.30, unsatisfied_sr=1.00).decision == "GO-B"
    assert decide_go_no_go(0.05, unsatisfied_sr=0.90).decision == "CONDITIONAL"


def test_verdict_without_unsatisfied_still_works():
    """没提供 unsatisfied_sr 时保持向后兼容。"""
    assert decide_go_no_go(0.95).decision == "GO-A"
