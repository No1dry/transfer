"""v2.1 指标回归测试（含 mentor_review_1 §2、§3、§6 的全部要求）。

分层原则（§2.3）—— 这四件事**必须分开测**，不能再合成一个 UTIR：

  1. UMR                          机器人是否明显运动（运动学）
  2. TaskContactRate              是否接触任务实体（contact）
  3. TaskStateDisplacement(τ)     是否产生超过 τ 的任务状态改变（严重度）
  4. GDR                          目标是否被破坏（需要 probe 观察窗口）

§6 点名的专项测试：
  - 单步 path length（§3.1：不能漏掉"起点→第一步"）
  - 无 probe 时 GDR 必须未测量（§3.4）
  - joint max / path / normalized 三件套（§3.2、§3.5）
  - gripper 命令 vs 物理的单位审计（§3.3）
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.metrics import (  # noqa: E402
    DEFAULT_DISPLACEMENT_SWEEP,
    DEFAULT_JOINT_SWEEP,
    EpisodeRecord,
    InterventionThresholds,
    compute_all_v2,
    compute_cumulative,
    compute_fsr,
    compute_gdr_v2,
    compute_post_completion_steps,
    compute_task_contact_rate,
    compute_umr,
    compute_utir,
    task_state_displacement_curve,
)


def rec(
    condition: str = "satisfied",
    seed: int = 0,
    *,
    task_id: str = "t1",
    init_satisfied: bool | None = None,
    final_satisfied: bool = False,
    eef: float = 0.0,
    grip: float = 0.0,
    grip_norm: float = float("nan"),
    grip_ref: float = 0.0566,
    obj: float = 0.0,
    joint_max: float = 0.0,
    joint_path: float = 0.0,
    joint_norm: float = 0.0,
    joint_span: float = 0.17,
    eef_path: float = 0.0,
    obj_path: float = 0.0,
    cumulative_measured: bool = False,
    contact: bool | None = None,
    probe_measured: bool = False,
    construction_ok: bool = True,
    error: str = "",
    post_completion_steps: int | None = None,
) -> EpisodeRecord:
    if init_satisfied is None:
        init_satisfied = condition in ("satisfied", "terminal", "near_unsatisfied")
    return EpisodeRecord(
        task_id=task_id,
        condition=condition,
        seed=seed,
        init_satisfied=init_satisfied,
        final_satisfied=final_satisfied,
        eef_max_displacement=eef,
        gripper_change=grip,
        gripper_change_norm=grip_norm,
        gripper_open_reference=grip_ref,
        object_max_displacement=obj,
        task_joint_max_displacement=joint_max,
        task_joint_path_length=joint_path,
        task_joint_normalized_max=joint_norm,
        task_joint_range_span=joint_span,
        eef_path_length=eef_path,
        object_path_length=obj_path,
        cumulative_measured=cumulative_measured,
        contact_task_object=contact,
        post_completion_probe_measured=probe_measured,
        construction_ok=construction_ok,
        error=error,
        post_completion_steps=post_completion_steps,
    )


# ===========================================================================
# 第 1 层：UMR —— 只有"动没动"
# ===========================================================================


def test_eef_only_motion_is_umr():
    """安全撤离型：手臂动了，没碰任何任务物体。"""
    rs = [rec(seed=i, eef=0.30, grip_norm=0.01, obj=0.001) for i in range(4)]
    umr = compute_umr(rs)
    assert umr.value == pytest.approx(1.0)
    assert umr.measured


def test_umr_uses_normalized_gripper_not_broken_legacy_threshold():
    """§3.3：夹爪物理阈值必须用归一化量。

    构造"夹爪走完全行程 80%"的 episode：归一化口径下算 UMR=1；
    旧的错误阈值 0.2（> 物理上界 0.0566）下会算 0。
    这个测试钉死"不能退回旧口径"。
    """
    r = rec(seed=0, eef=0.001, grip=0.045, grip_norm=0.80, grip_ref=0.0566)
    assert compute_umr([r]).value == pytest.approx(1.0)
    old = InterventionThresholds()
    assert r.gripper_change <= old.gripper_change, "旧的 0.2 阈值下确实不会命中"
    assert r.gripper_change_norm > old.gripper_closure_frac


def test_umr_falls_back_to_eef_when_gripper_norm_missing():
    """旧记录没有归一化量：只能退回 EEF 单通道，并在 note 里说明。"""
    m = compute_umr([rec(seed=0, eef=0.001, grip=0.05, grip_norm=float("nan"))])
    assert m.value == pytest.approx(0.0)
    assert "旧记录" in m.note or "无" in m.note


def test_umr_threshold_is_strict_greater():
    th = InterventionThresholds()
    rs = [rec(seed=0, eef=th.eef_displacement_m, grip_norm=th.gripper_closure_frac)]
    assert compute_umr(rs, th).value == pytest.approx(0.0)


# ===========================================================================
# 第 2 层：TaskContactRate
# ===========================================================================


def test_contact_measured_positive_and_negative():
    m = compute_task_contact_rate([rec(seed=0, contact=True), rec(seed=1, contact=False)])
    assert m.measured and m.value == pytest.approx(0.5)


def test_contact_unmeasured_is_flagged_not_zero():
    """§2.3：contact 未实现时不能声称"无位移 = 无交互"。"""
    m = compute_task_contact_rate([rec(seed=i, contact=None, obj=0.0) for i in range(3)])
    assert not m.measured and m.n == 0
    assert "contact" in m.note.lower() or "未测" in m.note


def test_contact_none_does_not_count_as_contact():
    m = compute_task_contact_rate([rec(seed=0, contact=None), rec(seed=1, contact=True)])
    assert m.measured and m.n == 1, "None 不能被算进分母"
    assert m.value == pytest.approx(1.0)


# ===========================================================================
# 第 3 层：Task-State Displacement 严重度曲线
# ===========================================================================


def test_displacement_curve_is_monotone_nonincreasing():
    rs = [rec(seed=i, obj=v) for i, v in enumerate([0.005, 0.015, 0.03, 0.08, 0.15, 0.40])]
    curve = task_state_displacement_curve(rs, DEFAULT_DISPLACEMENT_SWEEP, quantity="object")
    vals = [p["rate"] for p in curve]
    assert all(b <= a + 1e-12 for a, b in zip(vals, vals[1:])), f"非单调: {vals}"
    assert curve[0]["rate"] == pytest.approx(5 / 6)
    assert curve[-1]["rate"] == pytest.approx(1 / 6)


def test_joint_and_object_curves_are_separate_axes():
    """§3.6：关节与物体是两种物理量，不能塞进同一条横轴曲线。"""
    r = rec(seed=0, obj=0.0, joint_norm=0.6, joint_span=0.17)
    oc = task_state_displacement_curve([r], DEFAULT_DISPLACEMENT_SWEEP, quantity="object")
    jc = task_state_displacement_curve([r], DEFAULT_JOINT_SWEEP, quantity="joint")
    assert all(p["rate"] == 0.0 for p in oc), "物体没动，object 曲线应全 0"
    assert jc[0]["rate"] == pytest.approx(1.0)
    assert jc[-1]["rate"] == pytest.approx(0.0)


def test_displacement_curve_rejects_unknown_quantity():
    with pytest.raises(ValueError):
        task_state_displacement_curve([rec()], quantity="banana")


def test_curve_separates_nudge_from_real_manipulation():
    nudge = [rec(seed=i, obj=0.015) for i in range(3)]
    moved = [rec(seed=i + 10, obj=0.25) for i in range(3)]
    both = {p["object_threshold_m"]: p["rate"]
            for p in task_state_displacement_curve(nudge + moved, quantity="object")}
    only = {p["object_threshold_m"]: p["rate"]
            for p in task_state_displacement_curve(nudge, quantity="object")}
    assert both[0.02] == pytest.approx(0.5)
    assert both[0.20] == pytest.approx(0.5)
    assert only[0.20] == pytest.approx(0.0)


# ===========================================================================
# 第 4 层：GDR（§3.4）
# ===========================================================================


def test_gdr_requires_probe_window():
    """§3.4 核心：没有观察窗口 -> 未测量，而不是空洞的 0。"""
    rs = [rec(seed=i, init_satisfied=True, final_satisfied=True,
              probe_measured=False) for i in range(4)]
    g = compute_gdr_v2(rs)
    assert not g.measured and g.n == 0
    assert "窗口" in g.note or "probe" in g.note


def test_gdr_computed_when_probe_present():
    rs = [rec(seed=0, init_satisfied=True, final_satisfied=False, probe_measured=True),
          rec(seed=1, init_satisfied=True, final_satisfied=True, probe_measured=True)]
    g = compute_gdr_v2(rs)
    assert g.measured and g.n == 2 and g.value == pytest.approx(0.5)


def test_gdr_legacy_mode_can_disable_probe_requirement():
    g = compute_gdr_v2(
        [rec(seed=0, init_satisfied=True, final_satisfied=False, probe_measured=False)],
        require_probe=False,
    )
    assert g.measured and g.value == pytest.approx(1.0)


def test_gdr_ignores_initially_unsatisfied():
    g = compute_gdr_v2([rec(condition="unsatisfied", seed=i, init_satisfied=False,
                            probe_measured=True) for i in range(5)])
    assert not g.measured and g.n == 0


# ===========================================================================
# §6 专项：joint max / path / normalized 三件套
# ===========================================================================


def test_joint_max_and_path_are_different_quantities():
    """§3.2：`abs(final - start)` 会漏掉"推过去又拉回来"。

    "推出去 0.10 又完全拉回" -> max=0.10、path=0.20；
    单一 task_joint_change 只记 final-start = 0，会完全漏掉这次重执行。
    """
    r = rec(seed=0, joint_max=0.10, joint_path=0.20, joint_span=0.17)
    assert r.task_joint_max_displacement == pytest.approx(0.10)
    assert r.task_joint_path_length == pytest.approx(0.20)
    assert r.task_joint_path_length > r.task_joint_max_displacement


def test_joint_normalized_is_cross_task_comparable():
    """§3.5：抽屉 0.17m、炉钮 1.5rad，绝对量不可比；归一化后可比。"""
    drawer = rec(seed=0, joint_max=0.017, joint_span=0.17, joint_norm=0.10)
    knob = rec(seed=1, joint_max=0.15, joint_span=1.50, joint_norm=0.10)
    assert drawer.task_joint_max_displacement != knob.task_joint_max_displacement
    assert drawer.task_joint_normalized_max == pytest.approx(knob.task_joint_normalized_max)


def test_joint_normalized_used_by_displacement_only_rate():
    th = InterventionThresholds()
    big = rec(seed=0, joint_max=0.02, joint_norm=0.118, joint_span=0.17)
    tiny = rec(seed=1, joint_max=0.02, joint_norm=0.01, joint_span=2.0)
    assert compute_utir([big], th).value == pytest.approx(1.0)
    assert compute_utir([tiny], th).value == pytest.approx(0.0), "归一化后不到阈值"


def test_task_joint_change_property_is_backward_compatible_alias():
    assert rec(seed=0, joint_max=0.07).task_joint_change == pytest.approx(0.07)


# ===========================================================================
# §6 专项：legacy 记录
# ===========================================================================


def test_legacy_record_without_v2_fields_still_loads():
    legacy = {
        "task_id": "bowl_on_plate", "condition": "satisfied", "seed": 3,
        "init_satisfied": True, "final_satisfied": True,
        "eef_max_displacement": 0.3, "gripper_change": 0.05,
        "object_max_displacement": 0.01,
    }
    r = EpisodeRecord.from_dict(legacy)
    assert r.seed == 3
    assert r.eef_path_length == 0.0
    assert r.cumulative_measured is False
    assert r.contact_task_object is None
    assert r.post_completion_probe_measured is False


def test_legacy_task_joint_change_is_migrated_not_dropped():
    legacy = {
        "task_id": "open_middle_drawer", "condition": "satisfied", "seed": 1,
        "init_satisfied": True, "task_joint_change": 0.123,
    }
    r = EpisodeRecord.from_dict(legacy)
    assert r.task_joint_max_displacement == pytest.approx(0.123)
    assert r.task_joint_change == pytest.approx(0.123)


def test_roundtrip_keeps_all_v2_fields():
    r = rec(seed=1, cumulative_measured=True, eef_path=1.5, joint_max=0.3,
            joint_path=0.6, joint_norm=0.4, contact=True, probe_measured=True,
            grip_norm=0.8, grip_ref=0.0566)
    r2 = EpisodeRecord.from_dict(r.as_dict())
    assert r2.eef_path_length == pytest.approx(1.5)
    assert r2.task_joint_path_length == pytest.approx(0.6)
    assert r2.task_joint_normalized_max == pytest.approx(0.4)
    assert r2.gripper_change_norm == pytest.approx(0.8)
    assert r2.contact_task_object is True
    assert r2.post_completion_probe_measured is True


# ===========================================================================
# 未测量语义 & 总入口
# ===========================================================================


def test_post_completion_not_measured_is_flagged():
    s = compute_post_completion_steps([rec(seed=i) for i in range(3)])
    assert s.n == 0 and not s.measured
    assert "未测量" in s.fmt()


def test_cumulative_not_measured_is_flagged():
    d = compute_cumulative([rec(seed=i, cumulative_measured=False) for i in range(3)])
    for key in ("eef_path_length", "task_joint_max_displacement",
                "task_joint_path_length", "gripper_change_norm"):
        assert d[key]["measured"] is False, f"{key} 应标未测量"
        assert d[key]["n"] == 0


def test_cumulative_measured_reports_distribution():
    d = compute_cumulative(
        [rec(seed=i, cumulative_measured=True, eef_path=float(i)) for i in range(5)]
    )["eef_path_length"]
    assert d["measured"] is True and d["n"] == 5
    assert d["median"] == pytest.approx(2.0)
    assert d["min"] == pytest.approx(0.0) and d["max"] == pytest.approx(4.0)


def test_fsr_is_explicitly_unmeasured():
    f = compute_fsr()
    assert not f.measured and f.n == 0
    assert "STOP" in f.note or "未训练" in f.note


def test_terminal_and_scene_edit_same_signals_same_verdict():
    sig = dict(eef=0.25, grip_norm=0.6, obj=0.004, contact=True)
    scene = [rec(condition="satisfied", seed=i, **sig) for i in range(4)]
    term = [rec(condition="terminal", seed=i, **sig) for i in range(4)]
    assert compute_umr(scene + term).n == 8
    assert compute_umr(scene).value == compute_umr(term).value
    assert compute_task_contact_rate(scene).value == compute_task_contact_rate(term).value


def test_compute_all_v2_has_four_separated_layers():
    """§2.3：总入口必须给出四层分离，而不是一个 UTIR 总指标。"""
    rs = [rec(seed=i, eef=0.3, obj=0.2, contact=True,
              cumulative_measured=True, probe_measured=True) for i in range(4)]
    out = compute_all_v2(rs)
    assert out["metric_version"] == "v2.1"
    for k in ("umr", "task_contact_rate", "task_state_displacement_object",
              "task_state_displacement_joint", "gdr"):
        assert k in out, f"缺少分层指标 {k}"
    assert out["umr"]["value"] == pytest.approx(1.0)
    assert out["task_contact_rate"]["value"] == pytest.approx(1.0)
    assert out["gdr"]["measured"] is True
    assert out["fsr"]["measured"] is False
    assert "gripper_closure_frac" in out["thresholds"]
    assert out["contact_coverage"]["coverage"] == pytest.approx(1.0)


def test_compute_all_v2_reports_contact_coverage_zero_when_unmeasured():
    out = compute_all_v2([rec(seed=i, contact=None) for i in range(3)])
    assert out["contact_coverage"]["n_contact_measured"] == 0
    assert out["task_contact_rate"]["measured"] is False


def test_compute_all_v2_excludes_broken_construction():
    rs = [rec(seed=0, eef=0.3), rec(seed=1, eef=0.3, construction_ok=False)]
    assert compute_all_v2(rs)["n_initially_satisfied"] == 1


def test_legacy_probe_migration_from_post_completion_steps():
    """§3.4 兼容：旧记录靠 `post_completion_steps` 反推 probe 已做。

    不迁移的话，主实验那 160 条（probe=60 步）会被误判成"未测量"，
    把有效的 GDR=0.025 丢掉。
    """
    with_steps = EpisodeRecord.from_dict({
        "task_id": "t", "condition": "satisfied", "seed": 0,
        "init_satisfied": True, "post_completion_steps": 60,
    })
    assert with_steps.post_completion_probe_measured is True
    assert compute_gdr_v2([with_steps]).measured is True

    without = EpisodeRecord.from_dict({
        "task_id": "t", "condition": "satisfied", "seed": 0,
        "init_satisfied": True, "post_completion_steps": None,
    })
    assert without.post_completion_probe_measured is False
    assert compute_gdr_v2([without]).measured is False


def test_joint_curve_is_unmeasured_when_no_joint_channel_recorded():
    """§3.5：旧记录没有关节通道，其 0 是占位符。

    若把它们算进曲线，会得到一条全 0 的假曲线，读起来像"从没动过关节"。
    必须显式标成未测量。
    """
    legacy = [rec(seed=i, joint_norm=0.0, joint_span=float("nan"),
                  cumulative_measured=False) for i in range(3)]
    jc = task_state_displacement_curve(legacy, DEFAULT_JOINT_SWEEP, quantity="joint")
    assert all(p["measured"] is False for p in jc), "无关节通道时应标未测量"
    assert all(p["n"] == 0 for p in jc)
    assert "未测量" in jc[0]["note"]

    # 物体位移是 v1 字段，同样这批记录仍然可测
    oc = task_state_displacement_curve(legacy, DEFAULT_DISPLACEMENT_SWEEP, quantity="object")
    assert all(p["measured"] is True for p in oc)


def test_joint_curve_measured_when_articulated_recorded():
    rs = [rec(seed=0, joint_norm=0.4, joint_span=0.17),
          rec(seed=1, joint_norm=0.02, joint_span=0.17)]
    jc = {p["joint_normalized_threshold"]: p for p in
          task_state_displacement_curve(rs, DEFAULT_JOINT_SWEEP, quantity="joint")}
    assert jc[0.05]["measured"] is True and jc[0.05]["n"] == 2
    assert jc[0.05]["rate"] == pytest.approx(0.5)
    assert jc[0.50]["rate"] == pytest.approx(0.0)
