"""``benchmark.states.mujoco_state`` 的单元测试。

这些测试**不需要 MuJoCo / robosuite / LIBERO**，用 tests/fake_mujoco.py 里的
假模型即可验证下标运算、四元数保持、速度清零、几何推算等纯逻辑。
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.states import mujoco_state as ms  # noqa: E402
from tests.fake_mujoco import build_fake_model, make_state  # noqa: E402


@pytest.fixture()
def scene():
    model, data = build_fake_model()
    state = make_state(model, data)
    return model, data, state


# ---------------------------------------------------------------------------
# StateLayout
# ---------------------------------------------------------------------------


def test_state_layout_dimensions(scene):
    model, _, state = scene
    layout = ms.StateLayout.from_model(model)

    # robot(7) + gripper(2) + 4 free objects * 7
    assert layout.nq == 7 + 2 + 4 * 7
    # robot(7) + gripper(2) + 4 free objects * 6
    assert layout.nv == 7 + 2 + 4 * 6
    assert layout.na == 0
    assert layout.total_dim == 1 + layout.nq + layout.nv
    assert len(state) == layout.total_dim


def test_state_layout_mismatch_raises(scene):
    model, _, state = scene
    with pytest.raises(ValueError, match="状态长度"):
        ms.StateLayout.from_state(state[:-1], model)


def test_qpos_slice_matches_robot_joints(scene):
    model, data, state = scene
    layout = ms.StateLayout.from_model(model)
    qpos = ms.get_qpos(state, layout)
    # 前 9 个是机器人关节
    assert np.allclose(qpos[:9], data.qpos[:9])


# ---------------------------------------------------------------------------
# 关节发现
# ---------------------------------------------------------------------------


def test_iter_joints_counts(scene):
    model, _, _ = scene
    joints = ms.iter_joints(model)
    assert len(joints) == 9 + 4
    assert sum(j.is_free for j in joints) == 4


def test_resolve_free_joint_by_prefix(scene):
    model, _, _ = scene
    j = ms.resolve_free_joint(model, "akita_black_bowl_1")
    assert j.name == "akita_black_bowl_1_joint_0"
    assert j.is_free
    assert j.qpos_dim == 7
    assert j.dof_dim == 6


def test_resolve_free_joint_unknown_raises(scene):
    model, _, _ = scene
    with pytest.raises(KeyError, match="找不到自由关节"):
        ms.resolve_free_joint(model, "no_such_object")


def test_resolve_single_dof_rejects_free_joint(scene):
    """自由关节不应被当作单自由度关节解析（否则会写坏 qpos）。"""
    model, _, _ = scene
    with pytest.raises(KeyError):
        ms.resolve_single_dof_joint(model, "akita_black_bowl_1")


# ---------------------------------------------------------------------------
# 位置读写
# ---------------------------------------------------------------------------


def test_get_object_pos(scene):
    model, _, state = scene
    pos = ms.get_object_pos(state, model, "akita_black_bowl_1")
    assert np.allclose(pos, [-0.09, 0.0, 0.44])


def test_set_object_pos_is_pure(scene):
    """set_object_pos 不能修改传入的 state（避免隐蔽的别名 bug）。"""
    model, _, state = scene
    before = state.copy()
    new_state = ms.set_object_pos(state, model, "akita_black_bowl_1", [0.04, -0.02, 0.45])
    assert np.array_equal(state, before), "入参 state 被就地修改了"
    assert np.allclose(ms.get_object_pos(new_state, model, "akita_black_bowl_1"), [0.04, -0.02, 0.45])


def test_set_object_pos_keeps_quaternion(scene):
    model, _, state = scene
    joint = ms.resolve_free_joint(model, "akita_black_bowl_1")
    layout = ms.StateLayout.from_model(model)

    # 先给一个非 identity 的四元数
    custom = ms.set_object_quat(state, model, "akita_black_bowl_1", [0.5, 0.5, 0.5, 0.5])
    qpos = ms.get_qpos(custom, layout)
    quat_before = qpos[joint.qpos_adr + 3 : joint.qpos_adr + 7].copy()

    moved = ms.set_object_pos(custom, model, "akita_black_bowl_1", [0.1, 0.1, 0.5])
    qpos2 = ms.get_qpos(moved, layout)
    quat_after = qpos2[joint.qpos_adr + 3 : joint.qpos_adr + 7]

    assert np.allclose(quat_before, quat_after), "移动位置时朝向被改动了"


def test_set_object_pos_does_not_touch_other_objects(scene):
    model, _, state = scene
    plate_before = ms.get_object_pos(state, model, "plate_1")
    moved = ms.set_object_pos(state, model, "akita_black_bowl_1", [0.2, 0.2, 0.5])
    assert np.allclose(ms.get_object_pos(moved, model, "plate_1"), plate_before)


def test_set_object_quat_normalizes(scene):
    model, _, state = scene
    joint = ms.resolve_free_joint(model, "plate_1")
    layout = ms.StateLayout.from_model(model)
    out = ms.set_object_quat(state, model, "plate_1", [2.0, 0.0, 0.0, 0.0])
    quat = ms.get_qpos(out, layout)[joint.qpos_adr + 3 : joint.qpos_adr + 7]
    assert np.isclose(np.linalg.norm(quat), 1.0)


def test_set_object_quat_rejects_zero(scene):
    model, _, state = scene
    with pytest.raises(ValueError, match="范数"):
        ms.set_object_quat(state, model, "plate_1", [0.0, 0.0, 0.0, 0.0])


# ---------------------------------------------------------------------------
# 关节读写（抽屉）
# ---------------------------------------------------------------------------


def test_joint_read_write_with_drawer():
    model, data = build_fake_model(drawer=True)
    state = make_state(model, data)

    name = "wooden_cabinet_1_middle_level"
    assert ms.get_joint_pos(state, model, name) == pytest.approx(0.0)

    state2 = ms.set_joint_pos(state, model, name, -0.15)
    assert ms.get_joint_pos(state2, model, name) == pytest.approx(-0.15)
    # 纯函数性
    assert ms.get_joint_pos(state, model, name) == pytest.approx(0.0)


def test_get_joint_range_with_drawer():
    model, _ = build_fake_model(drawer=True)
    lo, hi = ms.get_joint_range(model, "wooden_cabinet_1_middle_level")
    assert (lo, hi) == pytest.approx((-0.16, 0.01))


def test_get_joint_range_rejects_unlimited():
    """free joint 的 range 是 (0,0)，应报错而不是返回无意义的上限。"""
    model, _ = build_fake_model()
    with pytest.raises((ValueError, KeyError)):
        ms.get_joint_range(model, "akita_black_bowl_1")


# ---------------------------------------------------------------------------
# 速度
# ---------------------------------------------------------------------------


def test_clear_object_velocity_only_affects_that_object(scene):
    model, _, state = scene
    layout = ms.StateLayout.from_model(model)
    joint = ms.resolve_free_joint(model, "akita_black_bowl_1")

    dirty = state.copy()
    dirty[layout.qvel_slice] = 1.0

    out = ms.clear_object_velocity(dirty, model, "akita_black_bowl_1")
    qvel = out[layout.qvel_slice]

    assert np.allclose(qvel[joint.dof_adr : joint.dof_adr + 6], 0.0)
    # 其他自由度仍为 1.0
    assert np.allclose(qvel[:9], 1.0)


def test_clear_all_velocities(scene):
    model, _, state = scene
    layout = ms.StateLayout.from_model(model)
    dirty = state.copy()
    dirty[layout.qvel_slice] = 0.7
    out = ms.clear_all_velocities(dirty, layout)
    assert np.allclose(out[layout.qvel_slice], 0.0)


# ---------------------------------------------------------------------------
# 几何推算
# ---------------------------------------------------------------------------


def test_suggest_resting_z_places_bowl_on_plate_top():
    """碗底应落在地板（plate 顶面）之上，误差在 clearance 量级。"""
    model, data = build_fake_model(
        object_heights={"akita_black_bowl_1": 0.05, "plate_1": 0.02},
        object_top_z={"plate_1": 0.42},
    )
    z, target_top = ms.suggest_resting_z(model, data, "akita_black_bowl_1", "plate_1")

    assert target_top == pytest.approx(0.42, abs=1e-6)
    # 中心 z = 顶面 + 半高 + clearance
    assert z == pytest.approx(0.42 + 0.025 + 0.002, abs=1e-6)


def test_suggest_resting_z_respects_object_height():
    """更高的物体应当被放到更高的 z。"""
    tall, tall_data = build_fake_model(
        object_heights={"akita_black_bowl_1": 0.20, "plate_1": 0.02},
        object_top_z={"plate_1": 0.42},
    )
    short, short_data = build_fake_model(
        object_heights={"akita_black_bowl_1": 0.04, "plate_1": 0.02},
        object_top_z={"plate_1": 0.42},
    )
    z_tall, _ = ms.suggest_resting_z(tall, tall_data, "akita_black_bowl_1", "plate_1")
    z_short, _ = ms.suggest_resting_z(short, short_data, "akita_black_bowl_1", "plate_1")
    assert z_tall > z_short


def test_find_body_id_unknown_raises(scene):
    model, _, _ = scene
    with pytest.raises(KeyError, match="找不到 body"):
        ms.find_body_id(model, "nonexistent_body")


# ---------------------------------------------------------------------------
# body 解析歧义（真实 LIBERO 上踩过的坑）
# ---------------------------------------------------------------------------


def test_find_body_id_prefers_main_on_ambiguity():
    """前缀匹配到多个时，必须确定性收敛到 ``<prefix>_main``。

    真实场景：LIBERO 的 flat_stove_1 下面有 _main / _base / _burner 三个 body，
    前缀解析会歧义。没有这条兜底就得给每个任务手工试 body 名。
    """

    class _M:
        nbody = 4
        body_names = ["world", "flat_stove_1_main", "flat_stove_1_base", "flat_stove_1_burner"]

    assert ms.find_body_id(_M(), "flat_stove_1") == 1
    assert ms.find_body_id(_M(), "flat_stove_1_main") == 1


def test_find_body_id_still_errors_without_main():
    """歧义且没有 _main 时，仍必须报错并列出候选，而不是随便选一个。"""

    class _M:
        nbody = 3
        body_names = ["world", "foo_a", "foo_b"]

    with pytest.raises(KeyError, match="匹配到多个"):
        ms.find_body_id(_M(), "foo")
