"""动作反归一化 key 的切换逻辑（不需要 torch / 权重）。

背景：Mini-PAB 一个进程里混跑多个 LIBERO suite，而动作反归一化的 quantile 是
**按 suite 分别统计**的。实测同一 checkpoint：

    libero_goal    dim0 q01/q99 = [-0.879, 0.938]   跨度 1.82
    libero_object  dim0 q01/q99 = [-0.538, 0.846]   跨度 1.38

用错会把平移/旋转幅度放大约 1.3 倍，且**不报错**。官方 eval 每个 suite 单独跑
所以碰不到；混跑就必须显式切换。这里把切换逻辑钉住。
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.policy.base import OpenVLAOFTAdapter  # noqa: E402


class _FakeStats(dict):
    pass


def _make_adapter(norm_stats: dict) -> OpenVLAOFTAdapter:
    """构造一个"已加载"的适配器，但完全不碰真实模型。"""
    a = OpenVLAOFTAdapter(
        openvla_oft_root="/nonexistent",
        checkpoint="fake/ckpt",
        unnorm_key="libero_goal",
    )

    class _M:
        pass

    class _Cfg:
        pass

    m = _M()
    m.norm_stats = norm_stats
    a._model = m          # type: ignore[attr-defined]
    a._cfg = _Cfg()       # type: ignore[attr-defined]
    a._loaded = True      # type: ignore[attr-defined]
    a._resolve_unnorm_key("libero_goal")  # type: ignore[attr-defined]
    return a


def test_resolves_no_noops_suffix():
    a = _make_adapter({"libero_goal_no_noops": {}, "libero_object_no_noops": {}})
    assert a._current_unnorm_key == "libero_goal_no_noops"


def test_switches_between_suites():
    """核心行为：换 suite 必须真的换 key。"""
    a = _make_adapter({"libero_goal_no_noops": {}, "libero_object_no_noops": {}})
    a.set_unnorm_key("libero_object")
    assert a._current_unnorm_key == "libero_object_no_noops"
    a.set_unnorm_key("libero_goal")
    assert a._current_unnorm_key == "libero_goal_no_noops"


def test_idempotent_when_same_suite():
    """同一 suite 重复设置不应重复解析（也不应报错）。"""
    a = _make_adapter({"libero_goal_no_noops": {}})
    a.set_unnorm_key("libero_goal")
    a.set_unnorm_key("libero_goal_no_noops")  # 已解析后的形式也应被识别
    assert a._current_unnorm_key == "libero_goal_no_noops"


def test_exact_key_without_suffix_also_works():
    """有的 checkpoint 直接就是裸 key，不该强行加后缀。"""
    a = _make_adapter({"libero_goal": {}})
    assert a._current_unnorm_key == "libero_goal"


def test_unknown_suite_raises_with_candidates():
    """未知 suite 必须报错并列出可用 key，而不是静默用错的统计量。"""
    a = _make_adapter({"libero_goal_no_noops": {}})
    with pytest.raises(KeyError, match="norm_stats"):
        a.set_unnorm_key("libero_spatial")


def test_before_load_updates_cfg_kwargs():
    """模型还没加载时，切换应写进 cfg_kwargs，加载时生效。"""
    a = OpenVLAOFTAdapter(
        openvla_oft_root="/nonexistent", checkpoint="fake/ckpt", unnorm_key="libero_goal"
    )
    a.set_unnorm_key("libero_object")
    assert a._cfg_kwargs["unnorm_key"] == "libero_object"
