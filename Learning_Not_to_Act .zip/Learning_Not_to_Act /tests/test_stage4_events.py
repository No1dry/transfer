"""Stage 4 预注册事件的单元测试（mentor_review_6 §5）。

事件定义必须**在跑实验之前**就固定下来，所以这些测试在跑 pilot 前写。
覆盖每条预注册判据的正例与反例，避免"跑完再凭视频定义"。
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.stage4_events import compute_stage4_events  # noqa: E402


def row(step, *, sg1=0, sg2=0, overall=0, d_c=1.0, d_orig=1.0, d_rem=1.0,
        moved=0.0, contact_c=False, contact_r=False, joint_path=0.0,
        proc_g=-1.0, raw_g=1.0, joint_norm=0.0):
    """一行 trace。三套参考坐标分开：
    d_c=到 completed **当前**位置, d_orig=到 **A 原位置**,
    d_rem=到 remaining；moved=completed 相对 **rollout 起点** 的位移。
    """
    return {
        "step": step, "sg1": sg1, "sg2": sg2, "overall": overall,
        "d_eef_completed_cur": d_c, "d_eef_completed_A_orig": d_orig,
        "d_eef_completed_start": d_c, "d_eef_remaining": d_rem,
        "completed_cur_xyz_0": moved, "completed_cur_xyz_1": 0.0,
        "completed_cur_xyz_2": 0.0,
        "completed_start_xyz_0": 0.0, "completed_start_xyz_1": 0.0,
        "completed_start_xyz_2": 0.0,
        "completed_A_orig_xyz_0": 0.0, "completed_A_orig_xyz_1": 0.0,
        "completed_A_orig_xyz_2": 0.0,
        "contact_completed": contact_c, "contact_remaining": contact_r,
        "contact_container": False,
        "joint_path": joint_path, "joint_norm_max": joint_norm,
        "processed_gripper": proc_g, "raw_gripper": raw_g,
    }


# ---------------------------------------------------------------------------
# I2：completed = stove button
# ---------------------------------------------------------------------------


def test_i2_reexecution_when_approaching_button_before_pot():
    """★ B 的正确行为是不再碰炉钮；先去够炉钮 = 没跳过已完成子目标。

    §6.1：必须是从阈值**外**进入阈值内才算 approach。
    """
    rows = [row(1, d_c=0.50, d_rem=0.90),          # 起点在 10cm 之外
            row(2, d_c=0.09, d_rem=0.90)]          # 进入 10cm 内 -> 有效 approach
    r = compute_stage4_events(rows, tag="I2", condition="B")
    assert r["events"]["completed_subgoal_reexecution"] is True
    assert r["events"]["first_task_target"] == "completed_current"


def test_i2_correct_skip_when_going_straight_to_pot():
    rows = [row(1, d_c=0.90, d_rem=0.50),
            row(2, d_c=0.90, d_rem=0.09),        # 从外进入 moka 的 10cm
            row(3, sg2=1, overall=1, d_c=0.90, d_rem=0.09)]
    r = compute_stage4_events(rows, tag="I2", condition="B")
    assert r["events"]["correct_skip"] is True
    assert r["events"]["completed_subgoal_reexecution"] is False
    assert r["events"]["first_task_target"] == "remaining"


def test_i2_reexecution_when_button_joint_moves():
    """炉钮出现显著 joint path -> 重新操纵了已完成的子目标。"""
    rows = [row(1, d_c=0.9, d_rem=0.9, joint_path=0.0, sg1=1),
            row(2, d_c=0.9, d_rem=0.9, joint_path=0.12, sg1=1)]
    ev = compute_stage4_events(rows, tag="I2", condition="B")["events"]
    assert ev["completed_subgoal_reexecution"] is True


def test_i2_disturbance_when_turnon_flips_false():
    """turnon 由 True 翻 False = 把已完成的子目标弄坏了。"""
    rows = [row(1, sg1=1, d_c=0.9, d_rem=0.9),
            row(2, sg1=0, d_c=0.9, d_rem=0.9)]
    r = compute_stage4_events(rows, tag="I2", condition="B")
    assert r["events"]["completed_subgoal_disturbed"] is True
    assert r["events"]["completed_subgoal_reexecution"] is True
    assert r["quantities"]["sg1_flips"]["first_true_to_false"] == 2


# ---------------------------------------------------------------------------
# I1：completed = alphabet soup
# ---------------------------------------------------------------------------


def test_i1_reexecution_via_old_position():
    """★ §4.1 的核心场景：模型照训练动作去 soup 的**旧位置**抓空。

    必须看 `d_eef_completed_A_orig`（到 A 原位置的距离），
    且该距离要**从阈值外进入阈值内**才算有效 approach（§6.1）。
    """
    rows = [row(1, d_c=0.60, d_orig=0.50, d_rem=0.90),
            row(2, d_c=0.60, d_orig=0.08, d_rem=0.90)]   # 进入 A 原位置的 10cm
    r = compute_stage4_events(rows, tag="I1", condition="B")
    assert r["events"]["completed_subgoal_reexecution"] is True
    assert r["events"]["first_task_target"] == "completed_A_orig"


def test_step0_inside_threshold_is_not_an_approach():
    """§6.1：step0 本来就在阈值内 -> **不算** approach（旧的绝对阈值会误判）。"""
    rows = [row(1, d_c=0.08, d_orig=0.90, d_rem=0.90),
            row(2, d_c=0.07, d_orig=0.90, d_rem=0.90)]
    r = compute_stage4_events(rows, tag="I1", condition="B")
    q = r["quantities"]["approach_completed_current"]
    assert q["levels"]["10cm"]["inside_at_step0"] is True
    assert q["levels"]["10cm"]["crossing_step"] is None, "起点已在阈值内不算穿越"
    assert r["events"]["first_task_target"] == "no_approach"


def test_simultaneous_crossing_is_ambiguous():
    """§6.1：两个目标同一步首次进入阈值 -> ambiguous，不硬选。"""
    rows = [row(1, d_c=0.50, d_orig=0.90, d_rem=0.50),
            row(2, d_c=0.09, d_orig=0.90, d_rem=0.09)]
    r = compute_stage4_events(rows, tag="I1", condition="B")
    assert r["events"]["first_task_target"] == "ambiguous/simultaneous"


def test_close_near_uses_distance_at_close_time():
    """§6.2：CLOSE_NEAR_M 必须按**合爪当时**的距离判断。"""
    # 第 2 步合爪，当时距 completed 8cm（<10cm）-> close_near_completed
    rows = [row(1, d_c=0.50, d_rem=0.90),
            row(2, d_c=0.08, d_rem=0.90, proc_g=1.0)]
    r = compute_stage4_events(rows, tag="I1", condition="B")
    assert r["quantities"]["close_near_completed"]["any"] is True
    assert r["quantities"]["close_near_completed"]["first_step"] == 2
    assert r["quantities"]["close_near_remaining"]["any"] is False

    # 合爪时距离 30cm -> 不算
    rows2 = [row(1, d_c=0.50, d_rem=0.90),
             row(2, d_c=0.30, d_rem=0.90, proc_g=1.0)]
    r2 = compute_stage4_events(rows2, tag="I1", condition="B")
    assert r2["quantities"]["close_near_completed"]["any"] is False


def test_condition_A_reports_no_reexecution_or_skip():
    """§6.4：A 里 subgoal-1 本来就要执行，不报 reexecution / skip。"""
    rows = [row(1, d_c=0.50), row(2, d_c=0.09), row(3, sg1=1, overall=1, d_c=0.09)]
    ev = compute_stage4_events(rows, tag="I1", condition="A")["events"]
    assert ev["completed_subgoal_reexecution"] is None
    assert ev["correct_skip"] is None
    assert ev["behavior_verdict"] == "A_template_only"


def test_i1_reexecution_when_moving_soup_in_basket():
    rows = [row(1, d_c=0.05, moved=0.12, d_rem=0.9, sg1=1)]
    ev = compute_stage4_events(rows, tag="I1", condition="B")["events"]
    assert ev["completed_subgoal_reexecution"] is True
    assert ev["completed_subgoal_disturbed"] is True


def test_i1_correct_skip():
    rows = [row(1, d_c=0.9, d_orig=0.9, d_rem=0.5),
            row(2, d_c=0.9, d_orig=0.9, d_rem=0.05),
            row(3, sg2=1, overall=1, d_c=0.9, d_orig=0.9, d_rem=0.05)]
    ev = compute_stage4_events(rows, tag="I1", condition="B")["events"]
    assert ev["correct_skip"] is True
    assert ev["completed_subgoal_reexecution"] is False


def test_i1_success_but_not_skip_when_soup_disturbed():
    """整体成功但把 soup 弄出来了 -> 不能算 correct skip。"""
    rows = [row(1, sg1=1, d_c=0.9, d_rem=0.5),
            row(2, sg1=0, d_c=0.9, d_rem=0.05, moved=0.2),
            row(3, sg2=1, overall=1, d_c=0.9, d_rem=0.05)]
    r = compute_stage4_events(rows, tag="I1", condition="B")
    assert r["events"]["completed_subgoal_disturbed"] is True
    assert r["events"]["correct_skip"] is False


# ---------------------------------------------------------------------------
# 连续量必须同时保留（§5 末句）
# ---------------------------------------------------------------------------


def test_continuous_quantities_preserved_alongside_binary_events():
    rows = [row(1, d_c=0.9, d_orig=0.30, d_rem=0.80),
            row(2, d_c=0.4, d_orig=0.05, d_rem=0.70)]
    r = compute_stage4_events(rows, tag="I1", condition="B")
    q = r["quantities"]
    for k in ("approach_completed_current", "approach_completed_A_orig",
              "approach_remaining", "close_near_completed", "close_near_A_orig",
              "close_near_remaining", "first_close_step",
              "completed_moved_from_start_max_m", "joint_path_max"):
        assert k in q, f"缺连续量 {k}"
    assert q["approach_completed_A_orig"]["min"] == pytest.approx(0.05)
    assert q["approach_completed_A_orig"]["step0"] == pytest.approx(0.30)
    assert q["approach_completed_A_orig"]["delta"] == pytest.approx(0.25)
    # 三档敏感度必须在
    assert set(q["approach_completed_A_orig"]["levels"]) == {"5cm", "10cm", "15cm"}
    assert "thresholds" in r


def test_empty_trace_is_unmeasured():
    r = compute_stage4_events([], tag="I1", condition="B")
    assert r["measured"] is False


def test_correct_skip_when_already_inside_at_step0():
    """★ natural intermediate 专用：截取时机器人**本来就在** remaining 的执行距离内。

    此时不会发生"阈值外->内"穿越（§6.1），但行为显然是正确的。
    若不接受这种情形，自然中间状态会被误判成 neither。
    """
    rows = [row(1, d_c=0.90, d_rem=0.06),          # step0 已在 10cm 内
            row(2, d_c=0.90, d_rem=0.03),
            row(3, sg2=1, overall=1, d_c=0.90, d_rem=0.02)]
    r = compute_stage4_events(rows, tag="I2", condition="B")
    q = r["quantities"]["approach_remaining"]
    assert q["levels"]["10cm"]["inside_at_step0"] is True
    assert q["levels"]["10cm"]["crossing_step"] is None
    assert r["events"]["correct_skip"] is True, \
        "已在执行距离内并成功 -> 应算 correct_skip，而不是 neither"


def test_already_inside_but_failed_is_not_correct_skip():
    """已在阈内但最终失败 -> 不算 correct_skip。"""
    rows = [row(1, d_c=0.90, d_rem=0.06), row(2, d_c=0.90, d_rem=0.05)]
    r = compute_stage4_events(rows, tag="I2", condition="B")
    assert r["events"]["correct_skip"] is False
