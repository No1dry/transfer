"""StateBuilder 的单元测试（用 MockArena，需要 MuJoCo / LIBERO）。

重点验证的是**语义正确性**，而不只是"代码没报错"：
  * satisfied 构造出来的状态，必须真的被 simulator predicate 判为完成
  * unsatisfied 构造出来的状态，必须真的被 predicate 判为未完成
  * 两种状态的**机器人关节完全相同**（§65.2 reset artifact 约束）
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmark.arena.mock import MockArena, MockArenaConfig  # noqa: E402
from benchmark.states import mujoco_state as ms  # noqa: E402
from benchmark.states.builder import StateBuilder, verify_robot_joints_unchanged  # noqa: E402
from benchmark.tasks.registry import TaskSpec  # noqa: E402


def make_placement_spec() -> TaskSpec:
    return TaskSpec(
        id="mock_bowl_on_plate",
        display_name="mock bowl on plate",
        suite="libero_goal",
        task_name="put_the_bowl_on_the_plate",
        task_id=8,
        expected_language="Put the bowl on the plate",
        mode="STOP",
        residual_kind="placement",
        construction_method="scene_edit",
        edit={
            "subject": "akita_black_bowl_1",
            "target": "plate_1",
            "placement": "on_target",
            "perturb": {"kind": "translate_xy", "distance_m": 0.12},
        },
    )


def make_joint_spec() -> TaskSpec:
    return TaskSpec(
        id="mock_open_drawer",
        display_name="mock open drawer",
        suite="libero_goal",
        task_name="open_the_middle_drawer_of_the_cabinet",
        task_id=0,
        expected_language="Open the middle layer of the drawer",
        mode="STOP",
        residual_kind="joint",
        construction_method="scene_edit",
        edit={
            "subject": "wooden_cabinet_1",
            "target": None,
            "joint_name": "wooden_cabinet_1_middle_level",
            "satisfied_joint_fraction": 1.0,
            "unsatisfied_joint_fraction": 0.0,
        },
    )


@pytest.fixture()
def placement_arena():
    arena = MockArena(MockArenaConfig())
    arena.reset()
    yield arena
    arena.close()


@pytest.fixture()
def joint_arena():
    arena = MockArena(
        MockArenaConfig(
            task_id="mock_open_drawer",
            task_language="Open the middle layer of the drawer",
            subject="wooden_cabinet_1",
            target="wooden_cabinet_1",
            articulated=True,
            joint_name="wooden_cabinet_1_middle_level",
        )
    )
    arena.reset()
    yield arena
    arena.close()


# ---------------------------------------------------------------------------
# placement
# ---------------------------------------------------------------------------


def test_satisfied_placement_passes_predicate(placement_arena):
    builder = StateBuilder()
    spec = make_placement_spec()

    result = builder.build_state(placement_arena, spec, "satisfied", seed=0)

    assert result.ok, f"构造失败: {result.failure_reason}\nattempts={[a.as_dict() for a in result.attempts]}"
    assert result.satisfied_after_build is True

    # 真正验一遍：把状态装回环境，predicate 必须为 True
    placement_arena.set_state(result.state, settle_steps=0)
    assert placement_arena.goal_satisfied() is True
    assert placement_arena.residual() < placement_arena.cfg.success_radius


def test_satisfied_placement_puts_subject_near_target(placement_arena):
    builder = StateBuilder()
    spec = make_placement_spec()
    result = builder.build_state(placement_arena, spec, "satisfied", seed=0)

    placement_arena.set_state(result.state, settle_steps=0)
    subject = ms.get_object_pos(result.state, placement_arena.model, "akita_black_bowl_1")
    target = ms.get_object_pos(result.state, placement_arena.model, "plate_1")

    assert np.allclose(subject[:2], target[:2], atol=1e-6), "水平方向没有对齐到目标"
    assert subject[2] > target[2], "碗应该落在盘子之上"


def test_unsatisfied_placement_fails_predicate(placement_arena):
    builder = StateBuilder()
    spec = make_placement_spec()

    result = builder.build_state(placement_arena, spec, "unsatisfied", seed=0)

    assert result.ok, f"构造失败: {result.failure_reason}"
    assert result.satisfied_after_build is False

    placement_arena.set_state(result.state, settle_steps=0)
    assert placement_arena.goal_satisfied() is False


def test_unsatisfied_placement_controls_residual_distance(placement_arena):
    """unsatisfied 的关键不变量：把物体放到**以目标为圆心、给定半径**的圆上。

    这里刻意不写"扰动后离目标更远" —— 那是早期实现的错误假设。
    早期版本按 `subject_xy + direction * distance` 扰动，参照系是物体自身，
    于是当物体本来就离目标很近时，朝目标方向的扰动会把它**推近**目标，
    甚至仍满足 predicate。正确的不变量是**到目标的距离**被控制住。
    """
    builder = StateBuilder()
    spec = make_placement_spec()
    distance = 0.12

    for seed in range(8):
        result = builder.build_state(placement_arena, spec, "unsatisfied", seed=seed)
        assert result.ok, f"seed={seed} 构造失败: {result.failure_reason}"
        placement_arena.set_state(result.state, settle_steps=0)
        residual = float(placement_arena.residual())

        assert not placement_arena.goal_satisfied()
        # 允许 settle 造成的偏差，但必须落在同一量级
        assert 0.5 * distance <= residual <= 2.0 * distance, (
            f"seed={seed} 的 residual={residual:.4f} 偏离目标半径 {distance}m 太远"
        )


def test_unsatisfied_placement_can_handle_near_target_start(placement_arena):
    """回归测试：物体一开始就紧贴目标时，扰动仍必须产出 unsatisfied 状态。

    这是早期实现的真实 bug —— 参照系取物体自身时，seed=10 会把物体推向目标，
    扰动 0.12m 后 predicate 依然为 True，"unsatisfied" 静默地变成了 satisfied。
    """
    builder = StateBuilder()
    spec = make_placement_spec()

    for seed in range(20):
        result = builder.build_state(placement_arena, spec, "unsatisfied", seed=seed)
        assert result.ok, f"seed={seed} 构造失败: {result.failure_reason}"
        placement_arena.set_state(result.state, settle_steps=0)
        assert placement_arena.goal_satisfied() is False, f"seed={seed} 竟然满足 predicate"


def test_unsatisfied_is_reproducible_for_same_seed(placement_arena):
    builder = StateBuilder()
    spec = make_placement_spec()

    r1 = builder.build_state(placement_arena, spec, "unsatisfied", seed=3)
    r2 = builder.build_state(placement_arena, spec, "unsatisfied", seed=3)
    r3 = builder.build_state(placement_arena, spec, "unsatisfied", seed=4)

    assert np.allclose(r1.state, r2.state), "同 seed 必须得到同一状态"
    assert not np.allclose(r1.state, r3.state), "不同 seed 应得到不同扰动方向"


def test_conditions_share_robot_pose(placement_arena):
    """§65.2: 不同 condition 必须共享机器人初始位姿，只改任务相关状态。"""
    builder = StateBuilder()
    spec = make_placement_spec()

    sat = builder.build_state(placement_arena, spec, "satisfied", seed=0)
    unsat = builder.build_state(placement_arena, spec, "unsatisfied", seed=0)

    assert sat.ok and unsat.ok
    assert verify_robot_joints_unchanged(sat.state, unsat.state, placement_arena.model)
    # 物体状态则必须不同
    assert not np.allclose(sat.state, unsat.state)


# ---------------------------------------------------------------------------
# joint (articulated)
# ---------------------------------------------------------------------------


def test_satisfied_joint_opens_drawer(joint_arena):
    builder = StateBuilder()
    spec = make_joint_spec()

    result = builder.build_state(joint_arena, spec, "satisfied", seed=0)

    assert result.ok, f"构造失败: {result.failure_reason}\n{[a.as_dict() for a in result.attempts]}"
    joint_arena.set_state(result.state, settle_steps=0)
    assert joint_arena.goal_satisfied() is True

    q = ms.get_joint_pos(result.state, joint_arena.model, "wooden_cabinet_1_middle_level")
    assert q < -0.14, f"抽屉开度 {q} 不够（打开对应负端 -0.16）"


def test_unsatisfied_joint_closes_drawer(joint_arena):
    builder = StateBuilder()
    spec = make_joint_spec()

    result = builder.build_state(joint_arena, spec, "unsatisfied", seed=0)

    assert result.ok, f"构造失败: {result.failure_reason}"
    joint_arena.set_state(result.state, settle_steps=0)
    assert joint_arena.goal_satisfied() is False

    q = ms.get_joint_pos(result.state, joint_arena.model, "wooden_cabinet_1_middle_level")
    assert q > -0.05, f"抽屉应处于非打开端，实际 qpos={q}"


# ---------------------------------------------------------------------------
# 防御性检查
# ---------------------------------------------------------------------------


def test_partial_condition_is_explicitly_unsupported(placement_arena):
    """Fast 版本不该悄悄支持 partial —— 必须明确报错。"""
    builder = StateBuilder()
    spec = make_placement_spec()
    with pytest.raises(NotImplementedError, match="M1-W2"):
        builder.build_state(placement_arena, spec, "partial", seed=0)


def test_unknown_condition_raises(placement_arena):
    builder = StateBuilder()
    spec = make_placement_spec()
    with pytest.raises(ValueError, match="未知 condition"):
        builder.build_state(placement_arena, spec, "half_done", seed=0)


def test_robot_joint_guard_detects_unexpected_layout():
    """如果 model 的前 9 个关节不是 robot0_*，防守性检查必须报错。"""

    class _WeirdModel:
        # 必须走完整的关节接口：iter_joints 现在兼容 mujoco 2.x / 3.x，
        # 但底层仍需要 njnt / jnt_type / jnt_qposadr / jnt_dofadr
        njnt = 9
        jnt_type = [3] * 9
        jnt_qposadr = list(range(9))
        jnt_dofadr = list(range(9))
        joint_names = ["some_other_joint"] + [f"robot0_joint{i}" for i in range(1, 9)]

    class _WeirdArena:
        model = _WeirdModel()

    with pytest.raises(RuntimeError, match="假设失效"):
        StateBuilder._assert_robot_untouched_policy(_WeirdArena())


def test_verify_robot_joints_unchanged_detects_difference(placement_arena):
    model = placement_arena.model
    s1 = placement_arena.get_state()
    layout = ms.StateLayout.from_model(model)
    qpos = ms.get_qpos(s1, layout).copy()
    qpos[0] += 0.5  # 改动机器人第一个关节
    s2 = ms.with_qpos(s1, layout, qpos)

    assert not verify_robot_joints_unchanged(s1, s2, model)


# ---------------------------------------------------------------------------
# unsatisfied 的默认语义：官方初始状态（回归测试）
# ---------------------------------------------------------------------------


def test_unsatisfied_defaults_to_official_init_state(placement_arena):
    """默认情况下 unsatisfied 必须**原样使用官方初始状态**，不做扰动。

    这条是有意的行为约定，不是实现细节：自己把物体摆到"距目标 12cm 的圆"上
    会摆到柜子旁 / 桌边等难夹位置，让失败反映"姿势被挡"而非模型能力。
    实测官方 eval 在 put_the_bowl_on_the_plate 上 4/4，而扰动版 20 seed 只成 3。

    这里断言：不启用扰动时，构造出的状态与 reset 后直接取的状态一致。
    """
    builder = StateBuilder(settle_steps=5)
    spec = make_placement_spec()

    for seed in (0, 1, 2):
        result = builder.build_state(placement_arena, spec, "unsatisfied", seed=seed)
        assert result.ok, f"seed={seed} 构造失败: {result.failure_reason}"

        # 复现官方初始状态作为对照
        placement_arena.reset(official_init_index=seed)
        expected = placement_arena.get_state()

        assert np.allclose(result.state, expected), (
            f"seed={seed}: unsatisfied 状态与官方初始状态不一致 —— "
            "说明默认路径被改成了扰动"
        )
        assert result.attempts[-1].method == "official_init_state"


def test_perturbation_still_available_when_enabled(placement_arena):
    """显式启用扰动时，仍应走扰动路径（保留给难度梯度用）。"""
    builder = StateBuilder(settle_steps=5, perturb_distance_m=0.12)
    spec = make_placement_spec()

    result = builder.build_state(placement_arena, spec, "unsatisfied", seed=0)
    assert result.ok
    assert result.attempts[-1].method == "place_on_circle_around_target", (
        "显式给了 perturb_distance_m 却没走扰动路径"
    )
